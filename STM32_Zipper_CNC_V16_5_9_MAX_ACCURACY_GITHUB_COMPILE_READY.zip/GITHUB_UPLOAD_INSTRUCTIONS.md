# GitHub Upload / Compile

This is the GitHub Actions-ready package.

Recommended repository layout: upload/extract the contents of this ZIP into the repository root. The included `.github/workflows/compile-stm32.yml` will compile the firmware automatically on push to `main`/`master` or manually with **Run workflow**.

Build target: `STMicroelectronics:stm32:GenF1:pn=BLUEPILL_F103C8`.

The workflow produces and uploads `STM32_Zipper_CNC_V16_5_0_Production.bin` as a GitHub Actions artifact. The artifact filename is retained for compatibility with the existing workflow; the source itself is the V16.5.9 PA0/PA8 Maximum Accuracy firmware.
