# V16.5.9 Settings / Auto-Save Update

## Implemented
- Settings entry changed from 8-second MODE hold to **7 seconds**.
- Settings entry remains restricted to full machine standstill.
- Removed the confusing 4–8 second manual "AUTO-SAVE ACTIVE" MODE branch.
- Operator setting changes now request a **safe deferred automatic save**.
- Actual Flash/EEPROM persistence occurs only after the machine is safely stopped and motion is inactive.
- ZIP-size changes no longer call `saveToEEPROM()` directly from the button event path.
- STEP/pulse tuning requests safe automatic persistence instead of direct persistence in the button path.
- Settings exit is now one menu item: **EXIT**.
- EXIT opens a choice screen with **SAVE & EXIT** or **EXIT WITHOUT SAVE**.
- Automatic saving may complete before EXIT if the safe-save debounce expires while the machine remains stopped.
- If the machine starts running while Settings are open, the UI exits and pending unsaved staged changes are discarded; no Flash write is attempted during motion.
- Boot LCD branding now shows `NIPON ZIPPER IND` / `RAJESH SHAH` for approximately 2 seconds, then returns to the normal status UI without blocking the motion hardware path.

## Validation
- Existing production host regression tests: PASS.
- New Settings navigation/auto-save source verification: PASS.
- Total host test suites: **27/27 PASS**.
- No STM32 production binary is claimed because the editing runtime does not contain the Arduino STM32 toolchain (`arduino-cli` / ARM GCC).
