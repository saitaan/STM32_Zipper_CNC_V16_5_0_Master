# V16.5.9 Maximum Accuracy / Production Safety

## Wiring
No wiring change is required.
- PA0 = Proximity / TIM2_CH1
- PA8 = STEP / TIM1_CH1
- PA2 = DIR
- PA3 = optional Tape Guard

## Timing architecture
- TIM2 runs as a dedicated free-running 1 MHz PA0 capture timer.
- TIM2 CH1 DMA continuously mirrors capture values into the circular capture buffer.
- TIM1 CH1 is the dedicated hardware STEP generator on PA8.
- TIM4/DWT provide the high-resolution software timing reference.
- PA0 hardware capture and DWT timing are cross-checked on every trigger.

## Safety policy
- CC1 overcapture -> trigger-integrity fault; no make-up STEP.
- Capture-vs-DWT mismatch > 12 us -> trigger-integrity fault; no make-up STEP.
- Ambiguous sub-blanking edge -> trigger-integrity fault; it is NOT silently discarded.
- Queue overflow -> fault; no overwrite.
- Flash save is never used to replay a late STEP during active motion.

## Verification
29/29 host test suites PASS.
The 26-scenario production regression remains 100% PASS.

## Target compilation
The included GitHub Actions workflow is the intended STM32F103C8T6 build/verification path. This environment did not contain the ARM STM32 toolchain, so no target .bin is claimed here.
