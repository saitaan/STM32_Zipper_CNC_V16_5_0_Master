# V16.5.9 PA8 STEP Wiring Update

The STEP output has been migrated from PA1/TIM2_CH2 to PA8/TIM1_CH1. Only the STEP wire changes.

| Function | Blue Pill pin | Driver connection | Status |
|---|---|---|---|
| Proximity | PA0 | Proximity input | UNCHANGED |
| STEP/PUL | **PA8** | Driver STEP/PUL input | **CHANGED: PA1 -> PA8** |
| DIR | PA2 | Driver DIR input | UNCHANGED |
| Tape Guard | PA3 | Future guard sensor | UNCHANGED |

## Important
- Remove the old PA1-to-STEP wire. Do not leave PA1 and PA8 connected together.
- Connect only Blue Pill **PA8** to the driver's STEP/PUL signal through the existing level-shifter channel used for STEP.
- Keep PA2/DIR exactly as before.
- Keep PA0/proximity exactly as before.
- Power/GND wiring remains unchanged.

## Firmware architecture
- TIM2/PA0 = dedicated proximity Input Capture + DMA.
- TIM1/PA8 = dedicated hardware STEP generator.
- PA2 = GPIO DIR.

This separation removes the previous timer resource conflict between PA0 capture and variable-period STEP generation.

## Maximum-accuracy firmware note
No additional wiring is required for the V16.5.9 Maximum Accuracy upgrade. PA0 remains Proximity, PA8 remains STEP, PA2 remains DIR, and PA3 remains optional Tape Guard.
