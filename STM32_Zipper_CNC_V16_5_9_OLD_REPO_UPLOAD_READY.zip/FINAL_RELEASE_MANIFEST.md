# Final Release Manifest

Firmware: STM32 Zipper CNC V16.5.9 Maximum Accuracy
Hardware: STM32F103C8T6 Blue Pill
Primary trigger: PA0 / TIM2_CH1
STEP: PA8 / TIM1_CH1
DIR: PA2
Tape Guard: PA3
Host regression: 29/29 GREEN

This package contains the source, tests, release notes, wiring/architecture documentation, and commissioning guidance.
