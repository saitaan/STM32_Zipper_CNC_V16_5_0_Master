# Firmware Architecture — Maximum Accuracy Production Candidate

## Primary motion path
1. PA0 receives the real machine proximity trigger.
2. TIM2_CH1 captures the edge in hardware and DMA mirrors CCR1 timestamps.
3. The firmware cross-checks the hardware capture against the independent timing reference.
4. The measured machine cycle is used for phase/fractional scheduling.
5. TIM1_CH1 generates the STEP waveform directly on PA8.
6. PA2 supplies DIR.

## Safety/integrity policy
- One accepted physical trigger maps to one corresponding STEP burst.
- No guessed or artificial make-up STEP is generated for an uncertain trigger.
- Capture overrun, DMA discontinuity, or timing inconsistency is treated as an integrity fault.
- Auxiliary sensors do not own the PA0->PA8 timing path.
- Flash/EEPROM persistence is deferred away from active motion.

## Timing features
- Hardware input capture + DMA audit.
- Dedicated TIM1 hardware STEP engine.
- Fractional/fixed-point scheduling.
- Cycle-to-cycle phase tracking.
- Pre-armed startup path.
- Hardware pulse-width generation.
- Timer preload/atomic update strategy.
- Trigger/STEP counters and diagnostics.
