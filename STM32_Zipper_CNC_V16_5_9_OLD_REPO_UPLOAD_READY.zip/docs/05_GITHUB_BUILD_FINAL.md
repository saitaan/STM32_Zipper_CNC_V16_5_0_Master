# GitHub Build

Target: STM32F103C8T6 Blue Pill.

FQBN:
`STMicroelectronics:stm32:GenF1:pn=BLUEPILL_F103C8`

Core used by the supplied workflow: STM32 Arduino core 2.11.0.

The GitHub workflow installs the STM32 core, locates the `.ino`, compiles it, validates the ARM vector table, and uploads the resulting `.bin` as an artifact.

## Important
A source ZIP is not a substitute for target hardware validation. The final `.bin` must be tested on the real Blue Pill and the PA0/PA8 relationship should be verified with a logic analyzer or oscilloscope at instant/max machine RPM.
