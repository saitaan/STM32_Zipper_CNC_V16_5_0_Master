# Boot / UI Final

Boot branding:

`NIPON ZIPPER IND`
`RAJESH SHAH`

Then normal status:

`PROX->STEP READY`
`SERVO SYNC LIVE`

The firmware does not command a servo acceleration/deceleration ramp. The servo remains the machine master; STM32 follows the actual proximity trigger.
