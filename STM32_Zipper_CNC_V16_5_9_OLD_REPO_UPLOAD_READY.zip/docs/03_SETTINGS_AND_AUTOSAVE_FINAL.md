# Settings / Auto-Save Final Behavior

- Settings entry: **7-second MODE hold**, machine stopped/idle only.
- Running machine: Settings are locked.
- Automatic save is mandatory but deferred to a safe idle/standstill point.
- No Flash/EEPROM write is allowed to block the active motion timing path.
- If power is removed after the setting has been safely committed, the latest value is retained.
- ZIP size values remain **#5 / #8 / #10**.
- The old 4–8 second manual “AUTO-SAVE ACTIVE” button mode is removed from the motion/UI path.
- Exit supports save/exit semantics while preserving safe deferred persistence.
