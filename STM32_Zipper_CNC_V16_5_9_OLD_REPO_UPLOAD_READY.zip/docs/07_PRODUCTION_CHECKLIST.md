# Production Commissioning Checklist

1. Disconnect PA1 from the STEP driver input.
2. Connect **PA8 -> STEP/PUL**.
3. Keep **PA2 -> DIR** unchanged.
4. Keep **PA0 -> Proximity** unchanged.
5. Keep PA3 reserved for the optional Tape Guard.
6. Flash the GitHub-built binary.
7. With the machine stopped, confirm boot and settings operation.
8. First run at low speed.
9. Observe PA0 and PA8 simultaneously with a logic analyzer/oscilloscope.
10. Test startup at instant RPM.
11. Test sustained high RPM.
12. Confirm no missed or extra STEP bursts before production use.
