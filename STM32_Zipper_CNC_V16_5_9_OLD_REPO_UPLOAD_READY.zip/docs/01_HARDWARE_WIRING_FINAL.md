# STM32 Zipper CNC V16.5.9 — Final Wiring

## MCU
STM32F103C8T6 Blue Pill, 72 MHz.

| Function | Blue Pill pin | Timer/peripheral | Connection |
|---|---|---|---|
| Proximity trigger | **PA0** | TIM2_CH1 | Proximity sensor output |
| STEP/PUL | **PA8** | TIM1_CH1 | STEP/PUL input of stepper driver |
| DIR | **PA2** | GPIO | DIR input of stepper driver |
| Tape Guard | **PA3** | GPIO | Optional future guard sensor |
| Machine relay request | **PB1** | GPIO | Existing relay interface, if fitted |

### Critical wiring rule
PA1 is **no longer the STEP output**. Do not connect the driver STEP input to PA1.

Final motion path:
`Proximity -> PA0/TIM2 capture -> motion scheduler -> TIM1/PA8 hardware STEP -> driver`

DIR remains on PA2. Tape Guard remains on PA3.
