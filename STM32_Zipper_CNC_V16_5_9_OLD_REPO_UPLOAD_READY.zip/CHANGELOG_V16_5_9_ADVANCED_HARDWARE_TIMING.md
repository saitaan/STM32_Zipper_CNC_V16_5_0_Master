# V16.5.9 Advanced Hardware Timing Update

## Motion/timing hardening
- PA0 EXTI edge is timestamped at the earliest possible ISR instructions using DWT + the independent TIM4 1 MHz free-running timebase.
- EXTI0 is raised to application priority 0; TIM1 STEP update is priority 1; TIM3 safety monitor remains priority 2.
- TIM2 CH1 input-capture remains enabled as a silicon-level capture audit and overcapture detector.
- TIM2 CC1 overcapture is now a hard trigger-integrity fault. Firmware does not guess, duplicate, or synthesize a make-up STEP for an ambiguous edge.
- Invalid pulse timing is now a trigger-integrity fault instead of silently dropping the physical trigger.
- A physical trigger arriving while a persistence transaction owns the save lock is treated as unsafe-to-replay and faults rather than being generated late.
- Existing hardware-timed TIM1 CH1 STEP generation, ARPE/OC preload, Q16 fractional period handling, burst FIFO, startup first-edge fallback, and pre-armed PA0 path are retained.

## Important hardware architecture note
The production pin/timer architecture is now split: TIM2/PA0 is dedicated to free-running Input Capture + DMA, while TIM1/PA8 is dedicated to variable-ARR hardware STEP generation. TIM4/DWT remains the authoritative continuous interval timestamp path. This removes the timer resource conflict instead of working around it.

## Verification
- All 28 host-side regression suites pass after the PA8/TIM1 migration.
- Advanced hardware timing policy regression: PASS.
- Target MCU compilation was not performed because an ARM/STM32 toolchain is not installed in this environment.
