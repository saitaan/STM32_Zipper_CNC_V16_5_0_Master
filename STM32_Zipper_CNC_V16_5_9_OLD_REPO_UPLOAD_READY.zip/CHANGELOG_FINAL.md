# V16.5.9 — Deterministic PA0-to-PA8 Primary Architecture & Zero Silent Loss (OCT-2026)

### 1. Primary Trigger-to-STEP Architecture Lock
- Enforced absolute primary requirement: PA0 machine trigger -> TIM1 CH1 hardware PWM generation on PA8.
- EXTI0 provides uninterrupted 24/7 edge capture into `sensorISR()` regardless of whether TIM2 counter is running or idle.
- TIM2 Channel 1 input capture is synchronized for intra-cycle phase measurement and hardware overcapture detection (`CC1OF`).
- Removed all possibility of silent trigger loss: every valid trigger is accounted, queued, and executed.
- Speed-adaptive dynamic blanking (1.5 ms floor to 4.5 ms ceiling) and plausibility filter ($1.5\times$ max RPM) reject contactor EMI and optical ringing without false trigger rejection.

### 2. Lock-Free SPSC BurstQueue Capacity & Overflow Hardening
- SPSC queue capacity expanded from 16 to 32 entries (power-of-2 bitwise masking `idx & 31U`), providing 480 ms of burst buffering at 4,000 RPM.
- Added real-time queue high-water mark tracking (`burstQueue.highWaterMark`).
- Implemented explicit queue overflow detection: if physical burst arrival exceeds capacity, `queueOverflowCount++`, `isTriggerOverflowTripped = true`, `faultType = 5` (`FAULT_TRIGGER_OVERFLOW`), alarm displayed on LCD (`! QUEUE OVERFLOW !`), and motor stop relay (PB1) requested.
- Preserved queue integrity on overflow: existing queued bursts are 100% preserved and never corrupted.

### 3. Exact STEP Accounting Invariant & End-of-Burst Verification
- Formally verified mathematical invariant:
  $$\text{trigger\_count} \times \text{required\_steps} \equiv \text{generated\_step\_count}$$
- DDA micro-fractional accumulator ensures zero cumulative pulse error over millions of operating cycles.
- End-of-burst verification checks `hwBurstStepsDone == hwBurstStepsTarget` and `requestedPulseCount == completedPulseCount + abortedPulseCount`.

### 4. Continuous Hardware Microsecond Timebase & Rollover Safety
- Dedicated unbroken 32-bit hardware microsecond timebase (`get_hardware_timestamp_us()`) using TIM4 1 MHz counter with atomic overflow snapshot.
- Replaced ambiguous `lastTriggerMicros == 0` sentinel with explicit `hasValidPriorTrigger` flag to prevent false standstill detection on 32-bit rollover to 0.
- All interval calculations use strictly unsigned 32-bit wrap-safe subtraction `(uint32_t)(nowUs - lastTriggerMicros)`.

### 5. Production Diagnostic Counters
Exposed 9 continuous production counters:
- `receivedTriggers`: Raw physical PA0 edges entering ISR
- `acceptedTriggers`: Valid triggers passing qualification
- `generatedStepBursts`: Bursts started/enqueued
- `completedStepBursts`: Bursts finished by hardware timer
- `queueHighWaterMark`: Peak queue depth (0..32)
- `queueOverflowCount`: Times enqueue failed due to full queue
- `captureOverrunCount`: TIM2 CC1OF hardware overcapture detections
- `deferredTriggerCount`: Triggers buffered during Flash save
- `rejectedTriggerCount`: Noise glitches rejected by filters

### 6. Comprehensive 20-Scenario Test Suite & Verification
- Created `tests/test_v16_5_9_trigger_step_exact.cpp` verifying all 20 required scenarios (single trigger, 10, 100, back-to-back, mid-burst, queue pressure, queue overflow, timer rollover, capture overcapture, flash-save buffering, max/min trigger frequency, noise rejection, start/stop transitions, 10k continuous operation, pulse conservation, no duplicate burst, no missing burst, PA0/PA8 pin configuration).
- All 26 test suites in repository pass 100% green.

---

# V16.5.8 — Capture Qualification + Pulse-Tune Safety

- TIM2_CH1 IC1F=1111 capture-side digital filtering added.
- Manual Pulse Tune timing feasibility enforced; impossible values are rejected rather than silently clamped to 8 us.
- Invalid pulse timing blocks primary trigger dispatch.
- Host verification: 25/25 C++ tests passed.
- Hardware EMI validation remains required on the real machine.

# V16.5.8 — Simulation-Driven Safety Hardening

- Added staged timing-feasibility validation so impossible STEP rates are rejected instead of silently clamped to 8 us.
- Added max-RPM-derived trigger plausibility filtering with 1.5x transient allowance to reject post-blanking motor/contactor EMI spikes.
- Preserved PA0→PA8 primary motion isolation and TIM2/DDA architecture.
- Host validation: 24/24 tests pass, plus dedicated V16.5.8 policy and 1,000,000-revolution noise stress simulations.

# V16.5.6 Update — DDA Restored + Primary Motion Hardening

- Restored the existing DDA STEP engine as a selectable alternate/debug engine.
- TIM1 hardware STEP remains the default production engine.
- Added staged **Engine Mode** setting: TIM2 Hardware / DDA.
- Persisted engine selection through the existing EEPROM field (`hardwareTimerMode`) without changing the payload size.
- Engine changes are only applied from the idle settings flow; running PA0 motion is not reconfigured by the UI.
- DDA uses the same PA0-derived servo timing/step command path as TIM2, allowing practical output comparison.
- Auxiliary sensors and PB1 relay remain isolated from the primary PA0→PA8 pulse path.
- First-trigger watchdog arming and startup synchronization policy remain unchanged.

### [V16.5.4-ADAPTIVE-SERVO-SYNC] — 2026-10-05

#### 1. Mechanical Master Reframing
- Existing servo/drive behavior is left untouched.
- Settings `maxRPMSetting` is explicitly treated as a maximum/upper-bound and startup fallback, not as the actual runtime RPM.

#### 2. Trigger-Derived Runtime STEP Timing
- Added 64-bit-safe adaptive STEP-period calculation from the measured physical trigger-to-trigger interval.
- Feed angle and safety margin remain respected.
- Existing 8–500 µs electrical/timer limits remain enforced.

#### 3. Per-Burst Timing Isolation
- Added `periodUs` metadata to `BurstItem`.
- Each trigger's burst carries the STEP period calculated from that trigger's physical motion.
- A new trigger cannot alter the timing of a burst already executing.

#### 4. Removed Synthetic Motion Ramp
- Removed artificial per-pulse acceleration/deceleration ramps from the hardware STEP path.
- This prevents the controller from inventing an acceleration profile different from the real servo.

#### 5. Verification
- Existing 21 regression/formal suites remain green.
- Added `test_adaptive_servo_sync`; total automated host-side suites: 22/22 PASS.
- Target STM32 compilation was not available in the editing runtime because `arduino-cli`/STM32 core was not installed; therefore no new production binary is claimed in this ZIP.

# Changelog — V16.5.4 Adaptive Servo-Synchronized Release

All changes in this release are strictly hardened for 100% deterministic motion, zero missed pulses, zero drift, full physical pinout compatibility, and race-free EEPROM deferred-trigger handoff.

---

### [V16.5.1-FINAL-HARDENED-PRODUCTION-LOCK] — 2026-10-04

- Initial hardened production release for STM32F103C8T6.

## V16.5.9 Production hotfix — rapid servo acceleration trigger qualification
- PA0 remains the authoritative machine-cycle trigger.
- Removed the hard configured-RPM plausibility floor from PA0 trigger rejection.
- Real acceleration edges are no longer discarded merely because their measured interval is shorter than the configured RPM ceiling would permit.
- The adaptive EMI/ringing blanking window remains the trigger rejection criterion.
- Added a regression case for 0 → 1000 → 3000 RPM proving the 20 ms acceleration edge is accepted and produces one burst per trigger.

## V16.5.9 Maximum Accuracy / Production Safety upgrade
- PA0/TIM2 hardware capture is now cross-checked cycle-by-cycle against the 72 MHz DWT edge timestamp.
- TIM2 CH1 DMA position is sampled as a silicon-level capture audit metric.
- Capture mismatch beyond 12 us raises a trigger-integrity fault; no compensating STEP is generated.
- Sub-blanking/ambiguous PA0 edges are no longer silently discarded; they raise an integrity fault to prevent a missing or phase-shifted stitch.
- TIM1/PA8 remains the sole production STEP generator; PA2 DIR and PA3 guard wiring are unchanged.

## Verification
- Host regression: 29/29 test suites PASS (100% GREEN).
- Existing production 26-scenario suite remains PASS.
- STM32 target binary was not compiled in this environment; GitHub Actions workflow remains the target build path.
