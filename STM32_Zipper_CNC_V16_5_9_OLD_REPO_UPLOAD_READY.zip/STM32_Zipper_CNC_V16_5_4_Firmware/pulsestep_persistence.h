#ifndef PULSESTEP_PERSISTENCE_H
#define PULSESTEP_PERSISTENCE_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

// =========================================================================
// PRODUCTION-SAFE PULSESTEP PERSISTENCE & FLASH WEAR PROTECTION ENGINE
// Architecture:
// 1. Immediate RAM tuning with zero Flash wear during button adjustments.
// 2. Dynamic dirty tracking: dirty = (RAM != Stored). Reverting clears dirty.
// 3. Strict Write Suppression: identical data write attempts skipped (0 writes).
// 4. Idle-Only Persistence: Flash operations blocked during any motion/burst.
// 5. Dual-Slot Transactional Storage with CRC32 & Monotonic Sequence Counter.
// 6. Diagnostic flashWriteCount tracking actual persistence operations.
// =========================================================================

#define EEPROM_MAGIC_V16_5_1 0x5A431651UL

// PulseStep Range Boundaries (in 1,000,000 units per step)
#define PULSE_STEP_MIN_FIXED  1000000ULL     // Minimum 1.00 step
#define PULSE_STEP_MAX_FIXED  5000000000ULL  // Maximum 5000.00 steps

// CRC-32 (IEEE 802.3 bitwise standard polynomial 0xEDB88320)
inline uint32_t calculateCRC32(const uint8_t *data, size_t length) {
    uint32_t crc = 0xFFFFFFFFUL;
    for (size_t i = 0; i < length; i++) {
        crc ^= data[i];
        for (int b = 0; b < 8; b++) {
            if (crc & 1) {
                crc = (crc >> 1) ^ 0xEDB88320UL;
            } else {
                crc >>= 1;
            }
        }
    }
    return ~crc;
}

// Persistent Machine Configuration Payload
struct MachineConfigPayload {
    uint64_t p5_fixed;          // Size #5 (2.50mm) 64-bit fixed point
    uint64_t p8_fixed;          // Size #8 (3.00mm) 64-bit fixed point
    uint64_t p10_fixed;         // Size #10 (4.00mm) 64-bit fixed point
    int32_t  driverResolution;  // Stepper driver microstepping resolution
    float    rollerDia;          // Physical feed roller diameter in mm
    int32_t  maxRPMSetting;      // Maximum machine operating RPM
    int32_t  feedAngleDeg;       // Cam mechanical feed sector angle (degrees)
    int32_t  safetyMarginPercent;// Feed timing safety margin percentage
    int32_t  currentSize;        // Active size: 1 (#5), 2 (#8), 3 (#10)
    uint32_t sensorGuardActive;  // 0: BYPASS [OFF], 1: ACTIVE [ON]
    uint32_t hardwareTimerMode;  // 0: AUTONOMOUS HW TIMER, 1: DDA FALLBACK
    uint32_t motorDirection;     // 0: NORMAL [FWD], 1: REVERSE [REV]
};

// Transactional Storage Record (Dual-slot ping-pong layout)
struct MachineConfigRecord {
    uint32_t magic;              // 0x5A431651UL
    uint32_t seq;                // Monotonic transaction sequence counter
    uint32_t crc32;              // CRC-32 checksum of payload
    uint32_t reserved;           // 64-bit alignment padding
    MachineConfigPayload payload;// Actual calibration settings
};

// Persistence Manager Class
class PulseStepPersistenceManager {
public:
    // RAM Values (Immediately used by stepping engine)
    uint64_t ram_p5;
    uint64_t ram_p8;
    uint64_t ram_p10;
    int32_t  ram_driverRes;
    float    ram_rollerDia;
    int32_t  ram_maxRPM;
    int32_t  ram_feedAngle;
    int32_t  ram_safetyMargin;
    int32_t  ram_currentSize;
    uint32_t ram_sensorGuard;
    uint32_t ram_hwTimerMode;
    uint32_t ram_motorDir;

    // Stored/Persisted Values (Reflects verified Flash ROM state)
    uint64_t stored_p5;
    uint64_t stored_p8;
    uint64_t stored_p10;
    int32_t  stored_driverRes;
    float    stored_rollerDia;
    int32_t  stored_maxRPM;
    int32_t  stored_feedAngle;
    int32_t  stored_safetyMargin;
    int32_t  stored_currentSize;
    uint32_t stored_sensorGuard;
    uint32_t stored_hwTimerMode;
    uint32_t stored_motorDir;

    // Transaction & Diagnostic Counters
    uint32_t lastSeq;
    uint32_t activeSlot;         // 0 or 1
    uint32_t flashWriteCount;    // Strictly increments on real Flash write

    PulseStepPersistenceManager() :
        ram_p5(113176848ULL), ram_p8(135812218ULL), ram_p10(181082957ULL),
        ram_driverRes(6400), ram_rollerDia(45.0f), ram_maxRPM(3000),
        ram_feedAngle(160), ram_safetyMargin(10), ram_currentSize(1),
        ram_sensorGuard(0), ram_hwTimerMode(0), ram_motorDir(0),
        stored_p5(113176848ULL), stored_p8(135812218ULL), stored_p10(181082957ULL),
        stored_driverRes(6400), stored_rollerDia(45.0f), stored_maxRPM(3000),
        stored_feedAngle(160), stored_safetyMargin(10), stored_currentSize(1),
        stored_sensorGuard(0), stored_hwTimerMode(0), stored_motorDir(0),
        lastSeq(0), activeSlot(0), flashWriteCount(0) {}

    // Factory Defaults (Safe baseline)
    void resetToFactoryDefaults() {
        ram_p5           = 113176848ULL;
        ram_p8           = 135812218ULL;
        ram_p10          = 181082957ULL;
        ram_driverRes    = 6400;
        ram_rollerDia    = 45.0f;
        ram_maxRPM       = 3000;
        ram_feedAngle    = 160;
        ram_safetyMargin = 10;
        ram_currentSize  = 1;
        ram_sensorGuard  = 0;
        ram_hwTimerMode  = 0;
        ram_motorDir     = 0;
    }

    // Synchronize stored baseline with RAM (Called after load or successful save)
    void syncStoredWithRam() {
        stored_p5           = ram_p5;
        stored_p8           = ram_p8;
        stored_p10          = ram_p10;
        stored_driverRes    = ram_driverRes;
        stored_rollerDia    = ram_rollerDia;
        stored_maxRPM       = ram_maxRPM;
        stored_feedAngle    = ram_feedAngle;
        stored_safetyMargin = ram_safetyMargin;
        stored_currentSize  = ram_currentSize;
        stored_sensorGuard  = ram_sensorGuard;
        stored_hwTimerMode  = ram_hwTimerMode;
        stored_motorDir     = ram_motorDir;
    }

    // Dynamic Dirty Check for PulseStep of a specific size
    inline bool isPulseStepDirty(int size) const {
        if (size == 1) return (ram_p5 != stored_p5);
        if (size == 2) return (ram_p8 != stored_p8);
        if (size == 3) return (ram_p10 != stored_p10);
        return false;
    }

    // Dynamic Dirty Check for entire machine configuration
    inline bool isAnyDirty() const {
        return (ram_p5 != stored_p5) ||
               (ram_p8 != stored_p8) ||
               (ram_p10 != stored_p10) ||
               (ram_driverRes != stored_driverRes) ||
               (ram_rollerDia != stored_rollerDia) ||
               (ram_maxRPM != stored_maxRPM) ||
               (ram_feedAngle != stored_feedAngle) ||
               (ram_safetyMargin != stored_safetyMargin) ||
               (ram_currentSize != stored_currentSize) ||
               (ram_sensorGuard != stored_sensorGuard) ||
               (ram_hwTimerMode != stored_hwTimerMode) ||
               (ram_motorDir != stored_motorDir);
    }

    // Complete serialized payload comparison against stored ROM baseline (Prompt 8Writing Section 6)
    inline bool isPayloadDirty(const MachineConfigPayload &candidate) const {
        MachineConfigPayload currentStored;
        currentStored.p5_fixed            = stored_p5;
        currentStored.p8_fixed            = stored_p8;
        currentStored.p10_fixed           = stored_p10;
        currentStored.driverResolution    = stored_driverRes;
        currentStored.rollerDia           = stored_rollerDia;
        currentStored.maxRPMSetting       = stored_maxRPM;
        currentStored.feedAngleDeg        = stored_feedAngle;
        currentStored.safetyMarginPercent = stored_safetyMargin;
        currentStored.currentSize         = stored_currentSize;
        currentStored.sensorGuardActive   = stored_sensorGuard;
        currentStored.hardwareTimerMode   = stored_hwTimerMode;
        currentStored.motorDirection      = stored_motorDir;
        return (memcmp(&candidate, &currentStored, sizeof(MachineConfigPayload)) != 0);
    }

    // Authoritative Safe-Save Precondition Check
    inline bool isMachineSafelyIdle(uint32_t currentRPM,
                                   int stepsRemaining,
                                   bool hwBurstActive,
                                   bool queueEmpty,
                                   int movementState,
                                   bool isSensorFault,
                                   bool isSyncLost) const {
        return (currentRPM == 0UL) &&
               (stepsRemaining == 0) &&
               (!hwBurstActive) &&
               (queueEmpty) &&
               (movementState == 0 /* STATE_IDLE */ || movementState == 3 /* STATE_COMPLETE */) &&
               (!isSensorFault) &&
               (!isSyncLost);
    }

    // Validate configuration payload sanity
    static bool validatePayload(const MachineConfigPayload &p) {
        if (p.p5_fixed < PULSE_STEP_MIN_FIXED || p.p5_fixed > PULSE_STEP_MAX_FIXED) return false;
        if (p.p8_fixed < PULSE_STEP_MIN_FIXED || p.p8_fixed > PULSE_STEP_MAX_FIXED) return false;
        if (p.p10_fixed < PULSE_STEP_MIN_FIXED || p.p10_fixed > PULSE_STEP_MAX_FIXED) return false;
        if (p.driverResolution < 200 || p.driverResolution > 51200) return false;
        if (p.rollerDia != p.rollerDia || p.rollerDia < 10.0f || p.rollerDia > 200.0f) return false;
        if (p.maxRPMSetting < 100 || p.maxRPMSetting > 10000) return false;
        if (p.feedAngleDeg < 30 || p.feedAngleDeg > 330) return false;
        if (p.safetyMarginPercent < 0 || p.safetyMarginPercent > 50) return false;
        if (p.currentSize < 1 || p.currentSize > 3) return false;
        return true;
    }

    // Validate a stored record with magic and CRC-32
    static bool validateRecord(const MachineConfigRecord &rec) {
        if (rec.magic != EEPROM_MAGIC_V16_5_1) return false;
        uint32_t expectedCRC = calculateCRC32((const uint8_t*)&rec.payload, sizeof(MachineConfigPayload));
        if (rec.crc32 != expectedCRC) return false;
        return validatePayload(rec.payload);
    }

    // Build record from RAM state
    MachineConfigRecord buildCurrentRecord(uint32_t seq) const {
        MachineConfigRecord rec;
        rec.magic = EEPROM_MAGIC_V16_5_1;
        rec.seq   = seq;
        rec.reserved = 0;

        rec.payload.p5_fixed            = ram_p5;
        rec.payload.p8_fixed            = ram_p8;
        rec.payload.p10_fixed           = ram_p10;
        rec.payload.driverResolution    = ram_driverRes;
        rec.payload.rollerDia           = ram_rollerDia;
        rec.payload.maxRPMSetting       = ram_maxRPM;
        rec.payload.feedAngleDeg        = ram_feedAngle;
        rec.payload.safetyMarginPercent = ram_safetyMargin;
        rec.payload.currentSize         = ram_currentSize;
        rec.payload.sensorGuardActive   = ram_sensorGuard;
        rec.payload.hardwareTimerMode   = ram_hwTimerMode;
        rec.payload.motorDirection      = ram_motorDir;

        rec.crc32 = calculateCRC32((const uint8_t*)&rec.payload, sizeof(MachineConfigPayload));
        return rec;
    }

    // Apply valid payload to RAM and Stored state
    void applyPayload(const MachineConfigPayload &p, uint32_t seq, uint32_t slot) {
        ram_p5           = p.p5_fixed;
        ram_p8           = p.p8_fixed;
        ram_p10          = p.p10_fixed;
        ram_driverRes    = p.driverResolution;
        ram_rollerDia    = p.rollerDia;
        ram_maxRPM       = p.maxRPMSetting;
        ram_feedAngle    = p.feedAngleDeg;
        ram_safetyMargin = p.safetyMarginPercent;
        ram_currentSize  = p.currentSize;
        ram_sensorGuard  = p.sensorGuardActive;
        ram_hwTimerMode  = p.hardwareTimerMode;
        ram_motorDir     = p.motorDirection;

        lastSeq    = seq;
        activeSlot = slot;
        syncStoredWithRam();
    }
};


// =========================================================================
// FORMAL 60-SECOND CONTINUOUS AUTO-SAVE QUALIFICATION ENGINE
// Requirements (Prompt 6Writing Section 1):
// 1. Spindle speed continuously >= threshold (300 RPM).
// 2. ANY drop below threshold resets qualification timer to zero and state to SAVE_NOT_QUALIFIED.
// 3. Stale RPM sensor / timeout resets qualification.
// 4. Safety fault (PA3 / PB0) resets qualification.
// 5. Machine stop/idle resets qualification.
// 6. Only after a genuinely continuous 60 seconds is auto-save armed.
// 7. Physical save executes strictly at 0 RPM standstill.
// =========================================================================

enum SaveQualificationState {
    SAVE_NOT_QUALIFIED = 0,
    SAVE_QUALIFYING    = 1,
    SAVE_QUALIFIED     = 2
};

class AutoSaveQualificationEngine {
public:
    SaveQualificationState state;
    uint32_t qualificationStartMs;
    uint32_t qualificationDurationMs; // Nominal 60,000 ms (60 seconds)
    bool autoSavePendingStandstill;
    uint32_t resetEventCount;

    AutoSaveQualificationEngine(uint32_t durationMs = 60000UL) :
        state(SAVE_NOT_QUALIFIED),
        qualificationStartMs(0),
        qualificationDurationMs(durationMs),
        autoSavePendingStandstill(false),
        resetEventCount(0) {}

    void reset() {
        if (state != SAVE_NOT_QUALIFIED) {
            resetEventCount++;
        }
        state = SAVE_NOT_QUALIFIED;
        qualificationStartMs = 0;
        autoSavePendingStandstill = false;
    }

    void clearPendingSave() {
        autoSavePendingStandstill = false;
        reset();
    }

    void update(uint32_t currentRPM,
                uint32_t rpmThreshold,
                bool isRpmSensorValid,
                bool isSensorFaultTripped,
                bool isMotionSyncLost,
                bool isMachineIdle,
                bool pulseModifiedByUser,
                uint32_t nowMs) {

        // Strict continuous qualification conditions:
        // Must be spinning continuously >= threshold, sensor valid, no safety fault, no motion sync lost, not idle, user modified
        bool isQualifiedOperatingState = (currentRPM >= rpmThreshold) &&
                                         isRpmSensorValid &&
                                         (!isSensorFaultTripped) &&
                                         (!isMotionSyncLost) &&
                                         (!isMachineIdle) &&
                                         pulseModifiedByUser;

        if (!isQualifiedOperatingState) {
            // ANY violation immediately resets the continuous qualification run to zero
            if (state == SAVE_QUALIFYING) {
                reset();
            }
            return;
        }

        // Running smoothly in qualified band:
        switch (state) {
            case SAVE_NOT_QUALIFIED:
                state = SAVE_QUALIFYING;
                qualificationStartMs = nowMs;
                break;

            case SAVE_QUALIFYING:
                if ((nowMs - qualificationStartMs) >= qualificationDurationMs) {
                    state = SAVE_QUALIFIED;
                    autoSavePendingStandstill = true; // Armed for safe save at 0 RPM
                }
                break;

            case SAVE_QUALIFIED:
                // Maintained qualified state until machine comes to a standstill
                break;
        }
    }
};


// =========================================================================
// ATOMIC FLASH SAVE TRANSACTION ENGINE & RACE-CONDITION INTERLOCK
// Requirements (Prompt 8Writing Section 2 & 3):
// 1. Eliminates race condition between idle check and Flash write.
// 2. State machine: SAVE_LOCK_IDLE -> SAVE_LOCK_ACQUIRING -> SAVE_LOCK_LOCKED -> SAVE_LOCK_IDLE.
// 3. Triggers arriving during save lock window are SAFELY DEFERRED/BUFFERED without loss.
// 4. Zero trigger loss. Zero motor motion during Flash write.
// 5. Minimal interrupt-disabled time.
// =========================================================================

enum FlashSaveLockState {
    SAVE_LOCK_IDLE      = 0,  // Normal operation: triggers processed immediately
    SAVE_LOCK_ACQUIRING = 1,  // Save requested: incoming triggers buffered/deferred
    SAVE_LOCK_LOCKED      = 2,  // Motion confirmed stopped: Flash write in progress
    SAVE_LOCK_DISPATCHING = 3,  // Save complete, deferred trigger handoff in progress: triggers remain deferred (no overtaking)
    SAVE_LOCK_ABORTED     = 4   // Aborted due to safety fault or motion conflict
};

class FlashSaveTransactionEngine {
public:
    volatile FlashSaveLockState lockState;
    volatile bool     deferredTriggerPending;
    volatile uint32_t deferredTriggerCount;
    volatile uint32_t deferredSteps;
    volatile uint8_t  deferredDirection;
    volatile uint32_t deferredTimestampUs;

    FlashSaveTransactionEngine() :
        lockState(SAVE_LOCK_IDLE),
        deferredTriggerPending(false),
        deferredTriggerCount(0),
        deferredSteps(0),
        deferredDirection(0),
        deferredTimestampUs(0) {}

    void reset() {
        lockState = SAVE_LOCK_IDLE;
        deferredTriggerPending = false;
        deferredTriggerCount = 0;
        deferredSteps = 0;
        deferredDirection = 0;
        deferredTimestampUs = 0;
    }

    // Called when persistence wants to write Flash
    inline bool requestSaveLock() {
        if (lockState == SAVE_LOCK_IDLE) {
            lockState = SAVE_LOCK_ACQUIRING;
            return true;
        }
        return false;
    }

    inline bool isSaveLockActive() const {
        return (lockState == SAVE_LOCK_ACQUIRING || 
                lockState == SAVE_LOCK_LOCKED || 
                lockState == SAVE_LOCK_DISPATCHING);
    }

    // Called in Trigger ISR: defer incoming trigger during save window without losing it
    inline void deferTrigger(uint32_t steps, uint8_t dir, uint32_t ts) {
        deferredTriggerPending = true;
        deferredTriggerCount++;
        deferredSteps += steps;
        deferredDirection = dir;
        deferredTimestampUs = ts;
    }

    // Confirm machine is stopped and transition to locked state
    inline bool confirmLockAndTransition(bool isMachineIdle) {
        if (lockState == SAVE_LOCK_ACQUIRING) {
            if (isMachineIdle) {
                lockState = SAVE_LOCK_LOCKED;
                return true;
            } else {
                lockState = SAVE_LOCK_ABORTED;
                return false;
            }
        }
        return false;
    }

    // Two-Phase Atomic Handoff Protocol (Section 6: EEPROM Deferred-Trigger Race Fix):
    // Phase 1: Atomically capture deferred trigger state while entering DISPATCHING state.
    // Lock remains ACTIVE (isSaveLockActive() == true) so any new trigger arriving during dispatch
    // will be deferred in FIFO order and CANNOT overtake this older deferred work.
    inline uint32_t captureDeferredForDispatch(uint8_t &outDir, uint32_t &outTs) {
        lockState = SAVE_LOCK_DISPATCHING;
        if (deferredTriggerPending) {
            deferredTriggerPending = false;
            uint32_t steps = deferredSteps;
            outDir = deferredDirection;
            outTs = deferredTimestampUs;
            deferredSteps = 0;
            return steps;
        }
        return 0;
    }

    // Phase 2: Complete handoff and return to IDLE only after deferred work has been safely handed off/executed.
    inline void completeHandoff() {
        lockState = SAVE_LOCK_IDLE;
    }

    // Backward-compatible single-call release: captures deferred steps and transitions to IDLE
    inline uint32_t releaseLock(uint8_t &outDir, uint32_t &outTs) {
        uint32_t steps = captureDeferredForDispatch(outDir, outTs);
        completeHandoff();
        return steps;
    }

    // Abort lock and retrieve any deferred steps so caller can dispatch or safely account for them
    inline uint32_t abortLock(uint8_t &outDir, uint32_t &outTs) {
        uint32_t steps = captureDeferredForDispatch(outDir, outTs);
        completeHandoff();
        return steps;
    }

    inline void abortLock() {
        lockState = SAVE_LOCK_IDLE;
    }
};

#endif // PULSESTEP_PERSISTENCE_H
