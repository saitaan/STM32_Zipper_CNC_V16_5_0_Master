#include <iostream>
#include <cassert>
#include <cstdint>

// Simulation of MODE button state machine matching STM32_Zipper_CNC_V16_5_1_Firmware.ino
class ModeButtonSimulator {
public:
    int menuState;
    bool isUiLocked;
    uint32_t currentRPM;
    int stepsRemaining;
    bool hwBurstActive;

    int currentSize;            // 1 = #5, 2 = #8, 3 = #10
    uint64_t stepGearFixed;     // 100000 = 0.10, 1000000 = 1.00, 10000000 = 10.0, 100000000 = 100

    bool modePressed;
    uint32_t modePressTime;
    uint32_t lastModeClickTime;
    bool pendingSingleClick;

    uint32_t simulatedMillis;

    // Diagnostic event flags
    bool eventSizeChanged;
    bool eventGearChanged;
    bool eventLockToggled;
    bool eventBlockedByRunning;

    ModeButtonSimulator() :
        menuState(0),
        isUiLocked(false),
        currentRPM(0),
        stepsRemaining(0),
        hwBurstActive(false),
        currentSize(1),
        stepGearFixed(1000000ULL),
        modePressed(false),
        modePressTime(0),
        lastModeClickTime(0),
        pendingSingleClick(false),
        simulatedMillis(1000),
        eventSizeChanged(false),
        eventGearChanged(false),
        eventLockToggled(false),
        eventBlockedByRunning(false) {}

    void advanceTime(uint32_t ms) {
        simulatedMillis += ms;
        processLoop();
    }

    // Process button press & release with given hold duration
    void pressAndRelease(uint32_t holdDurationMs) {
        eventSizeChanged = false;
        eventGearChanged = false;
        eventLockToggled = false;
        eventBlockedByRunning = false;

        // Button Down
        modePressTime = simulatedMillis;
        modePressed = true;

        // Advance while held
        simulatedMillis += holdDurationMs;

        // Button Up
        uint32_t holdTime = simulatedMillis - modePressTime;
        modePressed = false;

        if (menuState == 0) {
            if (holdTime < 350UL) {
                // Short click handling: check double-click or pending single
                if (pendingSingleClick && (simulatedMillis - lastModeClickTime < 350UL)) {
                    // Double Click detected -> Toggle Keypad Lock
                    pendingSingleClick = false;
                    isUiLocked = !isUiLocked;
                    eventLockToggled = true;
                    lastModeClickTime = 0UL;
                } else {
                    lastModeClickTime = simulatedMillis;
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        pendingSingleClick = true;
                    } else {
                        pendingSingleClick = false;
                        if (!isUiLocked) {
                            eventBlockedByRunning = true;
                        }
                    }
                }
            } else if (holdTime >= 1500UL && holdTime < 3000UL && !isUiLocked) {
                // 1.5 - 3 Second Hold: Zipper Size Sequence Switch (#5 -> #8 -> #10 -> #5)
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    currentSize++;
                    if (currentSize > 3) currentSize = 1;
                    eventSizeChanged = true;
                } else {
                    eventBlockedByRunning = true;
                }
            }
        }

        // Process loop checks
        processLoop();
    }

    void processLoop() {
        // Single click commit after 350ms window expires
        if (pendingSingleClick && (simulatedMillis - lastModeClickTime > 350UL)) {
            pendingSingleClick = false;
            if (!isUiLocked && menuState == 0) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    // Single Click -> Pulse Tuning Gear Change (0.10 -> 1.00 -> 10.0 -> 100)
                    if (stepGearFixed == 100000ULL) {
                        stepGearFixed = 1000000ULL;
                    } else if (stepGearFixed == 1000000ULL) {
                        stepGearFixed = 10000000ULL;
                    } else if (stepGearFixed == 10000000ULL) {
                        stepGearFixed = 100000000ULL;
                    } else {
                        stepGearFixed = 100000ULL;
                    }
                    eventGearChanged = true;
                } else {
                    eventBlockedByRunning = true;
                }
            }
        }
    }
};

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: MODE Button Behavior & Invariant Matrix (Prompt lastWriting)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    ModeButtonSimulator sim;

    // 1. Single Press (< 350ms) -> Changes Gear, DOES NOT Change Size
    {
        assert(sim.stepGearFixed == 1000000ULL);
        int initialSize = sim.currentSize;

        sim.pressAndRelease(100); // 100ms click
        sim.advanceTime(400);     // Wait for 350ms single-click timer to expire

        assert(sim.eventGearChanged == true);
        assert(sim.eventSizeChanged == false);
        assert(sim.stepGearFixed == 10000000ULL); // 1.00 -> 10.0
        assert(sim.currentSize == initialSize);   // Size UNCHANGED!
        std::cout << "[PASS] 1. MODE single press: Changes Gear (1.00->10.0), Size strictly unchanged." << std::endl;
    }

    // 2. 1.5 - 3 Second Hold -> Changes Size, DOES NOT Change Gear
    {
        uint64_t initialGear = sim.stepGearFixed;
        assert(sim.currentSize == 1); // #5

        sim.pressAndRelease(2000); // 2.0s hold
        sim.advanceTime(100);

        assert(sim.eventSizeChanged == true);
        assert(sim.eventGearChanged == false);
        assert(sim.currentSize == 2);           // #5 -> #8
        assert(sim.stepGearFixed == initialGear); // Gear UNCHANGED!
        std::cout << "[PASS] 2. MODE 1.5-3s hold: Changes Size (Size #5->#8), Gear strictly unchanged." << std::endl;
    }

    // 3. Boundary Tests around 1.5s and 3.0s
    {
        // 3a. Just below 1.5s (1490 ms): Neither Gear nor Size should trigger
        int s1 = sim.currentSize;
        uint64_t g1 = sim.stepGearFixed;
        sim.pressAndRelease(1490);
        sim.advanceTime(400);
        assert(sim.eventGearChanged == false);
        assert(sim.eventSizeChanged == false);
        assert(sim.currentSize == s1);
        assert(sim.stepGearFixed == g1);
        std::cout << "[PASS] 3a. Boundary hold (1490 ms, just below 1.5s): Ignored cleanly." << std::endl;

        // 3b. Exactly at 1.5s (1500 ms): Triggers Size change, NOT Gear
        uint64_t g2 = sim.stepGearFixed;
        sim.pressAndRelease(1500);
        sim.advanceTime(100);
        assert(sim.eventSizeChanged == true);
        assert(sim.eventGearChanged == false);
        assert(sim.currentSize == 3);           // #8 -> #10
        assert(sim.stepGearFixed == g2);
        std::cout << "[PASS] 3b. Boundary hold (1500 ms, exactly at 1.5s): Triggers Size change." << std::endl;

        // 3c. Normal hold (2500 ms): Triggers Size change, NOT Gear
        uint64_t g3 = sim.stepGearFixed;
        sim.pressAndRelease(2500);
        sim.advanceTime(100);
        assert(sim.eventSizeChanged == true);
        assert(sim.eventGearChanged == false);
        assert(sim.currentSize == 1);           // #10 -> #5 (wraparound)
        assert(sim.stepGearFixed == g3);
        std::cout << "[PASS] 3c. Normal hold (2500 ms): Triggers Size change (#10 -> #5)." << std::endl;

        // 3d. Just above 3.0s (3050 ms): Does not trigger 1.5-3s Size change
        int s4 = sim.currentSize;
        uint64_t g4 = sim.stepGearFixed;
        sim.pressAndRelease(3050);
        sim.advanceTime(400);
        assert(sim.eventGearChanged == false);
        assert(sim.eventSizeChanged == false);
        assert(sim.currentSize == s4);
        assert(sim.stepGearFixed == g4);
        std::cout << "[PASS] 3d. Boundary hold (3050 ms, above 3.0s): 1.5-3s window not triggered." << std::endl;
    }

    // 4. Repeated Single Presses -> Full Gear Cycle (0.10 -> 1.00 -> 10.0 -> 100 -> 0.10)
    {
        sim.stepGearFixed = 100000ULL; // 0.10
        int sInitial = sim.currentSize;

        // Press 1
        sim.pressAndRelease(80);
        sim.advanceTime(400);
        assert(sim.stepGearFixed == 1000000ULL); // 1.00

        // Press 2
        sim.pressAndRelease(80);
        sim.advanceTime(400);
        assert(sim.stepGearFixed == 10000000ULL); // 10.0

        // Press 3
        sim.pressAndRelease(80);
        sim.advanceTime(400);
        assert(sim.stepGearFixed == 100000000ULL); // 100

        // Press 4
        sim.pressAndRelease(80);
        sim.advanceTime(400);
        assert(sim.stepGearFixed == 100000ULL); // 0.10

        assert(sim.currentSize == sInitial); // Size stayed 100% constant throughout
        std::cout << "[PASS] 4. Repeated single presses: Gear cycles 0.10 -> 1.00 -> 10.0 -> 100 -> 0.10, Size constant." << std::endl;
    }

    // 5. Repeated Holds -> Full Size Sequence Cycle (#5 -> #8 -> #10 -> #5)
    {
        sim.currentSize = 1; // #5
        uint64_t gInitial = sim.stepGearFixed;

        sim.pressAndRelease(2000);
        assert(sim.currentSize == 2); // #8

        sim.pressAndRelease(2000);
        assert(sim.currentSize == 3); // #10

        sim.pressAndRelease(2000);
        assert(sim.currentSize == 1); // #5

        assert(sim.stepGearFixed == gInitial); // Gear stayed 100% constant throughout
        std::cout << "[PASS] 5. Repeated holds: Size sequence cycles #5 -> #8 -> #10 -> #5, Gear constant." << std::endl;
    }

    // 6. Double-Click Detection: Toggles Lock, NEVER Triggers Size or Gear
    {
        assert(!sim.isUiLocked);
        int sInitial = sim.currentSize;
        uint64_t gInitial = sim.stepGearFixed;

        // Click 1
        sim.pressAndRelease(80);
        sim.advanceTime(150); // within 350ms double-click window
        // Click 2
        sim.pressAndRelease(80);
        sim.advanceTime(400);

        assert(sim.eventLockToggled == true);
        assert(sim.isUiLocked == true);
        assert(sim.currentSize == sInitial);
        assert(sim.stepGearFixed == gInitial);

        // Unlock
        sim.pressAndRelease(80);
        sim.advanceTime(150);
        sim.pressAndRelease(80);
        sim.advanceTime(400);

        assert(sim.isUiLocked == false);
        assert(sim.currentSize == sInitial);
        assert(sim.stepGearFixed == gInitial);
        std::cout << "[PASS] 6. Double-click (< 350ms): Toggles lock/unlock, zero accidental Size or Gear actions." << std::endl;
    }

    // 7. Hold followed by immediate press (Zero interference, no double action)
    {
        // 2s Hold -> Size changes
        sim.pressAndRelease(2000);
        assert(sim.eventSizeChanged == true);
        assert(sim.eventGearChanged == false);

        // Immediate single press -> Gear changes
        sim.advanceTime(50);
        sim.pressAndRelease(80);
        sim.advanceTime(400);
        assert(sim.eventGearChanged == true);
        assert(sim.eventSizeChanged == false);
        std::cout << "[PASS] 7. Hold followed by immediate press: Clean sequential execution, zero crosstalk." << std::endl;
    }

    // 8. Safety Blocking during Machine Activity (RPM > 0)
    {
        sim.currentRPM = 1500; // Machine running at 1500 RPM
        int sInitial = sim.currentSize;
        uint64_t gInitial = sim.stepGearFixed;

        // Attempt single press while running
        sim.pressAndRelease(80);
        sim.advanceTime(400);
        assert(sim.eventBlockedByRunning == true);
        assert(sim.stepGearFixed == gInitial); // Gear change blocked!

        // Attempt hold while running
        sim.pressAndRelease(2000);
        sim.advanceTime(100);
        assert(sim.eventBlockedByRunning == true);
        assert(sim.currentSize == sInitial); // Size change blocked!

        std::cout << "[PASS] 8. Safety blocking: Both Size and Gear changes strictly blocked while machine running." << std::endl;
    }

    std::cout << "==========================================================" << std::endl;
    std::cout << "ALL MODE BUTTON BEHAVIOR TESTS PASSED (100% GREEN)!" << std::endl;
    std::cout << "==========================================================" << std::endl;

    return 0;
}
