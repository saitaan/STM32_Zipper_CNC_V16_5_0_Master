#include <cassert>
#include <cstdint>
#include <fstream>
#include <sstream>
#include <string>

int main() {
    std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
    std::stringstream ss; ss << f.rdbuf();
    const std::string s = ss.str();

    assert(s.find("TIM2_CAPTURE_AUDIT_TOLERANCE_US 12U") != std::string::npos);
    assert(s.find("auditTim2Capture") != std::string::npos);
    assert(s.find("auditCaptureDmaPosition") != std::string::npos);
    assert(s.find("triggerIntegrityFault(4U)") != std::string::npos);
    assert(s.find("triggerIntegrityFault(3U)") != std::string::npos);
    assert(s.find("TIM1: >HW") != std::string::npos);
    assert(s.find("Dual-clock silicon capture audit") != std::string::npos);

    // Safety policy: no silent sub-blanking trigger rejection.
    auto p = s.find("if (diff < triggerQualificationUs)");
    assert(p != std::string::npos);
    auto q = s.find("triggerIntegrityFault(3U)", p);
    assert(q != std::string::npos);

    return 0;
}
