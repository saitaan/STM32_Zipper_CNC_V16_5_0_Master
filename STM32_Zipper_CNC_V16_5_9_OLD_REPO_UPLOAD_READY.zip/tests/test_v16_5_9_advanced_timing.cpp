#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
int main(){
 std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
 std::stringstream ss; ss<<f.rdbuf(); std::string s=ss.str();
 assert(s.find("uint32_t edgeCycles = 0")!=std::string::npos);
 assert(s.find("uint32_t edgeUs = get_hardware_timestamp_us()")!=std::string::npos);
 assert(s.find("NVIC_SetPriority(EXTI0_IRQn, 0)")!=std::string::npos);
 assert(s.find("TIM2->CCMR1 |= (0xFU << 4)")!=std::string::npos);
 assert(s.find("capStatus & TIM_SR_CC1OF")!=std::string::npos);
 assert(s.find("triggerIntegrityFault(1U)")!=std::string::npos);
 assert(s.find("triggerIntegrityFault(2U)")!=std::string::npos);
 assert(s.find("flashSaveTx.isSaveLockActive()")!=std::string::npos);
 assert(s.find("do not safely replay")!=std::string::npos || s.find("not safely replayable")!=std::string::npos);
 assert(s.find("TIM4")!=std::string::npos);
 std::cout<<"PASS V16.5.9 advanced hardware timing policy\n";
}
