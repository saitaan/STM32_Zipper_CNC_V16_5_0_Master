#include <cassert>
#include <fstream>
#include <iostream>
#include <string>

int main() {
    const char* path = "STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino";
    std::ifstream f(path);
    assert(f && "authoritative firmware source must exist");
    std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());

    assert(s.find("holdTime >= 7000UL && !isUiLocked") != std::string::npos);
    assert(s.find("holdTime >= 8000UL && !isUiLocked") == std::string::npos);
    assert(s.find("requestSafeAutoSave") != std::string::npos);
    assert(s.find("if (!isMachineSafelyIdle() || currentRPM != 0UL || stepsRemaining != 0 || hwBurstActive) return;") != std::string::npos);
    assert(s.find("13. EXIT") != std::string::npos);
    assert(s.find("SAVE & EXIT") != std::string::npos);
    assert(s.find("EXIT WITHOUT SAVE") != std::string::npos);
    assert(s.find("NIPON ZIPPER IND") != std::string::npos);
    assert(s.find("RAJESH SHAH     ") != std::string::npos);
    assert(s.find("bootSplashUntilMs = millis() + 2000UL") != std::string::npos);

    // Immediate Flash write from the ZIP-size button path must be gone.
    assert(s.find("saveToEEPROM(); // Standstill size commit") == std::string::npos);

    std::cout << "[PASS] Settings entry = 7s, safe automatic save, single EXIT choice, and 2s boot branding verified.\n";
    return 0;
}
