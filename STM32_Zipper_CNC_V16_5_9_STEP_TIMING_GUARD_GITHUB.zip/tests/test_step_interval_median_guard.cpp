#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

static uint32_t median3(uint32_t a, uint32_t b, uint32_t c) {
    if (a > b) { auto t = a; a = b; b = t; }
    if (b > c) { auto t = b; b = c; c = t; }
    if (a > b) { auto t = a; a = b; b = t; }
    return b;
}
int main() {
    // A single timestamp outlier must not change the period estimator at steady speed.
    assert(median3(20000, 20000, 41000) == 20000);
    assert(median3(20000, 9000, 20000) == 20000);
    assert(median3(19800, 20000, 20200) == 20000);

    std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
    assert(f && "authoritative firmware sketch must be present");
    std::ostringstream buffer; buffer << f.rdbuf();
    const std::string s = buffer.str();
    assert(s.find("uint32_t stepTimingIntervalUs") != std::string::npos);
    assert(s.find("calculateAdaptiveStepPeriodQ16(stepTimingIntervalUs") != std::string::npos);
    assert(s.find("updateStepPeriodFromServoInterval(stepTimingIntervalUs") != std::string::npos);
    std::cout << "PASS: STEP period scheduling uses median-filtered interval; raw interval remains available for trigger qualification/watchdog.\n";
}
