#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
    std::stringstream ss; ss << f.rdbuf();
    const std::string s = ss.str();
    assert(!s.empty());
    assert(s.find("TIM2 input capture is disabled in this build") != std::string::npos);
    assert(s.find("TIM2->DIER &= ~(TIM_DIER_CC1DE | TIM_DIER_CC1IE)") != std::string::npos);
    assert(s.find("stepTimingIntervalUs = median3u32") != std::string::npos);
    assert(s.find("updateStepPeriodFromServoInterval(stepTimingIntervalUs") != std::string::npos);
    assert(s.find("calculateAdaptiveStepPeriodQ16(stepTimingIntervalUs") != std::string::npos);
    assert(s.find("diff = 0UL; // This edge re-baselines motion") != std::string::npos);
    assert(s.find("CAPTURE HEALTH") == std::string::npos);
    assert(s.find("captureIntervalValid") == std::string::npos);
    assert(s.find("capturedIntervalUs") == std::string::npos);
    assert(s.find("servoCaptureDma") == std::string::npos);
    // This filter suppresses an isolated long interval: median(20,20,40)=20.
    auto median3 = [](unsigned a, unsigned b, unsigned c) {
        if (a > b) { auto t=a; a=b; b=t; }
        if (b > c) { auto t=b; b=c; c=t; }
        if (a > b) { auto t=a; a=b; b=t; }
        return b;
    };
    assert(median3(20000, 20000, 40000) == 20000);
    assert(median3(20000, 40000, 20000) == 20000);
    assert(median3(40000, 20000, 20000) == 20000);
    std::cout << "PASS consistent trigger timestamp + median STEP timing regression\n";
}
