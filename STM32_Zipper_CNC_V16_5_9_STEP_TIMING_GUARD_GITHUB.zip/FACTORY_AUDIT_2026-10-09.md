# Factory-floor source audit — 2026-10-09

## Confirmed configuration math
- Driver resolution 6400 and roller diameter 45.0 mm are consistent with the source's pulse profiles.
- Calculated circumference is pi * 45 mm. The source pulse profiles correspond to about 45.27 steps/mm: Size #5 (2.50 mm) = 113.176848 steps, Size #8 (3.00 mm) = 135.812218 steps, Size #10 (4.00 mm) = 181.082957 steps.
- At Max RPM 3000, Feed Angle 160 degrees, Safety Margin 10%, the available feed window is 8000 us/revolution. Approximate step periods are 70.69 us (#5), 58.90 us (#8), and 44.18 us (#10), all above the 8 us minimum. These defaults are mathematically feasible; real zipper length still depends on the actual feed mechanics and calibrated output.

## Corrections made in this audit package
- Corrected Settings option 11's misleading `Engine/Diag` / `View System Diag` labels to `STEP Engine` / `Select STEP Mode`.
- Corrected the engine detail label from `TIM2: >HW` to `TIM1: >HW`. TIM1 generates PA8 STEP; TIM2 captures PA0.
- Corrected related comments and all three synchronized copies of `hardware_capture_spec.h`, which still incorrectly described PA1/TIM2_CH2 as the STEP output.
- Corrected the source-consistency test's printed release label to V16.5.9.
- Integrated a 3-interval median estimator and applied it to PA8 STEP-period scheduling once three valid intervals exist. This prevents one isolated long/short timestamp outlier from directly stretching/shrinking a burst. Raw timing remains in use for trigger qualification and watchdog checks. It cannot restore a physically missed PA0 edge or prove STEP output continuity.

## Remaining technical risk — requires further test/fix
- `sensorISR()` still computes its raw interval from DWT/continuous software timestamps at EXTI ISR entry. It reads `TIM2->CCR1` but discards the captured value, while the circular DMA capture array is configured but not consumed for interval/RPM calculation. Therefore TIM2 hardware capture is not yet the authoritative trigger-time source. The median estimator mitigates a single interval outlier after three valid samples, but cannot remove all ISR-latency effects or reconstruct a missed trigger.
- PC13 status indication is tied to the PA0 trigger ISR, so a missed/rejected PA0 event can look like a heartbeat drop. The median display filter does not fix this.
- Do not assume a dropped RPM/heartbeat display means PA8 STEP stopped. The PA8 pulse stream must be checked independently; host tests cannot prove physical output continuity.
- The host suite is simulation/model tests, not a target build or machine test. No local Arduino STM32 target toolchain was available during this audit. Confirm the GitHub Actions target compile and then supervised machine testing before production use.

## Verification performed here
- `bash tests/run_tests.sh`: 26 suites passed after the STEP timing outlier guard.
- Source/header copies are synchronized; ZIP integrity is checked when the release archive is created.
- Not performed: STM32 target compilation, physical LCD check, tachometer measurement, oscilloscope/logic-analyzer validation, or full stitching test.
