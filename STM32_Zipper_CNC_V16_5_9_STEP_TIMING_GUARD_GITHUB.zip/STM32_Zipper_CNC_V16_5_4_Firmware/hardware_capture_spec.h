#ifndef HARDWARE_CAPTURE_SPEC_H
#define HARDWARE_CAPTURE_SPEC_H

#include <stdint.h>
#include <stdbool.h>
#include <cstring>

// =========================================================================
// STM32F103C8T6 HARDWARE CAPTURE & TIMING SPECIFICATION (V16.5.9)
// =========================================================================
// 1. PIN & CHANNEL PHYSICAL MAPPING:
//    - PA0: Cam/proximity sensor input; falling-edge EXTI is the motion trigger.
//    - PA8: Stepper driver PUL-/STEP output; TIM1_CH1 active-low hardware PWM.
//    - PA2: Stepper driver DIR output; GPIOA push-pull output.
//    - TIM1 is the STEP pulse generator. Do not interchange timer ownership.
//
// 2. PRODUCTION TRIGGER TIMING (V16.5.9 timing guard):
//    - The sketch uses one consistent EXTI-side timestamp source (DWT/continuous timebase).
//    - TIM2 CC1 capture/DMA/interrupt are disabled in the production sketch because
//      EXTI and capture flags can race when consumed from separate timing paths.
//    - STEP scheduling uses a median of three accepted trigger intervals once filled;
//      raw intervals remain responsible for qualification and watchdog logic.
//    - This reduces isolated interval outliers but cannot reconstruct a missed physical edge.
//
// 3. TIMER OWNERSHIP & CONTINUOUS TIMEBASE:
//    - TIM1: PA8 STEP pulse generation; its ARR/CCR1 define the STEP pulse period/width.
//    - TIM2: free-running diagnostic counter only; no active input-capture path.
//    - TIM3: 1 kHz safety monitor.
//    - TIM4: independent 1 MHz timebase with overflow extension where available.
//
// 4. TIMING METRICS (nominal 72 MHz STM32F103 clock):
//    - TIM1/TIM2/TIM4 prescaler 71 gives a nominal 1 MHz timer tick where configured.
//    - Configured machine speed ceiling defaults to 3000 RPM; settings permit up to 4000 RPM.
//    - RPM standstill timeout: > 2,000,000 us without an accepted trigger.
// =========================================================================

// Diagnostic model used by host tests. Production timing is implemented in the
// firmware sketch; this class does not drive timers or prove physical edge counts.
struct HardwareCaptureDiagnostics {
    uint32_t totalTriggersDetected;
    uint32_t hardwareCapturesRead;
    uint32_t captureOverruns;
    uint32_t noiseSpikesFiltered;
    uint32_t timeoutsDetected;
    uint32_t lastLatchedCCR;
    uint32_t lastTimestampUs;
    uint32_t lastIntervalUs;
    bool     isCaptureStreamDiscontinuous;
    uint32_t overcaptureTimestampUs;
    uint32_t overcaptureEventCount;
    uint32_t lowerBoundLostEdges;
    uint32_t knownLostPulses;
    uint32_t acceptedPulses;
    uint32_t resyncEvents;

};

class HardwareCaptureStreamEngine {
public:
    HardwareCaptureDiagnostics diag;

    HardwareCaptureStreamEngine() { memset(&diag, 0, sizeof(diag)); }

    void handleHardwareEdge(bool cc1of, uint16_t ccr1, uint32_t timestampUs, uint32_t blankingFloorUs = 1500UL) {
        diag.totalTriggersDetected++;
        if (cc1of) {
            diag.captureOverruns++;
            diag.overcaptureEventCount++;
            diag.lowerBoundLostEdges++;
            diag.knownLostPulses++;
            diag.isCaptureStreamDiscontinuous = true;
            diag.overcaptureTimestampUs = timestampUs;
        }
        diag.hardwareCapturesRead++;
        diag.lastLatchedCCR = ccr1;
        if (diag.lastTimestampUs > 0) {
            uint32_t interval = timestampUs - diag.lastTimestampUs;
            if (interval < blankingFloorUs) {
                diag.noiseSpikesFiltered++;
                return;
            }
            diag.lastIntervalUs = interval;
        }
        diag.acceptedPulses++;
        diag.lastTimestampUs = timestampUs;
        if (!cc1of && diag.isCaptureStreamDiscontinuous) {
            diag.isCaptureStreamDiscontinuous = false;
            diag.resyncEvents++;
        }
    }

    bool verifyConservationInvariant(uint32_t physicalEdges) const {
        return physicalEdges == (diag.acceptedPulses + diag.lowerBoundLostEdges + diag.noiseSpikesFiltered);
    }
};

#endif // HARDWARE_CAPTURE_SPEC_H
