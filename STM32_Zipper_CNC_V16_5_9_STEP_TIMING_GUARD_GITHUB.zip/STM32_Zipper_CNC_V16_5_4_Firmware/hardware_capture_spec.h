#ifndef HARDWARE_CAPTURE_SPEC_H
#define HARDWARE_CAPTURE_SPEC_H

#include <stdint.h>
#include <stdbool.h>
#include <cstring>

// =========================================================================
// STM32F103C8T6 HARDWARE CAPTURE & TIMING SPECIFICATION (V16.5.9)
// =========================================================================
// 1. PIN & CHANNEL PHYSICAL MAPPING:
//    - PA0: Cam/proximity sensor input; EXTI0 falling edge and TIM2_CH1 input capture.
//    - PA8: Stepper driver PUL-/STEP output; TIM1_CH1 active-low hardware PWM.
//    - PA2: Stepper driver DIR output; GPIOA push-pull output.
//    - TIM2 is capture-only; TIM1 is the STEP pulse generator. Do not interchange them.
//
// 2. HARDWARE CAPTURE MECHANISM (TIM2_CH1):
//    - TIM2 Channel 1 is configured in Input Capture mode (CC1S = 01b).
//    - Falling-edge capture latches TIM2->CNT into TIM2->CCR1 in hardware.
//    - EXTI0 remains the low-latency software trigger path; TIM2 capture/DMA is a
//      parallel diagnostic capture path and does not itself schedule PA8 pulses.
//    - Overcapture: TIM2->SR CC1OF indicates at least one capture was overwritten
//      before the capture register was read; the flag is not an exact edge counter.
//
// 3. TIMER OWNERSHIP & CONTINUOUS TIMEBASE:
//    - TIM1: PA8 STEP pulse generation; its ARR/CCR1 define the STEP pulse period/width.
//    - TIM2: PA0 input capture, free-running at 1 MHz with ARR=0xFFFF.
//    - TIM3: 1 kHz safety monitor.
//    - TIM4: independent 1 MHz timebase with overflow extension where available.
//    - TIM2 is not stopped between STEP bursts and its ARR does not define STEP timing.
//
// 4. TIMING METRICS (nominal 72 MHz STM32F103 clock):
//    - TIM1/TIM2/TIM4 prescaler 71 gives a nominal 1 MHz timer tick where configured.
//    - Configured machine speed ceiling defaults to 3000 RPM; settings permit up to 4000 RPM.
//    - RPM standstill timeout: > 2,000,000 us without an accepted trigger.
// =========================================================================

// Diagnostic model used by host tests. Production timing is implemented in the
// firmware sketch; this class does not drive timers or prove physical edge counts.
struct HardwareCaptureDiagnostics {
    uint32_t totalTriggersDetected;
    uint32_t hardwareCapturesRead;
    uint32_t captureOverruns;
    uint32_t noiseSpikesFiltered;
    uint32_t timeoutsDetected;
    uint32_t lastLatchedCCR;
    uint32_t lastTimestampUs;
    uint32_t lastIntervalUs;
    bool     isCaptureStreamDiscontinuous;
    uint32_t overcaptureTimestampUs;
    uint32_t overcaptureEventCount;
    uint32_t lowerBoundLostEdges;
    uint32_t knownLostPulses;
    uint32_t acceptedPulses;
    uint32_t resyncEvents;

};

class HardwareCaptureStreamEngine {
public:
    HardwareCaptureDiagnostics diag;

    HardwareCaptureStreamEngine() { memset(&diag, 0, sizeof(diag)); }

    void handleHardwareEdge(bool cc1of, uint16_t ccr1, uint32_t timestampUs, uint32_t blankingFloorUs = 1500UL) {
        diag.totalTriggersDetected++;
        if (cc1of) {
            diag.captureOverruns++;
            diag.overcaptureEventCount++;
            diag.lowerBoundLostEdges++;
            diag.knownLostPulses++;
            diag.isCaptureStreamDiscontinuous = true;
            diag.overcaptureTimestampUs = timestampUs;
        }
        diag.hardwareCapturesRead++;
        diag.lastLatchedCCR = ccr1;
        if (diag.lastTimestampUs > 0) {
            uint32_t interval = timestampUs - diag.lastTimestampUs;
            if (interval < blankingFloorUs) {
                diag.noiseSpikesFiltered++;
                return;
            }
            diag.lastIntervalUs = interval;
        }
        diag.acceptedPulses++;
        diag.lastTimestampUs = timestampUs;
        if (!cc1of && diag.isCaptureStreamDiscontinuous) {
            diag.isCaptureStreamDiscontinuous = false;
            diag.resyncEvents++;
        }
    }

    bool verifyConservationInvariant(uint32_t physicalEdges) const {
        return physicalEdges == (diag.acceptedPulses + diag.lowerBoundLostEdges + diag.noiseSpikesFiltered);
    }
};

#endif // HARDWARE_CAPTURE_SPEC_H
