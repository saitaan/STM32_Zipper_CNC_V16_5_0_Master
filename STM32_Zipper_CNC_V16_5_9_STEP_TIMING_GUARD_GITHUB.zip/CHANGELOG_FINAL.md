# Changelog — V16.5.9 PA0/TIM2 + PA8/TIM1

## Current update
- Confirmed target: STM32F103C8T6.
- PA0 proximity sensor remains the primary trigger input, using EXTI and TIM2_CH1 capture.
- PA8 is configured as TIM1_CH1 active-low hardware STEP/PUL output.
- Trigger capture timer and STEP pulse timer are separated: TIM2 captures, TIM1 generates pulses.
- MODE zipper-size hold window extended from 1.5–3 seconds to 1.5–8 seconds; 8-second hold remains reserved for hidden settings.
- Persistence now checks safe standstill before requesting the save lock and feeds the watchdog around early exits and Flash write/readback path.
- GitHub Actions workflow corrected to run host tests and compile the actual sketch folder, then publish the binary artifact.

## Validation notes
- Host test results must be obtained by running `bash tests/run_tests.sh` or from the GitHub Actions run.
- Target compilation is delegated to GitHub Actions; no local STM32 target compile is claimed here.
- Oscilloscope/logic-analyzer validation on the actual machine is mandatory before production use, especially for PA8 pulse polarity/width, PA0-to-PA8 synchronization, watchdog behavior during persistence, and MODE size retention.
- Historical files and comments may refer to PA1/TIM2 because that was the previous hardware mapping; the current main sketch is the source of truth for PA8/TIM1.


## RPM display update
- RPM display field now refreshes periodically while stopped as well as running, so stale RPM digits are cleared.
- RPM values are derived only from a measured interval of 0–2,000,000 us; longer gaps are treated as standstill/new-start conditions rather than a displayed low-speed reading.
- No trigger pin, STEP pin, pulse-count, button mapping, or timer mapping changed in this RPM-only update.

## Factory-floor audit follow-up (2026-10-09)
- Fixed auto-save UI correctness: `AUTO-SAVED OK!` is shown only when `saveToEEPROM()` reports a verified successful transaction.
- Failed auto-save now displays `SAVE FAILED!` and keeps the pending-save state for a later safe retry.
- MODE zipper-size commit now reports a failed persistence transaction instead of implying the save succeeded; the selected size remains a RAM change until successfully saved.
- Settings-apply save path now checks the transaction result and retains pending retry state on failure.
- Re-ran the included host regression suite: 25 suites passed. This is not a substitute for STM32 target compilation or physical-machine validation.

## Read-only live diagnostics update
- Info/Diag menu (menuState 9) is retained when motion starts, instead of being auto-exited like configuration menus.
- The Info/Diag LCD page refreshes while running (rate-limited to 150 ms) so RPM, proximity interval, sync state, capture counters, and step/guard status remain live.
- Optocoupler sink test remains standstill-only; its page explicitly displays `BLOCKED: RUNNING` during motion.
- PA0 trigger capture and PA8 STEP generation paths were not intentionally modified by this UI-only change.
- Validation: host test runner passed 25 suites. This is not a target-board compile or physical-machine test.

## LCD settings-menu display fix (2026-10-09)
- Fixed option 12 second-line label to `Open Diagnostics`.
- Added option 13 second-line label `Apply & Exit`.
- Added a fixed-width 16-column LCD line writer for settings and menu-detail screens to clear trailing characters consistently.
- Initialized menu line buffers so options without an explicit second-line value do not use uninitialized text.
- No pin assignments, sensor logic, RPM estimation, or motion scheduling logic intentionally changed.
- Verification: `tests/run_tests.sh` completed with 25 host-test suites passing. STM32 target compilation and physical LCD/hardware testing were not performed.


## Additional audit correction (2026-10-09)
- Corrected settings-menu engine labels and comments: TIM1 drives PA8 STEP; TIM2 captures PA0.
- Rewrote all three synchronized `hardware_capture_spec.h` copies to remove obsolete PA1/TIM2 STEP descriptions and to document timer ownership accurately.
- Corrected the source-consistency test's printed release label to V16.5.9.
- These changes fix menu/documentation/test-label mismatches; they do not replace target compilation or on-machine timing validation.


## STEP timing outlier guard (2026-10-09)
- Added a source-level regression test for the motion-period estimator.
- After three valid trigger intervals are available, PA8 STEP burst-period scheduling now uses the median of the latest three measured intervals, rather than allowing one isolated long/short timestamp outlier to directly stretch/shrink a burst.
- Raw interval is still used for trigger qualification and watchdog logic; the RPM display and STEP-period estimator share the median window.
- This is a mitigation for isolated timing outliers, not recovery for a physically missed PA0 trigger.
- Verification: 26 host test suites passed. Target compile and machine timing validation remain outstanding.
