# STM32 ZIPPER CNC V16.5.0 ULTRA-HARDWARE MASTER EDITION
## Autonomous Hardware Timer 2 Engine • 0% CPU Stepping Load • Industrial UX & Confirmation Suite
**Organization:** Nipon Zipper Industries Pvt Ltd, Sarigam GIDC, Gujarat, India  
**Lead Engineer / Author:** Rajesh Shah (Industrial Automation & Embedded Systems)  
**Target Microcontroller:** STM32F103C8T6 (32-bit ARM Cortex-M3 @ 72MHz)  
**Date:** September 2026  

---

### 1. Executive Summary & V16.5.0 Production Breakthroughs
1. **Hardware Timer 2 Autonomous Burst Engine (`TIM2` on `PA1`):**
   - Configures STM32 Hardware Timer 2 on Pin `PA1` (`TIM2_CH2`).
   - Sinks pulses directly via silicon hardware clock without `loop()` polling or software delay counters.
   - Stepping CPU load drops to **0%**, completely eliminating CPU starvation during high-speed feed bursts.
2. **Dual-Mode Engine Selector (Option 7 in Hidden Menu):**
   - **Mode 0: HW-TIMER [AUTO]:** Hardware autonomous peripheral execution (0ns jitter).
   - **Mode 1: DDA-LOOP [DDA]:** Classic 1,000,000x micro-fractional DDA fallback engine.
3. **Step Tuning Save Confirmation Dialogue (`[UP] YES / [DN] NO`):**
   - After adjusting pulse via UP/DOWN, pressing MODE enters a dedicated confirmation dialogue:
     - Line 1: `SAVE: 114.17 ?  `
     - Line 2: `[UP]YES   [DN]NO`
     - `[UP]`: Commits to EEPROM and shows `PARAM SAVED OK!`.
     - `[DN]`: Discards changes and restores calibrated pitch (`CHANGES CANCEL`).
     - 5-Second Inactivity Timeout: Auto-cancels safely to prevent accidental parameter corruption.
4. **Transient Tuning Overlay (UP/DOWN Pop-up Banner):**
   - When UP/DOWN is pressed at 0 RPM, a 1.2-second full-screen tuning popup appears:
     - Line 1: `PULSE: 114.17   ` (Exact 6-decimal live pulse)
     - Line 2: `GEAR: ±1.00 [UP]` (Active gear: ±0.10, ±1.00, ±10.0, or ±100)
   - Automatically reverts to running telemetry after 1.2s timeout.
5. **Zipper Size Switch Pop-up Banners (#5 ➔ #8 ➔ #10):**
   - On single-click MODE, displays a 1.0-second clear status banner:
     - `#5`: `ACTIVE: SIZE #5 ` / `PITCH: 2.50 mm  `
     - `#8`: `ACTIVE: SIZE #8 ` / `PITCH: 3.00 mm  `
     - `#10`: `ACTIVE: SIZE #10` / `PITCH: 4.00 mm  `
   - Keypad Locked notification: `KEYPAD LOCKED!  ` / `DBL-CLICK [U]   `.
6. **Dual Optical Safety Guard Subsystem:**
   - `PA3`: Tape Run-Out & Breakage Optical Sensor (PC817 Ch 1).
   - `PB0`: Coil Jam & Breakage Fiber-Optic Sensor (PC817 Ch 2).
   - `PB1`: Main Motor E-Stop Relay (NC Clutch-Brake Loop).
   - **STRICT DEFAULT: BYPASS [OFF]** (Must be enabled explicitly via Option 6).
   - Optical trip immediately cuts TIM2 in hardware and trips PB1 relay in sub-millisecond time.
7. **Bootup Branding Splash Screen:**
   - Line 1: `  NIPON ZIPPER  `
   - Line 2: ` BY RAJESH SHAH `
   - Duration: 2.0 Seconds.
8. **I2C Noise Immunity (`Wire.setTimeout(25000)`):**
   - Protects STM32 I2C bus against lockups caused by 24V motor/relay electrical noise.

---

### 2. Hardware Pinout & Industrial Netlist (100% Backwards-Compatible)

| Peripheral | STM32 Pin | Signal Type | Hardware Peripheral Mapping |
| :--- | :--- | :--- | :--- |
| **Cam Proximity Sensor** | `PA0` | Input (Active-LOW) | PC817 Optocoupler -> Clean MCU GND (EXTI0 / FALLING ISR) |
| **Stepper Step Pulse (PUL-)**| `PA1` | Output (Active-LOW) | **Hardware TIM2_CH2** / BSS138 CH3 Level Shifter |
| **Stepper Direction (DIR-)** | `PA2` | Output (Active-LOW) | GPIOA Direct BSRR / BSS138 CH4 Level Shifter |
| **Tape Run-Out Optical Sensor**| `PA3` | Input (Active-LOW) | PC817 Ch 1 Optocoupler (Pull-up to 3.3V) |
| **Coil Breakage Fiber Sensor** | `PB0` | Input (Active-LOW) | PC817 Ch 2 Optocoupler (Pull-up to 3.3V) |
| **Main Motor Stop Relay** | `PB1` | Output (Active-HIGH Trip)| 5V Opto-Isolated Relay Module (NC Clutch Loop) |
| **UP Push Button** | `PB12` | Input (Active-LOW) | Internal Pull-Up to Clean MCU GND |
| **DOWN Push Button** | `PB13` | Input (Active-LOW) | Internal Pull-Up to Clean MCU GND |
| **MODE Push Button** | `PB14` | Input (Active-LOW) | Internal Pull-Up to Clean MCU GND |
| **16x2 Character LCD** | `PB6` / `PB7` | I2C (400kHz) | Level-Shifted 5V Fast I2C Bus |

---

### 3. Hidden Menu Navigation & Options (V16.5.0)
1. `1. Driver Res`: Microstepping resolution (Default: 6400 steps).
2. `2. Roller Dia`: Roller diameter in mm (Default: 45.0 mm).
3. `3. Max RPM`: Maximum machine speed (Default: 3000 RPM).
4. `4. Feed Angle`: Mechanical feed window sector (Default: 160°).
5. `5. Safety Margin`: Timing calculation buffer (Default: 10%).
6. `6. Sensor Guard`: **`State: BYPASS [OFF]`** (Default) / **`ACTIVE [ON]`**.
7. `7. Engine Mode`: **`Mode: HW-TIMER`** (Default) / **`Mode: DDA-LOOP`**.
8. `8. Info Diag`: 7-Point Interactive System Info & Field Troubleshooter.
   - Screen 1: Firmware Version (`VER: V16.5.0-PRO` / `BUILD: SEP-2026`)
   - Screen 2: Developer (`DEV: RAJESH SHAH` / `NIPON ZIPPER IND`)
   - Screens 3-7: Troubleshooting Guides (Motor Stall, Pitch Error, Noise, Motor Heat, Tape Drift).
9. `9. Save & Sync`: Commits all staged RAM tweaks atomically to EEPROM (`0x5A431650`).
10. `10. Cancel/Exit`: Discards uncommitted staged changes.
