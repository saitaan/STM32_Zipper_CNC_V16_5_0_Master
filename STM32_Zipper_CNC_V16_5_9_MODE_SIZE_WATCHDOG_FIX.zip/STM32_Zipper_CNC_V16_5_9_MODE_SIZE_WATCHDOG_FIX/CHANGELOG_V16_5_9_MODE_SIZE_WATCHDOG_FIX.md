# V16.5.9 — MODE / Zipper-Size Restart Fix

## Bug
Changing the zipper size with the MODE button could be followed by an unexpected MCU restart.

## Root cause
The zipper-size path schedules a deferred EEPROM save. The save transaction then entered an application-level global interrupt blackout around `EEPROM.put()`. The firmware watchdog was configured for approximately 3.2 seconds. A slow STM32 Flash/EEPROM-emulation transaction could therefore starve the foreground watchdog long enough to cause an IWDG reset.

## Fix
- Removed the application-level `__disable_irq()` / `__set_PRIMASK()` wrapper around `EEPROM.put()`.
- Refresh the independent watchdog immediately before and after the persistence transaction.
- Increased the IWDG timeout to approximately 10 seconds (40 kHz LSI / 256 prescaler / RLR 1562), while keeping the watchdog permanently enabled.
- No MODE timing, zipper-size sequence, motion timing, pulse calculation, safety interlocks, or machine-running protections were changed.
- Existing deferred standstill save policy remains intact.

## Validation
- MODE behavior regression: PASS.
- Zipper size sequence and boundary tests: PASS.
- Full repository automated verification: **29/29 test suites PASS**.
- No production firmware binary was generated in this environment because the STM32/Arduino toolchain is not bundled with the supplied repository.
