#include <iostream>
#include <cstdint>
#include <cassert>
#include <vector>
#include <random>
#include "../STM32_Zipper_CNC_V16_5_4_Firmware/safety_sensors.h"

// =========================================================================
// AUTOMATED TEST SUITE: INDEPENDENT SAFETY SENSOR QUALIFICATION (PA3 & PB0)
// Mandated by Nipon Zipper Production Release Specification (Prompt 3Writing)
// Tests: Cases A through N
// =========================================================================

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Independent Safety Sensor Qualification (PA3 & PB0)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    volatile uint8_t pa3Counter = 0;
    volatile uint8_t pb0Counter = 0;
    bool pa3Qualified = false;
    bool pb0Qualified = false;

    // ---------------------------------------------------------------------
    // Test A: PA3 Below Threshold (1, 5, 10, 14 ms -> NO PA3 fault)
    // ---------------------------------------------------------------------
    {
        const int testDurations[] = {1, 5, 10, 14};
        for (int dur : testDurations) {
            pa3Counter = 0;
            pb0Counter = 0;
            for (int t = 0; t < dur; t++) {
                updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
                assert(!pa3Qualified);
                assert(!pb0Qualified);
                assert(pa3Counter == (t + 1));
                assert(pb0Counter == 0);
            }
        }
        std::cout << "[PASS] Test A: PA3 Below Threshold (1, 5, 10, 14 ms) -> NO Fault Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test B: PA3 Threshold (15 ms -> PA3 fault)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        for (int t = 0; t < 14; t++) {
            updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(!pa3Qualified);
            assert(!pb0Qualified);
        }
        // 15th sample
        updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pa3Qualified);
        assert(!pb0Qualified);
        assert(pa3Counter == 15);

        // Saturation check (does not overflow beyond 15)
        for (int t = 0; t < 50; t++) {
            updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(pa3Qualified);
            assert(pa3Counter == 15);
        }
        std::cout << "[PASS] Test B: PA3 Threshold (15 ms) -> PA3 Fault & Saturation Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test C: PA3 Reset (14 ms HIGH -> LOW -> resets to 0, NO fault)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        for (int t = 0; t < 14; t++) {
            updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        }
        assert(pa3Counter == 14);
        assert(!pa3Qualified);

        // PA3 goes LOW (inactive)
        updateSafetySensorCounters(true, false, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pa3Counter == 0);
        assert(!pa3Qualified);
        assert(!pb0Qualified);
        std::cout << "[PASS] Test C: PA3 Reset (14 ms HIGH then LOW) -> Counter Cleared, NO Fault." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test D: PB0 Below Threshold (1, 5, 10, 14 ms -> NO PB0 fault)
    // ---------------------------------------------------------------------
    {
        const int testDurations[] = {1, 5, 10, 14};
        for (int dur : testDurations) {
            pa3Counter = 0;
            pb0Counter = 0;
            for (int t = 0; t < dur; t++) {
                updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
                assert(!pa3Qualified);
                assert(!pb0Qualified);
                assert(pb0Counter == (t + 1));
                assert(pa3Counter == 0);
            }
        }
        std::cout << "[PASS] Test D: PB0 Below Threshold (1, 5, 10, 14 ms) -> NO Fault Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test E: PB0 Threshold (15 ms -> PB0 fault)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        for (int t = 0; t < 14; t++) {
            updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(!pa3Qualified);
            assert(!pb0Qualified);
        }
        // 15th sample
        updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(!pa3Qualified);
        assert(pb0Qualified);
        assert(pb0Counter == 15);

        // Saturation check
        for (int t = 0; t < 50; t++) {
            updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(pb0Qualified);
            assert(pb0Counter == 15);
        }
        std::cout << "[PASS] Test E: PB0 Threshold (15 ms) -> PB0 Fault & Saturation Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test F: PB0 Reset (14 ms HIGH -> LOW -> resets to 0, NO fault)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        for (int t = 0; t < 14; t++) {
            updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        }
        assert(pb0Counter == 14);
        assert(!pb0Qualified);

        // PB0 goes LOW (inactive)
        updateSafetySensorCounters(true, false, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pb0Counter == 0);
        assert(!pa3Qualified);
        assert(!pb0Qualified);
        std::cout << "[PASS] Test F: PB0 Reset (14 ms HIGH then LOW) -> Counter Cleared, NO Fault." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test G: Cross-Sensor False-Accumulation Test (PA3 8ms, LOW, PB0 7ms -> NO fault)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        // PA3 HIGH for 8 ms
        for (int t = 0; t < 8; t++) {
            updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        }
        assert(pa3Counter == 8);
        assert(pb0Counter == 0);
        assert(!pa3Qualified && !pb0Qualified);

        // PA3 goes LOW
        updateSafetySensorCounters(true, false, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pa3Counter == 0);
        assert(pb0Counter == 0);

        // PB0 HIGH for 7 ms
        for (int t = 0; t < 7; t++) {
            updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        }
        assert(pa3Counter == 0);
        assert(pb0Counter == 7);
        assert(!pa3Qualified);
        assert(!pb0Qualified); // 8ms PA3 + 7ms PB0 must NEVER trip (zero cross-accumulation)

        // PB0 goes LOW
        updateSafetySensorCounters(true, false, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pb0Counter == 0);
        assert(!pa3Qualified && !pb0Qualified);
        std::cout << "[PASS] Test G: Cross-Sensor False-Accumulation (PA3 8ms + PB0 7ms) -> NO Fault Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test H: Reverse Cross-Sensor Test (PB0 8ms, LOW, PA3 7ms -> NO fault)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        // PB0 HIGH for 8 ms
        for (int t = 0; t < 8; t++) {
            updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        }
        assert(pb0Counter == 8);
        assert(pa3Counter == 0);
        assert(!pa3Qualified && !pb0Qualified);

        // PB0 goes LOW
        updateSafetySensorCounters(true, false, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pb0Counter == 0);
        assert(pa3Counter == 0);

        // PA3 HIGH for 7 ms
        for (int t = 0; t < 7; t++) {
            updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        }
        assert(pb0Counter == 0);
        assert(pa3Counter == 7);
        assert(!pa3Qualified);
        assert(!pb0Qualified); // 8ms PB0 + 7ms PA3 must NEVER trip

        // PA3 goes LOW
        updateSafetySensorCounters(true, false, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pa3Counter == 0);
        assert(!pa3Qualified && !pb0Qualified);
        std::cout << "[PASS] Test H: Reverse Cross-Sensor (PB0 8ms + PA3 7ms) -> NO Fault Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test I: Alternating Sensor Test (PA3 1ms, PB0 1ms, repeat 1000 times -> NO fault)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        for (int cycle = 0; cycle < 1000; cycle++) {
            // PA3 active, PB0 inactive
            updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(!pa3Qualified && !pb0Qualified);
            assert(pa3Counter == 1);
            assert(pb0Counter == 0);

            // PB0 active, PA3 inactive
            updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(!pa3Qualified && !pb0Qualified);
            assert(pa3Counter == 0);
            assert(pb0Counter == 1);
        }
        std::cout << "[PASS] Test I: Alternating Sensor Test (1000 cycles PA3 1ms / PB0 1ms) -> Zero Accrual Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test J: Both Active Simultaneously (PA3 HIGH & PB0 HIGH for 15 ms)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        for (int t = 0; t < 14; t++) {
            updateSafetySensorCounters(true, true, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(!pa3Qualified && !pb0Qualified);
            assert(pa3Counter == (t + 1));
            assert(pb0Counter == (t + 1));
        }
        // 15th sample: both qualify simultaneously
        updateSafetySensorCounters(true, true, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pa3Qualified);
        assert(pb0Qualified);
        assert(pa3Counter == 15);
        assert(pb0Counter == 15);
        std::cout << "[PASS] Test J: Both Active Simultaneously (PA3 + PB0 >= 15ms) -> Dual Qualification Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test K: Sensor Guard OFF (PA3 HIGH > 15ms, PB0 HIGH > 15ms -> NO fault)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        for (int t = 0; t < 100; t++) {
            updateSafetySensorCounters(false, true, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(!pa3Qualified);
            assert(!pb0Qualified);
            assert(pa3Counter == 0);
            assert(pb0Counter == 0);
        }
        std::cout << "[PASS] Test K: Sensor Guard OFF -> 100% Inactive & Bypassed Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test L: Guard OFF -> ON (Guard OFF, PA3 HIGH > 15ms, then Guard ON -> Starts from 0)
    // ---------------------------------------------------------------------
    {
        pa3Counter = 0;
        pb0Counter = 0;
        // Guard OFF with PA3 HIGH for 50 ms
        for (int t = 0; t < 50; t++) {
            updateSafetySensorCounters(false, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(!pa3Qualified);
            assert(pa3Counter == 0);
        }

        // Guard turned ON: qualification must start strictly from zero
        for (int t = 0; t < 14; t++) {
            updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
            assert(!pa3Qualified);
            assert(pa3Counter == (t + 1));
        }
        // 15th sample after Guard ON
        updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pa3Qualified);
        assert(pa3Counter == 15);
        std::cout << "[PASS] Test L: Guard OFF -> ON Transition -> Zero Stale State & Clean Start Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test M: Guard ON -> OFF During Qualification (Guard ON, PA3 HIGH 8ms, Guard OFF -> Reset)
    // ---------------------------------------------------------------------
    {
        // PA3 test
        pa3Counter = 0;
        pb0Counter = 0;
        for (int t = 0; t < 8; t++) {
            updateSafetySensorCounters(true, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        }
        assert(pa3Counter == 8);
        assert(!pa3Qualified);

        // Turn Guard OFF
        updateSafetySensorCounters(false, true, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pa3Counter == 0);
        assert(!pa3Qualified);

        // PB0 test
        pa3Counter = 0;
        pb0Counter = 0;
        for (int t = 0; t < 8; t++) {
            updateSafetySensorCounters(true, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        }
        assert(pb0Counter == 8);
        assert(!pb0Qualified);

        // Turn Guard OFF
        updateSafetySensorCounters(false, false, true, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
        assert(pb0Counter == 0);
        assert(!pb0Qualified);
        std::cout << "[PASS] Test M: Guard ON -> OFF During Active Counting -> Immediate Reset Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Test N: Randomized Cross-Sensor Stress Test (100,000 bursts & samples)
    // ---------------------------------------------------------------------
    {
        std::mt19937 rng(1337);
        std::uniform_int_distribution<int> guardDist(0, 100);
        std::uniform_int_distribution<int> burstLengthDist(1, 30);
        std::uniform_int_distribution<int> sensorDist(0, 3); // 0: None, 1: PA3, 2: PB0, 3: Both

        pa3Counter = 0;
        pb0Counter = 0;
        pa3Qualified = false;
        pb0Qualified = false;

        uint32_t expectedPa3Consecutive = 0;
        uint32_t expectedPb0Consecutive = 0;

        uint32_t totalSamples = 0;
        uint32_t pa3TripEvents = 0;
        uint32_t pb0TripEvents = 0;

        while (totalSamples < 100000) {
            bool guard = (guardDist(rng) > 10); // 90% guard ON, 10% guard OFF
            int burstLen = burstLengthDist(rng);
            int activeSensorMode = sensorDist(rng);

            bool rawPa3 = (activeSensorMode == 1 || activeSensorMode == 3);
            bool rawPb0 = (activeSensorMode == 2 || activeSensorMode == 3);

            for (int b = 0; b < burstLen && totalSamples < 100000; b++) {
                totalSamples++;

                // Ground-truth model
                if (!guard) {
                    expectedPa3Consecutive = 0;
                    expectedPb0Consecutive = 0;
                } else {
                    if (rawPa3) expectedPa3Consecutive++; else expectedPa3Consecutive = 0;
                    if (rawPb0) expectedPb0Consecutive++; else expectedPb0Consecutive = 0;
                }

                // Update production logic
                updateSafetySensorCounters(guard, rawPa3, rawPb0, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);

                // Strict Invariant Check
                if (guard) {
                    if (expectedPa3Consecutive >= 15) {
                        assert(pa3Qualified == true);
                        assert(pa3Counter == 15);
                        pa3TripEvents++;
                    } else {
                        assert(pa3Qualified == false);
                        assert(pa3Counter == expectedPa3Consecutive);
                    }

                    if (expectedPb0Consecutive >= 15) {
                        assert(pb0Qualified == true);
                        assert(pb0Counter == 15);
                        pb0TripEvents++;
                    } else {
                        assert(pb0Qualified == false);
                        assert(pb0Counter == expectedPb0Consecutive);
                    }
                } else {
                    assert(pa3Qualified == false);
                    assert(pb0Qualified == false);
                    assert(pa3Counter == 0);
                    assert(pb0Counter == 0);
                }
            }

            // Inactive inter-burst gap
            int gapLen = burstLengthDist(rng);
            for (int g = 0; g < gapLen && totalSamples < 100000; g++) {
                totalSamples++;
                expectedPa3Consecutive = 0;
                expectedPb0Consecutive = 0;

                updateSafetySensorCounters(guard, false, false, pa3Counter, pb0Counter, pa3Qualified, pb0Qualified);
                assert(pa3Qualified == false);
                assert(pb0Qualified == false);
                assert(pa3Counter == 0);
                assert(pb0Counter == 0);
            }
        }
        std::cout << "[PASS] Test N: Randomized Stress (" << totalSamples << " Samples, "
                  << pa3TripEvents << " PA3 Trips, " << pb0TripEvents << " PB0 Trips) -> 100% Invariant Match." << std::endl;
    }

    std::cout << "==========================================================" << std::endl;
    std::cout << "SUCCESS: ALL SENSOR QUALIFICATION TESTS PASSED (100% GREEN)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    return 0;
}
