#include <iostream>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <vector>
#include <random>
#include "../STM32_Zipper_CNC_V16_5_4_Firmware/hardware_capture_spec.h"

// Simulated STM32 Timer Status Register
#define TIM_SR_CC1IF (1U << 1)
#define TIM_SR_CC1OF (1U << 9)

struct MockTimer2 {
    uint32_t SR;
    uint32_t CCR1;
    uint32_t CNT;
};

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Hardware Overcapture (CC1OF) Detection & Handling" << std::endl;
    std::cout << "==========================================================" << std::endl;

    // ---------------------------------------------------------------------
    // Scenario 1: Clean Single Trigger
    // ---------------------------------------------------------------------
    {
        MockTimer2 tim2 = {0, 0, 0};
        HardwareCaptureDiagnostics diag;
        memset(&diag, 0, sizeof(diag));

        tim2.CNT  = 12345;
        tim2.CCR1 = 12345;
        tim2.SR  |= TIM_SR_CC1IF; // Capture flag set by hardware

        // Emulate ISR processing
        if (tim2.SR & TIM_SR_CC1OF) {
            tim2.SR &= ~TIM_SR_CC1OF;
            diag.captureOverruns++;
            diag.isCaptureStreamDiscontinuous = true;
            diag.knownLostPulses++;
        }
        if (tim2.SR & TIM_SR_CC1IF) {
            tim2.SR &= ~TIM_SR_CC1IF;
            diag.hardwareCapturesRead++;
            diag.lastLatchedCCR = tim2.CCR1;
            diag.acceptedPulses++;
        }

        assert(diag.hardwareCapturesRead == 1);
        assert(diag.captureOverruns == 0);
        assert(diag.acceptedPulses == 1);
        assert(!diag.isCaptureStreamDiscontinuous);
        assert(diag.lastLatchedCCR == 12345);
        std::cout << "[PASS] 1. Clean Hardware Capture Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Scenario 2: Overcapture Condition (Silicon Overwrite in CCR1)
    // ---------------------------------------------------------------------
    {
        MockTimer2 tim2 = {0, 0, 0};
        HardwareCaptureDiagnostics diag;
        memset(&diag, 0, sizeof(diag));

        // Edge A was latched at 10000, but before ISR serviced it, Edge B arrived at 30000!
        // Silicon sets CC1OF and overwrites CCR1 with Edge B (30000).
        tim2.CCR1 = 30000;
        tim2.SR  |= (TIM_SR_CC1IF | TIM_SR_CC1OF);

        uint32_t currentTs = 30000;
        if (tim2.SR & TIM_SR_CC1OF) {
            tim2.SR &= ~TIM_SR_CC1OF; // Explicit clear
            diag.captureOverruns++;    // Explicit detection and recording
            diag.isCaptureStreamDiscontinuous = true; // Stream marked discontinuous!
            diag.knownLostPulses++;    // Edge A accounted as lost!
            diag.overcaptureTimestampUs = currentTs;
        }
        if (tim2.SR & TIM_SR_CC1IF) {
            tim2.SR &= ~TIM_SR_CC1IF;
            diag.hardwareCapturesRead++;
            diag.lastLatchedCCR = tim2.CCR1;
            diag.acceptedPulses++;     // Edge B accepted!
        }

        assert(diag.captureOverruns == 1);
        assert(diag.isCaptureStreamDiscontinuous == true);
        assert(diag.knownLostPulses == 1);
        assert(diag.acceptedPulses == 1);
        // Total physical edges = 2, accounted as: accepted (1) + knownLost (1) = 2
        assert((diag.acceptedPulses + diag.knownLostPulses) == 2);
        assert(diag.lastLatchedCCR == 30000);
        assert((tim2.SR & (TIM_SR_CC1IF | TIM_SR_CC1OF)) == 0); // SR clean
        std::cout << "[PASS] 2. Hardware Overcapture (CC1OF) Explicitly Detected & Logged." << std::endl;

        // Next valid edge arrives outside blanking window -> Stream resynchronizes cleanly
        uint32_t nextTs = currentTs + 20000; // 50000 (20ms later)
        tim2.CCR1 = (uint16_t)(nextTs % 65536);
        tim2.SR |= TIM_SR_CC1IF;

        if (tim2.SR & TIM_SR_CC1IF) {
            tim2.SR &= ~TIM_SR_CC1IF;
            diag.hardwareCapturesRead++;
            diag.lastLatchedCCR = tim2.CCR1;
            diag.acceptedPulses++;

            if (diag.isCaptureStreamDiscontinuous) {
                diag.isCaptureStreamDiscontinuous = false; // Stream safely resynchronized!
                diag.resyncEvents++;
            }
        }

        assert(diag.isCaptureStreamDiscontinuous == false);
        assert(diag.resyncEvents == 1);
        assert(diag.acceptedPulses == 2);
        assert(diag.knownLostPulses == 1);
        // Total physical edges = 3, accounted as: accepted (2) + knownLost (1) = 3
        assert((diag.acceptedPulses + diag.knownLostPulses) == 3);
        std::cout << "[PASS] 3. Stream Resynchronization without Fake Pulses Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Scenario 3: Real Overcapture End-to-End Simulation Engine (Prompt Section 4 & 5)
    // ---------------------------------------------------------------------
    {
        HardwareCaptureStreamEngine engine;

        // Pattern A: 2 physical edges (1 overwritten/lost in silicon, 1 latched & serviced)
        engine.handleHardwareEdge(true, 1000, 20000); // 1 lost (CC1OF), 1 accepted (20000)
        assert(engine.diag.acceptedPulses == 1);
        assert(engine.diag.captureOverruns == 1);
        assert(engine.diag.knownLostPulses == 1);
        assert(engine.diag.isCaptureStreamDiscontinuous);
        assert(engine.verifyConservationInvariant(2));
        std::cout << "[PASS] 4. Pattern A: 2 Physical Edges with Overcapture Conserved Exactly (1 accepted + 1 lost = 2)." << std::endl;

        // Pattern B: Next clean pulse 20ms later -> resyncs stream
        engine.handleHardwareEdge(false, 5000, 40000);
        assert(engine.diag.acceptedPulses == 2);
        assert(engine.diag.resyncEvents == 1);
        assert(!engine.diag.isCaptureStreamDiscontinuous);
        assert(engine.verifyConservationInvariant(3));
        std::cout << "[PASS] 5. Pattern B: Resynchronization After Overcapture Verified." << std::endl;

        // Pattern C: 3 physical edges (2 overcapture events)
        engine.handleHardwareEdge(true,  10050, 60000);
        engine.handleHardwareEdge(true,  10100, 80000);
        assert(engine.verifyConservationInvariant(7)); // 3 previous + 3 new = 6 total physical
        std::cout << "[PASS] 6. Pattern C: Multi-Edge Overcapture Burst Invariant Verified." << std::endl;

        // Pattern D: 10 physical edges
        for (int i = 0; i < 5; i++) {
            // each call has cc1of=true (1 lost + 1 accepted = 2 physical)
            engine.handleHardwareEdge(true, (uint16_t)(10000 + i * 1000), 100000 + i * 20000);
        }
        assert(engine.verifyConservationInvariant(17)); // 7 + 10 = 17
        std::cout << "[PASS] 7. Pattern D: 10 Physical Edges Invariant Verified." << std::endl;

        // Pattern E: 100-edge randomized burst with mixed clean and overcapture spacing
        std::mt19937 rng(1337);
        std::uniform_int_distribution<uint32_t> intervalDist(5000, 25000);
        std::bernoulli_distribution overDist(0.2); // 20% overcapture rate
        uint32_t simTime = 200000;
        uint32_t totalPhysical = 17;

        for (int i = 0; i < 100; i++) {
            uint32_t dt = intervalDist(rng);
            simTime += dt;
            bool isOvercapture = overDist(rng);
            engine.handleHardwareEdge(isOvercapture, (uint16_t)(simTime % 65536), simTime);
            totalPhysical += isOvercapture ? 2 : 1;
        }
        assert(engine.verifyConservationInvariant(totalPhysical));
        std::cout << "[PASS] 8. Pattern E: 100-Edge Randomized Burst Conservation Invariant Verified." << std::endl;

        // Pattern F: Burst around 16-bit timer overflow boundary (0xFFFF -> 0x0000)
        simTime = 65500;
        for (int i = 0; i < 20; i++) {
            simTime += 5000; // clean valid spacing across rollover
            bool isOver = (i % 4 == 0);
            engine.handleHardwareEdge(isOver, (uint16_t)(simTime % 65536), simTime);
            totalPhysical += isOver ? 2 : 1;
        }
        assert(engine.verifyConservationInvariant(totalPhysical));
        std::cout << "[PASS] 9. Pattern F: Burst Around Timer Overflow Invariant Verified." << std::endl;
    }

    // ---------------------------------------------------------------------
    // Scenario 4: Formal Invariant Scaling Matrix (1, 10, 100, 1000, 10000 Pulses)
    // ---------------------------------------------------------------------
    {
        uint32_t testSizes[] = {1, 10, 100, 1000, 10000};
        for (uint32_t N : testSizes) {
            HardwareCaptureStreamEngine eng;
            uint32_t t = 10000;
            for (uint32_t i = 0; i < N; i++) {
                t += 20000; // clean 20ms spacing (3000 RPM)
                eng.handleHardwareEdge(false, (uint16_t)(t % 65536), t);
            }
            assert(eng.diag.acceptedPulses == N);
            assert(eng.diag.knownLostPulses == 0);
            assert(eng.diag.captureOverruns == 0);
            assert(eng.verifyConservationInvariant(N));
        }
        std::cout << "[PASS] 10. Formal Invariant Scaling Matrix (1 to 10,000 pulses) Verified: 100% Exact Conservation." << std::endl;
    }

    std::cout << "==========================================================" << std::endl;
    std::cout << "ALL OVERCAPTURE & CONSERVATION TESTS PASSED (100% GREEN)!" << std::endl;
    std::cout << "==========================================================" << std::endl;
    return 0;
}
