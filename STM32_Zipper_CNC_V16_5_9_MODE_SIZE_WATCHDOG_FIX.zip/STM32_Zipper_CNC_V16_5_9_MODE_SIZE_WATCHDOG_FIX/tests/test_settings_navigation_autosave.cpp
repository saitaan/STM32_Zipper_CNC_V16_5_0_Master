#include <cassert>
#include <fstream>
#include <iostream>
#include <string>

int main() {
    const char* path = "STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino";
    std::ifstream f(path);
    assert(f && "authoritative firmware source must exist");
    std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());

    assert(s.find("holdTime >= 7000UL && !isUiLocked") != std::string::npos);
    assert(s.find("holdTime >= 8000UL && !isUiLocked") == std::string::npos);
    assert(s.find("requestSafeAutoSave") != std::string::npos);
    assert(s.find("if (!isMachineSafelyIdle() || currentRPM != 0UL || stepsRemaining != 0 || hwBurstActive) return;") != std::string::npos);
    assert(s.find("13. EXIT") != std::string::npos);
    assert(s.find("SAVE & EXIT") != std::string::npos);
    assert(s.find("EXIT WITHOUT SAVE") != std::string::npos);
    assert(s.find("NIPON ZIPPER IND") != std::string::npos);
    assert(s.find("RAJESH SHAH     ") != std::string::npos);
    assert(s.find("bootSplashUntilMs = millis() + 2000UL") != std::string::npos);

    // Immediate Flash write from the ZIP-size button path must be gone.
    assert(s.find("saveToEEPROM(); // Standstill size commit") == std::string::npos);
    // Size-change persistence must not wrap EEPROM.put() in an application-level
    // interrupt blackout; that can starve the foreground watchdog during Flash writes.
    const auto savePos = s.find("bool saveToEEPROM() {");
    assert(savePos != std::string::npos);
    const auto putPos = s.find("EEPROM.put(targetOffset, rec);", savePos);
    assert(putPos != std::string::npos);
    const auto feedBefore = s.rfind("IWDG_FEED();", putPos);
    assert(feedBefore != std::string::npos && feedBefore > savePos);
    const auto feedAfter = s.find("IWDG_FEED();", putPos);
    assert(feedAfter != std::string::npos && feedAfter > putPos);
    assert(s.find("__disable_irq();\n    EEPROM.put(targetOffset, rec);") == std::string::npos);
    assert(s.find("RLR=1562") != std::string::npos);

    std::cout << "[PASS] Settings entry = 7s, safe automatic save, single EXIT choice, and 2s boot branding verified.\n";
    return 0;
}
