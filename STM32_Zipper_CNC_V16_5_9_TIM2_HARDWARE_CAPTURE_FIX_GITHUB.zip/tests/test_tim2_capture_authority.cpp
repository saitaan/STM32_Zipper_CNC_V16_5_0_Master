#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
    std::stringstream ss; ss << f.rdbuf();
    const std::string s = ss.str();
    assert(!s.empty());
    assert(s.find("V16.5.9-PA0-TIM2-CAPTURE-PA8-TIM1") != std::string::npos);
    assert(s.find("TIM2->CCMR1 = (TIM2->CCMR1 & ~0x3U) | 0x1U") != std::string::npos);
    assert(s.find("TIM2->DIER = TIM_DIER_UIE | TIM_DIER_CC1IE") != std::string::npos);
    assert(s.find("extern \"C\" void TIM2_IRQHandler(void)") != std::string::npos);
    assert(s.find("const uint32_t timestampUs = (high << 16) | (uint32_t)captured") != std::string::npos);
    assert(s.find("processSensorTrigger(timestampUs)") != std::string::npos);
    assert(s.find("attachInterrupt(digitalPinToInterrupt(proxSensorPin), sensorISR, FALLING)") == std::string::npos);
    assert(s.find("TIM2 input capture is disabled") == std::string::npos);
    std::cout << "PASS: TIM2 hardware capture is the sole trigger source; EXTI duplicate path absent\n";
}
