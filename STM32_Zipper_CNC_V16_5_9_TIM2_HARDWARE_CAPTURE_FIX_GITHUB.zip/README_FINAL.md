# STM32 Zipper CNC — V16.5.9 Isolated Trigger/STEP Timers

## Release purpose
This package updates the earlier PA0/PA1/TIM2 firmware mapping to the confirmed current wiring:

- **MCU:** STM32F103C8T6 (Blue Pill, 72 MHz)
- **PA0:** proximity/cam sensor input; TIM2_CH1 falling-edge hardware capture is the sole motion trigger
- **PA8:** stepper driver PUL−/STEP output; TIM1_CH1 active-low hardware PWM
- **PA2:** DIR output
- **PB13 / PB12 / PB14:** UP / DOWN / MODE buttons (active-low)

The timing split is **PA0 → TIM2_CH1 hardware capture = motion trigger timestamp**, **TIM2 update IRQ = extended 32-bit 1 MHz capture time**, and **TIM1_CH1 = PA8 STEP pulse engine**. EXTI is not attached to PA0, so one physical edge cannot be processed by two interrupt paths. TIM2 CCR1 has one consumer in `TIM2_IRQHandler`; DMA is disabled. TIM2_CH2 is not used as STEP output.

## Critical operator behavior
- A proximity trigger is the mechanical timing reference for needle synchronization; do not treat it as a generic button.
- Auto-save is permitted only after the firmware's standstill/safe-idle check passes.
- MODE zipper-size selection uses a 1.5–8 second hold on release; the 8-second hold remains reserved for the hidden settings menu. Changes are accepted only while stopped and unlocked.
- The watchdog timeout was lengthened and feeds were added around persistence exits to reduce save-related resets. This does **not** prove every Flash operation will finish before watchdog expiry on every board/core combination.
- Do not enable automatic motion resume after watchdog reset.

## Trigger/STEP timing correction (V16.5.9 timing guard)
- Made TIM2_CH1 hardware capture the sole PA0 trigger source. EXTI is not attached, so capture flags cannot race with a separate EXTI handler. TIM2 IRQ extends the counter across 16-bit overflows and reads CCR1 only when CC1IF is set.
- STEP burst scheduling now uses a 3-accepted-interval median after the history fills. Raw interval still governs edge qualification and watchdog logic. A single isolated long/short interval is less likely to stretch the next burst.
- A trigger arriving after a >2 s standstill re-baselines timing and uses the startup period instead of converting the long idle gap into a STEP period.
- Diagnostic page 11 reports the STEP timing filter history count (`N`) and TIM2 capture-overrun count (`O`). Diagnostic page 10 reports interval jitter.
- Limitation: a hardware capture overrun means one or more edges were overwritten before CCR1 was serviced and cannot be reconstructed from a single capture register. Target build and physical validation are still required; this is not proof that the stitching-position issue is solved.

## RPM display correction (V16.5.9 RPM refresh)
- RPM is updated from qualified PA0 trigger intervals only; intervals longer than 2 seconds are treated as standstill/restart and are not displayed as a false low RPM.
- The main screen refreshes the RPM field at 250 ms intervals even when the value is `0000`, preventing a stale display value after a stop.
- This does not alter PA0 trigger qualification or the PA8 STEP scheduling path. RPM correctness still depends on receiving valid proximity edges and must be checked against a tachometer/logic analyzer on the machine.

## GitHub Actions build
The workflow at `.github/workflows/auto_unzip_compile.yml` runs host regression tests and compiles the sketch using the official STM32duino core for `STMicroelectronics:stm32:GenF1:pnum=BLUEPILL_F103C8`. The compiled `.bin` is uploaded as a GitHub Actions artifact. Open **Actions → latest workflow run → Artifacts** to retrieve it.

## Local build
Install Arduino CLI, the STM32duino core and the `LiquidCrystal I2C` library, then run:

```bash
arduino-cli core install STMicroelectronics:stm32
arduino-cli lib install "LiquidCrystal I2C"
arduino-cli compile --fqbn STMicroelectronics:stm32:GenF1:pnum=BLUEPILL_F103C8 \
  --warnings all --output-dir build --export-binaries \
  STM32_Zipper_CNC_V16_5_4_Firmware
```

Run host tests with:

```bash
bash tests/run_tests.sh
```

## Hardware verification required before production
Host tests and GitHub compilation cannot establish real trigger-to-needle timing. On the actual board, verify with an oscilloscope/logic analyzer:

1. PA0 proximity edge and PA8 STEP pulse timing simultaneously.
2. PA8 idle level, active-low pulse width and pulse count at slow and maximum intended speed.
3. Confirm PA0 hardware-capture intervals and PA8 STEP spacing on a logic analyzer; verify TIM2 capture-overrun count stays at zero.
4. MODE size changes while stopped, then power-cycle to confirm persistence.
5. Auto-save while stopped; verify no watchdog reset and verify stored settings after reboot.
6. Confirm the DM542 input wiring/level shifter accepts PA8 active-low pulses and common-ground/reference wiring is correct.

**Important validation status:** this editing environment does not have the Arduino STM32 target toolchain attached. Do not interpret a successful ZIP operation or host tests as a completed target compile or hardware test. The GitHub workflow is included to perform the target compile.

## Project layout
- `STM32_Zipper_CNC_V16_5_4_Firmware/`: Arduino sketch source folder used by the CI build.
- `include/`, `src/`: shared headers.
- `tests/`: host-side regression tests.
- `.github/workflows/auto_unzip_compile.yml`: GitHub Actions host-test + STM32 compile pipeline.
- `CHANGELOG_FINAL.md`: historical change log; older pin references in historical entries describe previous revisions.

## Factory-floor audit follow-up
The auto-save and settings UI now report persistence success only after `saveToEEPROM()` returns success. Failed saves are reported explicitly and pending-save state is retained for retry at a later safe standstill. Host regression suite: 27 suites passed after the TIM2 hardware-capture correction. Confirm the GitHub Actions STM32 compile and perform supervised hardware tests before production use.

### Live read-only diagnostics during motion
Open the existing Info/Diag screen before starting the machine. It now remains visible while the machine runs and refreshes live status approximately every 150 ms. UP/DOWN scroll diagnostic pages. The optocoupler sink test is blocked while motion is active; configuration menus still auto-exit on motion start. This feature is intended for observation only and does not establish that RPM readings or hardware behavior are correct; verify on the actual controller/machine.

### LCD settings display update
The settings menu now shows `Open Diagnostics` for option 12 and `Apply & Exit` for option 13. Settings/detail LCD rows are written as fixed 16-character lines to prevent leftover characters when labels or values become shorter. Historical validation note: 25 suites passed at that earlier revision; the current revision has 27 host suites passing. Target compilation and hardware display validation remain to be performed.


### Additional source audit correction (2026-10-09)
- Corrected the settings-menu engine label: the production STEP generator is TIM1; TIM2 is reserved for PA0 input capture.
- Renamed settings option 11 to `STEP Engine` and its detail to `Select STEP Mode`; option 12 remains the separate `Open Diagnostics` entry.
- Corrected the source-consistency test's printed firmware version from V16.5.8 to V16.5.9.
- These are source/UI/documentation consistency corrections. They do not establish physical RPM stability or hardware timing; target compilation and machine tests remain required.
