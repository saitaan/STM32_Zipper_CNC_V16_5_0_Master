# Factory-floor source audit — 2026-10-09

## Confirmed configuration math
- Driver resolution 6400 and roller diameter 45.0 mm are consistent with the source's pulse profiles.
- Calculated circumference is pi * 45 mm. The source pulse profiles correspond to about 45.27 steps/mm: Size #5 (2.50 mm) = 113.176848 steps, Size #8 (3.00 mm) = 135.812218 steps, Size #10 (4.00 mm) = 181.082957 steps.
- At Max RPM 3000, Feed Angle 160 degrees, Safety Margin 10%, the available feed window is 8000 us/revolution. Approximate step periods are 70.69 us (#5), 58.90 us (#8), and 44.18 us (#10), all above the 8 us minimum. These defaults are mathematically feasible; real zipper length still depends on the actual feed mechanics and calibrated output.

## Corrections made in this audit package
- Corrected Settings option 11's misleading `Engine/Diag` / `View System Diag` labels to `STEP Engine` / `Select STEP Mode`.
- Corrected the engine detail label from `TIM2: >HW` to `TIM1: >HW`. TIM1 generates PA8 STEP; PA0 EXTI is the motion trigger.
- Corrected related comments and all three synchronized copies of `hardware_capture_spec.h`, which still incorrectly described PA1/TIM2_CH2 as the STEP output.
- Corrected the source-consistency test's printed release label to V16.5.9.
- Kept the RPM 3-interval median and added a separate STEP-scheduling interval selection using the 3-interval median after the history fills. Raw interval remains the input for trigger qualification and watchdog.
- Corrected the earlier mixed timestamp design by making TIM2_CH1 capture IRQ the sole trigger source. PA0 EXTI is no longer attached, so capture flags cannot race against a separate EXTI callback. TIM2 IRQ extends the 16-bit counter and consumes CCR1 only when CC1IF is set; DMA remains disabled.
- A >2 s idle gap now re-baselines the interval and uses the startup STEP period for that trigger rather than treating idle time as a real revolution.
- Replaced the misleading Capture Health diagnostic page with STEP Timing Filter; page 11 shows interval-history count and capture-overrun count, while page 10 shows interval jitter.

## Remaining technical risk — requires target and machine validation
- TIM2 hardware capture removes CPU interrupt-entry latency from the timestamp itself. However, a CC1 overcapture means at least one physical edge was overwritten before service and cannot be reconstructed from CCR1 alone. Check overrun diagnostics and verify the capture-to-STEP behavior on the target board.
- PC13 status indication is tied to PA0 trigger activity, not an independent firmware-health heartbeat. A missed/rejected PA0 event can therefore look like a heartbeat drop.
- STEP pulse timing also depends on TIM1 update/preload behavior and the physical driver/input wiring. Host tests cannot prove PA8 pulse continuity or stitching position.
- Keep production stitching stopped until the target build is successful and supervised physical tests confirm stable PA0 intervals, continuous PA8 pulse spacing, and repeatable stitching position.

## Verification performed here
- `bash tests/run_tests.sh`: 27 host suites passed after restoring sole-source TIM2 hardware capture.
- Source/header copies are synchronized; ZIP integrity is checked when the release archive is created.
- Not performed: STM32 target compilation, physical LCD check, tachometer measurement, oscilloscope/logic-analyzer validation, or full stitching test.
