# Changelog — V16.5.9 PA0 EXTI timing guard + PA8/TIM1

## Current update
- Confirmed target: STM32F103C8T6.
- PA0 proximity sensor is captured on TIM2_CH1 falling edge; TIM2_IRQHandler is the sole trigger processor and extends the 1 MHz counter across 16-bit overflows. EXTI is not attached to PA0.
- PA8 is configured as TIM1_CH1 active-low hardware STEP/PUL output.
- TIM1 generates PA8 STEP pulses; hardware-captured TIM2 timestamps estimate trigger intervals, with a median filter for STEP period scheduling.
- MODE zipper-size hold window extended from 1.5–3 seconds to 1.5–8 seconds; 8-second hold remains reserved for hidden settings.
- Persistence now checks safe standstill before requesting the save lock and feeds the watchdog around early exits and Flash write/readback path.
- GitHub Actions workflow corrected to run host tests and compile the actual sketch folder, then publish the binary artifact.

## Validation notes
- Host test results must be obtained by running `bash tests/run_tests.sh` or from the GitHub Actions run.
- Target compilation is delegated to GitHub Actions; no local STM32 target compile is claimed here.
- Oscilloscope/logic-analyzer validation on the actual machine is mandatory before production use, especially for PA8 pulse polarity/width, PA0-to-PA8 synchronization, watchdog behavior during persistence, and MODE size retention.
- Historical files and comments may refer to PA1/TIM2 because that was the previous hardware mapping; the current main sketch is the source of truth for PA8/TIM1.


## RPM display update
- RPM display field now refreshes periodically while stopped as well as running, so stale RPM digits are cleared.
- RPM values are derived only from a measured interval of 0–2,000,000 us; longer gaps are treated as standstill/new-start conditions rather than a displayed low-speed reading.
- No trigger pin, STEP pin, pulse-count, button mapping, or timer mapping changed in this RPM-only update.

## Factory-floor audit follow-up (2026-10-09)
- Fixed auto-save UI correctness: `AUTO-SAVED OK!` is shown only when `saveToEEPROM()` reports a verified successful transaction.
- Failed auto-save now displays `SAVE FAILED!` and keeps the pending-save state for a later safe retry.
- MODE zipper-size commit now reports a failed persistence transaction instead of implying the save succeeded; the selected size remains a RAM change until successfully saved.
- Settings-apply save path now checks the transaction result and retains pending retry state on failure.
- Re-ran the included host regression suite: 25 suites passed. This is not a substitute for STM32 target compilation or physical-machine validation.

## Read-only live diagnostics update
- Info/Diag menu (menuState 9) is retained when motion starts, instead of being auto-exited like configuration menus.
- The Info/Diag LCD page refreshes while running (rate-limited to 150 ms) so RPM, proximity interval, sync state, capture counters, and step/guard status remain live.
- Optocoupler sink test remains standstill-only; its page explicitly displays `BLOCKED: RUNNING` during motion.
- PA0 trigger capture and PA8 STEP generation paths were not intentionally modified by this UI-only change.
- Validation: host test runner passed 25 suites. This is not a target-board compile or physical-machine test.

## LCD settings-menu display fix (2026-10-09)
- Fixed option 12 second-line label to `Open Diagnostics`.
- Added option 13 second-line label `Apply & Exit`.
- Added a fixed-width 16-column LCD line writer for settings and menu-detail screens to clear trailing characters consistently.
- Initialized menu line buffers so options without an explicit second-line value do not use uninitialized text.
- No pin assignments, sensor logic, RPM estimation, or motion scheduling logic intentionally changed.
- Verification: `tests/run_tests.sh` completed with 25 host-test suites passing. STM32 target compilation and physical LCD/hardware testing were not performed.


## Additional audit correction (2026-10-09)
- Corrected settings-menu engine labels and comments: TIM1 drives PA8 STEP; PA0 EXTI is the motion trigger.
- Rewrote all three synchronized `hardware_capture_spec.h` copies to remove obsolete PA1/TIM2 STEP descriptions and to document timer ownership accurately.
- Corrected the source-consistency test's printed release label to V16.5.9.
- These changes fix menu/documentation/test-label mismatches; they do not replace target compilation or on-machine timing validation.

## V16.5.9 STEP timing guard correction (2026-10-09)
- Corrected the earlier timing-guard approach: TIM2_CH1 hardware capture is restored as the sole trigger source, rather than disabling hardware capture. PA0 EXTI is not attached, eliminating competing interrupt paths.
- STEP burst period now uses the median of the last three accepted intervals once available, while raw timing remains in use for qualification and watchdog decisions.
- Standstill restart (>2 s gap) re-baselines timing and uses the configured startup estimate for the first burst.
- Diagnostics page 11 now reports STEP timing filter history/jitter instead of inactive capture-overrun counters.
- Added regression checks for the sole TIM2 capture IRQ source, extended timestamp handling, median scheduler input, and standstill re-baseline.
- Validation: 26 host test suites passed. Target compile and physical machine validation are still required; this does not prove the stitch-position shift is solved.


## Sole TIM2 hardware-capture correction (2026-10-09)
- Restored TIM2_CH1 falling-edge capture as the only PA0 trigger source; removed the PA0 EXTI attachment to prevent duplicate/racing edge processing.
- Added a TIM2 IRQ that extends the 1 MHz 16-bit timer with update interrupts, handles capture/overflow coincidence, and consumes CCR1 only when CC1IF is pending.
- Added capture-overrun counting and exposed the overrun count on diagnostic page 11 (`O`); interval jitter remains on page 10.
- Updated regression tests and CI artifact names for the capture-based build.
- Validation performed: 27 host test suites passed. STM32 target compilation and physical machine timing/stitching validation remain unverified in this environment.
