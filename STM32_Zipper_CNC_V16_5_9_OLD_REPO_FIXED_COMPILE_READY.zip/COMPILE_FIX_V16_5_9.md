# V16.5.9 Compile Fix

Fixed the `SERVO_CAPTURE_DMA_SAMPLES` preprocessor definition ordering. The macro is now defined before its first use and appears only once.
This package is intended to be uploaded as a ZIP to the existing/old GitHub repository; the repository's existing workflow remains responsible for the build.
