// Servo capture / DMA configuration
#define SERVO_CAPTURE_DMA_SAMPLES 32U

#include <cmath>
/*
====================================================================================================
PROJECT  : STM32 ZIPPER CNC (ADAPTIVE SERVO-SYNC MASTER-FOLLOWER ENGINE)
VERSION  : 16.5.9 (PA0->PA8 PRIMARY MOTION / TIM2 CAPTURE + TIM1 STEP)
AUTHOR   : RAJESH SHAH / INDUSTRIAL AUTOMATION & EMBEDDED SYSTEMS
DATE     : SEPTEMBER 2026
TARGET   : STM32F103C8T6 (32-BIT ARM CORTEX-M3 @ 72MHz)
LOCATION : NIPON ZIPPER INDUSTRIES PVT LTD, SARIGAM GIDC, GUJARAT, INDIA

VERSION 16.5.0 ARCHITECTURAL ADVANCEMENTS & HARDWARE-LEVEL ENGINE:
1. PRIMARY PROXIMITY->STEP HARDWARE PATH:
   - PA0 is the master proximity input; PA8 is the hardware-timed STEP output.
   - TIM1 hardware generation is the production/default engine; DDA is restored as an operator-selectable diagnostic/alternate engine for timing comparison.
   - First PA0 edge is accepted immediately; the first measured interval establishes real servo synchronization and arms Motion Lost monitoring.
2. OPTIONAL AUXILIARY SENSOR / RELAY SUBSYSTEM:
   - PA3: optional Tape Run-Out sensor.
   - PB0: optional future Coil/Thread sensor.
   - PB3: optional future sensor.
   - PB1: optional Motor Stop Relay.
   - All auxiliary features are OFF by default and have no authority over PA0 capture or PA8 STEP timing.
   - A qualified enabled sensor may request PB1; it never aborts the current STEP burst.
   - Motion Lost may request PB1 only after a real measured PA0 interval has armed the watchdog.
3. BOOTUP HARDWARE RELAY GLITCH SUPPRESSION:
   - Atomic GPIOB->BRR clear on PB1 before setting pinMode to eliminate contact chatter on reset.
4. BACKWARDS-COMPATIBLE THREE-TIER EEPROM MIGRATION:
   - Automatically migrates existing V16.3.3 (0x5A431633) and V16.4.0 (0x5A431640) calibration parameters
     into V16.5.0 (0x5A431650) without resetting roller diameter or driver resolution.
5. 64-BIT DOUBLE PRECISION 1,000,000x DDA MATH:
   - Guaranteed < 0.025 mm error over 1.6 km of fed zipper tape.
====================================================================================================
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>
#include "burst_queue.h"
#include "motion_scheduler.h"
#include "hardware_capture_spec.h"
#include "safety_sensors.h"
#include "pulsestep_persistence.h"
#ifndef nvic_irq_enable
#define nvic_irq_enable(irq) NVIC_EnableIRQ(irq)
#endif

LiquidCrystal_I2C lcd(0x27, 16, 2);

// =========================================================================
// BUILD IDENTIFIERS & SOURCE-TO-BINARY METADATA
// =========================================================================
#define FW_VERSION_STR       "V16.5.9-PA0-PA8-TIM2-CAPTURE-TIM1-STEP"
#define FW_BUILD_DATE_STR    "OCT-2026"
#define FW_BUILD_METADATA    "NIPON_ZIPPER_CNC_FW_V16_5_9_PA0_PA8_TIM2_CAPTURE_TIM1_STEP:OCT-2026:PRIMARY-MOTION"

// Embedded ROM identifier string for binary provenance verification
const char g_firmware_build_tag[] __attribute__((used)) = FW_BUILD_METADATA;

// Hardware Pin Definitions (100% Backwards-Compatible Pinout)
const int statusLedPin      = PC13; // Built-in Onboard LED (Active-LOW: LOW=ON, HIGH=OFF)
#define STATUS_LED_ON()    (GPIOC->BRR = (1 << 13))   // Atomic Clear PC13 -> LED ON
#define STATUS_LED_OFF()   (GPIOC->BSRR = (1 << 13))  // Atomic Set PC13   -> LED OFF
const int proxSensorPin     = PA0;  // Cam Proximity (PC817 Opto, Clean MCU GND, Falling ISR)
const int stepPin           = PA8;  // Driver STEP/PUL (Hardware TIM1_CH1)
const int dirPin            = PA2;  // Driver DIR- via Level Shifter CH4 LV (GPIOA Pin 2)
// =========================================================================
// SENSOR POLARITY & FAIL-SAFE LOGIC DEFINITIONS
// Industrial optical sensors via PC817 optocoupler with STM32 INPUT_PULLUP:
// - NORMAL STATE (Tape/Coil Present): Sensor actively conducts, pulling pin LOW (0V).
// - FAULT STATE (Tape Run-Out / Break / Cable Cut): Optocoupler OFF, pin pulled HIGH (3.3V).
// Fail-safe: Wire break, disconnected sensor, or power loss safely trips E-Stop.
// =========================================================================
#define SENSOR_STATE_NORMAL     LOW   // Sunk to GND (0V) by conducting PC817 phototransistor
#define SENSOR_STATE_FAULT      HIGH  // Pulled to 3.3V by internal pull-up (Fail-Safe Open)

const int tapeSensorPin     = PA3;  // Tape Run-Out Optical Sensor (PC817 Ch 1: Normal=LOW, Fault/Broken=HIGH)
const int coilSensorPin     = PB0;  // Coil Breakage Fiber Sensor (PC817 Ch 2: Normal=LOW, Fault/Broken=HIGH)
const int mainMotorRelayPin = PB1;  // Optional Main Motor Stop Relay (Active-HIGH Trip / NC Clutch Loop)
const int futureSensor2Pin  = PB3;  // Future auxiliary sensor #2; intentionally OFF by default
const int btnUp             = PB13; // UP Button (Swapped to match physical panel wiring)
const int btnDown           = PB12; // DOWN Button (Swapped to match physical panel wiring)
const int btnMode           = PB14; // MODE Multi-Function Button (Active-LOW to Clean MCU GND)

// Direct Register Bit Set/Reset (1-Cycle 13.8ns Sinking)
#define STEP_LOW_ACTIVE()  (GPIOA->BSRR = (1 << (8 + 16)))
#define STEP_HIGH_IDLE()   (GPIOA->BSRR = (1 << 8))
#define DIR_LOW()          (GPIOA->BSRR = (1 << (2 + 16)))
#define DIR_HIGH()         (GPIOA->BSRR = (1 << 2))

// 1,000,000x Micro-Fractional DDA Fixed-Point Scaling Factor (6 Decimal Places)
#define FIXED_SCALE 1000000ULL

// IWDG: Independent Watchdog Timer (40kHz LSI / 256 Prescaler -> 6.4ms/count, RLR=500 -> ~3.2s Timeout)
#define IWDG_INIT() do {     IWDG->KR = 0x5555;     IWDG->PR = 0x06;       IWDG->RLR = 500;       IWDG->KR = 0xAAAA;     IWDG->KR = 0xCCCC; } while (0)
#define IWDG_FEED() (IWDG->KR = 0xAAAA)

#define EEPROM_MAGIC_V16_3_3 0x5A431633UL
#define EEPROM_MAGIC_V16_4_0 0x5A431640UL
#define EEPROM_MAGIC         0x5A431650UL

// Persistent EEPROM Storage Configuration Structure
#define EEPROM_MAGIC_V16_5_1 0x5A431651UL

// Legacy V16.5.0 Struct (52 bytes) - preserved for automatic field migration
struct MachineConfigLegacy {
    uint32_t p5_fixed;
    uint32_t p8_fixed;
    uint32_t p10_fixed;
    int32_t  driverResolution;
    float    rollerDia;
    int32_t  maxRPMSetting;
    int32_t  feedAngleDeg;
    int32_t  safetyMarginPercent;
    int32_t  currentSize;
    uint32_t sensorGuardActive; // Legacy field: bit0=PA3 Tape, bit1=PB0 Coil, bit2=PB3 Future, bit3=Motion->PB1
    uint32_t hardwareTimerMode; // 0: AUTONOMOUS HW TIMER (DEFAULT), 1: CLASSIC DDA ENGINE
    uint32_t motorDirection;   // 0: NORMAL [FWD] (DEFAULT), 1: REVERSE [REV]
    uint32_t magic;
};

// =========================================================================
// PERSISTENT EEPROM CONFIGURATION STRUCTURE
// Authoritative structure size is dynamically enforced by sizeof(MachineConfig).
// Structure layout features 64-bit safe fixed-point pulse counts (p5, p8, p10)
// and 32-bit hardware parameters. magic header is placed at Offset 0 (0x5A431651UL)
// to uniquely differentiate from legacy V16.5.0/V16.4.0/V16.3.3 memory images.
// =========================================================================
struct MachineConfig {
    uint32_t magic;             // Offset 0: 0x5A431651UL (Magic header)
    uint32_t reserved;          // 64-bit alignment padding
    uint64_t p5_fixed;          // 64-bit safe fixed point (avoids uint32 overflow at 51200 res)
    uint64_t p8_fixed;          // 64-bit safe fixed point
    uint64_t p10_fixed;         // 64-bit safe fixed point
    int32_t  driverResolution;
    float    rollerDia;
    int32_t  maxRPMSetting;
    int32_t  feedAngleDeg;
    int32_t  safetyMarginPercent;
    int32_t  currentSize;
    uint32_t sensorGuardActive; // Legacy field: bit0=PA3 Tape, bit1=PB0 Coil, bit2=PB3 Future, bit3=Motion->PB1
    uint32_t hardwareTimerMode; // 0: AUTONOMOUS HW TIMER (DEFAULT), 1: CLASSIC DDA ENGINE
    uint32_t motorDirection;   // 0: NORMAL [FWD] (DEFAULT), 1: REVERSE [REV]
};

// 6-Decimal Exact Mathematical Pitch Pulses (6400 Resolution / 45.0mm Roller Diameter)
uint64_t p5_fixed  = 113176848ULL; // Size #5 (2.50mm): 113.176848 steps
uint64_t p8_fixed  = 135812218ULL; // Size #8 (3.00mm): 135.812218 steps
uint64_t p10_fixed = 181082957ULL; // Size #10 (4.00mm): 181.082957 steps

int32_t driverResolution    = 6400;
float   rollerDia           = 45.0f;
int32_t maxRPMSetting       = 3000;
int32_t feedAngleDeg        = 160;
int32_t safetyMarginPercent = 10;
bool    sensorGuardActive   = false; // PA3 Tape Guard; OFF by default
bool    coilGuardActive     = false; // PB0 future Coil/Thread sensor; OFF by default
bool    pb3GuardActive      = false; // PB3 future sensor; OFF by default
bool    motionRelayEnabled  = false; // Motion-sync -> PB1 relay; OFF by default
// IMPORTANT: Auxiliary features never own the PA0->PA8 timing path. They may request PB1 only.
volatile bool hardwareTimerMode   = true;  // DEFAULT: TRUE (TIM1/PA8 HARDWARE ENGINE); FALSE = DDA DEBUG ENGINE

bool    motorDirection      = false; // DEFAULT: FALSE (NORMAL / FORWARD ROTATION)
#define SENSOR_FEATURE_PA3_TAPE       (1UL << 0)
#define SENSOR_FEATURE_PB0_COIL       (1UL << 1)
#define SENSOR_FEATURE_PB3_FUTURE     (1UL << 2)
#define SENSOR_FEATURE_MOTION_RELAY   (1UL << 3)

static inline uint32_t sensorFeatureMask() {
    return (sensorGuardActive ? SENSOR_FEATURE_PA3_TAPE : 0UL) |
           (coilGuardActive ? SENSOR_FEATURE_PB0_COIL : 0UL) |
           (pb3GuardActive ? SENSOR_FEATURE_PB3_FUTURE : 0UL) |
           (motionRelayEnabled ? SENSOR_FEATURE_MOTION_RELAY : 0UL);
}

static inline void applySensorFeatureMask(uint32_t mask) {
    sensorGuardActive  = (mask & SENSOR_FEATURE_PA3_TAPE) != 0UL;
    coilGuardActive    = (mask & SENSOR_FEATURE_PB0_COIL) != 0UL;
    pb3GuardActive     = (mask & SENSOR_FEATURE_PB3_FUTURE) != 0UL;
    motionRelayEnabled = (mask & SENSOR_FEATURE_MOTION_RELAY) != 0UL;
}

bool    tempMotorDir        = false; // Staged Menu Direction

extern volatile bool hwBurstActive;
extern volatile int stepsRemaining;
void stopHardwareTimerImmediately();

// Hardware-level Motor Direction Controller (PA2 DIR-)
void applyMotorDirection() {
    // Safety: ensure any active movement is completely stopped before changing DIR pin
    if (hwBurstActive || stepsRemaining > 0) {
        stopHardwareTimerImmediately();
    }
    delayMicroseconds(20); // Safe hold time after last step pulse before DIR edge
    if (motorDirection) {
        DIR_LOW();  // Active-LOW sinking for Reverse rotation
    } else {
        DIR_HIGH(); // Idle-HIGH for Normal Forward rotation
    }
    delayMicroseconds(20); // Safe setup time (exceeds 5us DM542 specification by 400%)
}


int autoPulseWidth_P5   = 25;
int autoPulseWidth_P8   = 29;
int autoPulseWidth_P10  = 22;
volatile int activePulseWidth = 70; // Nominal 70us step period (~14.2 kHz) for 3000 RPM / 160 deg
unsigned long dynamicDebounceUs = 3000UL; // 3.0ms: Rejects EMI, supports 12 to 20,000 RPM

int32_t resStepGear    = 100;
float   diaStepGear    = 0.1f;
int32_t rpmStepGear    = 100;
int32_t angleStepGear  = 5;
int32_t marginStepGear = 1;

int32_t currentSize = 1; // 1: #5 (2.50mm), 2: #8 (3.00mm), 3: #10 (4.00mm)
// =========================================================================
// ATOMIC COHERENT PULSE PARAMETER SNAPSHOT & TELEMETRY
// =========================================================================
#ifndef DEBUG_TEST_MODE
#define DEBUG_TEST_MODE 0
#endif

struct PulseParameters {
    uint32_t integerPart;
    uint32_t fractionalPart;
    uint32_t generation;

    PulseParameters() : integerPart(113), fractionalPart(176848UL), generation(1) {}
    PulseParameters(uint32_t i, uint32_t f, uint32_t g) : integerPart(i), fractionalPart(f), generation(g) {}
    PulseParameters(const PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters(const volatile PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters& operator=(const PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    PulseParameters& operator=(const volatile PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    void operator=(const PulseParameters& o) volatile {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
    }
};

BurstQueue burstQueue;
volatile uint32_t captureOverrunCount = 0;
volatile uint32_t tim4_overflow_count = 0;

volatile PulseParameters activePulseParams   = {113, 176848UL, 1};
PulseParameters          pendingPulseParams  = {113, 176848UL, 1};
volatile uint32_t        paramGenerationUsed = 1;

// =========================================================================
// PRODUCTION TRIGGER-TO-STEP ACCOUNTING & DIAGNOSTIC COUNTERS (V16.5.9)
// =========================================================================
volatile uint32_t receivedTriggers       = 0; // Total physical PA0 trigger edges entering ISR
volatile uint32_t acceptedTriggers       = 0; // Valid triggers passed through qualification
volatile uint32_t generatedStepBursts    = 0; // STEP bursts started or enqueued
volatile uint32_t completedStepBursts    = 0; // STEP bursts completed by hardware timer
volatile uint32_t queueOverflowCount     = 0; // Times burstQueue.enqueue() was rejected due to full queue
volatile uint32_t deferredTriggerCount   = 0; // Triggers deferred during Flash save transactions
volatile uint32_t rejectedTriggerCount   = 0; // Spurious noise / over-speed triggers filtered out

volatile bool     hasValidPriorTrigger   = false;
volatile bool     isTriggerOverflowTripped = false;

// Production accounting & regression counters
volatile uint32_t acceptedTriggerCount   = 0;
volatile uint32_t triggerMissedCount     = 0;
volatile uint32_t requestedPulseCount    = 0;
volatile uint32_t startedPulseCount      = 0;
volatile uint32_t completedPulseCount    = 0;
volatile uint32_t abortedPulseCount      = 0;
volatile uint32_t queuedPulseCount       = 0;
volatile uint32_t burstStartedCount      = 0;
volatile uint32_t burstCompletedCount    = 0;
volatile uint32_t burstQueuedCount       = 0;
volatile uint32_t paramGenChangesCount   = 0;
volatile uint32_t maxISRLatencyCycles    = 0;
volatile uint32_t maxTriggerJitterUs     = 0;
volatile uint32_t assertionFailureCount  = 0;
volatile uint32_t triggerIntegrityFaultCount = 0;
volatile uint32_t triggerOvercaptureFaultCount = 0;
volatile uint32_t pulseTimingFaultCount = 0;
volatile uint32_t dmaCaptureWrapCount = 0;
volatile uint32_t dmaCaptureLastRemaining = SERVO_CAPTURE_DMA_SAMPLES;
volatile uint32_t dmaCaptureAuditSamples = 0;
volatile uint32_t dmaCaptureAuditMisses = 0;
volatile uint32_t captureAuditMismatchCount = 0;
volatile uint32_t captureAuditMaxErrorUs = 0;
volatile uint32_t captureAuditLastErrorUs = 0;
volatile uint16_t lastTim2Capture16 = 0;
volatile uint32_t lastTim2CaptureCycles = 0;
volatile bool tim2CaptureAuditArmed = false;
volatile uint32_t triggerEdgeTimestampUs = 0;
volatile uint32_t triggerEdgeTimestampCycles = 0;

// Hardware timing policy:
// PA0 EXTI is the earliest software event, while TIM2 CH1 is a simultaneous
// silicon capture/DMA reference. TIM1/PA8 owns STEP generation independently.
// The two PA0 timing observations are cross-checked cycle-by-cycle; a mismatch
// beyond the hardware qualification tolerance is treated as an integrity fault
// rather than silently accepting a potentially phase-shifted trigger.

void commitPulseParameters(uint32_t intPart, uint32_t fracPart) {
    pendingPulseParams.integerPart    = intPart;
    pendingPulseParams.fractionalPart = fracPart;
    pendingPulseParams.generation++;
#if DEBUG_TEST_MODE
    paramGenChangesCount++;
#endif
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    activePulseParams.integerPart = pendingPulseParams.integerPart;
    activePulseParams.fractionalPart = pendingPulseParams.fractionalPart;
    activePulseParams.generation = pendingPulseParams.generation;
    __set_PRIMASK(primask);
}

volatile uint64_t currentPulsesFixed = 113176848ULL;
volatile uint32_t currentPulsesInt   = 113;      // Whole step portion for fast 32-bit ISR math
volatile uint32_t currentPulsesFrac  = 176848UL; // Fractional micro-step portion (< 1,000,000)
volatile uint32_t pulseFracAccumulator = 0UL;     // 32-bit fractional accumulator (zero 64-bit division)
volatile uint64_t pulseAccumulatorFixed = 0ULL;
volatile uint32_t lastTriggerCycles    = 0;
volatile bool pendingMenuExit = false;
uint64_t stepGearFixed = 1000000ULL; // 1.00 pulse tuning step (1,000,000 units)

bool isUiLocked = true;
unsigned long lastUnlockActivity = 0UL;
unsigned long confirmDialogStartTime = 0UL;

// =========================================================================
// 1-MINUTE CONTINUOUS SMOOTH RUN AUTO-SAVE STATE MACHINE
// Gated strictly to 0 RPM Standstill (Zero Pulse & Trigger Interference)
// Anti-Repeat Latch: Saved exactly once per parameter modification
// =========================================================================
bool pulseModifiedByUser            = false;  // Armed when user tunes pulse with UP/DOWN
unsigned long smoothRunStartMillis   = 0UL;    // Legacy fallback timer
bool autoSavePendingStandstill       = false;  // Set when 60s qualified in RAM; deferred to 0 RPM
AutoSaveQualificationEngine autoSaveEngine(60000UL); // Formal 60-Second Auto-Save Engine
FlashSaveTransactionEngine  flashSaveTx;             // Atomic Flash Save Transaction Engine
// Safe deferred auto-save: never write Flash/EEPROM while motion is active.
bool safeAutoSavePending = false;
uint32_t safeAutoSaveDueMs = 0UL;
bool exitSaveChoice = true; // true = SAVE & EXIT, false = EXIT WITHOUT SAVE
bool bootSplashActive = false;
uint32_t bootSplashUntilMs = 0UL;

// Hardware Overcapture State Tracking (Prompt 6Writing Section 3)
volatile bool     isCaptureStreamDiscontinuous   = false;
volatile uint32_t knownOvercaptureLostPulses     = 0;
volatile uint32_t lastOvercaptureTimestampUs     = 0;
volatile uint32_t captureResyncCount             = 0;
volatile uint32_t acceptedTriggerPulses          = 0;

// Authoritative PulseStep Persistence State Tracking
uint32_t flashWriteCount            = 0;      // Diagnostic counter: strictly increments on actual Flash write
uint32_t activeEEPROMSlot           = 0;      // Active transaction slot (0 or 1)
uint32_t eepromSeqNumber            = 0;      // Monotonic transaction sequence counter
uint64_t pulseStepStored_p5         = 113176848ULL; // Stored ROM baseline for Size #5
uint64_t pulseStepStored_p8         = 135812218ULL; // Stored ROM baseline for Size #8
uint64_t pulseStepStored_p10        = 181082957ULL; // Stored ROM baseline for Size #10


unsigned long uiMessageTimer = 0UL;
const char* uiBannerLine1 = nullptr;
const char* uiBannerLine2 = nullptr;

// Staged RAM Parameters for Zero Flash Wear
int32_t tempDriverRes       = 6400;
float   tempRollerDia       = 45.0f;
int32_t tempMaxRPM          = 3000;
int32_t tempFeedAngle       = 160;
int32_t tempSafetyMargin    = 10;

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm);

static inline bool stagedTimingConfigurationFeasible() {
    return timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, 2.50) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, 3.00) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, 4.00);
}

// True when the manually tuned pulse count cannot fit inside the configured
// feed-angle window at the configured maximum RPM. Never silently clamp an
// invalid manual tuning to the 8us timer floor.
volatile bool pulseTimingInvalid = false;

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#ifndef SERVO_PERIOD_Q_SHIFT
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U
#endif

static inline bool currentPulseTimingFeasible() {
    if (driverResolution < 200 || driverResolution > 51200 || rollerDia < 15.0f || rollerDia > 100.0f ||
        maxRPMSetting < 100 || maxRPMSetting > 4000 || feedAngleDeg < 30 || feedAngleDeg > 270 ||
        safetyMarginPercent < 0 || safetyMarginPercent > 25) return false;
    const double circumference = 3.14159265358979323846 * (double)rollerDia;
    const double stepCount = (double)currentPulsesFixed / 1000000.0;
    const double windowUs = (60000000.0 / (double)maxRPMSetting) * ((double)feedAngleDeg / 360.0) *
                            (1.0 - ((double)safetyMarginPercent / 100.0));
    return stepCount > 0.0 && windowUs > 0.0 && (windowUs / stepCount) >= (double)SERVO_PERIOD_MIN_US;
}

static inline void refreshPulseTimingValidity() {
    pulseTimingInvalid = !currentPulseTimingFeasible();
}
bool    tempSensorGuard     = false;
bool    tempCoilGuard        = false;
bool    tempPb3Guard         = false;
bool    tempMotionRelay      = false;
bool    tempHwTimerMode     = true;  // staged engine selection: true=TIM1/PA8, false=DDA
bool    hasStagedChanges    = false;
bool    isTimingWarningActive = false;
int diagMinW = 0;
const char* diagFixLine1 = nullptr;
const char* diagFixLine2 = nullptr;
int infoIndex = 1;

// Optical Safety Guard State Machine
unsigned long sensorTripStartTime = 0UL;
volatile bool isSensorFaultTripped = false;
volatile bool isMotionSyncLost     = false; // Diagnostic state; never blocks PA0/PA8 timing
volatile bool motionWatchdogArmed   = false; // Armed only after a valid measured trigger interval
volatile uint32_t validTriggerCount  = 0;
volatile bool auxSensorFaultActive  = false; // Auxiliary sensor fault; may trip PB1 but never cancels STEP
volatile int  faultType            = 0;     // 0: None, 1: Tape Run-Out, 2: Coil Breakage, 3: Trigger Sync Lost
// queuedBurstSteps removed: SPSC BurstQueue burstQueue is the single authoritative production scheduling queue

// Stepper Step State Machine
volatile bool triggerPull = false;
volatile unsigned long lastTriggerMicros = 0UL;
volatile unsigned long lastMeasuredIntervalUs = 0UL;
volatile unsigned long rawIntervalMicros = 0UL;
volatile int stepsRemaining = 0;
volatile int totalStepsInBurst = 0;
volatile int currentStepIndex = 0;
volatile bool stepPinState = HIGH;
volatile unsigned long lastStepMicros = 0UL;

// Hardware Timer 2 Burst Controller State
volatile bool hwBurstActive = false;
volatile int  hwBurstStepsTarget = 0;
volatile int  hwBurstStepsDone = 0;

volatile unsigned long currentRPM = 0UL;
unsigned long lastDisplayUpdate = 0UL;
unsigned long lastRpmDisplayUpdate = 0UL;
unsigned long lastButtonCheck = 0UL;
unsigned long modePressTime = 0UL;
unsigned long lastModeClickTime = 0UL;
unsigned long upPressTime = 0UL;
unsigned long downPressTime = 0UL;
unsigned long dualPressTime = 0UL;

bool modePressed = false;
bool upDownPressed = false;
bool pendingSingleClick = false;

int menuState = 0;
int oldMenuState = -1;
int hiddenOption = 1;
bool resetChoice = false;

// Hardware Timer 2 Instance for Stepping Pulses
// =========================================================================
// AUTHORITATIVE CNC MOVEMENT STATE MACHINE
// IDLE -> ARMED -> RUNNING -> STOPPING -> COMPLETE -> IDLE
// Fault/Abort: RUNNING/STOPPING -> FAULT/ABORTED -> IDLE (Standstill Gated)
// =========================================================================
enum MovementState {
    STATE_IDLE = 0,
    STATE_ARMED,
    STATE_RUNNING,
    STATE_STOPPING,
    STATE_COMPLETE,
    STATE_ABORTED,
    STATE_FAULT
};
volatile MovementState movementState = STATE_IDLE;

inline bool isMachineSafelyIdle() {
    return (currentRPM == 0UL) &&
           (stepsRemaining == 0) &&
           (!hwBurstActive) &&
           (burstQueue.isEmpty()) &&
           (movementState == STATE_IDLE || movementState == STATE_COMPLETE) &&
           (!isSensorFaultTripped) &&
           (!auxSensorFaultActive) &&
           (!isMotionSyncLost) &&
           (!isTriggerOverflowTripped);
}

static inline void triggerIntegrityFault(uint32_t faultCode) {
    triggerIntegrityFaultCount++;
    if (faultCode == 1U) triggerOvercaptureFaultCount++;
    if (faultCode == 2U || faultCode == 4U) pulseTimingFaultCount++;
    movementState = STATE_FAULT;
    isTriggerOverflowTripped = true;
    faultType = (int)faultCode;
    stepsRemaining = 0;
    uiBannerLine1 = "TRIGGER FAULT!  ";
    if (faultCode == 1U) uiBannerLine2 = "CAPTURE LOST!  ";
    else if (faultCode == 4U) uiBannerLine2 = "CAPTURE MISMATCH";
    else if (faultCode == 3U) uiBannerLine2 = "AMBIGUOUS EDGE!";
    else uiBannerLine2 = "TIMING INVALID! ";
    uiMessageTimer = millis() + 3000UL;
    oldMenuState = -1;
    if (motionRelayEnabled) GPIOB->BSRR = (1U << 1);
}

const uint16_t STEP_PULSE_WIDTH_US   = 5; // 5.0us Active LOW pulse for Leadshine DM542

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U

// TIM2_CH1 is mapped to DMA1 Channel 5 on STM32F103. DMA mirrors the
// hardware-captured CCR1 values into RAM without adding CPU latency.
volatile uint16_t servoCaptureDma[ SERVO_CAPTURE_DMA_SAMPLES ];
volatile uint32_t servoCaptureDmaWriteCount = 0;
volatile uint32_t servoPhaseRelockCount = 0;
volatile bool servoPhaseLocked = false;
volatile uint32_t servoLastIntervalUs = 0;
volatile uint32_t servoPrevIntervalUs = 0;
volatile uint32_t servoMaxJitterUs = 0;
volatile uint32_t servoPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t servoPeriodFrac = 0;
volatile uint32_t hwBurstPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t hwBurstPeriodFrac = 0;

static inline uint16_t q16PeriodToTimerUs(volatile uint32_t &frac, uint32_t q16) {
    // True Q16.16 accumulation: retain both the configured fractional period
    // and the carry from prior timer cycles. This preserves the long-term
    // average period instead of truncating the Q16 fractional component.
    uint32_t sum = (q16 & 0xFFFFUL) + (frac & 0xFFFFUL);
    uint32_t whole = (q16 >> SERVO_PERIOD_Q_SHIFT) + (sum >> SERVO_PERIOD_Q_SHIFT);
    frac = sum & 0xFFFFUL;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm) {
    if (resolution < 200 || resolution > 51200 || !(diameter == diameter) || diameter < 15.0f || diameter > 100.0f ||
        rpm < 100 || rpm > 4000 || angle < 30 || angle > 270 || margin < 0 || margin > 25 || pitchMm <= 0.0) return false;
    const double circumference = 3.14159265358979323846 * (double)diameter;
    const double stepCount = ((double)resolution / circumference) * pitchMm;
    const double windowUs = (60000000.0 / (double)rpm) * ((double)angle / 360.0) * (1.0 - ((double)margin / 100.0));
    if (!(stepCount > 0.0) || !(windowUs > 0.0)) return false;
    // The timer's hard minimum is 8 us. A configuration whose requested burst
    // period is below this cannot physically fit the commanded pulse count into
    // the configured feed-angle window. Never silently clamp such a case to 8 us.
    return (windowUs / stepCount) >= (double)SERVO_PERIOD_MIN_US;
}

static inline uint32_t calculateAdaptiveStepPeriodQ16(uint32_t revolutionUs, uint32_t stepCount) {
    if (stepCount == 0U || revolutionUs == 0U) return servoPeriodQ16;
    int angle = feedAngleDeg;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    int margin = safetyMarginPercent;
    if (margin < 0) margin = 0;
    if (margin > 25) margin = 25;
    uint64_t windowUs = ((uint64_t)revolutionUs * (uint64_t)angle) / 360ULL;
    windowUs = (windowUs * (uint64_t)(100 - margin)) / 100ULL;
    if (windowUs < 1ULL) windowUs = 1ULL;
    uint64_t q16 = (windowUs << SERVO_PERIOD_Q_SHIFT) / (uint64_t)stepCount;
    uint64_t minQ = ((uint64_t)SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT);
    uint64_t maxQ = ((uint64_t)SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT);
    if (q16 < minQ) q16 = minQ;
    if (q16 > maxQ) q16 = maxQ;
    return (uint32_t)q16;
}


HardwareTimer *stepTimer     = new HardwareTimer(TIM1);
HardwareTimer *safetyTimer   = new HardwareTimer(TIM3);
#if defined(TIM4)
HardwareTimer *timebaseTimer = new HardwareTimer(TIM4);
#endif
volatile uint8_t pa3FaultCounterMs   = 0; // Independent 15ms consecutive qualification counter for PA3 (Tape)
volatile uint8_t pb0FaultCounterMs   = 0; // Independent 15ms consecutive qualification counter for PB0 (Coil)

// =========================================================================
// TRUE HARDWARE TIMER 2 PWM (OC2) STEP GENERATION & BURST CONTROLLER
// 1. Pure Continuous PWM Mode 2: Inactive (HIGH) 0..CCR2-1, Active (LOW) CCR2..ARR.
// 2. Output is natively, physically HIGH at CNT=0 rollover.
// 3. Software halts CEN and CC2E at CNT=0 upon burst completion (0.2us latency vs 30us safety window).
// 4. Zero OPM hardware race conditions: Timer NEVER stalls or dies on rapid/boundary triggers!
// 5. Seamless mid-burst trigger queueing: BurstQueue queues incoming triggers without losing a single pulse.
// =========================================================================

// =========================================================================
// DETERMINISTIC MULTI-SEGMENT RAMP PARAMETER CALCULATOR
// Provides smooth, bounded acceleration/deceleration with zero staircase jerk
// Dedicated short-burst handling: N<=4 (pure cruise), 5<=N<=12 (gentle soft boundary)
// =========================================================================
static inline uint16_t calculateAdaptiveStepPeriodUs(uint32_t revolutionUs, uint32_t stepCount) {
    uint32_t q16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    uint32_t whole = q16 >> SERVO_PERIOD_Q_SHIFT;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline void updateStepPeriodFromServoInterval(uint32_t revolutionUs, uint32_t stepCount) {
    if (revolutionUs == 0U || stepCount == 0U) return;
    servoPrevIntervalUs = servoLastIntervalUs;
    servoLastIntervalUs = revolutionUs;
    if (servoPrevIntervalUs != 0U) {
        uint32_t jitter = (revolutionUs > servoPrevIntervalUs) ? (revolutionUs - servoPrevIntervalUs) : (servoPrevIntervalUs - revolutionUs);
        if (jitter > servoMaxJitterUs) servoMaxJitterUs = jitter;
    }
    servoPeriodQ16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    servoPhaseLocked = (servoPrevIntervalUs != 0U);
    if (servoPhaseLocked) servoPhaseRelockCount++;
}

void stepTimerCallback() {
    if (hwBurstActive && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        hwBurstStepsDone++;
        completedPulseCount++;

        if (hwBurstStepsDone >= hwBurstStepsTarget) {
            completedStepBursts++;
            burstCompletedCount++;
            BurstItem nextBurst{};
            if (movementState != STATE_FAULT && movementState != STATE_ABORTED && burstQueue.dequeue(nextBurst)) {
                // Seamlessly chain queued burst from authoritative SPSC BurstQueue without dropping timer
                hwBurstStepsTarget = (int)nextBurst.stepCount;
                hwBurstStepsDone   = 0;
                queuedPulseCount  -= nextBurst.stepCount;
                startedPulseCount += nextBurst.stepCount;
                burstStartedCount++;
                generatedStepBursts++;
                stepsRemaining     = hwBurstStepsTarget;
                totalStepsInBurst  = hwBurstStepsTarget;

                // Direction Fix (per Rajesh Shah directive):
                // Direction is strictly Settings-controlled and fixed during RUN.
                // Pulse, burst, queue, ISR, DDA, RPM, trigger, and sensor processing NEVER change DIR at runtime.

                // Each queued burst carries the period calculated from the physical
                // servo interval that created it. Never rewrite the active burst with a
                // newer measurement; this preserves deterministic phase timing.
                if (nextBurst.periodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && nextBurst.periodQ16 <= (SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT)) {
                    hwBurstPeriodQ16 = nextBurst.periodQ16;
                    hwBurstPeriodFrac = 0;
                    activePulseWidth = (int)(hwBurstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
                } else if (nextBurst.periodUs >= SERVO_PERIOD_MIN_US && nextBurst.periodUs <= SERVO_PERIOD_MAX_US) {
                    activePulseWidth = (int)nextBurst.periodUs;
                    hwBurstPeriodQ16 = ((uint32_t)activePulseWidth << SERVO_PERIOD_Q_SHIFT);
                    hwBurstPeriodFrac = 0;
                }
                uint16_t nextARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
                TIM1->ARR = nextARR;
                uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
                if (pWidth < 2) pWidth = 2;
                TIM1->CCR1 = nextARR - pWidth + 1;
                return;
            }

            // Burst complete with no queued steps: disable PWM output and stop timer in silicon
            TIM1->CCER &= ~TIM_CCER_CC1E; // Disconnect hardware PWM output on PA8 immediately
            TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
            
            // Restore PA8 pin to General Purpose Output HIGH (Idle)
            GPIOA->CRH &= ~(0xFU << 0);
            GPIOA->CRH |= (0x3U << 0); // 50MHz GP Output Push-Pull
            STEP_HIGH_IDLE();
            stepPinState = HIGH;

            // Clear any pending update flags in NVIC
            TIM1->SR &= ~TIM_SR_UIF;
            NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

            hwBurstActive  = false;
            stepsRemaining = 0;
            movementState  = STATE_COMPLETE;
            if (queuedPulseCount == 0 && !hwBurstActive) {
                if (requestedPulseCount != (completedPulseCount + abortedPulseCount)) {
                    assertionFailureCount++;
                }
            }
            STATUS_LED_OFF(); // Stepper burst complete -> Turn OFF LED
        } else {
            stepsRemaining = (hwBurstStepsTarget - hwBurstStepsDone);
            movementState  = STATE_RUNNING;

            // Keep every pulse in the burst at the servo-synchronized period.
            // Artificial per-pulse ramps are deliberately removed because they change
            // the commanded pulse density away from the measured master motion.
            uint16_t scheduledPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
            activePulseWidth = (int)scheduledPeriodUs;
            uint16_t nextARR = (scheduledPeriodUs > 1) ? (uint16_t)(scheduledPeriodUs - 1) : 1;
            TIM1->ARR  = nextARR;
            uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
            if (pWidth < 2) pWidth = 2;
            TIM1->CCR1 = nextARR - pWidth + 1; // Pulse ends exactly at ARR rollover
        }
    } else {
        TIM1->CCER &= ~TIM_CCER_CC1E;
        TIM1->CR1  &= ~TIM_CR1_CEN;
        GPIOA->CRH &= ~(0xFU << 0);
        GPIOA->CRH |= (0x3U << 0);
        STEP_HIGH_IDLE();
        stepPinState   = HIGH;
        TIM1->SR &= ~TIM_SR_UIF;
        NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
        hwBurstActive  = false;
        stepsRemaining = 0;
        movementState  = STATE_IDLE;
    }
}

// =========================================================================
// DETERMINISTIC 1 KHZ HARDWARE SAFETY MONITOR (TIM3)
// Unblockable by loop() or I2C LCD delays. 15ms Anti-Vibration Qualified E-Stop.
// =========================================================================
void safetyTimerCallback() {
    // IMPORTANT ARCHITECTURE RULE:
    // PA0 proximity capture + TIM1/PA8 STEP generation are the primary motion path.
    // Auxiliary sensors and PB1 relay logic NEVER stop/abort/cancel the STEP engine.
    // A qualified auxiliary fault may request PB1, allowing the servo/clutch to stop;
    // any already-scheduled STEP burst is allowed to finish deterministically.

    const bool tapeBroken = sensorGuardActive && ((GPIOA->IDR & (1U << 3)) != 0U);
    const bool coilBroken = coilGuardActive && ((GPIOB->IDR & (1U << 0)) != 0U);
    const bool pb3Broken  = pb3GuardActive  && ((GPIOB->IDR & (1U << 3)) != 0U);

    bool pa3Qualified = false;
    bool pb0Qualified = false;
    bool pb3Qualified = false;
    if (sensorGuardActive || coilGuardActive || pb3GuardActive) {
        updateSafetySensorCounters((sensorGuardActive || coilGuardActive), tapeBroken, coilBroken,
                                   pa3FaultCounterMs, pb0FaultCounterMs,
                                   pa3Qualified, pb0Qualified);
        // PB3 uses the same 15 ms qualification window without sharing a counter.
        static uint8_t pb3FaultCounterMs = 0;
        if (pb3Broken) {
            if (pb3FaultCounterMs < SENSOR_QUALIFICATION_MS) pb3FaultCounterMs++;
        } else {
            pb3FaultCounterMs = 0;
        }
        pb3Qualified = (pb3FaultCounterMs >= SENSOR_QUALIFICATION_MS);
    } else {
        pa3FaultCounterMs = 0;
        pb0FaultCounterMs = 0;
    }

    const bool anyAuxFault = pa3Qualified || pb0Qualified || pb3Qualified;
    if (anyAuxFault && (sensorGuardActive || coilGuardActive || pb3GuardActive)) {
        auxSensorFaultActive = true;
        isSensorFaultTripped = true;
        if (pa3Qualified) faultType = 1;
        else if (pb0Qualified) faultType = 2;
        else faultType = 4;

        // Auxiliary sensor -> PB1 ONLY. Do not stop TIM2, abort the queue, or change movementState.
        if (motionRelayEnabled) {
            GPIOB->BSRR = (1U << 1);
        }
        uiBannerLine1 = pa3Qualified ? "! TAPE RUN-OUT !" :
                        (pb0Qualified ? "! COIL SENSOR ! " : "! PB3 SENSOR !  ");
        uiBannerLine2 = motionRelayEnabled ? "AUX STOP RELAY  " : "STEP PATH SAFE  ";
        uiMessageTimer = millis() + 2500UL;
        oldMenuState = -1;
    }

    // Motion watchdog is optional and is deliberately DISARMED until two valid
    // proximity edges establish a real physical period. This prevents a first-run
    // false "Motion Lost" before the servo/proximity stream has established sync.
    if (motionRelayEnabled && motionWatchdogArmed && currentRPM > 100UL &&
        !isMotionSyncLost) {
        const unsigned long elapsedSinceTrigger = micros() - lastTriggerMicros;
        unsigned long syncTimeoutUs = (lastMeasuredIntervalUs > 0UL)
            ? (lastMeasuredIntervalUs * 4UL + 50000UL) : 300000UL;
        if (syncTimeoutUs < 300000UL) syncTimeoutUs = 300000UL;
        if (elapsedSinceTrigger > syncTimeoutUs) {
            isMotionSyncLost = true;
            faultType = 3;
            // PB1 relay request only. Never stop TIM2 or clear the STEP queue here.
            GPIOB->BSRR = (1U << 1);
            uiBannerLine1 = "! SYNC TIMEOUT !";
            uiBannerLine2 = "RELAY STOP ONLY ";
            uiMessageTimer = millis() + 3000UL;
            oldMenuState = -1;
        }
    }

    // Standstill recovery releases PB1 only when the machine has genuinely stopped.
    // A new valid PA0 stream then re-arms synchronization in sensorISR().
    if (currentRPM == 0UL) {
        if (isMotionSyncLost) {
            isMotionSyncLost = false;
            motionWatchdogArmed = false;
        }
        if (isTriggerOverflowTripped && burstQueue.isEmpty() && !hwBurstActive) {
            isTriggerOverflowTripped = false;
        }
        if (!tapeBroken && !coilBroken && !pb3Broken && !isTriggerOverflowTripped) {
            auxSensorFaultActive = false;
            isSensorFaultTripped = false;
            if (motionRelayEnabled || !sensorGuardActive || !coilGuardActive || !pb3GuardActive) {
                GPIOB->BRR = (1U << 1);
            }
            if (movementState == STATE_FAULT) movementState = STATE_IDLE;
        }
    }
}


// =========================================================================
// CONTINUOUS 1 MHZ FREE-RUNNING TIMER 4 (STM32F103 HARDWARE TIMESTAMPING)
// 1.0 microsecond deterministic tick resolution, independent of TIM2/TIM3
// =========================================================================
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
void tim4UpdateCallback(void) {
    tim4_overflow_count++;
}

void initFreeRunningTimer4() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
    TIM4->PSC = 71;     // 72MHz / (71 + 1) = 1MHz (1.0 us tick)
    TIM4->ARR = 0xFFFF; // 16-bit free-running counter rollover at 65535us
    TIM4->CNT = 0;
    TIM4->SR &= ~TIM_SR_UIF;
    TIM4->DIER |= TIM_DIER_UIE; // Enable update interrupt for 32-bit rollover

    // Attach callback using official STM32duino HardwareTimer framework
    // (Prevents duplicate definition of TIM4_IRQHandler with SrcWrapper/HardwareTimer.cpp)
    timebaseTimer->pause();
    timebaseTimer->attachInterrupt(tim4UpdateCallback);
    timebaseTimer->resume();
}

// Provably race-safe atomic snapshot across 16-bit hardware timer overflow
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t high;
    uint16_t low;
    bool pending;

    do {
        high = tim4_overflow_count;
        low  = (uint16_t)(TIM4->CNT);
        pending = (TIM4->SR & TIM_SR_UIF) != 0;
    } while (high != tim4_overflow_count);

    // If an overflow interrupt is pending (UIF set) and CNT has already rolled over
    // to a small value (< 0x8000), account for the unserviced rollover in this reading
    if (pending && (low < 0x8000)) {
        high++;
    }

    return (high << 16) | low;
}
#else
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t nowCycles = 0;
#if defined(CoreDebug) && defined(DWT)
    nowCycles = DWT->CYCCNT;
#endif
    return (nowCycles != 0) ? (nowCycles / 72UL) : micros();
}
#endif
void initHardwareSafetyTimer3() {
    // 1. Enable TIM3 peripheral clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    // 2. Prescaler: 72MHz / (71 + 1) = 1MHz (1 tick = 1.0 microsecond)
    TIM3->PSC = 71;
    // Auto-reload: 1000 ticks = 1000 microseconds = 1.0ms (1 kHz sampling)
    TIM3->ARR = 999;
    TIM3->CNT = 0;

    // Clear update flag
    TIM3->SR &= ~TIM_SR_UIF;

    // Enable update interrupt
    TIM3->DIER |= TIM_DIER_UIE;

    // Attach callback with HardwareTimer wrapper
    safetyTimer->pause();
    safetyTimer->attachInterrupt(safetyTimerCallback);
    safetyTimer->resume();
}

void initHardwareTimer2() {
    // TIM2 is now dedicated to PA0 proximity capture. It is a free-running
    // 1 MHz hardware timestamp source; STEP generation is completely separated
    // onto TIM1/PA8 so ARR/CCR updates cannot disturb PA0 capture.
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    TIM2->CR1 = 0;
    TIM2->PSC = 71;                 // 72 MHz / 72 = 1 MHz
    TIM2->ARR = 0xFFFF;             // free-running 16-bit capture timebase
    TIM2->CNT = 0;
    TIM2->CCMR1 = 0;
    TIM2->CCER = 0;
    TIM2->CCMR1 |= TIM_CCMR1_CC1S_0; // CH1 mapped to TI1 (PA0)
    TIM2->CCMR1 |= (0xFU << 4);       // strong digital input qualification
    TIM2->CCER |= TIM_CCER_CC1P | TIM_CCER_CC1E; // falling edge
    TIM2->CR1 |= TIM_CR1_ARPE;

#if defined(DMA1_Channel5)
    RCC->AHBENR |= RCC_AHBENR_DMA1EN;
    DMA1_Channel5->CCR = 0;
    DMA1_Channel5->CPAR = (uint32_t)&TIM2->CCR1;
    DMA1_Channel5->CMAR = (uint32_t)servoCaptureDma;
    DMA1_Channel5->CNDTR = SERVO_CAPTURE_DMA_SAMPLES;
    DMA1_Channel5->CCR = DMA_CCR_MINC | DMA_CCR_CIRC | DMA_CCR_PSIZE_0 | DMA_CCR_MSIZE_0;
    DMA1_Channel5->CCR |= DMA_CCR_PL_0;
    DMA1_Channel5->CCR |= DMA_CCR_EN;
#endif
    TIM2->EGR = TIM_EGR_UG;
    TIM2->SR = 0;
}

void initHardwareStepTimer1() {
    // TIM1 CH1 -> PA8 is the dedicated production STEP generator.
    // Timer runs at 1 MHz: ARR controls pulse-to-pulse period and CCR1 controls
    // the active-low pulse width. ARPE/OC1PE make period updates glitch-free.
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
    pinMode(stepPin, OUTPUT);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;

    TIM1->CR1 = 0;
    TIM1->PSC = 71;                 // 1 us timer tick
    uint16_t initARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
    TIM1->ARR = initARR;
    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;

    // CH1 PWM Mode 2: idle HIGH, active LOW from CCR1 through ARR.
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_OC1PE);
    TIM1->CCMR1 |= (0x7U << 4) | TIM_CCMR1_OC1PE;
    TIM1->CCER = TIM_CCER_CC1P;
    TIM1->CR1 |= TIM_CR1_ARPE;
    TIM1->CR1 &= ~TIM_CR1_OPM;
    TIM1->BDTR |= TIM_BDTR_MOE;     // advanced timer output enable
    TIM1->DIER |= TIM_DIER_UIE;
    TIM1->EGR = TIM_EGR_UG;
    TIM1->SR = 0;
    stepTimer->pause();
    stepTimer->attachInterrupt(stepTimerCallback);
}

void startHardwareTimerBurst(int stepCount, uint16_t burstPeriodUs = 0, uint32_t burstPeriodQ16 = 0) {
    if (stepCount <= 0 || movementState == STATE_FAULT || movementState == STATE_ABORTED) return;

    // ATOMIC CRITICAL SECTION: Protect against concurrent trigger/timer queue updates
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    uint32_t nowUs = get_hardware_timestamp_us();
    hwBurstPeriodQ16 = burstPeriodQ16 ? burstPeriodQ16 : ((uint32_t)burstPeriodUs << SERVO_PERIOD_Q_SHIFT);
    if (burstPeriodQ16 == 0U && burstPeriodUs == 0U) hwBurstPeriodQ16 = servoPeriodQ16;
    hwBurstPeriodFrac = 0;
    static uint32_t s_burstSeq = 0;

    if (hwBurstActive) {
        // Enqueue into authoritative production SPSC BurstQueue
        bool enqueued = burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, (uint32_t)hwBurstPeriodQ16);
        if (enqueued) {
            generatedStepBursts++;
            burstQueuedCount++;
            queuedPulseCount += stepCount;
            movementState = STATE_RUNNING;
        } else {
            // Queue overflow detected: physical machine unable to keep up!
            queueOverflowCount++;
            isTriggerOverflowTripped = true;
            faultType = 5; // FAULT_TRIGGER_OVERFLOW
            uiBannerLine1 = "! QUEUE OVERFLOW !";
            uiBannerLine2 = "TRIGGER LOST    ";
            uiMessageTimer = millis() + 3000UL;
            oldMenuState = -1;
            if (motionRelayEnabled) {
                GPIOB->BSRR = (1U << 1); // Request main motor stop
            }
            movementState = STATE_FAULT;
        }
        __set_PRIMASK(primask);
        return;
    }

    // Active burst is idle: enqueue into BurstQueue and immediately dequeue to start TIM2
    bool enqueued = burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, (uint32_t)hwBurstPeriodQ16);
    if (!enqueued) {
        queueOverflowCount++;
        isTriggerOverflowTripped = true;
        faultType = 5;
        uiBannerLine1 = "! QUEUE OVERFLOW !";
        uiBannerLine2 = "TRIGGER LOST    ";
        uiMessageTimer = millis() + 3000UL;
        oldMenuState = -1;
        if (motionRelayEnabled) {
            GPIOB->BSRR = (1U << 1);
        }
        movementState = STATE_FAULT;
        __set_PRIMASK(primask);
        return;
    }
    BurstItem item{};
    burstQueue.dequeue(item);

    generatedStepBursts++;
    if (item.periodUs >= 8U && item.periodUs <= 500U) {
        activePulseWidth = (int)item.periodUs;
    }
    hwBurstStepsTarget = (int)item.stepCount;
    hwBurstStepsDone   = 0;
    hwBurstActive      = true;
    burstStartedCount++;
    startedPulseCount += stepCount;
    stepsRemaining     = stepCount;
    totalStepsInBurst  = stepCount;
    stepPinState       = HIGH;
    movementState      = STATE_RUNNING;

    // Connect PA8 directly to TIM1_CH1: Alternate Function Push-Pull 50MHz
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0xBU << 0); // 1011b = AF Output Push-Pull 50MHz

    // The servo is the mechanical master. Do not invent an acceleration ramp here.
    // activePulseWidth is derived from the most recent physical trigger interval;
    // maxRPMSetting is only the startup/fallback bound before the first valid interval.
    uint16_t initPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
    activePulseWidth = (int)initPeriodUs;
    uint16_t initARR = (initPeriodUs > 1) ? (uint16_t)(initPeriodUs - 1) : 1;
    TIM1->ARR  = initARR;

    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;

    // Ensure OPM is disabled
    TIM1->CR1 &= ~TIM_CR1_OPM;

    // Force load preload registers into shadow registers and reset CNT to 0
    // Temporarily mask UIE so EGR_UG does not latch a spurious update interrupt into NVIC
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR   = TIM_EGR_UG;
    TIM1->SR   &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    TIM1->DIER |= TIM_DIER_UIE;

    // Enable hardware PWM output on PA8 in silicon
    TIM1->BDTR |= TIM_BDTR_MOE;
    TIM1->CCER |= TIM_CCER_CC1E;

    // Start timer counter in silicon
    TIM1->CR1 |= TIM_CR1_CEN;

    __set_PRIMASK(primask);
}

void stopHardwareTimerImmediately() {
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    TIM1->CCER &= ~TIM_CCER_CC1E; // Disable hardware PWM output on PA8 in silicon
    TIM1->BDTR &= ~TIM_BDTR_MOE;
    TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
    TIM1->CR1  &= ~TIM_CR1_OPM;   // Ensure OPM cleared

    // Restore PA8 pin to General Purpose Output HIGH (Idle)
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;

    // Clear all pending flags and interrupts
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

    uint32_t abortedFromQueue = burstQueue.abortAll();
#if DEBUG_TEST_MODE
    int uncompleted = (hwBurstStepsTarget - hwBurstStepsDone) + (int)abortedFromQueue;
    if (uncompleted > 0) {
        abortedPulseCount += uncompleted;
        queuedPulseCount = 0;
    }
#else
    (void)abortedFromQueue;
#endif

    hwBurstActive      = false;
    hwBurstStepsTarget = 0;
    hwBurstStepsDone   = 0;
    stepsRemaining     = 0;
    movementState      = isSensorFaultTripped ? STATE_FAULT : STATE_ABORTED;

    __set_PRIMASK(primask);
}

void recalculatePitchProfiles() {
    // Explicit numerical bounds checking
    if ((rollerDia != rollerDia) || rollerDia < 15.0f || rollerDia > 100.0f) rollerDia = 45.0f;
    if (driverResolution < 200 || driverResolution > 51200) driverResolution = 6400;
    double circumference = 3.14159265358979323846 * (double)rollerDia;
    double pulsesPerMM = (double)driverResolution / circumference;
    // 64-bit intermediate arithmetic: strictly prevents uint32_t overflow at max 51200 res / 15mm roller
    p5_fixed  = (uint64_t)(2.50 * pulsesPerMM * 1000000.0 + 0.5);
    p8_fixed  = (uint64_t)(3.00 * pulsesPerMM * 1000000.0 + 0.5);
    p10_fixed = (uint64_t)(4.00 * pulsesPerMM * 1000000.0 + 0.5);
    if (p5_fixed < 1000000ULL) p5_fixed = 1000000ULL;
    if (p8_fixed < 1000000ULL) p8_fixed = 1000000ULL;
    if (p10_fixed < 1000000ULL) p10_fixed = 1000000ULL;
}

void syncPulseIntegerFraction() {
    uint32_t intPart  = (uint32_t)(currentPulsesFixed / 1000000ULL);
    uint32_t fracPart = (uint32_t)(currentPulsesFixed % 1000000ULL);
    currentPulsesInt  = intPart;
    currentPulsesFrac = fracPart;
    commitPulseParameters(intPart, fracPart);
}

void updateActivePulseWidth() {
    syncPulseIntegerFraction();
    if (maxRPMSetting < 100 || maxRPMSetting > 4000) maxRPMSetting = 3000;
    if (feedAngleDeg < 30 || feedAngleDeg > 270) feedAngleDeg = 160;
    if (safetyMarginPercent < 0 || safetyMarginPercent > 25) safetyMarginPercent = 10;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));
    float activeSteps = (float)currentPulsesFixed / 1000000.0f;
    if (activeSteps < 1.0f) activeSteps = 1.0f;
    // Startup/fallback STEP period only; runtime period is replaced by measured servo timing.
    double requestedPeriodUs = (double)timeWindowUs / (double)activeSteps;
    refreshPulseTimingValidity();
    if (requestedPeriodUs < (double)SERVO_PERIOD_MIN_US) {
        // Do not hide an impossible manual tuning behind the 8us timer clamp.
        // Keep the timer at its safe floor, but mark the configuration invalid so
        // the UI/start path can block motion until the operator corrects it.
        pulseTimingInvalid = true;
        activePulseWidth = SERVO_PERIOD_MIN_US;
        return;
    }
    int calcPeriod = (int)requestedPeriodUs;
    if (calcPeriod > (int)SERVO_PERIOD_MAX_US) calcPeriod = SERVO_PERIOD_MAX_US;
    activePulseWidth = calcPeriod;
}

void calculateAllPulseWidths() {
    if (maxRPMSetting <= 0) maxRPMSetting = 3000;
    if (feedAngleDeg <= 0) feedAngleDeg = 160;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));

    float s5 = (float)p5_fixed / 1000000.0f;
    if (s5 < 1.0f) s5 = 1.0f;
    // Safe industrial limit: Full step period [8us, 500us] (guarantees >= 2.5us driver opto timing)
    autoPulseWidth_P5 = constrain((int)(timeWindowUs / s5), 8, 500);

    float s8 = (float)p8_fixed / 1000000.0f;
    if (s8 < 1.0f) s8 = 1.0f;
    autoPulseWidth_P8 = constrain((int)(timeWindowUs / s8), 8, 500);

    float s10 = (float)p10_fixed / 1000000.0f;
    if (s10 < 1.0f) s10 = 1.0f;
    autoPulseWidth_P10 = constrain((int)(timeWindowUs / s10), 8, 500);

    updateActivePulseWidth();

    // 50% nominal period debounce: completely rejects trailing edge & contactor EMI noise
    dynamicDebounceUs = 3000UL; // Legacy UI/diagnostic value; trigger qualification uses measured adaptive blanking.
}

void evaluateDiagnostics() {
    float tempDia  = (tempRollerDia > 0.1f) ? tempRollerDia : 45.0f;
    int32_t tempRes   = (tempDriverRes > 200) ? tempDriverRes : 6400;
    int32_t tempRPM   = (tempMaxRPM > 100) ? tempMaxRPM : 3000;
    int32_t tempAngle  = (tempFeedAngle > 10) ? tempFeedAngle : 160;
    int32_t tempMargin = constrain(tempSafetyMargin, 0, 25);

    float tempCirc = 3.14159265f * tempDia;
    float tempPPM  = (float)tempRes / tempCirc;
    float s10_test = 4.00f * tempPPM;
    if (s10_test < 1.0f) s10_test = 1.0f;

    float timeWinTest = (60000000.0f / (float)tempRPM) * ((float)tempAngle / 360.0f) * (1.0f - ((float)tempMargin / 100.0f));
    diagMinW = (int)(timeWinTest / s10_test);

    if (diagMinW < 6) {
        isTimingWarningActive = true;
        if (tempRes > 12800) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET RES <= 12800";
        } else if (tempAngle < 120) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "INC ANGLE >= 150";
        } else if (tempRPM > 2500) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RPM <= 2500 ";
        } else if (tempMargin > 15) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET MARGIN 10%  ";
        } else {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RES/INC ANG ";
        }
    } else {
        isTimingWarningActive = false;
        diagFixLine1 = "TIMING HEALTH:  ";
        diagFixLine2 = "SYSTEM OPTIMAL  ";
    }
}

// =========================================================================
// TWO-PHASE ATOMIC DEFERRED TRIGGER DISPATCH ENGINE (SECTION 6 RACE FIX)
// Dispatches any triggers deferred during Flash save/abort window.
// Prevents newer incoming physical triggers from overtaking older deferred work.
// Only after deferred pulses are safely handed off does the lock return to IDLE.
// =========================================================================
static void dispatchDeferredSaveTriggers() {
    for (;;) {
        uint8_t defDir = 0;
        uint32_t defTs = 0;
        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        uint32_t defSteps = flashSaveTx.captureDeferredForDispatch(defDir, defTs);
        const bool stillPending = flashSaveTx.deferredTriggerPending;
        if (defSteps == 0U && !stillPending) {
            // Close the handoff while IRQs are masked so no ISR can enqueue between
            // the final empty check and SAVE_LOCK_IDLE.
            flashSaveTx.completeHandoff();
            __set_PRIMASK(primask);
            break;
        }
        __set_PRIMASK(primask);

        if (defSteps == 0U) continue;
        if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
            if (hardwareTimerMode) {
                startHardwareTimerBurst((int)defSteps);
            } else {
                primask = __get_PRIMASK();
                __disable_irq();
                stepsRemaining += (int)defSteps;
                totalStepsInBurst = stepsRemaining;
                __set_PRIMASK(primask);
            }
        } else {
#if DEBUG_TEST_MODE
            abortedPulseCount += (int)defSteps;
#endif
        }
    }
}

void requestSafeAutoSave(uint32_t delayMs = 1000UL);
void serviceSafeAutoSave();
void applyStagedSettingsToRuntime();

bool saveToEEPROM() {
    // 1. Request Atomic Save Lock (SAVE_LOCK_IDLE -> SAVE_LOCK_ACQUIRING)
    if (!flashSaveTx.requestSaveLock()) {
        return false;
    }

    // 2. Authoritative Safe-Save Precondition Check & Lock Confirmation
    if (!flashSaveTx.confirmLockAndTransition(isMachineSafelyIdle())) {
        dispatchDeferredSaveTriggers();
        return false; // Prohibited while machine moving or safety fault active
    }

    // 3. Prepare Candidate Dual-Slot Record
    uint32_t targetSlot = 1 - activeEEPROMSlot;
    int targetOffset = (targetSlot == 0) ? 0 : 128;
    uint32_t nextSeq = eepromSeqNumber + 1;

    MachineConfigRecord rec;
    rec.magic    = EEPROM_MAGIC_V16_5_1;
    rec.seq      = nextSeq;
    rec.reserved = 0;

    rec.payload.p5_fixed            = p5_fixed;
    rec.payload.p8_fixed            = p8_fixed;
    rec.payload.p10_fixed           = p10_fixed;
    rec.payload.driverResolution    = driverResolution;
    rec.payload.rollerDia           = rollerDia;
    rec.payload.maxRPMSetting       = maxRPMSetting;
    rec.payload.feedAngleDeg        = feedAngleDeg;
    rec.payload.safetyMarginPercent = safetyMarginPercent;
    rec.payload.currentSize         = currentSize;
    rec.payload.sensorGuardActive   = sensorFeatureMask();
    rec.payload.hardwareTimerMode   = 0; // PRIMARY POLICY: persisted engine is always TIM1 Hardware; DDA is diagnostic-only.
    rec.payload.motorDirection      = motorDirection ? 1 : 0;

    // 4. Complete-Payload Equality Check against active persisted payload (Section 6)
    MachineConfigRecord activeRec;
    int activeOffset = (activeEEPROMSlot == 0) ? 0 : 128;
    EEPROM.get(activeOffset, activeRec);
    if (PulseStepPersistenceManager::validateRecord(activeRec) &&
        memcmp(&rec.payload, &activeRec.payload, sizeof(MachineConfigPayload)) == 0) {
        // Complete serialized payload identical: skip Flash write (0 writes)
        dispatchDeferredSaveTriggers();
        return true;
    }

    rec.crc32 = calculateCRC32((const uint8_t*)&rec.payload, sizeof(MachineConfigPayload));

    // 5. Flash Programming is permitted ONLY after the authoritative standstill gate.
    // PA0 capture is already armed, but a physical machine must not be moving during persistence.
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    EEPROM.put(targetOffset, rec);
    __set_PRIMASK(primask);

    // 6. Verification Read-back
    MachineConfigRecord readBack;
    EEPROM.get(targetOffset, readBack);

    bool saveOk = false;
    if (PulseStepPersistenceManager::validateRecord(readBack) &&
        memcmp(&rec, &readBack, sizeof(MachineConfigRecord)) == 0) {
        // Successfully verified in ROM
        flashWriteCount++;
        activeEEPROMSlot = targetSlot;
        eepromSeqNumber  = nextSeq;

        // Synchronize stored baseline
        pulseStepStored_p5  = p5_fixed;
        pulseStepStored_p8  = p8_fixed;
        pulseStepStored_p10 = p10_fixed;
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
        calculateAllPulseWidths();
        saveOk = true;
    }

    // 7. Atomic Handoff and Dispatch of Any Triggers Deferred During Save Window (Section 6)
    dispatchDeferredSaveTriggers();
    return saveOk;
}

void requestSafeAutoSave(uint32_t delayMs) {
    safeAutoSavePending = true;
    safeAutoSaveDueMs = millis() + delayMs;
}

void applyStagedSettingsToRuntime() {
    driverResolution    = tempDriverRes;
    rollerDia           = tempRollerDia;
    maxRPMSetting       = tempMaxRPM;
    feedAngleDeg        = tempFeedAngle;
    safetyMarginPercent = tempSafetyMargin;
    sensorGuardActive   = tempSensorGuard;
    coilGuardActive     = tempCoilGuard;
    pb3GuardActive      = tempPb3Guard;
    motionRelayEnabled  = tempMotionRelay;
    if (!motionRelayEnabled) {
        GPIOB->BRR = (1U << 1);
        motionWatchdogArmed = false;
        isMotionSyncLost = false;
    }
    hardwareTimerMode = tempHwTimerMode;
    if (!hardwareTimerMode) {
        hwBurstActive = false;
        TIM1->DIER &= ~TIM_DIER_UIE;
        TIM1->CCER &= ~TIM_CCER_CC1E;
        TIM1->BDTR &= ~TIM_BDTR_MOE;
        TIM1->CR1 &= ~TIM_CR1_CEN;
        STEP_HIGH_IDLE();
        stepPinState = HIGH;
    }
    tempHwTimerMode = hardwareTimerMode;
    motorDirection = tempMotorDir;
    applyMotorDirection();
    recalculatePitchProfiles();
    refreshPulseTimingValidity();
    hasStagedChanges = false;
}

void serviceSafeAutoSave() {
    if (!safeAutoSavePending) return;
    if ((int32_t)(millis() - safeAutoSaveDueMs) < 0) return;
    if (!isMachineSafelyIdle() || currentRPM != 0UL || stepsRemaining != 0 || hwBurstActive) return;

    if (hasStagedChanges) {
        if (!stagedTimingConfigurationFeasible()) {
            safeAutoSavePending = false;
            uiBannerLine1 = "TIMING INVALID! ";
            uiBannerLine2 = "AUTO-SAVE BLOCK";
            uiMessageTimer = millis() + 1600UL;
            oldMenuState = -1;
            return;
        }
        applyStagedSettingsToRuntime();
    }

    if (saveToEEPROM()) {
        safeAutoSavePending = false;
        autoSavePendingStandstill = false;
        uiBannerLine1 = "AUTO-SAVED OK!  ";
        uiBannerLine2 = "SETTINGS SAVED  ";
        uiMessageTimer = millis() + 1200UL;
        oldMenuState = -1;
    }
}

void loadFactoryDefaults() {
    driverResolution    = 6400;
    rollerDia           = 45.0f;
    maxRPMSetting       = 3000;
    feedAngleDeg        = 160;
    safetyMarginPercent = 10;
    currentSize         = 1;
    sensorGuardActive   = false;
    coilGuardActive     = false;
    pb3GuardActive      = false;
    motionRelayEnabled  = false; // All auxiliary stop features OFF by default
    hardwareTimerMode   = true;  // AUTONOMOUS HARDWARE ENGINE DEFAULT
    motorDirection      = false; // NORMAL FORWARD DEFAULT
    applyMotorDirection();
    recalculatePitchProfiles();
    currentPulsesFixed  = p5_fixed;
    calculateAllPulseWidths();
    // Do NOT write Flash merely because defaults loaded in RAM
    pulseStepStored_p5  = p5_fixed;
    pulseStepStored_p8  = p8_fixed;
    pulseStepStored_p10 = p10_fixed;
    pulseModifiedByUser = false;
    hasStagedChanges    = false;
}

void loadFromEEPROM() {
    MachineConfigRecord rec0, rec1;
    EEPROM.get(0, rec0);
    EEPROM.get(128, rec1);

    bool v0 = PulseStepPersistenceManager::validateRecord(rec0);
    bool v1 = PulseStepPersistenceManager::validateRecord(rec1);

    MachineConfigRecord *chosen = nullptr;
    uint32_t chosenSlot = 0;

    if (v0 && v1) {
        if (rec0.seq >= rec1.seq) {
            chosen = &rec0;
            chosenSlot = 0;
        } else {
            chosen = &rec1;
            chosenSlot = 1;
        }
    } else if (v0) {
        chosen = &rec0;
        chosenSlot = 0;
    } else if (v1) {
        chosen = &rec1;
        chosenSlot = 1;
    }

    if (chosen != nullptr) {
        // Valid transactional record found
        activeEEPROMSlot = chosenSlot;
        eepromSeqNumber  = chosen->seq;

        p5_fixed            = chosen->payload.p5_fixed;
        p8_fixed            = chosen->payload.p8_fixed;
        p10_fixed           = chosen->payload.p10_fixed;
        driverResolution    = chosen->payload.driverResolution;
        rollerDia           = chosen->payload.rollerDia;
        maxRPMSetting       = chosen->payload.maxRPMSetting;
        feedAngleDeg        = chosen->payload.feedAngleDeg;
        safetyMarginPercent = chosen->payload.safetyMarginPercent;
        currentSize         = chosen->payload.currentSize;
        applySensorFeatureMask(chosen->payload.sensorGuardActive);
        hardwareTimerMode   = true; // PRIMARY POLICY: every boot starts on TIM1 Hardware; DDA remains temporary diagnostic mode.
        motorDirection      = (chosen->payload.motorDirection == 1);

        applyMotorDirection();
        calculateAllPulseWidths();
        recalculatePitchProfiles();

        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        if (currentSize == 1) currentPulsesFixed = p5_fixed;
        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
        else currentPulsesFixed = p10_fixed;
        __set_PRIMASK(primask);
        updateActivePulseWidth();

        pulseStepStored_p5  = p5_fixed;
        pulseStepStored_p8  = p8_fixed;
        pulseStepStored_p10 = p10_fixed;
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
    } else {
        // Check legacy single-slot format (V16.5.0 / V16.4.0 / V16.3.3)
        MachineConfigLegacy leg;
        EEPROM.get(0, leg);
        if (leg.magic == EEPROM_MAGIC || (leg.driverResolution >= 200 && (leg.rollerDia == leg.rollerDia) && leg.rollerDia > 0.1f)) {
            p5_fixed            = (uint64_t)leg.p5_fixed;
            p8_fixed            = (uint64_t)leg.p8_fixed;
            p10_fixed           = (uint64_t)leg.p10_fixed;
            driverResolution    = leg.driverResolution;
            rollerDia           = leg.rollerDia;
            maxRPMSetting       = (leg.maxRPMSetting >= 100 && leg.maxRPMSetting <= 4000) ? leg.maxRPMSetting : 3000;
            feedAngleDeg        = (leg.feedAngleDeg >= 30 && leg.feedAngleDeg <= 270) ? leg.feedAngleDeg : 160;
            safetyMarginPercent = (leg.safetyMarginPercent <= 25) ? leg.safetyMarginPercent : 10;
            currentSize         = (leg.currentSize >= 1 && leg.currentSize <= 3) ? leg.currentSize : 1;
            sensorGuardActive   = false;
            coilGuardActive     = false;
            pb3GuardActive      = false;
            motionRelayEnabled  = false;
            hardwareTimerMode   = true;
            motorDirection      = false;
            applyMotorDirection();
            recalculatePitchProfiles();
            uint32_t primask = __get_PRIMASK();
            __disable_irq();
            if (currentSize == 1) currentPulsesFixed = p5_fixed;
            else if (currentSize == 2) currentPulsesFixed = p8_fixed;
            else currentPulsesFixed = p10_fixed;
            __set_PRIMASK(primask);
            calculateAllPulseWidths();

            // Migrated baseline:
            pulseStepStored_p5  = p5_fixed;
            pulseStepStored_p8  = p8_fixed;
            pulseStepStored_p10 = p10_fixed;
            pulseModifiedByUser = false;
            autoSavePendingStandstill = false;
            hasStagedChanges    = false;
        } else {
            loadFactoryDefaults();
        }
    }
}

// Dual-clock silicon capture audit. TIM2 runs at 1 MHz, while DWT runs at
// the 72 MHz core clock. Both observe the same PA0 edge independently. Comparing
// successive deltas catches DMA/capture discontinuity or an unexpected capture
// path shift without changing the authoritative edge timestamp.
#ifndef TIM2_CAPTURE_AUDIT_TOLERANCE_US
#define TIM2_CAPTURE_AUDIT_TOLERANCE_US 12U
#endif

static inline bool auditTim2Capture(uint16_t captured16, uint32_t edgeCycles) {
    bool ok = true;
    if (tim2CaptureAuditArmed) {
        uint16_t capDeltaUs = (uint16_t)(captured16 - lastTim2Capture16);
        uint32_t cycleDelta = edgeCycles - lastTim2CaptureCycles;
        uint32_t edgeDeltaUs = cycleDelta / 72UL;
        uint32_t capUs = (uint32_t)capDeltaUs;
        uint32_t err = (capUs > edgeDeltaUs) ? (capUs - edgeDeltaUs) : (edgeDeltaUs - capUs);
        captureAuditLastErrorUs = err;
        if (err > captureAuditMaxErrorUs) captureAuditMaxErrorUs = err;
        if (err > TIM2_CAPTURE_AUDIT_TOLERANCE_US) {
            captureAuditMismatchCount++;
            ok = false;
        }
    }
    lastTim2Capture16 = captured16;
    lastTim2CaptureCycles = edgeCycles;
    tim2CaptureAuditArmed = true;
    return ok;
}

static inline void auditCaptureDmaPosition() {
#if defined(DMA1_Channel5)
    uint32_t remaining = DMA1_Channel5->CNDTR;
    dmaCaptureLastRemaining = remaining;
    if (remaining <= SERVO_CAPTURE_DMA_SAMPLES) {
        dmaCaptureAuditSamples++;
    } else {
        dmaCaptureAuditMisses++;
    }
#endif
}

// PRIMARY MOTION PATH: PA0 falling-edge trigger -> earliest-cycle timestamp ->
// deterministic TIM1/PA8 STEP burst. One accepted trigger produces exactly one
// burst; ambiguous capture/timing conditions fault instead of being guessed.
// Proximity Sensor Hardware ISR (Active-LOW Falling Edge)
// Highest application priority: EXTI0. TIM2 CH1 capture/DMA is an independent
// silicon audit because TIM2 is now free-running for capture; TIM1 owns variable STEP timing.
void sensorISR() {
    // First instructions: capture the edge timestamp before any queue, LCD,
    // diagnostic or timing calculation work. EXTI0 is the highest application
    // priority, so TIM1 STEP servicing cannot add an extra interrupt-level delay.
    receivedTriggers++;
    uint32_t edgeCycles = 0;
#if defined(CoreDebug) && defined(DWT)
    edgeCycles = DWT->CYCCNT;
#endif
    uint32_t edgeUs = get_hardware_timestamp_us();
    triggerEdgeTimestampCycles = edgeCycles;
    triggerEdgeTimestampUs = edgeUs;

    // 1. Silicon capture audit. A CC1 overcapture means the hardware saw more
    // than one PA0 edge before software consumed the capture register. For this
    // machine, guessing which edge was lost is unsafe: enter FAULT and do not
    // generate a compensating STEP.
#if defined(TIM2)
    uint16_t capStatus = TIM2->SR;
    volatile uint16_t latchedCCR1 = TIM2->CCR1;
    if (capStatus & TIM_SR_CC1OF) {
        TIM2->SR &= ~TIM_SR_CC1OF;
        TIM2->SR &= ~TIM_SR_CC1IF;
        captureOverrunCount++;
        knownOvercaptureLostPulses++;
        lastOvercaptureTimestampUs = edgeUs;
        isCaptureStreamDiscontinuous = true;
        triggerIntegrityFault(1U);
        return;
    }
    if (capStatus & TIM_SR_CC1IF) TIM2->SR &= ~TIM_SR_CC1IF;
    auditCaptureDmaPosition();
    if (!auditTim2Capture(latchedCCR1, edgeCycles)) {
        isCaptureStreamDiscontinuous = true;
        triggerIntegrityFault(4U);
        return;
    }
#endif

    // 2. Authoritative interval timestamp. The DWT/TIM4 timestamp is sampled
    // immediately at EXTI entry; this removes variable work inside the ISR from
    // the measured interval.
    uint32_t nowCycles = edgeCycles;
    unsigned long nowUs = edgeUs;
    unsigned long diff = 0;

    if (!hasValidPriorTrigger) {
        lastMeasuredIntervalUs = 0UL;
        currentRPM = 0UL;
        validTriggerCount = 1;
        motionWatchdogArmed = false;
        hasValidPriorTrigger = true;
    } else {
        if (nowCycles != 0 && lastTriggerCycles != 0) {
            uint32_t diffCycles = nowCycles - lastTriggerCycles; // Unsigned wrap-safe arithmetic
            diff = diffCycles / 72UL;
        } else {
            diff = (uint32_t)(nowUs - lastTriggerMicros);
        }

        if (diff > 2000000UL) {
            // Standstill: the next edge is a new first edge. Do not watchdog it.
            lastMeasuredIntervalUs = 0UL;
            currentRPM = 0UL;
            validTriggerCount = 1;
            motionWatchdogArmed = false;
        } else {
            // Speed-Adaptive Dynamic Blanking Engine:
            // 1.5ms floor rejects optocoupler ringing & contactor EMI up to 30,000 RPM.
            // 4.5ms ceiling guarantees >=70% valid trigger window open at 4,000 RPM (15.0ms period).
            unsigned long activeBlankingUs = 1500UL;
            if (lastMeasuredIntervalUs > 0UL) {
                activeBlankingUs = lastMeasuredIntervalUs / 3UL; // 33% of previous revolution
                if (activeBlankingUs < 1500UL) activeBlankingUs = 1500UL;
                if (activeBlankingUs > 4500UL) activeBlankingUs = 4500UL;
            }

            // Qualification must never discard a legitimate acceleration edge merely
            // because it arrives faster than the configured RPM ceiling. The servo is
            // the physical master and PA0 is the authoritative cycle trigger. A hard
            // max-RPM plausibility floor here could silently drop a real needle cycle
            // during 0 -> 3000 RPM acceleration (or any rapid speed change).
            //
            // Keep only the electrical/EMI blanking window as the rejection criterion.
            // The previous-interval adaptive blanking still rejects ringing/glitches,
            // while a real edge at a faster speed is accepted and used immediately.
            // maxRPMSetting remains an operating/configuration value for timing and
            // diagnostics, but is NOT allowed to veto an authoritative PA0 edge.
            uint32_t triggerQualificationUs = activeBlankingUs;
            if (diff < triggerQualificationUs) {
                // Do NOT silently discard an edge: the machine has one physical
                // trigger per needle cycle. If an edge is too close to the prior
                // edge to classify safely as real trigger vs. electrical glitch,
                // stop/fault rather than risk a phase-shifted or missing STEP.
                rejectedTriggerCount++;
                triggerIntegrityFault(3U);
                return;
            }

            lastMeasuredIntervalUs = diff;
            acceptedTriggerPulses++;
            validTriggerCount++;
            // A real interval now exists: this is the first point at which
            // motion-loss monitoring is allowed to arm.
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
                if (motionRelayEnabled) GPIOB->BRR = (1U << 1);
            }

            // Resynchronize discontinuous stream cleanly on next valid edge
            if (isCaptureStreamDiscontinuous) {
                isCaptureStreamDiscontinuous = false;
                captureResyncCount++;
            }
        }
    }

    // 2. Hardware-synchronous RPM measurement
    if (diff > 0UL && diff < 5000000UL) {
        unsigned long instantRPM = 60000000UL / diff;
        if (currentRPM == 0UL) {
            currentRPM = instantRPM;
        } else {
            currentRPM = (unsigned long)((3UL * instantRPM + 5UL * currentRPM) / 8UL);
        }
    }
    lastTriggerMicros = nowUs;
    lastTriggerCycles = nowCycles;
    acceptedTriggers++;
    STATUS_LED_ON(); // Flash Onboard PC13 LED on Cam Proximity Trigger

    // 3. Atomic Coherent Parameter Snapshot & Zero-Latency Stepper Burst Triggering
    // An impossible manually tuned pulse count must never be converted into a
    // silently clamped burst. Requiring the operator to correct it protects both
    // TIM2 and DDA from running outside the configured timing envelope.
    if (pulseTimingInvalid) {
        // Never silently accept a physical trigger without its corresponding STEP
        // burst. An invalid timing configuration is a trigger-integrity fault.
        triggerIntegrityFault(2U);
        return;
    }
    if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        // Capture integer and fractional microsteps from the exact same generation
        PulseParameters snap;
        snap.integerPart = activePulseParams.integerPart;
        snap.fractionalPart = activePulseParams.fractionalPart;
        snap.generation = activePulseParams.generation;
        paramGenerationUsed = snap.generation;
        acceptedTriggerCount++;
        requestedPulseCount += snap.integerPart;
        int newSteps = (int)snap.integerPart;
        pulseFracAccumulator += snap.fractionalPart;
        if (pulseFracAccumulator >= 1000000UL) {
            newSteps++;
            pulseFracAccumulator -= 1000000UL;
            requestedPulseCount++;
        }

        // Servo is the master: derive this trigger's burst period from the exact
        // physical revolution interval and exact integer pulse count for this burst.
        // First trigger has no interval yet, so the configured max-RPM value remains
        // only the startup/fallback estimate.
        uint32_t startupRevUs = (maxRPMSetting > 0)
            ? (uint32_t)(60000000UL / (uint32_t)maxRPMSetting) : 20000UL;
        uint32_t burstPeriodQ16 = (diff > 0UL)
            ? calculateAdaptiveStepPeriodQ16((uint32_t)diff, (uint32_t)newSteps)
            : calculateAdaptiveStepPeriodQ16(startupRevUs, (uint32_t)newSteps);
        uint16_t burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        if (burstPeriodUs < SERVO_PERIOD_MIN_US) burstPeriodUs = SERVO_PERIOD_MIN_US;
        if (burstPeriodUs > SERVO_PERIOD_MAX_US) burstPeriodUs = SERVO_PERIOD_MAX_US;
        if (diff > 0UL) {
            updateStepPeriodFromServoInterval((uint32_t)diff, (uint32_t)newSteps);
            burstPeriodQ16 = servoPeriodQ16;
            burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        }

        if (newSteps > 0) {
            if (flashSaveTx.isSaveLockActive()) {
                // A physical trigger during persistence is not safely replayable:
                // the exact mechanical phase may have advanced. Fault rather than
                // generate a late/make-up STEP. Normal operation saves only at idle.
                triggerIntegrityFault(2U);
                return;
            } else if (hardwareTimerMode) {
                startHardwareTimerBurst(newSteps, burstPeriodUs, burstPeriodQ16);
            } else {
                uint32_t primask = __get_PRIMASK();
                __disable_irq();
                if (stepsRemaining == 0) {
                    stepsRemaining = newSteps;
                    totalStepsInBurst = stepsRemaining;
                    currentStepIndex = 0;
                    lastStepMicros = micros();
                } else {
                    stepsRemaining += newSteps;
                    totalStepsInBurst = stepsRemaining;
                }
                __set_PRIMASK(primask);
            }
        }
    }

    // 4. Signal background loop to exit menu if machine starts running while in settings
    if (menuState != 0) {
        pendingMenuExit = true;
    }
}

void setup() {
    // Hardware Safety: Ensure Main Motor Relay Pin (PB1) is driven LOW in hardware before setting OUTPUT
    GPIOB->BRR = (1 << 1); // Atomic Clear PB1 LOW
    pinMode(mainMotorRelayPin, OUTPUT);
    digitalWrite(mainMotorRelayPin, LOW);

    pinMode(stepPin, OUTPUT);
    pinMode(dirPin, OUTPUT);
    applyMotorDirection();
    STEP_HIGH_IDLE();

    pinMode(proxSensorPin, INPUT_PULLUP);
    pinMode(tapeSensorPin, INPUT_PULLUP);
    pinMode(coilSensorPin, INPUT_PULLUP);
    pinMode(futureSensor2Pin, INPUT_PULLUP);

    pinMode(btnUp, INPUT_PULLUP);
    pinMode(btnDown, INPUT_PULLUP);
    pinMode(btnMode, INPUT_PULLUP);

    pinMode(statusLedPin, OUTPUT);
    STATUS_LED_OFF(); // Built-in LED initial state: OFF

    // Initialize ARM Cortex-M3 DWT Cycle Counter for Sub-Microsecond Hardware Timestamping
#if defined(CoreDebug) && defined(DWT)
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
#endif

    // Load configuration and arm the primary motion path before any UI splash.
    // This guarantees that servo/proximity activity is never hidden behind a boot delay.
    loadFromEEPROM();
    initHardwareTimer2();
    initHardwareStepTimer1();
    initHardwareSafetyTimer3();
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
    initFreeRunningTimer4();
#endif

    attachInterrupt(digitalPinToInterrupt(proxSensorPin), sensorISR, FALLING);
    // PA0 edge capture gets the highest application interrupt priority.
    // TIM1 STEP servicing is deliberately one level lower so a STEP update
    // cannot postpone the physical proximity edge bookkeeping. TIM3 remains
    // below both; it is a safety monitor, not the motion clock.
    NVIC_SetPriority(EXTI0_IRQn, 0);
    NVIC_SetPriority(TIM1_UP_IRQn, 1);
    NVIC_SetPriority(TIM2_IRQn, 2);
    NVIC_SetPriority(TIM3_IRQn, 2);
    NVIC_SetPriority(SysTick_IRQn, 3);
    IWDG_INIT();

    Wire.begin();
    Wire.setClock(400000);
#if defined(WIRE_HAS_TIMEOUT) || defined(ARDUINO_ARCH_STM32)
    Wire.setTimeout(25000);
#endif
    lcd.init();
    lcd.backlight();
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("NIPON ZIPPER IND");
    lcd.setCursor(0, 1);
    lcd.print("RAJESH SHAH     ");
    bootSplashActive = true;
    bootSplashUntilMs = millis() + 2000UL;
}

void loop() {
    IWDG_FEED();
    if (bootSplashActive && (int32_t)(millis() - bootSplashUntilMs) >= 0) {
        bootSplashActive = false;
        oldMenuState = -1;
    }

    // =========================================================================
    // INTERACTIVE OPTOCOUPLER SINKING BENCH TEST (Menu 9, Option 8)
    // Allows technician to verify PUL- <= 0.5V with standard Digital Multimeter
    // =========================================================================
    if (menuState == 9 && infoIndex == 8 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        if (digitalRead(btnUp) == LOW) {
            STEP_LOW_ACTIVE(); // Force PA8 LOW (Sinks DM542 PUL- to GND)
            stepPinState = LOW;
        } else {
            STEP_HIGH_IDLE();  // Release to Idle HIGH (+5V through optocoupler)
            stepPinState = HIGH;
        }
    }

    // Onboard PC13 LED: Live Cam Proximity Diagnostic (Handwheel alignment & monitoring)
    if (!hwBurstActive && stepsRemaining == 0) {
        if (movementState == STATE_COMPLETE || movementState == STATE_ABORTED) {
            movementState = STATE_IDLE; // Safely return to IDLE when machine is at rest
        }
        if (digitalRead(proxSensorPin) == LOW) {
            STATUS_LED_ON();  // Cam detected in front of sensor
        } else {
            STATUS_LED_OFF(); // Cam clear
        }
    }

    // =========================================================================
    // SAFETY GUARD STATUS & BYPASS CONTROLLER
    // Real-time sensor sampling & E-stop executed by 1 kHz TIM3 hardware interrupt.
    // =========================================================================
    // Auxiliary sensor state is deliberately isolated from the PA0->PA8 motion path.
    // If all auxiliary features are OFF, clear any stale relay/fault state.
    if (!sensorGuardActive && !coilGuardActive && !pb3GuardActive && !motionRelayEnabled) {
        auxSensorFaultActive = false;
        isSensorFaultTripped = false;
        GPIOB->BRR = (1U << 1);
        pa3FaultCounterMs = 0;
        pb0FaultCounterMs = 0;
    }

    // RPM Zeroing timeout if machine stops > 2.0s
    uint32_t currentLoopUs = get_hardware_timestamp_us();
    if (currentRPM > 0UL && ((uint32_t)(currentLoopUs - lastTriggerMicros) > 2000000UL)) {
        currentRPM = 0UL;
        lastMeasuredIntervalUs = 0UL; // Reset measured interval on standstill
        hasValidPriorTrigger = false;
        // Keep oldMenuState intact to prevent lcd.clear() full redraw glitch on startup!
    }

    // SAFE IDLE AUTO-SAVE: normal operator persistence is automatic and is
    // performed only at full standstill. The legacy 60-second qualification
    // engine remains compiled for diagnostics but no longer gates saving.
    serviceSafeAutoSave();

    // Safety Auto-Abort: Return to Main Screen if machine starts running while in any menu
    if (pendingMenuExit) {
        pendingMenuExit = false;
        // Do NOT reload EEPROM here: loadFromEEPROM() calls applyMotorDirection(),
        // which can intentionally stop an active STEP burst. Once PA0 starts the
        // machine, the primary motion path must never be interrupted by UI exit logic.
        // Staged menu values were never applied while the machine was running, so
        // simply discard the staged UI state and return to the main screen.
        menuState = 0;
        oldMenuState = -1;
        hasStagedChanges = false;
        safeAutoSavePending = false;
    }

    // Classic DDA Software Fallback Stepper Execution (Active only when hardwareTimerMode == false)
    if (!hardwareTimerMode && stepsRemaining > 0) {
        unsigned long currentMicros = micros();
        // DDA is a service fallback only.  It follows the most recently measured
        // physical Proximity interval and does NOT invent an acceleration/deceleration ramp.
        unsigned long activeStepPeriod = (unsigned long)activePulseWidth;
        // In DDA mode, each toggle is half of the step period (50% duty cycle)
        unsigned long halfPeriod = activeStepPeriod / 2UL;
        if (halfPeriod < 3UL) halfPeriod = 3UL; // Minimum 3us half-period (6us step period)

        if (currentMicros - lastStepMicros >= halfPeriod) {
            if (stepPinState == HIGH) {
                STEP_LOW_ACTIVE();
                stepPinState = LOW;
            } else {
                STEP_HIGH_IDLE();
                stepPinState = HIGH;
                stepsRemaining--;
                currentStepIndex++;
                if (stepsRemaining % 100 == 0) {
                    IWDG_FEED();
                }
            }

            if (currentMicros - lastStepMicros > (halfPeriod * 3UL) / 2UL) {
                lastStepMicros = currentMicros;
            } else {
                lastStepMicros += halfPeriod;
            }
        }
        return;
    }

// Manual Save Confirmation Dialog (menuState 12) eliminated per Rajesh Shah directive
    // Auto-Relock Timeout after 30s of inactivity
    if (!isUiLocked && menuState == 0) {
        if (millis() - lastUnlockActivity > 30000UL) {
            isUiLocked = true;
            oldMenuState = -1;
        }
    }

    // Industrial Edge-Triggered Button States with Hold Auto-Repeat
static bool upPressedState = false;
static unsigned long upFirstPressTime = 0UL;
static unsigned long lastUpRepeatTime = 0UL;

static bool downPressedState = false;
static unsigned long downFirstPressTime = 0UL;
static unsigned long lastDownRepeatTime = 0UL;

    // Button Debouncing and Event Processing
    if (millis() - lastButtonCheck > 20UL) {
        lastButtonCheck = millis();
        if (digitalRead(btnUp) == LOW || digitalRead(btnDown) == LOW || digitalRead(btnMode) == LOW) {
            lastUnlockActivity = millis();
        }

        // Single Click MODE handling: Pulse Tuning Gear Change (0.10 -> 1.00 -> 10.0 -> 100 Pulses)
        if (pendingSingleClick && (millis() - lastModeClickTime > 350UL)) {
            pendingSingleClick = false;
            if (isUiLocked && menuState == 0) {
                uiBannerLine1 = "KEYPAD LOCKED!  ";
                uiBannerLine2 = "DBL-CLICK [MODE]";
                uiMessageTimer = millis() + 1000UL;
                oldMenuState = -1;
            } else if (!isUiLocked && menuState == 0) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (stepGearFixed == 100000ULL) {
                        stepGearFixed = 1000000ULL;
                        uiBannerLine1 = "GEAR: 1.00 PULSE";
                    } else if (stepGearFixed == 1000000ULL) {
                        stepGearFixed = 10000000ULL;
                        uiBannerLine1 = "GEAR: 10.0 PULSE";
                    } else if (stepGearFixed == 10000000ULL) {
                        stepGearFixed = 100000000ULL;
                        uiBannerLine1 = "GEAR: 100 PULSE ";
                    } else {
                        stepGearFixed = 100000ULL;
                        uiBannerLine1 = "GEAR: 0.10 PULSE";
                    }
                    uiBannerLine2 = "FINE TUNING OK  ";
                    uiMessageTimer = millis() + 800UL;
                    lastUnlockActivity = millis();
                    oldMenuState = -1;
                } else {
                    uiBannerLine1 = "MACHINE RUNNING!";
                    uiBannerLine2 = "GEAR CHG BLOCKED";
                    uiMessageTimer = millis() + 800UL;
                    oldMenuState = -1;
                }
            }
        }

        // Dual Button Press: Emergency Factory Reset (>10s)
        if (digitalRead(btnUp) == LOW && digitalRead(btnDown) == LOW) {
            if (!upDownPressed) dualPressTime = millis();
            upDownPressed = true;
            if (millis() - dualPressTime > 10000UL && menuState != 3) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    menuState = 3;
                    resetChoice = false;
                    oldMenuState = -1;
                } else {
                    uiBannerLine1 = "MACHINE RUNNING!";
                    uiBannerLine2 = "RESET BLOCKED!  ";
                    uiMessageTimer = millis() + 1000UL;
                    oldMenuState = -1;
                }
            }
        } else {
            upDownPressed = false;
        }

        // MODE Button State Machine
        if (digitalRead(btnMode) == LOW) {
            if (!modePressed) modePressTime = millis();
            modePressed = true;
        } else if (modePressed) {
            unsigned long holdTime = millis() - modePressTime;
            modePressed = false;

            if (menuState == 0) {
                if (holdTime < 350UL) {
                    if (pendingSingleClick && (millis() - lastModeClickTime < 350UL)) {
                        pendingSingleClick = false;
                        isUiLocked = !isUiLocked;
                        lastUnlockActivity = millis();
                        uiBannerLine1 = isUiLocked ? "KEYPAD LOCKED!  " : "KEYPAD UNLOCKED ";
                        uiBannerLine2 = isUiLocked ? "*[L] ACTIVE     " : "*[U] ACTIVE     ";
                        uiMessageTimer = millis() + 800UL;
                        oldMenuState = -1;
                        lastModeClickTime = 0UL;
                    } else {
                        lastModeClickTime = millis();
                        if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                            pendingSingleClick = true;
                        } else {
                            pendingSingleClick = false;
                            if (!isUiLocked) {
                                uiBannerLine1 = "MACHINE RUNNING!";
                                uiBannerLine2 = "GEAR CHG BLOCKED";
                                uiMessageTimer = millis() + 800UL;
                                oldMenuState = -1;
                            }
                        }
                    }
                } else if (holdTime >= 1500UL && holdTime < 3000UL && !isUiLocked) {
                    // 1.5-3 Second Hold: Zipper Size Sequence Switch (#5 -> #8 -> #10 -> #5)
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        currentSize++;
                        if (currentSize > 3) currentSize = 1;
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentSize == 1) currentPulsesFixed = p5_fixed;
                        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                        else currentPulsesFixed = p10_fixed;
                        __set_PRIMASK(primask);
                        updateActivePulseWidth();
                        requestSafeAutoSave(); // Safe deferred standstill save
                        lastUnlockActivity = millis();
                        if (currentSize == 1) {
                            uiBannerLine1 = "ACTIVE: SIZE #5 ";
                            uiBannerLine2 = "PITCH: 2.50 mm  ";
                        } else if (currentSize == 2) {
                            uiBannerLine1 = "ACTIVE: SIZE #8 ";
                            uiBannerLine2 = "PITCH: 3.00 mm  ";
                        } else {
                            uiBannerLine1 = "ACTIVE: SIZE #10";
                            uiBannerLine2 = "PITCH: 4.00 mm  ";
                        }
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "SIZE CHG BLOCKED";
                        uiMessageTimer = millis() + 800UL;
                        oldMenuState = -1;
                    }
                } else if (holdTime >= 7000UL && !isUiLocked) {
                    // 7-second MODE hold: enter Settings only at full standstill.

                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        tempDriverRes       = driverResolution;
                        tempRollerDia       = rollerDia;
                        tempMaxRPM          = maxRPMSetting;
                        tempFeedAngle       = feedAngleDeg;
                        tempSafetyMargin    = safetyMarginPercent;
                        tempSensorGuard     = sensorGuardActive;
                        tempCoilGuard        = coilGuardActive;
                        tempPb3Guard         = pb3GuardActive;
                        tempMotionRelay      = motionRelayEnabled;
                        tempHwTimerMode     = hardwareTimerMode;
                        tempMotorDir        = motorDirection;
                        hasStagedChanges    = false;
                        menuState = 1;
                        hiddenOption = 1;
                        oldMenuState = -1;
                    } else {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "MENU LOCKED [L] ";
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    }
                }
            } else if (menuState == 1) {
                // Hidden Menu Navigation
                if (hiddenOption == 1)      menuState = 2;  // Driver Res
                else if (hiddenOption == 2) menuState = 4;  // Roller Dia
                else if (hiddenOption == 3) menuState = 5;  // Max RPM
                else if (hiddenOption == 4) menuState = 6;  // Feed Angle
                else if (hiddenOption == 5) menuState = 8;  // Safety Margin
                else if (hiddenOption == 6) menuState = 10; // PA3 Tape Guard
                else if (hiddenOption == 7) menuState = 11; // PB0 Coil Guard
                else if (hiddenOption == 8) menuState = 12; // PB3 Future Guard
                else if (hiddenOption == 9) menuState = 14; // Motion->PB1 Relay
                else if (hiddenOption == 10) menuState = 16; // Motor Direction
                else if (hiddenOption == 11) menuState = 18; // Diagnostic Engine (TIM1 hardware / DDA temporary)
                else if (hiddenOption == 12) {
                    evaluateDiagnostics();
                    infoIndex = 1;
                    menuState = 9;  // Info / Diag Screen
                    oldMenuState = -1;
                } else if (hiddenOption == 13) {
                    // 13. EXIT: open a single exit-choice screen.
                    exitSaveChoice = true;
                    menuState = 7;
                    oldMenuState = -1;
                    return;
                }
            } else if (menuState == 7) {
                if (exitSaveChoice) {
                    if (hasStagedChanges) requestSafeAutoSave(0UL);
                    else requestSafeAutoSave(0UL);
                    isUiLocked = true;
                    menuState = 0;
                    oldMenuState = -1;
                    uiBannerLine1 = "SAVE & EXIT     ";
                    uiBannerLine2 = "AUTO-SAVE PEND  ";
                    uiMessageTimer = millis() + 1000UL;
                } else {
                    hasStagedChanges = false;
                    safeAutoSavePending = false;
                    tempDriverRes = driverResolution;
                    tempRollerDia = rollerDia;
                    tempMaxRPM = maxRPMSetting;
                    tempFeedAngle = feedAngleDeg;
                    tempSafetyMargin = safetyMarginPercent;
                    tempSensorGuard = sensorGuardActive;
                    tempCoilGuard = coilGuardActive;
                    tempPb3Guard = pb3GuardActive;
                    tempMotionRelay = motionRelayEnabled;
                    tempHwTimerMode = hardwareTimerMode;
                    tempMotorDir = motorDirection;
                    isUiLocked = true;
                    menuState = 0;
                    oldMenuState = -1;
                    uiBannerLine1 = "EXIT WITHOUT SAVE";
                    uiBannerLine2 = "CHANGES DISCARDED";
                    uiMessageTimer = millis() + 1000UL;
                }
            } else if (menuState == 2 || menuState == 4 || menuState == 5 || menuState == 6 ||
                       menuState == 8 || menuState == 9 || menuState == 10 || menuState == 11 ||
                       menuState == 12 || menuState == 14 || menuState == 16 || menuState == 18) {
                menuState = 1;
                oldMenuState = -1;
            } else if (menuState == 3) {
                if (resetChoice) {
                    loadFactoryDefaults();
                    uiBannerLine1 = "FACTORY RESET OK";
                    uiBannerLine2 = "DEFAULTS LOADED ";
                    uiMessageTimer = millis() + 1000UL;
                }
                menuState = 0;
                oldMenuState = -1;
            }
        }

                // UP Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool upRaw = (digitalRead(btnUp) == LOW);
        bool triggerUpStep = false;
        if (upRaw && !upDownPressed) {
            if (!upPressedState) {
                upPressedState = true;
                upFirstPressTime = millis();
                lastUpRepeatTime = millis();
                triggerUpStep = true; // Immediate 1-step on press!
            } else if (millis() - upFirstPressTime >= 600UL) {
                if (millis() - lastUpRepeatTime >= 200UL) {
                    lastUpRepeatTime = millis();
                    triggerUpStep = true; // Auto-repeat!
                }
            }
        } else {
            upPressedState = false;
        }

        if (triggerUpStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        uiBannerLine1 = "KEYPAD LOCKED!  ";
                        uiBannerLine2 = "DBL-CLICK [MODE]";
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint64_t proposedPulses = currentPulsesFixed + stepGearFixed;
                        uint64_t oldPulses = currentPulsesFixed;
                        currentPulsesFixed = proposedPulses;
                        refreshPulseTimingValidity();
                        currentPulsesFixed = oldPulses;
                        if (pulseTimingInvalid) {
                            refreshPulseTimingValidity();
                            uiBannerLine1 = "TIMING INVALID! ";
                            uiBannerLine2 = "LOWER PULSE/RES";
                            uiMessageTimer = millis() + 1200UL;
                            oldMenuState = -1;
                            break;
                        }
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        currentPulsesFixed = proposedPulses;
                        if (currentPulsesFixed > PULSE_STEP_MAX_FIXED) currentPulsesFixed = PULSE_STEP_MAX_FIXED;
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        uint64_t currentStored = (currentSize == 1) ? pulseStepStored_p5 : ((currentSize == 2) ? pulseStepStored_p8 : pulseStepStored_p10);
                        pulseModifiedByUser = (currentPulsesFixed != currentStored);
                        smoothRunStartMillis = 0UL;
                        autoSavePendingStandstill = false;
                        requestSafeAutoSave();

                        static char tuningL1[17];
                        static char tuningL2[17];
                        unsigned long pInt = (unsigned long)(currentPulsesFixed / 1000000ULL);
                        unsigned long pFrac = (unsigned long)((currentPulsesFixed % 1000000ULL) / 10000ULL);
                        snprintf(tuningL1, sizeof(tuningL1), "PULSE: %lu.%02lu    ", pInt, pFrac);
                        const char* gearStr = "+1.00";
                        if (stepGearFixed == 100000ULL) gearStr = "+0.10";
                        else if (stepGearFixed == 1000000ULL) gearStr = "+1.00";
                        else if (stepGearFixed == 10000000ULL) gearStr = "+10.0";
                        else if (stepGearFixed == 100000000ULL) gearStr = "+100 ";
                        snprintf(tuningL2, sizeof(tuningL2), "GEAR: %s [UP] ", gearStr);
                        uiBannerLine1 = tuningL1;
                        uiBannerLine2 = tuningL2;
                        uiMessageTimer = millis() + 1200UL;
                        oldMenuState = -1;
                    } else if (currentRPM > 0UL || stepsRemaining > 0 || hwBurstActive) {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "PULSE TUNE LOCK ";
                        uiMessageTimer = millis() + 800UL;
                        oldMenuState = -1;
                    }
                    break;
                case 1:
                    hiddenOption--;
                    if (hiddenOption < 1) hiddenOption = 13;
                    break;
                case 2:
                    tempDriverRes += resStepGear;
                    if (tempDriverRes > 51200) tempDriverRes = 51200;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 3: resetChoice = true; break;
                case 4:
                    tempRollerDia += diaStepGear;
                    if (tempRollerDia > 100.0f) tempRollerDia = 100.0f;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 5:
                    tempMaxRPM += rpmStepGear;
                    if (tempMaxRPM > 4000) tempMaxRPM = 4000;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 6:
                    tempFeedAngle += angleStepGear;
                    if (tempFeedAngle > 270) tempFeedAngle = 270;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 8:
                    tempSafetyMargin += marginStepGear;
                    if (tempSafetyMargin > 25) tempSafetyMargin = 25;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 10: tempSensorGuard = true; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 11: tempCoilGuard = true; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 12: tempPb3Guard = true; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 14: tempMotionRelay = true; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 16: tempMotorDir = false; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 18: tempHwTimerMode = false; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 7:
                    exitSaveChoice = true;
                    break;
                case 9:
                    infoIndex--;
                    if (infoIndex < 1) infoIndex = 12;
                    break;
// Obsolete manual Save Settings Confirmation Dialog (case 7) removed
            }
            upPressTime = millis();
        }

        // DOWN Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool downRaw = (digitalRead(btnDown) == LOW);
        bool triggerDownStep = false;
        if (downRaw && !upDownPressed) {
            if (!downPressedState) {
                downPressedState = true;
                downFirstPressTime = millis();
                lastDownRepeatTime = millis();
                triggerDownStep = true; // Immediate 1-step on press!
            } else if (millis() - downFirstPressTime >= 600UL) {
                if (millis() - lastDownRepeatTime >= 200UL) {
                    lastDownRepeatTime = millis();
                    triggerDownStep = true; // Auto-repeat!
                }
            }
        } else {
            downPressedState = false;
        }

        if (triggerDownStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        uiBannerLine1 = "KEYPAD LOCKED!  ";
                        uiBannerLine2 = "DBL-CLICK [MODE]";
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentPulsesFixed > stepGearFixed + PULSE_STEP_MIN_FIXED) {
                            currentPulsesFixed -= stepGearFixed;
                        } else {
                            currentPulsesFixed = PULSE_STEP_MIN_FIXED; // Minimum 1.00 pulse clamp
                        }
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        uint64_t currentStored = (currentSize == 1) ? pulseStepStored_p5 : ((currentSize == 2) ? pulseStepStored_p8 : pulseStepStored_p10);
                        pulseModifiedByUser = (currentPulsesFixed != currentStored);
                        smoothRunStartMillis = 0UL;
                        autoSavePendingStandstill = false;
                        requestSafeAutoSave();

                        static char tuningL1[17];
                        static char tuningL2[17];
                        unsigned long pInt = (unsigned long)(currentPulsesFixed / 1000000ULL);
                        unsigned long pFrac = (unsigned long)((currentPulsesFixed % 1000000ULL) / 10000ULL);
                        snprintf(tuningL1, sizeof(tuningL1), "PULSE: %lu.%02lu    ", pInt, pFrac);
                        const char* gearStr = "-1.00";
                        if (stepGearFixed == 100000ULL) gearStr = "-0.10";
                        else if (stepGearFixed == 1000000ULL) gearStr = "-1.00";
                        else if (stepGearFixed == 10000000ULL) gearStr = "-10.0";
                        else if (stepGearFixed == 100000000ULL) gearStr = "-100 ";
                        snprintf(tuningL2, sizeof(tuningL2), "GEAR: %s [DN] ", gearStr);
                        uiBannerLine1 = tuningL1;
                        uiBannerLine2 = tuningL2;
                        uiMessageTimer = millis() + 1200UL;
                        oldMenuState = -1;
                    } else if (currentRPM > 0UL || stepsRemaining > 0 || hwBurstActive) {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "PULSE TUNE LOCK ";
                        uiMessageTimer = millis() + 800UL;
                        oldMenuState = -1;
                    }
                    break;
// case 12 manual confirmation removed
                case 1:
                    hiddenOption++;
                    if (hiddenOption > 13) hiddenOption = 1;
                    break;
                case 2:
                    if (tempDriverRes > resStepGear + 200) tempDriverRes -= resStepGear;
                    else tempDriverRes = 200;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 3: resetChoice = false; break;
                case 4:
                    if (tempRollerDia > diaStepGear + 15.0f) tempRollerDia -= diaStepGear;
                    else tempRollerDia = 15.0f;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 5:
                    if (tempMaxRPM > rpmStepGear + 100) tempMaxRPM -= rpmStepGear;
                    else tempMaxRPM = 100;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 6:
                    if (tempFeedAngle > angleStepGear + 30) tempFeedAngle -= angleStepGear;
                    else tempFeedAngle = 30;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 8:
                    if (tempSafetyMargin >= marginStepGear) tempSafetyMargin -= marginStepGear;
                    hasStagedChanges = true;
                    requestSafeAutoSave();
                    break;
                case 10: tempSensorGuard = false; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 11: tempCoilGuard = false; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 12: tempPb3Guard = false; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 14: tempMotionRelay = false; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 16: tempMotorDir = true; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 18: tempHwTimerMode = true; hasStagedChanges = true; requestSafeAutoSave(); break;
                case 7:
                    exitSaveChoice = false;
                    break;
                case 9:
                    infoIndex++;
                    if (infoIndex > 12) infoIndex = 1;
                    break;
// Obsolete case 7 removed
            }
            downPressTime = millis();
        }

        if (digitalRead(btnUp) == HIGH && digitalRead(btnDown) == HIGH) {
            upDownPressed = false;
        }
    }

    // 16x2 Character LCD Screen Renderer (Anti-Blanking & Anti-Flicker Direct Overwrite)
    if (!bootSplashActive && uiBannerLine1 != nullptr) {
        if (millis() < uiMessageTimer) {
            char b1[17], b2[17];
            snprintf(b1, sizeof(b1), "%-16s", uiBannerLine1);
            snprintf(b2, sizeof(b2), "%-16s", uiBannerLine2 ? uiBannerLine2 : "");
            lcd.setCursor(0, 0); lcd.print(b1);
            lcd.setCursor(0, 1); lcd.print(b2);
            oldMenuState = -2;
            return;
        } else {
            uiBannerLine1 = nullptr;
            uiBannerLine2 = nullptr;
            oldMenuState = -1;
            lcd.clear();
        }
    }

    // Running-State RPM Refresh (0.4ms I2C duration)
    if (menuState == 0 && currentRPM > 0UL && oldMenuState == menuState) {
        if (millis() - lastRpmDisplayUpdate > 250UL) {
            lastRpmDisplayUpdate = millis();
            char rpmBuf[16];
            unsigned int dispRpm = (currentRPM > 9999UL) ? 9999U : (unsigned int)currentRPM;
            snprintf(rpmBuf, sizeof(rpmBuf), "%04u", dispRpm);
            lcd.setCursor(5, 0);
            lcd.print(rpmBuf);
        }
        return;
    }

    // Stationary Screen Refresh (100ms cycle)
    if (!bootSplashActive && millis() - lastDisplayUpdate > 100UL) {
        if (menuState != oldMenuState) {
            lcd.clear();
            oldMenuState = menuState;
        }

        char l1[17], l2[17];
        switch (menuState) {
            case 0: // Normal Operational Screen
            {
                int szNum = (currentSize == 1) ? 5 : ((currentSize == 2) ? 8 : 10);
                double actualPitch = ((double)currentPulsesFixed / 1000000.0) * (3.14159265358979323846 * (double)rollerDia) / (double)driverResolution;
                int actInt = constrain((int)actualPitch, 0, 99);
                int actFrac = constrain((int)((actualPitch - (float)actInt) * 100.0f + 0.5f), 0, 99);
                if (actFrac >= 100) { actInt++; actFrac -= 100; }
                char lenStr[6];
                snprintf(lenStr, sizeof(lenStr), "%d.%02d", actInt, actFrac);
                unsigned int dispRpm = constrain((unsigned int)currentRPM, 0U, 9999U);
                snprintf(l1, sizeof(l1), "S:%-2d %04u I:%s", szNum, dispRpm, lenStr);
                char cue = (activePulseWidth <= 2) ? '*' : ((activePulseWidth < 6) ? '#' : (hardwareTimerMode ? 'H' : 'u'));
                int pInt = (int)(currentPulsesFixed / 1000000ULL);
                int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                snprintf(l2, sizeof(l2), "P:%3d.%01d W:%d%c%s",
                         pInt, pFrac, activePulseWidth, cue, isUiLocked ? "[L]" : "[U]");
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
            }
            break;

            case 1: // Hidden Settings Staged Menu List
            {
                if (hiddenOption == 1)      snprintf(l1, sizeof(l1), "1. Driver Res   ");
                else if (hiddenOption == 2) snprintf(l1, sizeof(l1), "2. Roller Dia   ");
                else if (hiddenOption == 3) snprintf(l1, sizeof(l1), "3. Max RPM      ");
                else if (hiddenOption == 4) snprintf(l1, sizeof(l1), "4. Feed Angle   ");
                else if (hiddenOption == 5) snprintf(l1, sizeof(l1), "5. Safety Margin");
                else if (hiddenOption == 6) snprintf(l1, sizeof(l1), "6. Tape Guard   ");
                else if (hiddenOption == 7) snprintf(l1, sizeof(l1), "7. Coil Guard   ");
                else if (hiddenOption == 8) snprintf(l1, sizeof(l1), "8. PB3 Future   ");
                else if (hiddenOption == 9) snprintf(l1, sizeof(l1), "9. Motion Relay ");
                else if (hiddenOption == 10)snprintf(l1, sizeof(l1), "10. Motor Dir   ");
                else if (hiddenOption == 11)snprintf(l1, sizeof(l1), "11. Engine/Diag ");
                else if (hiddenOption == 12)snprintf(l1, sizeof(l1), "12. Info Diag   ");
                else if (hiddenOption == 13)snprintf(l1, sizeof(l1), "13. EXIT        ");

                if (hiddenOption == 1)      snprintf(l2, sizeof(l2), "Val: %-5d steps", (int)tempDriverRes);
                else if (hiddenOption == 2) {
                    int dInt = (int)tempRollerDia;
                    int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
                    snprintf(l2, sizeof(l2), "Val: %2d.%1d mm  ", dInt, dFrac);
                }
                else if (hiddenOption == 3) snprintf(l2, sizeof(l2), "Val: %-4d RPM  ", (int)tempMaxRPM);
                else if (hiddenOption == 4) snprintf(l2, sizeof(l2), "Val: %-3d deg   ", (int)tempFeedAngle);
                else if (hiddenOption == 5) snprintf(l2, sizeof(l2), "Val: %-2d%%     ", (int)tempSafetyMargin);
                else if (hiddenOption == 6) snprintf(l2, sizeof(l2), tempSensorGuard ? "PA3: >ON       " : "PA3: >OFF      ");
                else if (hiddenOption == 7) snprintf(l2, sizeof(l2), tempCoilGuard ? "PB0: >ON       " : "PB0: >OFF      ");
                else if (hiddenOption == 8) snprintf(l2, sizeof(l2), tempPb3Guard ? "PB3: >ON       " : "PB3: >OFF      ");
                else if (hiddenOption == 9) snprintf(l2, sizeof(l2), tempMotionRelay ? "PB1: >ON       " : "PB1: >OFF      ");
                else if (hiddenOption == 10)snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: REVERSE[RV]" : "Dir: NORMAL [FW]");
                else if (hiddenOption == 11)snprintf(l2, sizeof(l2), "View System Diag");
                else if (hiddenOption == 12)snprintf(l2, sizeof(l2), "View System Diag ");
                else if (hiddenOption == 13)snprintf(l2, sizeof(l2), "Choose Save/Exit ");

                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
            }
            break;

            case 2: // Edit Driver Resolution
                snprintf(l1, sizeof(l1), "Res: %-5d stp", (int)tempDriverRes);
                snprintf(l2, sizeof(l2), "Step: %-3d [MD]", (int)resStepGear);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 3: // Emergency Factory Reset
                lcd.setCursor(0, 0); lcd.print("Factory Reset?  ");
                lcd.setCursor(0, 1); lcd.print(resetChoice ? ">YES  NO         " : " YES >NO         ");
                break;

            case 4: // Edit Roller Diameter
            {
                int dInt = (int)tempRollerDia;
                int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
                snprintf(l1, sizeof(l1), "Dia: %2d.%1d mm  ", dInt, dFrac);
                int gInt = (int)diaStepGear;
                int gFrac = (int)((diaStepGear - (float)gInt) * 10.0f + 0.5f);
                snprintf(l2, sizeof(l2), "Step: %d.%1d [MD]", gInt, gFrac);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
            }
            break;

            case 5: // Edit Max RPM
                snprintf(l1, sizeof(l1), "Max RPM: %-4d   ", (int)tempMaxRPM);
                snprintf(l2, sizeof(l2), "Step: %-3d [MD]", (int)rpmStepGear);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 6: // Edit Feed Angle
                snprintf(l1, sizeof(l1), "Angle: %-3d deg ", (int)tempFeedAngle);
                snprintf(l2, sizeof(l2), "Step: %-2d  [MD]", (int)angleStepGear);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 7:
                lcd.setCursor(0, 0); lcd.print("EXIT OPTIONS    ");
                lcd.setCursor(0, 1); lcd.print(exitSaveChoice ? ">SAVE & EXIT    " : ">EXIT NO SAVE   ");
                break;

            case 8: // Edit Safety Margin
                snprintf(l1, sizeof(l1), "Safety Margin:  ");
                snprintf(l2, sizeof(l2), "Margin: %-2d%% [MD]", (int)tempSafetyMargin);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 10:
                snprintf(l1, sizeof(l1), "Tape Guard:     ");
                snprintf(l2, sizeof(l2), tempSensorGuard ? "PA3: >ON  [UP]" : "PA3: >OFF [DN]");
                lcd.setCursor(0, 0); lcd.print(l1); lcd.setCursor(0, 1); lcd.print(l2); break;
            case 11:
                snprintf(l1, sizeof(l1), "Coil Guard:     ");
                snprintf(l2, sizeof(l2), tempCoilGuard ? "PB0: >ON  [UP]" : "PB0: >OFF [DN]");
                lcd.setCursor(0, 0); lcd.print(l1); lcd.setCursor(0, 1); lcd.print(l2); break;
            case 12:
                snprintf(l1, sizeof(l1), "PB3 Future:     ");
                snprintf(l2, sizeof(l2), tempPb3Guard ? "PB3: >ON  [UP]" : "PB3: >OFF [DN]");
                lcd.setCursor(0, 0); lcd.print(l1); lcd.setCursor(0, 1); lcd.print(l2); break;
            case 14:
                snprintf(l1, sizeof(l1), "Motion Relay:   ");
                snprintf(l2, sizeof(l2), tempMotionRelay ? "PB1: >ON  [UP]" : "PB1: >OFF [DN]");
                lcd.setCursor(0, 0); lcd.print(l1); lcd.setCursor(0, 1); lcd.print(l2); break;
            case 16:
                snprintf(l1, sizeof(l1), "Motor Direction:");
                snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: >REV  [DN]" : "Dir: >FWD  [UP]");
                lcd.setCursor(0, 0); lcd.print(l1); lcd.setCursor(0, 1); lcd.print(l2); break;

            case 18:
                snprintf(l1, sizeof(l1), "STEP ENGINE:    ");
                snprintf(l2, sizeof(l2), tempHwTimerMode ? "TIM1: >HW  [UP] " : "DDA: >ON  [UP]  ");
                lcd.setCursor(0, 0); lcd.print(l1); lcd.setCursor(0, 1); lcd.print(l2); break;

            case 9: // Info / Diag: System Info & Field Troubleshooter
            {
                int cycle = (millis() / 1500UL) % 2;
                lcd.setCursor(0, 0);
                switch (infoIndex) {
                    case 1:
                        lcd.print("VER: " FW_VERSION_STR);
                        lcd.setCursor(0, 1);
                        lcd.print("BUILD: " FW_BUILD_DATE_STR);
                        break;
                    case 2:
                        lcd.print("DEV: RAJESH SHAH");
                        lcd.setCursor(0, 1);
                        lcd.print("NIPON ZIPPER IND");
                        break;
                    case 3:
                        lcd.print("1. MOTOR STALL? ");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: INC ANGLE  " : "OR DEC RES/RPM  ");
                        break;
                    case 4:
                        lcd.print("2. PITCH ERROR? ");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: TUNE DIA MM" : "OR GEAR +/- PUL ");
                        break;
                    case 5:
                        lcd.print("3. SENSOR NOISE?");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: CLEAN CAM  " : "CHECK PC817 GND ");
                        break;
                    case 6:
                        lcd.print("4. MOTOR HOT?   ");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: SW4=HALF   " : "CURR 2.8A-3.0A  ");
                        break;
                    case 7:
                        lcd.print("5. TEETH DRIFT? ");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: TIGHT TAPE " : "CHK ROLLER GRIP ");
                        break;
                    case 8:
                        lcd.print("6. OPTO SINK TST");
                        lcd.setCursor(0, 1);
                        lcd.print(digitalRead(btnUp) == LOW ? "V<=0.5V SINK ON " : "HOLD [UP] TEST  ");
                        break;
                    case 9:
                        lcd.print("PROX HEALTH     ");
                        lcd.setCursor(0, 1);
                        if (lastMeasuredIntervalUs > 0UL) {
                            char b[17];
                            snprintf(b, sizeof(b), "P:%4lu RPM:%4lu", lastMeasuredIntervalUs, currentRPM);
                            lcd.print(b);
                        } else {
                            lcd.print("P:WAIT  RPM: 0  ");
                        }
                        break;
                    case 10:
                        lcd.print("SYNC HEALTH     ");
                        lcd.setCursor(0, 1);
                        if (isMotionSyncLost) lcd.print("FAULT:SYNC LOST ");
                        else if (servoPhaseLocked) {
                            char b[17];
                            snprintf(b, sizeof(b), "LOCK J:%4luus", servoMaxJitterUs);
                            lcd.print(b);
                        } else lcd.print("ACQUIRING...    ");
                        break;
                    case 11:
                        lcd.print("CAPTURE HEALTH  ");
                        lcd.setCursor(0, 1);
                        {
                            char b[17];
                            snprintf(b, sizeof(b), "OF:%lu RS:%lu", captureOverrunCount, captureResyncCount);
                            lcd.print(b);
                        }
                        break;
                    case 12:
                        lcd.print("STEP / GUARD    ");
                        lcd.setCursor(0, 1);
                        {
                            char b[17];
                            if (!tempSensorGuard) snprintf(b, sizeof(b), "STEP:%s G:OFF", hwBurstActive ? "RUN" : "IDLE");
                            else if (digitalRead(tapeSensorPin) == HIGH) snprintf(b, sizeof(b), "STEP:%s TAPE-END", hwBurstActive ? "RUN" : "IDLE");
                            else snprintf(b, sizeof(b), "STEP:%s TAPE:OK", hwBurstActive ? "RUN" : "IDLE");
                            lcd.print(b);
                        }
                        break;
                    default:
                        infoIndex = 1;
                        break;
                }
            }
            break;

// case 12 manual confirmation screen removed

// Obsolete case 7 display dialog removed
        }
        lastDisplayUpdate = millis();
    }
}
