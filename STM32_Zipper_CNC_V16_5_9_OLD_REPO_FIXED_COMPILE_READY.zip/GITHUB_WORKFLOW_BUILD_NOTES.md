# GitHub Actions Build Package

This ZIP is prepared for the STM32F103C8T6 GitHub Actions workflow.

- Target: STM32F103C8T6 / Blue Pill
- Board core: STMicroelectronics STM32 2.11.0
- FQBN: `STMicroelectronics:stm32:GenF1:pn=BLUEPILL_F103C8`
- Sketch is auto-discovered from the firmware folder.
- The generated `.bin` is normalized to:
  `build/STM32_Zipper_CNC_V16_5_0_Production.bin`
- ARM vector-table SP/PC validation is performed before artifact upload.
- The workflow is also manually runnable through GitHub Actions (`workflow_dispatch`).

## Hardware mapping in this firmware

- PA0 = Proximity / TIM2_CH1 capture
- PA8 = STEP / TIM1_CH1
- PA2 = DIR
- PA3 = optional Tape Guard

Do not reconnect STEP to PA1.
