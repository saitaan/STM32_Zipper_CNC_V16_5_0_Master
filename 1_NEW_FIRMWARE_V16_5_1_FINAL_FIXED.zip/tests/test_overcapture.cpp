#include <iostream>
#include <cassert>
#include <cstdint>
#include "../include/hardware_capture_spec.h"

// Simulated STM32 Timer Status Register
#define TIM_SR_CC1IF (1U << 1)
#define TIM_SR_CC1OF (1U << 9)

struct MockTimer2 {
    uint32_t SR;
    uint32_t CCR1;
    uint32_t CNT;
};

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Hardware Overcapture (CC1OF) Detection & Handling" << std::endl;
    std::cout << "==========================================================" << std::endl;

    MockTimer2 tim2 = {0, 0, 0};
    HardwareCaptureDiagnostics diag = {0, 0, 0, 0, 0, 0, 0, 0};

    // Scenario 1: Clean Single Trigger
    tim2.CNT  = 12345;
    tim2.CCR1 = 12345;
    tim2.SR  |= TIM_SR_CC1IF; // Capture flag set by hardware

    // Emulate ISR processing
    if (tim2.SR & TIM_SR_CC1OF) {
        tim2.SR &= ~TIM_SR_CC1OF;
        diag.captureOverruns++;
    }
    if (tim2.SR & TIM_SR_CC1IF) {
        tim2.SR &= ~TIM_SR_CC1IF;
        diag.hardwareCapturesRead++;
        diag.lastLatchedCCR = tim2.CCR1;
    }

    assert(diag.hardwareCapturesRead == 1);
    assert(diag.captureOverruns == 0);
    assert(diag.lastLatchedCCR == 12345);
    std::cout << "[PASS] 1. Clean Hardware Capture Verified." << std::endl;

    // Scenario 2: Overcapture Condition (Two edges arrive before ISR reads CCR1)
    // Hardware sets CC1OF flag
    tim2.CCR1 = 54321; // Overwritten by second hardware edge
    tim2.SR  |= (TIM_SR_CC1IF | TIM_SR_CC1OF); // Hardware sets BOTH flags

    // Emulate ISR processing
    if (tim2.SR & TIM_SR_CC1OF) {
        tim2.SR &= ~TIM_SR_CC1OF; // Explicit clear
        diag.captureOverruns++;    // Explicit detection and recording
    }
    if (tim2.SR & TIM_SR_CC1IF) {
        tim2.SR &= ~TIM_SR_CC1IF;
        diag.hardwareCapturesRead++;
        diag.lastLatchedCCR = tim2.CCR1;
    }

    assert(diag.hardwareCapturesRead == 2);
    assert(diag.captureOverruns == 1); // Explicitly detected and counted!
    assert(diag.lastLatchedCCR == 54321);
    std::cout << "[PASS] 2. Hardware Overcapture (CC1OF) Explicitly Detected & Logged." << std::endl;

    // Scenario 3: Verify Flag Clearing (SR is clean after ISR exit)
    assert((tim2.SR & (TIM_SR_CC1IF | TIM_SR_CC1OF)) == 0);
    std::cout << "[PASS] 3. Status Register Flags Deterministically Cleared." << std::endl;

    std::cout << "==========================================================" << std::endl;
    std::cout << "OVERCAPTURE TEST PASSED (100% GREEN)" << std::endl;
    std::cout << "==========================================================" << std::endl;
    return 0;
}
