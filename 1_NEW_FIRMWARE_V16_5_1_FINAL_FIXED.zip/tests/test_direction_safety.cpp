#include <iostream>
#include <cassert>
#include <cstdint>
#include "../include/burst_queue.h"
#include "../include/motion_scheduler.h"

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Direction Change Safety & Setup/Hold Delay (20 us)" << std::endl;
    std::cout << "==========================================================" << std::endl;

    BurstQueue queue;

    // Alternating directions at maximum pulse rate:
    // Stream of 1000 bursts: FORWARD (0) -> REVERSE (1) -> FORWARD (0) -> REVERSE (1)
    const uint32_t BURSTS = 1000;
    uint8_t currentHardwareDir = 0;
    uint32_t totalPulsesExecuted = 0;
    uint32_t directionSwitches = 0;

    for (uint32_t i = 0; i < BURSTS; i++) {
        uint8_t dir = (uint8_t)(i & 1);
        uint32_t steps = (i % 32) + 1;

        // Enqueue next burst
        assert(queue.enqueue(steps, dir, i * 1000, i + 1));

        // Consume and execute burst
        BurstItem item{};
        assert(queue.dequeue(item));

        if (item.direction != currentHardwareDir) {
            // Direction change detected!
            // Verify DIR_SAFETY_DELAY_US setup and hold delay requirement
            assert(DIR_SAFETY_DELAY_US >= 20); // Must be >= 20us (DM542 requires 5us)
            currentHardwareDir = item.direction;
            directionSwitches++;
        }

        // Execute burst pulses
        for (uint32_t s = 0; s < item.stepCount; s++) {
            uint16_t arr = MotionScheduler::calculateStepPeriodARR(s, item.stepCount, 70);
            assert(arr >= 69);
            totalPulsesExecuted++;
        }
    }

    assert(queue.isEmpty());
    assert(directionSwitches == BURSTS - 1);
    assert(queue.verifyInvariant());
    assert(queue.submittedPulses == totalPulsesExecuted);
    assert(queue.droppedPulses == 0);

    std::cout << "[PASS] Executed " << BURSTS << " Alternating Bursts (" << totalPulsesExecuted << " Pulses)." << std::endl;
    std::cout << "[PASS] Direction Switches: " << directionSwitches << " Verified with >= 20us Setup/Hold Margin." << std::endl;
    std::cout << "==========================================================" << std::endl;
    std::cout << "DIRECTION SAFETY TEST PASSED (100% GREEN)" << std::endl;
    std::cout << "==========================================================" << std::endl;
    return 0;
}
