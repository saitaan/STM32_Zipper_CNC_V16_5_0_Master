#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================================="
echo "COMPILING & RUNNING HOST-SIDE HARDENED TEST HARNESS"
echo "Working Directory: $SCRIPT_DIR"
echo "=========================================================="

TESTS=(
    "test_exact_regression"
    "test_comprehensive_suite"
    "test_queue_formal"
    "test_fractional_ratios"
    "test_direction_safety"
    "test_overcapture"
    "test_trigger_capture"
    "test_pulse_conservation"
    "test_burst_boundary"
    "test_timer_overflow"
    "test_rpm_sweep"
    "test_watchdog"
    "test_fault_recovery"
    "test_randomized_stress_500k"
    "test_long_duration_10m"
)

TOTAL_PASS=0
TOTAL_FAIL=0

for t in "${TESTS[@]}"; do
    echo "--- Building & Running $t ---"
    g++ -O3 -Wall -Wextra -std=c++11 -I../include "${t}.cpp" -o "$t"
    ./"$t"
    rm -f "$t"
    TOTAL_PASS=$((TOTAL_PASS + 1))
    echo ""
done

echo "=========================================================="
echo "ALL $TOTAL_PASS TEST TARGETS PASSED 100% GREEN (ZERO FAILURES)!"
echo "=========================================================="
