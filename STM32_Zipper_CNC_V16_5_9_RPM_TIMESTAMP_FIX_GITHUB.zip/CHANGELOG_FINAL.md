# Changelog — V16.5.9 PA0/TIM2 + PA8/TIM1

## Current update
- Confirmed target: STM32F103C8T6.
- PA0 proximity sensor remains the primary trigger input, using EXTI and TIM2_CH1 capture.
- PA8 is configured as TIM1_CH1 active-low hardware STEP/PUL output.
- Trigger capture timer and STEP pulse timer are separated: TIM2 captures, TIM1 generates pulses.
- MODE zipper-size hold window extended from 1.5–3 seconds to 1.5–8 seconds; 8-second hold remains reserved for hidden settings.
- Persistence now checks safe standstill before requesting the save lock and feeds the watchdog around early exits and Flash write/readback path.
- GitHub Actions workflow corrected to run host tests and compile the actual sketch folder, then publish the binary artifact.

## Validation notes
- Host test results must be obtained by running `bash tests/run_tests.sh` or from the GitHub Actions run.
- Target compilation is delegated to GitHub Actions; no local STM32 target compile is claimed here.
- Oscilloscope/logic-analyzer validation on the actual machine is mandatory before production use, especially for PA8 pulse polarity/width, PA0-to-PA8 synchronization, watchdog behavior during persistence, and MODE size retention.
- Historical files and comments may refer to PA1/TIM2 because that was the previous hardware mapping; the current main sketch is the source of truth for PA8/TIM1.


## RPM display update
- RPM display field now refreshes periodically while stopped as well as running, so stale RPM digits are cleared.
- RPM values are derived only from a measured interval of 0–2,000,000 us; longer gaps are treated as standstill/new-start conditions rather than a displayed low-speed reading.
- No trigger pin, STEP pin, pulse-count, button mapping, or timer mapping changed in this RPM-only update.

## Factory-floor audit follow-up (2026-10-09)
- Fixed auto-save UI correctness: `AUTO-SAVED OK!` is shown only when `saveToEEPROM()` reports a verified successful transaction.
- Failed auto-save now displays `SAVE FAILED!` and keeps the pending-save state for a later safe retry.
- MODE zipper-size commit now reports a failed persistence transaction instead of implying the save succeeded; the selected size remains a RAM change until successfully saved.
- Settings-apply save path now checks the transaction result and retains pending retry state on failure.
- Re-ran the included host regression suite: 25 suites passed. This is not a substitute for STM32 target compilation or physical-machine validation.


## RPM timestamp-domain correction (2026-10-09)
- Fixed RPM zeroing, RPM freshness, and motion-watchdog elapsed-time checks to use `get_hardware_timestamp_us()` consistently with `lastTriggerMicros`.
- This addresses a concrete clock-domain mismatch: the stored timestamp can be TIM4-based, while the old elapsed-time checks used Arduino `micros()`. Mixing clock origins can make RPM appear to reset while machine movement continues.
- PA0 trigger qualification and PA8 STEP-generation code were not changed. Host tests and GitHub STM32 compile are still required; physical behavior remains unverified until tested on the machine.
