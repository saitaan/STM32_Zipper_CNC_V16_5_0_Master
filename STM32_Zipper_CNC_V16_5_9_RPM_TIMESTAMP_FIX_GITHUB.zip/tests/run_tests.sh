#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p /tmp/zipper-cnc-tests
count=0
for src in tests/test_*.cpp; do
  name="$(basename "$src" .cpp)"
  echo "[BUILD] $name"
  g++ -std=c++17 -O2 -Wall -Wextra -pedantic -Iinclude -Isrc -ISTM32_Zipper_CNC_V16_5_4_Firmware "$src" -o "/tmp/zipper-cnc-tests/$name"
  echo "[RUN]   $name"
  "/tmp/zipper-cnc-tests/$name"
  count=$((count + 1))
done
echo "Host tests completed: $count suites passed."

# Regression guard: trigger timestamps and elapsed-time checks must share the
# same hardware timestamp clock domain (TIM4 when available, fallback otherwise).
FIRMWARE="STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino"
if grep -nE 'micros\(\)[[:space:]]*-[[:space:]]*lastTriggerMicros' "$FIRMWARE"; then
  echo "[FAIL] mixed timestamp domains: micros() compared with lastTriggerMicros" >&2
  exit 1
fi
for required in \
  'get_hardware_timestamp_us() - lastTriggerMicros > 2000000UL' \
  'get_hardware_timestamp_us() - lastTriggerMicros) < 2000000UL' \
  'get_hardware_timestamp_us() - lastTriggerMicros;'; do
  if ! grep -Fq "$required" "$FIRMWARE"; then
    echo "[FAIL] missing timestamp-domain regression guard: $required" >&2
    exit 1
  fi
done
echo "[PASS] RPM/watchdog elapsed-time checks use the trigger timestamp clock domain."
