# STM32 Zipper CNC — V16.5.9 Isolated Trigger/STEP Timers

## Release purpose
This package updates the uploaded PA0/PA1/TIM2 firmware for the confirmed wiring:

- **MCU:** STM32F103C8T6 (Blue Pill, 72 MHz)
- **PA0:** proximity/cam sensor input; falling-edge EXTI plus TIM2_CH1 input capture
- **PA8:** stepper driver PUL−/STEP output; TIM1_CH1 active-low hardware PWM
- **PA2:** DIR output
- **PB13 / PB12 / PB14:** UP / DOWN / MODE buttons (active-low)

The intended timing split is **TIM2 = PA0 trigger interval capture** and **TIM1 = PA8 STEP pulse engine**. TIM2_CH2 is no longer used as the STEP output. PA0 trigger-to-needle scheduling, pulse-count math, queue, and safety logic are otherwise intended to remain unchanged.

## Critical operator behavior
- A proximity trigger is the mechanical timing reference for needle synchronization; do not treat it as a generic button.
- Auto-save is permitted only after the firmware's standstill/safe-idle check passes.
- MODE zipper-size selection uses a 1.5–8 second hold on release; the 8-second hold remains reserved for the hidden settings menu. Changes are accepted only while stopped and unlocked.
- The watchdog timeout was lengthened and feeds were added around persistence exits to reduce save-related resets. This does **not** prove every Flash operation will finish before watchdog expiry on every board/core combination.
- Do not enable automatic motion resume after watchdog reset.

## RPM display correction (V16.5.9 RPM refresh)
- RPM is updated from qualified PA0 trigger intervals only; intervals longer than 2 seconds are treated as standstill/restart and are not displayed as a false low RPM.
- The main screen refreshes the RPM field at 250 ms intervals even when the value is `0000`, preventing a stale display value after a stop.
- This does not alter PA0 trigger qualification or the PA8 STEP scheduling path. RPM correctness still depends on receiving valid proximity edges and must be checked against a tachometer/logic analyzer on the machine.

## GitHub Actions build
The workflow at `.github/workflows/auto_unzip_compile.yml` runs host regression tests and compiles the sketch using the official STM32duino core for `STMicroelectronics:stm32:GenF1:pnum=BLUEPILL_F103C8`. The compiled `.bin` is uploaded as a GitHub Actions artifact. Open **Actions → latest workflow run → Artifacts** to retrieve it.

## Local build
Install Arduino CLI, the STM32duino core and the `LiquidCrystal I2C` library, then run:

```bash
arduino-cli core install STMicroelectronics:stm32
arduino-cli lib install "LiquidCrystal I2C"
arduino-cli compile --fqbn STMicroelectronics:stm32:GenF1:pnum=BLUEPILL_F103C8 \
  --warnings all --output-dir build --export-binaries \
  STM32_Zipper_CNC_V16_5_4_Firmware
```

Run host tests with:

```bash
bash tests/run_tests.sh
```

## Hardware verification required before production
Host tests and GitHub compilation cannot establish real trigger-to-needle timing. On the actual board, verify with an oscilloscope/logic analyzer:

1. PA0 proximity edge and PA8 STEP pulse timing simultaneously.
2. PA8 idle level, active-low pulse width and pulse count at slow and maximum intended speed.
3. No timer reconfiguration or interrupt collision between TIM1 update IRQ and TIM2 capture/DMA.
4. MODE size changes while stopped, then power-cycle to confirm persistence.
5. Auto-save while stopped; verify no watchdog reset and verify stored settings after reboot.
6. Confirm the DM542 input wiring/level shifter accepts PA8 active-low pulses and common-ground/reference wiring is correct.

**Important validation status:** this editing environment does not have the Arduino STM32 target toolchain attached. Do not interpret a successful ZIP operation or host tests as a completed target compile or hardware test. The GitHub workflow is included to perform the target compile.

## Project layout
- `STM32_Zipper_CNC_V16_5_4_Firmware/`: Arduino sketch source folder used by the CI build.
- `include/`, `src/`: shared headers.
- `tests/`: host-side regression tests.
- `.github/workflows/auto_unzip_compile.yml`: GitHub Actions host-test + STM32 compile pipeline.
- `CHANGELOG_FINAL.md`: historical change log; older pin references in historical entries describe previous revisions.

## Factory-floor audit follow-up
The auto-save and settings UI now report persistence success only after `saveToEEPROM()` returns success. Failed saves are reported explicitly and pending-save state is retained for retry at a later safe standstill. Host regression suite: 25 suites passed. Confirm the GitHub Actions STM32 compile and perform supervised hardware tests before production use.
