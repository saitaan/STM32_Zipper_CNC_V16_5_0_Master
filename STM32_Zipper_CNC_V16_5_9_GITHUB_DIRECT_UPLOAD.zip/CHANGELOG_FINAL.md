# Changelog — V16.5.9 PA0/TIM2 + PA8/TIM1

## Current update
- Confirmed target: STM32F103C8T6.
- PA0 proximity sensor remains the primary trigger input, using EXTI and TIM2_CH1 capture.
- PA8 is configured as TIM1_CH1 active-low hardware STEP/PUL output.
- Trigger capture timer and STEP pulse timer are separated: TIM2 captures, TIM1 generates pulses.
- MODE zipper-size hold window extended from 1.5–3 seconds to 1.5–8 seconds; 8-second hold remains reserved for hidden settings.
- Persistence now checks safe standstill before requesting the save lock and feeds the watchdog around early exits and Flash write/readback path.
- GitHub Actions workflow corrected to run host tests and compile the actual sketch folder, then publish the binary artifact.

## Validation notes
- Host test results must be obtained by running `bash tests/run_tests.sh` or from the GitHub Actions run.
- Target compilation is delegated to GitHub Actions; no local STM32 target compile is claimed here.
- Oscilloscope/logic-analyzer validation on the actual machine is mandatory before production use, especially for PA8 pulse polarity/width, PA0-to-PA8 synchronization, watchdog behavior during persistence, and MODE size retention.
- Historical files and comments may refer to PA1/TIM2 because that was the previous hardware mapping; the current main sketch is the source of truth for PA8/TIM1.
