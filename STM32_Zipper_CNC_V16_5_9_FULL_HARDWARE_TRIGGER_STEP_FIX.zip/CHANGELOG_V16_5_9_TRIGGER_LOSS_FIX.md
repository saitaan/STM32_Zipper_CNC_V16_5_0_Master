# V16.5.9 Trigger-Loss / STEP-Generation Fix

## Fixed
- PA0 EXTI remains the authoritative physical trigger path.
- TIM2 input-capture is diagnostic/audit only when CC1IF is actually present.
- A missing TIM2 CC1IF no longer suppresses a real PA0 trigger or its STEP burst.
- TIM2 digital input qualification changed from 0xF to 0x3 so short real proximity pulses are less likely to be filtered before capture.
- A real PA0 trigger arriving during the short EEPROM/Flash save window is now deferred instead of being falsely converted into `TRIGGER LOST`.
- Deferred triggers use a 32-entry FIFO and preserve each trigger's STEP count, direction, timestamp and Q16.16 STEP period.
- Deferred triggers are dispatched FIFO-order after the atomic save handoff.
- Deferred FIFO overflow is explicitly faulted; it is never silently dropped.

## Preserved
- Existing watchdog/auto-save behavior.
- MODE and zipper-size behavior.
- TIM1/PA8 hardware STEP generation architecture.
- Safety sensor policy and standstill-gated recovery.
- Existing pulse-count conservation rules.

## Validation
- Automated source/model verification: **30/30 test suites passed**.
- Added `tests/test_trigger_save_window.cpp` covering multiple triggers during persistence and preservation of per-trigger timing metadata.
- Hardware/Arduino compilation and physical oscilloscope verification are still required on the target STM32 board.
