# Final Release Manifest

Firmware: STM32 Zipper CNC V16.5.9 Maximum Accuracy
Hardware: STM32F103C8T6 Blue Pill
Primary trigger: PA0 / TIM2_CH1
STEP: PA8 / TIM1_CH1
DIR: PA2
Tape Guard: PA3
Host regression: 29/29 GREEN

This package contains the source, tests, release notes, wiring/architecture documentation, and commissioning guidance.

- `CHANGELOG_V16_5_9_MODE_SIZE_WATCHDOG_FIX.md` — MODE zipper-size restart/watchdog fix and validation record.

- Trigger/STEP loss hardening: EXTI-authoritative capture audit + save-window deferred trigger dispatch.

## Trigger/STEP hardware update
- TIM2 CH1 capture DMA request explicitly enabled (`CC1DE`).
- Capture ring increased to 64 samples.
- Minimal TIM2 input qualification selected to avoid suppressing short valid PA0 trigger pulses.
- PA0 EXTI remains authoritative for trigger-to-needle timing.
- TIM1 CH1/PA8 remains the hardware STEP pulse engine.
- Missing TIM2 CC1IF is not treated as trigger loss because DMA may consume the flag first.
- Auto-save remains strictly standstill-gated; unexpected motion cancels the save transaction instead of delaying the needle trigger.
