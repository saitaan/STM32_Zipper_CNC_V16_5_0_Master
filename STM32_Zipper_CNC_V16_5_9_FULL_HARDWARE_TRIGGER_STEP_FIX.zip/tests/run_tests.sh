#!/usr/bin/env bash
set -e

# Determine repository root directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${REPO_ROOT}"

echo "========================================================================"
echo "⚡ Running STM32 Zipper CNC V16.5.9 Production Automated Test Suites ⚡"
echo "========================================================================"

FAILED=0
TOTAL=0

# Include flags to support both relative and root include paths
CXXFLAGS="-std=c++17 -pthread -Itests -I. -ISTM32_Zipper_CNC_V16_5_4_Firmware"

for TEST_SRC in tests/*.cpp; do
    TOTAL=$((TOTAL + 1))
    TEST_BIN="/tmp/$(basename "${TEST_SRC}" .cpp)"
    
    # Compile test target
    if g++ ${CXXFLAGS} "${TEST_SRC}" -o "${TEST_BIN}"; then
        # Run test target
        if "${TEST_BIN}"; then
            echo "✅ [PASS] ${TEST_SRC}"
        else
            echo "❌ [FAIL - RUNTIME] ${TEST_SRC}"
            FAILED=$((FAILED + 1))
        fi
        rm -f "${TEST_BIN}"
    else
        echo "❌ [FAIL - COMPILATION] ${TEST_SRC}"
        FAILED=$((FAILED + 1))
    fi
done

echo "========================================================================"
if [ ${FAILED} -eq 0 ]; then
    echo "🎉 ALL ${TOTAL}/${TOTAL} TEST SUITES PASSED CLEANLY (100% GREEN)!"
    echo "========================================================================"
    exit 0
else
    echo "❌ ${FAILED}/${TOTAL} TEST SUITES FAILED!"
    echo "========================================================================"
    exit 1
fi

# Advanced hardware timing policy regression
g++ -std=c++17 tests/test_v16_5_9_advanced_timing.cpp -o /tmp/test_v16_5_9_advanced_timing && (cd /mnt/data/fw_adv && /tmp/test_v16_5_9_advanced_timing)
g++ -std=c++17 -O2 test_trigger_save_window.cpp -o /tmp/test_trigger_save_window && /tmp/test_trigger_save_window
