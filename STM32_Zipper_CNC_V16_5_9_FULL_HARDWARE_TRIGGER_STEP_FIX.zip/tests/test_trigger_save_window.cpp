#include <cassert>
#include <iostream>
#include "../STM32_Zipper_CNC_V16_5_4_Firmware/pulsestep_persistence.h"

int main() {
    FlashSaveTransactionEngine tx;
    assert(tx.requestSaveLock());
    assert(tx.confirmLockAndTransition(true));

    // The production policy no longer defers a needle trigger behind persistence.
    // The persistence transaction can be cancelled if physical motion resumes.
    tx.cancelSaveLock();
    assert(!tx.isSaveLockActive());

    assert(tx.requestSaveLock());
    assert(tx.confirmLockAndTransition(true));
    assert(tx.deferTrigger(113, 0, 10000, 70, 70U << 16));
    assert(tx.deferTrigger(135, 0, 25000, 82, 82U << 16));

    uint8_t dir = 0; uint32_t ts = 0; uint16_t period = 0; uint32_t q16 = 0;
    uint32_t s1 = tx.captureDeferredForDispatch(dir, ts, period, q16);
    assert(s1 == 113 && ts == 10000 && period == 70 && q16 == (70U << 16));
    tx.completeHandoff();
    assert(tx.isSaveLockActive());

    uint32_t s2 = tx.captureDeferredForDispatch(dir, ts, period, q16);
    assert(s2 == 135 && ts == 25000 && period == 82 && q16 == (82U << 16));
    tx.completeHandoff();
    assert(!tx.isSaveLockActive());
    assert(tx.deferredSteps == 0);

    std::cout << "PASS: persistence lock is cancellable; legacy deferred-queue storage remains lossless for compatibility, while production trigger handling stays on the direct STEP path.\n";
    return 0;
}
