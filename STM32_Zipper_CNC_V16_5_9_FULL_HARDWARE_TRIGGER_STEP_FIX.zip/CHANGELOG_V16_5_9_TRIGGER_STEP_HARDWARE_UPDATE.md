# V16.5.9 Trigger/STEP Hardware Update

## Core machine requirement
The PA0 zipper-coil trigger is the authoritative needle-cycle event. Every accepted physical trigger must reach the PA8 hardware STEP engine without being delayed behind EEPROM/Flash, LCD, diagnostics, or background work.

## Hardware changes
- TIM2_CH1 remains the silicon capture recorder for PA0.
- TIM2 CH1 DMA request (`CC1DE`) is now explicitly enabled. The previous build armed DMA1 Channel 5 but did not enable the timer's capture-to-DMA request.
- Capture DMA ring increased to 64 samples.
- TIM2 input qualification reduced to the minimum filter setting used by this firmware so short valid optocoupler pulses are not suppressed by an unnecessarily long digital filter.
- PA0 EXTI remains the earliest authoritative trigger event.
- TIM1_CH1 on PA8 remains the production hardware PWM STEP generator.
- A missing TIM2 `CC1IF` is never treated as trigger loss because DMA may consume the flag before EXTI software runs.
- A real `CC1OF` is recorded as a hardware overcapture diagnostic, but the current EXTI trigger is not discarded.

## Persistence policy
Auto-save is strictly standstill-gated. No trigger FIFO is used as a substitute for this policy.

If a trigger appears while a save lock is unexpectedly active, the trigger goes directly to the hardware STEP path and the persistence transaction is cancelled at its final standstill/trigger-consistency gate.

## Validation
The complete repository test suite is expected to remain green after the test-policy updates. Physical validation with the actual zipper coil, optocoupler, needle mechanism, and oscilloscope is still required for final production sign-off.
