# STM32 Zipper CNC — V17.0.0 Production Firmware Package

## Release Overview
Authoritative production firmware for the **Nipon Zipper Industries Pvt. Ltd.** (Sarigam GIDC / Surat, Gujarat) high-speed zipper stitching CNC feeder (`STM32F103C8T6` Blue Pill @ 72 MHz, Lead Systems Architect: **Rajesh Shah**).

### Hardware Pinout & Timer Architecture (100% Matched to Code)
- **MCU:** `STM32F103C8T6` (ARM Cortex-M3 @ 72 MHz)
- **`PA0` (`proxSensorPin`):** Cam proximity sensor input (`TIM2_CH1` hardware falling-edge capture, `1 MHz` counter, `IC1F = 0x3` 8-cycle silicon digital filter, internal pull-up + external `PC817` optocoupler). Sole authoritative motion trigger (`NVIC Priority 1`).
- **`PA8` (`stepPin`):** Stepper driver `PUL-` output (`TIM1_CH1` hardware PWM Mode 2 active-low burst engine, `5.0 µs` pulse width, `NVIC Priority 0`).
- **`PA2` (`dirPin`):** Stepper driver `DIR-` output (`HIGH` = Normal Forward `[FW]`, `LOW` = Reverse `[RV]`, with `20 µs` hardware setup/hold guard).
- **`PB1` (`motorEnaPin`):** Stepper driver `ENA-` output (`LOW` = Driver Active/Enabled, `HIGH` = Standstill Motor Sleep Mode with 1-cycle `13.8 ns` hardware wake ISR `tim2WakeOnceCallback`).
- **`PB6` / `PB7` (`I2C1_SCL` / `I2C1_SDA`):** 16x2 I2C LCD (`0x27` PCF8574) driven by deterministic `FastLiquidCrystal_I2C` (`100 kHz` zero-blink power-on boot splash `DEV: RAJESH SHAH` / `NIPON ZIPPER IND` for `2.0 s`, switching to `400 kHz` Fast-Mode in `loop()`).
- **`PC13` (`statusLedPin`):** Onboard active-low status LED (indicates active burst while running and proximity sensor alignment at standstill).
- **Dual-Mode Keypad (`INPUT_PULLUP`, Active-LOW to MCU GND):**
  - **3-Button Standard Mode (`keypad6ButtonMode = false`, Default):**
    - `PB13` = `[UP]`
    - `PB12` = `[DOWN]`
    - `PB14` = `[MODE / SELECT]`
  - **6-Button Extended Mode (`keypad6ButtonMode = true`, selectable in Settings Option 7):**
    - Adds `PB15` = `[BACK]`, `PB11` = `[LEFT]`, `PB10` = `[RIGHT]`.

## Operator Controls & Main Screen Behavior (`menuState == 0`)
- **Zero-Blink Power-On Splash:** Displays `DEV: RAJESH SHAH` (Row 0) and `NIPON ZIPPER IND` (Row 1) immediately on power-on (`~60 ms`, zero 1-second blank delay, zero backlight blink) for `2.0 seconds` before opening the Main Screen.
- **Main Screen Telemetry:**
  - Row 0: `S: 8 0000 F:1.77` (Active Size `#5`/`#8`/`#10`, Live 4-digit RPM `0000..9999`, Calculated Feed `mm`).
  - Row 1: `P:80.0 W:53 * [U]` (Active Pulses, Step Period `µs`, Timing Cue `*`/`#`/`H`, Lock State `[U]`/`[L]`).
- **Pulse Tuning at Standstill (`0 RPM`, Unlocked `[U]`):**
  - **Direct `[UP]` / `[DOWN]`:** Adjusts whole pulses (`+1.0` / `-1.0`) while preserving the `.10` decimal fraction; holding `>= 600 ms` auto-repeats at `200 ms` intervals.
  - **Single-Click `[MODE]`:** Opens the **4-Digit Digital Watch Inline Editor** starting at `.10` decimal (`cursor 0 = .10`, `1 = Units`, `2 = Tens`, `3 = Hundreds`, range `001.0` to `500.0`, 10-second idle auto-timeout).
    - In 3-BTN Mode: `[DOWN]` shifts cursor to the next digit, `[UP]` increments the blinking digit, and a second `[MODE]` click confirms (`OK`).
    - In 6-BTN Mode: `[LEFT]` / `[RIGHT]` move the cursor physically left/right across the 4 digits, `[UP]` / `[DOWN]` increment/decrement the digit, and `[MODE]` or `[BACK]` confirms/exits.
- **Switch Zipper Size (`#5 -> #8 -> #10 -> #5`):** **Double-Click `[MODE]`** at `0 RPM` standstill (Unlocked).
- **Open Settings Menu (`menuState = 1`):** **Hold `[MODE]` for 5 seconds** at `0 RPM` standstill (`ENTER SETTINGS: / IN 4 SEC... -> IN 1 SEC...`).
- **Keypad Auto-Lock & Sequential Unlock:** Automatically locks (`[L]`) after `autoLockSec` of inactivity (default `30s`, or disabled when set to `OFF`). To unlock, press **`[MODE]`** (`UNLOCK KEYPAD: / PRESS [DOWN] NOW`) followed by **`[DOWN]`** within 3 seconds.
- **Emergency Factory Reset (`menuState = 3`):** Hold **`[UP] + [DOWN]`** together for `> 10 seconds` at `0 RPM` standstill (`Factory Reset? >YES  NO`).

## 12-Option Settings Menu (`menuState == 1`)
1. **`1. Driver Res`:** Discrete DM542 DIP resolutions (`400` to `51200`, Default `6400 steps`).
2. **`2. Roller Dia`:** 4-digit Digital Watch editor (`010.0` to `100.0 mm`, Default `045.0 mm`).
3. **`3. Max RPM`:** 4-digit Digital Watch editor (`0100` to `4000 RPM`, Default `3000 RPM`).
4. **`4. Feed Angle`:** 3-digit Digital Watch editor (`030` to `270 deg`, Default `090 deg`).
5. **`5. Safety Margin`:** 2-digit Digital Watch editor (`00` to `29 %`, Default `15 %`).
6. **`6. Motor Dir`:** `NORMAL [FW]` <-> `REVERSE [RV]` (Default `NORMAL [FW]`).
7. **`7. Keypad Mode`:** `3-BTN [3K]` <-> `6-BTN [6K]` (Default `3-BTN [3K]`).
8. **`8. Auto Lock`:** `Lock: 030s [ON]` <-> `Lock: OFF [OFF]` at cursor 0; `010s..300s` 3-digit editing at cursors 1..3 (Default `030s [ON]`).
9. **`9. Backlight`:** `ALWAYS ON` (`000s`) or `010s..300s` 3-digit timeout (Default `ALWAYS ON`).
10. **`10. Motor Sleep`:** `OFF` (`000m`) or `030m..300m` 3-digit standstill sleep timer on `PB1` (Default `OFF`).
11. **`11. Info Diag`:** Opens the **9-Page Diagnostics & Bench Test Suite** (`menuState = 9`) + **5-Page Field Troubleshooting Help Guide** (`menuState = 21`).
12. **`12. Save & Exit`:** Opens `SAVE CHANGES? >YES  NO` (`menuState = 13`), writing selectively to Dual-Slot Ping-Pong EEPROM (`Slot 0` @ offset 0 <-> `Slot 1` @ offset 128) with CRC32 validation and instant save-abort protection if a `PA0` trigger arrives.

## Build & Regression Test Verification
Run the fail-fast host regression & HIL simulation suite (9 master test suites):
```bash
bash tests/run_tests.sh
```
Compile the production binary for `STM32F103C8T6` via `arduino-cli` (or `.github/workflows/auto_unzip_compile.yml`):
```bash
arduino-cli core install STMicroelectronics:stm32
arduino-cli lib install "LiquidCrystal I2C"
arduino-cli compile --fqbn STMicroelectronics:stm32:GenF1:pnum=BLUEPILL_F103C8 \
  --warnings all --output-dir build --export-binaries \
  STM32_Zipper_CNC_V16_5_4_Firmware
```
