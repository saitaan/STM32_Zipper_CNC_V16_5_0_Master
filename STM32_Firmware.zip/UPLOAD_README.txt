STM32_Firmware.zip — GitHub Actions upload package

This ZIP is arranged for the workflow shown in the screenshot: upload this ZIP to the repository root; the workflow extracts it and searches for the .ino sketch. The sketch and its required local headers are at the ZIP root.

IMPORTANT: GitHub Actions only discovers workflow YAML files stored in the repository at .github/workflows/*.yml. A workflow file inside this ZIP cannot run until it is separately committed to that path. This package does not claim that target compilation or machine pulse timing has been verified.
