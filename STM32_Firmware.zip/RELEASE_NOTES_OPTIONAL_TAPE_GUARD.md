# V16.5.4 Optional Tape Guard

- Proximity sensor (PA0) remains the authoritative motion reference.
- STEP generation/synchronization is independent of Tape Guard state.
- Tape Guard uses PA3 as an optional tape run-out/end sensor.
- Tape Guard OFF (default): PA3 is ignored; absence of the sensor cannot stop, suppress, or alter proximity-triggered STEP generation.
- Tape Guard ON: PA3 is qualified for 15 ms before declaring tape run-out and initiating the existing safety stop path.
- The legacy PB0/coil input is retained for compatibility but is not used to stop the machine in this tape-only Guard design.
- There is intentionally no automatic 'sensor present' detection from PA3 alone: an absent sensor and a tape-end/open signal are electrically indistinguishable with the current single fail-safe input. Therefore Guard must remain OFF until the physical sensor is installed and wired.
- Sensor Guard does not gate the Proximity Sync Watchdog; trigger-loss protection remains active regardless of Guard setting.


## Future-ready 3-state design

The firmware now defines an explicit Tape Guard state model:
- `DISABLED`: Guard OFF; PA3 has no influence on operation.
- `MONITORING`: Guard ON and tape sensor is healthy/present.
- `TAPE_END`: qualified tape run-out condition.
- `SENSOR_FAULT`: reserved for a future diagnostic-capable sensor interface.

The current single-wire PA3 hardware cannot safely distinguish an unplugged sensor from an open/tape-end signal, so `SENSOR_FAULT` is intentionally not synthesized in software. A future 3-state implementation must add a defined electrical diagnostic signature (for example a supervised sensor interface), then enable `SENSOR_HW_DIAGNOSTIC_PRESENT`.

This change does not gate or modify the Proximity→STEP synchronization path.
