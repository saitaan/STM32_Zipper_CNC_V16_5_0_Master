#include <iostream>
#include <cstdint>
#include <cassert>
#include <vector>

// Emulated STM32 TIM4 Peripheral & Overflow State Machine
struct HardwareTimer4Mock {
    uint16_t cnt;
    bool uif;
    uint32_t overflow_count;
    bool delay_isr;

    void reset() {
        cnt = 0;
        uif = false;
        overflow_count = 0;
        delay_isr = false;
    }

    void tick() {
        if (cnt == 0xFFFF) {
            cnt = 0;
            uif = true; // Hardware sets Update Interrupt Flag at CNT rollover
            if (!delay_isr) {
                // If interrupts not delayed, ISR runs immediately
                overflow_count++;
                uif = false;
            }
        } else {
            cnt++;
        }
    }

    void service_overflow_isr() {
        if (uif) {
            overflow_count++;
            uif = false;
        }
    }

    // Exact implementation matching production get_hardware_timestamp_us()
    uint32_t get_hardware_timestamp_us() const {
        uint32_t high;
        uint16_t low;
        bool pending;

        do {
            high = overflow_count;
            low  = cnt;
            pending = uif;
        } while (high != overflow_count);

        // If an overflow interrupt is pending and CNT has already rolled over
        // to a small value (< 0x8000), account for the unserviced rollover
        if (pending && (low < 0x8000)) {
            high++;
        }

        return (high << 16) | low;
    }
};

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Deterministic TIM4 32-Bit Rollover & Race Safety Audit" << std::endl;
    std::cout << "==========================================================" << std::endl;

    HardwareTimer4Mock timer;
    timer.reset();

    // 1. Boundary Test: Read immediately before overflow
    timer.cnt = 0xFFFE;
    timer.overflow_count = 4;
    timer.uif = false;
    uint32_t ts_before1 = timer.get_hardware_timestamp_us();
    assert(ts_before1 == ((4U << 16) | 0xFFFE));

    timer.tick(); // cnt = 0xFFFF
    uint32_t ts_before2 = timer.get_hardware_timestamp_us();
    assert(ts_before2 == ((4U << 16) | 0xFFFF));
    assert(ts_before2 == ts_before1 + 1);
    std::cout << "[PASS] 1. Pre-overflow timestamps (0xFFFE, 0xFFFF) coherent." << std::endl;

    // 2. Boundary Test: Read exactly at rollover with delayed ISR
    timer.delay_isr = true; // Emulate delayed ISR (e.g. EXTI0 or TIM2 preemption)
    timer.tick(); // cnt wraps to 0x0000, uif = true, overflow_count still 4!
    assert(timer.cnt == 0x0000);
    assert(timer.uif == true);
    assert(timer.overflow_count == 4);

    uint32_t ts_at_wrap = timer.get_hardware_timestamp_us();
    // Must return epoch 5 (0x00050000), NOT epoch 4 (0x00040000)!
    assert(ts_at_wrap == ((5U << 16) | 0x0000));
    assert(ts_at_wrap == ts_before2 + 1); // Strictly monotonic!
    std::cout << "[PASS] 2. Rollover at 0x0000 with delayed ISR correctly yields next epoch (Zero backwards jump)." << std::endl;

    // 3. Boundary Test: Delayed ISR across multiple microseconds
    for (int i = 1; i <= 20; i++) {
        timer.tick();
        uint32_t ts = timer.get_hardware_timestamp_us();
        assert(ts == ((5U << 16) | (uint16_t)i));
    }
    std::cout << "[PASS] 3. Delayed ISR across 20us maintains continuous monotonic progression." << std::endl;

    // 4. Delayed ISR finally runs and clears UIF
    timer.service_overflow_isr();
    assert(timer.uif == false);
    assert(timer.overflow_count == 5);
    uint32_t ts_after_isr = timer.get_hardware_timestamp_us();
    assert(ts_after_isr == ((5U << 16) | 20U));
    std::cout << "[PASS] 4. Post-ISR execution yields identical coherent timestamp." << std::endl;

    // 5. Long-Run Stress Test: 1,000,000 continuous ticks spanning 15+ full 16-bit overflows
    // with random ISR delay bursts (up to 100 ticks)
    timer.reset();
    uint32_t prev_ts = timer.get_hardware_timestamp_us();
    uint32_t total_overflows_observed = 0;

    for (uint32_t tick = 1; tick <= 1000000; tick++) {
        // Randomly enable delay near overflow boundaries
        if ((timer.cnt >= 0xFFF0) || (timer.cnt <= 0x0020)) {
            timer.delay_isr = ((tick % 3) != 0);
        } else {
            timer.delay_isr = false;
            timer.service_overflow_isr();
        }

        timer.tick();

        uint32_t curr_ts = timer.get_hardware_timestamp_us();

        // Formal Monotonicity Invariant: Every timestamp must advance by exactly 1us
        assert(curr_ts >= prev_ts);
        assert((curr_ts - prev_ts) == 1U);

        if ((curr_ts >> 16) != (prev_ts >> 16)) {
            total_overflows_observed++;
        }
        prev_ts = curr_ts;
    }

    assert(total_overflows_observed >= 15);
    std::cout << "[PASS] 5. 1,000,000 Ticks / " << total_overflows_observed 
              << " 16-bit rollovers verified: 100% strictly monotonic (0 backwards jumps, 0 glitches)." << std::endl;
    std::cout << "==========================================================" << std::endl;
    std::cout << "ALL TIM4 OVERFLOW RACE AUDIT TESTS PASSED (100% GREEN)!" << std::endl;
    std::cout << "==========================================================" << std::endl;

    return 0;
}
