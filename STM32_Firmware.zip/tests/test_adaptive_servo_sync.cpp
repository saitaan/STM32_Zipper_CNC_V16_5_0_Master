#include <cassert>
#include <cstdint>
#include <iostream>

static uint32_t adaptivePeriod(uint32_t revUs, uint32_t steps, int angle, int margin) {
    if (!revUs || !steps) return 0;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    if (margin < 0) margin = 0;
    if (margin > 25) margin = 25;
    uint64_t window = (uint64_t)revUs * (uint64_t)angle / 360ULL;
    window = window * (uint64_t)(100 - margin) / 100ULL;
    uint64_t p = (window + steps/2ULL) / steps;
    if (p < 8) p = 8;
    if (p > 500) p = 500;
    return (uint32_t)p;
}

int main() {
    const int angle=160, margin=10, steps=136;
    // 3000 RPM -> 20,000us/rev; period must be based on measured servo interval.
    uint32_t p3000=adaptivePeriod(20000,steps,angle,margin);
    uint32_t p1500=adaptivePeriod(40000,steps,angle,margin);
    uint32_t p1000=adaptivePeriod(60000,steps,angle,margin);
    assert(p3000 < p1500 && p1500 < p1000);
    // Changing the Settings max-RPM value must not alter measured-motion math.
    assert(adaptivePeriod(20000,steps,angle,margin) == p3000);
    // Fast servo transition remains bounded by electrical timer limits.
    assert(adaptivePeriod(15000,steps,angle,margin) >= 8);
    assert(adaptivePeriod(600000,steps,angle,margin) <= 500);
    // 4000 RPM and 2000 RPM are both tracked from physical intervals.
    assert(adaptivePeriod(15000,steps,angle,margin) < adaptivePeriod(30000,steps,angle,margin));
    std::cout << "[PASS] adaptive servo synchronization period math" << std::endl;
}
