#include <iostream>
#include <vector>
#include <cstdint>
#include <cassert>
#include "motion_scheduler.h"
#include "burst_queue.h"

int main() {
    std::cout << "Running test_pulse_conservation..." << std::endl;
    BurstQueue q;

    uint32_t totalRequested = 0;
    uint32_t totalCompleted = 0;

    std::vector<uint32_t> burstSizes = {
        1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 50, 100, 500, 1000, 2500, 5000, 10000
    };

    // 1. Isolated bursts conservation
    for (uint32_t sz : burstSizes) {
        totalRequested += sz;
        assert(q.enqueue(sz, 0, 1000, 1));
        BurstItem item{};
        assert(q.dequeue(item));
        assert(item.stepCount == sz);
        totalCompleted += item.stepCount;
    }
    assert(totalRequested == totalCompleted);
    assert(q.verifyInvariant());

    // 2. Chained bursts conservation
    q.reset();
    uint32_t chainedReq = 0;
    uint32_t chainedComp = 0;
    for (uint32_t i = 0; i < 15; i++) {
        uint32_t count = (i + 1) * 37;
        chainedReq += count;
        assert(q.enqueue(count, (i & 1), 2000 + i * 50, i + 1));
    }
    assert(q.count() == 15);
    while (!q.isEmpty()) {
        BurstItem item{};
        assert(q.dequeue(item));
        chainedComp += item.stepCount;
    }
    assert(chainedReq == chainedComp);
    assert(q.verifyInvariant());

    std::cout << "[PASS] test_pulse_conservation: Total " << (totalCompleted + chainedComp) << " Pulses Conserved Exactly (Error = 0)." << std::endl;
    return 0;
}
