#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>

static constexpr uint32_t MIN_PERIOD_US = 8;

static bool timingFeasible(int32_t resolution, double diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm) {
    if (resolution < 200 || resolution > 51200 || !std::isfinite(diameter) || diameter < 15.0 || diameter > 100.0 ||
        rpm < 100 || rpm > 4000 || angle < 30 || angle > 270 || margin < 0 || margin > 25 || pitchMm <= 0.0) return false;
    double steps = (double)resolution / (M_PI * diameter) * pitchMm;
    double window = (60000000.0 / rpm) * (angle / 360.0) * (1.0 - margin / 100.0);
    return steps > 0.0 && window > 0.0 && (window / steps) >= MIN_PERIOD_US;
}

static uint32_t qualificationFloor(uint32_t previousInterval, uint32_t configuredMaxRpm) {
    uint32_t adaptive = 1500;
    if (previousInterval > 0) {
        adaptive = previousInterval / 3;
        if (adaptive < 1500) adaptive = 1500;
        if (adaptive > 4500) adaptive = 4500;
    }
    uint32_t maxInterval = 60000000UL / ((configuredMaxRpm >= 100 && configuredMaxRpm <= 4000) ? configuredMaxRpm : 3000UL);
    uint32_t plaus = (maxInterval * 2UL) / 3UL;
    if (plaus < 1500) plaus = 1500;
    return adaptive > plaus ? adaptive : plaus;
}

int main() {
    // Default must remain feasible.
    assert(timingFeasible(6400,45,3000,160,10,2.5));
    // Previously silent clamp-to-8us combinations must now be rejected.
    assert(!timingFeasible(51200,15,4000,30,25,2.5));
    assert(!timingFeasible(51200,15,4000,270,0,4.0));
    // Representative safe extremes remain accepted.
    assert(timingFeasible(200,100,100,270,0,2.5));
    // Every supported size is checked: high-res/high-rpm combo fails at least one size.
    bool all = timingFeasible(25600,45,4000,160,10,2.5) && timingFeasible(25600,45,4000,160,10,3.0) && timingFeasible(25600,45,4000,160,10,4.0);
    assert(all);
    // Noise after the old 4.5ms blanking window is now rejected at 4k RPM.
    assert(qualificationFloor(15000,4000) == 10000);
    assert(5000 < qualificationFloor(15000,4000));
    assert(10000 >= qualificationFloor(15000,4000));
    // Configured 100 RPM ceiling still permits its intended 1.5x transient margin.
    assert(qualificationFloor(600000,100) == 400000);
    std::cout << "[PASS] V16.5.8 timing-feasibility + noise-qualification policy\n";
}
