#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
    std::stringstream ss; ss << f.rdbuf();
    const std::string s = ss.str();
    assert(!s.empty());
    assert(s.find("V16.5.9-PA0-TIM2-CAPTURE-PA8-TIM1") != std::string::npos);
    assert(s.find("captureTimer->setMode(1, TIMER_INPUT_CAPTURE_FALLING, proxSensorPin)") != std::string::npos);
    assert(s.find("captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback)") != std::string::npos);
    assert(s.find("extern \"C\" void TIM2_IRQHandler(void)") == std::string::npos);
    assert(s.find("processSensorTrigger(captureTimestampUs)") != std::string::npos);
    assert(s.find("processSensorTrigger(captureTimestampUs)") != std::string::npos);
    assert(s.find("attachInterrupt(digitalPinToInterrupt(proxSensorPin), sensorISR, FALLING)") == std::string::npos);
    assert(s.find("TIM2 input capture is disabled") == std::string::npos);
    assert(s.find("attachInterrupt(digitalPinToInterrupt(proxSensorPin), sensorISR, FALLING)") == std::string::npos);
    assert(s.find("processSensorTrigger(captureTimestampUs)") != std::string::npos);
    std::cout << "PASS: TIM2 hardware capture is authoritative via core-owned IRQ callback\n";
}
