#include <cassert>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>

static std::string readSketch() {
    const char* paths[] = {
        "STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino",
        "../STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino"
    };
    for (const char* p : paths) {
        std::ifstream f(p);
        if (f.good()) {
            std::ostringstream ss;
            ss << f.rdbuf();
            return ss.str();
        }
    }
    return "";
}

static void check(bool cond, const char* msg) {
    if (!cond) {
        std::fprintf(stderr, "FAIL: %s\n", msg);
        assert(false);
    }
}

int main() {
    std::string src = readSketch();
    check(!src.empty(), "Could not read firmware .ino file");

    // 1. Complete DDA & Soft-Start Removal + TIM1 PA8 Hardware Step Engine
    check(src.find("hardwareTimerMode") == std::string::npos,
          "hardwareTimerMode should be completely removed");
    check(src.find("startSpeedPercent") == std::string::npos,
          "startSpeedPercent should be completely removed");
    check(src.find("startHardwareTimerBurst()") != std::string::npos,
          "startHardwareTimerBurst() must be present as permanent STEP engine");
    check(src.find("TIM1->CCMR1 |= (0x7U << 4); // CH1 PWM Mode 2") != std::string::npos,
          "TIM1 CH1 hardware PWM Mode 2 must be configured");

    // 2. Roller Diameter minimum limit = 10.0 mm
    check(src.find("< 10.0f ||") != std::string::npos && src.find("< 15.0f") == std::string::npos,
          "rollerDia feasibility range must be 10.0f to 100.0f");

    // 3. Extra Guards & Relay Removal
    check(src.find("tapeGuardEnabled") == std::string::npos,
          "tapeGuardEnabled must be removed");
    check(src.find("coilSensorEnabled") == std::string::npos,
          "coilSensorEnabled must be removed");
    check(src.find("safetyGuardEnabled") == std::string::npos,
          "safetyGuardEnabled must be removed");
    check(src.find("relayOutputEnabled") == std::string::npos,
          "relayOutputEnabled must be removed");

    // 4. 6-Button + 3-Button Backward-Compatible Keypad System (Default 3-BTN = false)
    check(src.find("btnBack") != std::string::npos && src.find("PB15") != std::string::npos,
          "btnBack must be configured on PB15");
    check(src.find("btnLeft") != std::string::npos && src.find("PB11") != std::string::npos,
          "btnLeft must be configured on PB11");
    check(src.find("btnRight") != std::string::npos && src.find("PB10") != std::string::npos,
          "btnRight must be configured on PB10");
    check(src.find("keypad6ButtonMode   = false;") != std::string::npos,
          "Default keypad mode must be 3-BTN (keypad6ButtonMode = false)");
    check(src.find("rec.payload.sensorGuardActive   = keypad6ButtonMode ? 1UL : 0UL;") != std::string::npos,
          "EEPROM payload must persist 3-BTN (0) vs 6-BTN (1) mode");

    // 5. Selective Parameter-Only EEPROM Save
    check(src.find("offsetof(MachineConfigRecord, payload.p5_fixed)") != std::string::npos,
          "saveToEEPROM() must selectively update changed parameter offsets via offsetof");
    check(src.find("offsetof(MachineConfigRecord, payload.sensorGuardActive)") != std::string::npos,
          "saveToEEPROM() must selectively update keypadMode6Btn when changed");

    // 6. Smart [BACK] Confirmation on Settings Exit & In-Place Blinking
    check(src.find("if (hasStagedChanges)") != std::string::npos,
          "Settings exit must check hasStagedChanges before exiting");
    check(src.find("BLINK_MAIN_PULSE") != std::string::npos,
          "In-place parameter blinking helper isParamBlinkHidden must be present");

    // 7. PA0 Trigger Pin & 2-Minute Standstill Auto-Save
    check(src.find("pinMode(proxSensorPin, INPUT_PULLUP)") != std::string::npos,
          "PA0 proxPin must remain INPUT_PULLUP");
    check(src.find("120000UL") != std::string::npos,
          "STANDSTILL_AUTOSAVE_MS must be 120000UL (2 minutes)");

    std::printf("PASS: All V17.0.0 11-Point Master Batch Update tests succeeded.\n");
    return 0;
}
