#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include "../include/pulsestep_persistence.h"

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: V17.0.0 StepPulse (PA8/TIM1), LCD Format & 2-Min Auto-Save" << std::endl;
    std::cout << "==========================================================" << std::endl;

    std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
    assert(f.is_open());
    std::stringstream ss;
    ss << f.rdbuf();
    const std::string fw = ss.str();

    // 1. Verify TIM1_UP_IRQn is enabled and stepTimer->pause() does not leave TIM1 disabled after config
    auto initPos = fw.find("void initHardwareTimer2()");
    auto startBurstPos = fw.find("void startHardwareTimerBurst(");
    auto stopBurstPos = fw.find("void stopHardwareTimerImmediately()");
    assert(initPos != std::string::npos);
    assert(startBurstPos != std::string::npos);
    assert(stopBurstPos != std::string::npos);

    const std::string initSection = fw.substr(initPos, startBurstPos - initPos);
    const std::string burstSection = fw.substr(startBurstPos, stopBurstPos - startBurstPos);

    auto resumePos = initSection.find("stepTimer->resume();");
    auto dierPos = initSection.find("TIM1->DIER |= TIM_DIER_UIE;");
    auto nvicPos = initSection.find("NVIC_EnableIRQ(TIM1_UP_IRQn);");
    assert(resumePos != std::string::npos);
    assert(dierPos != std::string::npos);
    assert(nvicPos != std::string::npos);
    assert(resumePos < dierPos);
    assert(dierPos < nvicPos);

    assert(initSection.find("GPIOA->CRH |= (0x3U << 0);") != std::string::npos);
    auto capResumePos = initSection.find("captureTimer->resume();");
    auto pa0PullupPos = initSection.find("GPIOA->CRL |= (0x8U << 0);");
    assert(capResumePos != std::string::npos);
    assert(pa0PullupPos != std::string::npos);
    assert(capResumePos < pa0PullupPos);

    assert(burstSection.find("TIM1->BDTR |= TIM_BDTR_MOE;") != std::string::npos);
    assert(burstSection.find("NVIC_EnableIRQ(TIM1_UP_IRQn);") != std::string::npos);
    assert(burstSection.find("GPIOA->CRH |= (0xBU << 0);") != std::string::npos);
    std::cout << "[PASS] 1. PA8 (TIM1_CH1) & PA0 (TIM2_CH1) Silicon Initialization & Burst Handoff Verified." << std::endl;

    // 2. Verify loadFromEEPROM() does NOT overwrite saved p5/p8/p10 with unconditional recalculatePitchProfiles()
    auto loadPos = fw.find("void loadFromEEPROM()");
    auto procPos = fw.find("static inline void resetRpmIntervalHistory()");
    assert(loadPos != std::string::npos && procPos != std::string::npos);
    const std::string loadSection = fw.substr(loadPos, procPos - loadPos);

    assert(loadSection.find("EEPROM.begin()") == std::string::npos); // Must not use non-STM32duino EEPROM.begin()
    assert(loadSection.find("if (p5_fixed < PULSE_STEP_MIN_FIXED || p5_fixed > PULSE_STEP_MAX_FIXED") != std::string::npos);
    std::cout << "[PASS] 2. loadFromEEPROM() Preserves User-Tuned Step Pulses Across Power Cycles." << std::endl;

    // 3. Verify UP, DOWN, and MODE gear-snap call autoSaveEngine.notifyModification(millis())
    size_t notifyCount = 0;
    size_t searchPos = 0;
    while ((searchPos = fw.find("autoSaveEngine.notifyModification(millis());", searchPos)) != std::string::npos) {
        notifyCount++;
        searchPos += 10;
    }
    assert(notifyCount >= 3);
    std::cout << "[PASS] 3. [UP], [DOWN], and [MODE] Gear Snap Notify 2-Minute AutoSaveQualificationEngine (" << notifyCount << " call sites)." << std::endl;

    // 4. Verify LCD Row 2 formatting for 2-digit vs 3-digit pulses
    char l2[17];
    // 2-digit pulse (70.0), W=60 -> "P:70.0 W:60 H[L]"
    int pInt = 70, pFrac = 0, activePulseWidth = 60;
    char cue = 'H';
    bool isUiLocked = true;
    if (pInt < 100 && activePulseWidth < 100) {
        snprintf(l2, sizeof(l2), "P:%d.%01d W:%d %c%s", pInt, pFrac, activePulseWidth, cue, isUiLocked ? "[L]" : "[U]");
    } else {
        snprintf(l2, sizeof(l2), "P:%d.%01d W:%d%c%s", pInt, pFrac, activePulseWidth, cue, isUiLocked ? "[L]" : "[U]");
    }
    assert(std::string(l2) == "P:70.0 W:60 H[L]");

    // 3-digit pulse (100.0), W=42 -> "P:100.0 W:42H[L]"
    pInt = 100; pFrac = 0; activePulseWidth = 42;
    if (pInt < 100 && activePulseWidth < 100) {
        snprintf(l2, sizeof(l2), "P:%d.%01d W:%d %c%s", pInt, pFrac, activePulseWidth, cue, isUiLocked ? "[L]" : "[U]");
    } else {
        snprintf(l2, sizeof(l2), "P:%d.%01d W:%d%c%s", pInt, pFrac, activePulseWidth, cue, isUiLocked ? "[L]" : "[U]");
    }
    assert(std::string(l2) == "P:100.0 W:42H[L]");
    std::cout << "[PASS] 4. LCD Row 2 Formatting ('P:70.0 W:60 H[L]' & 'P:100.0 W:42H[L]') Verified." << std::endl;

    return 0;
}
