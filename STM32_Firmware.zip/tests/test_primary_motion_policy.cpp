#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

static std::string readFirmware() {
    const char* paths[] = {
        "STM32_Zipper_CNC_V16_5_4/STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino",
        "STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino",
        "../STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino"
    };
    for (const char* p : paths) {
        std::ifstream f(p);
        if (f) { std::stringstream ss; ss << f.rdbuf(); return ss.str(); }
    }
    assert(false && "firmware not found");
    return {};
}

static std::string section(const std::string& s, const std::string& a, const std::string& b) {
    auto p = s.find(a); assert(p != std::string::npos);
    auto q = s.find(b, p); assert(q != std::string::npos);
    return s.substr(p, q-p);
}

int main() {
    const std::string fw = readFirmware();
    const std::string safety = section(fw, "void safetyTimerCallback()", "// =========================================================================\n// CONTINUOUS 1 MHZ");
    assert(fw.find("V16.5.9-PA0-TIM2-CAPTURE-PA8-TIM1") != std::string::npos);
    assert(fw.find("Primary STEP engine is TIM1 hardware") != std::string::npos);
    assert(fw.find("every boot starts on TIM1 STEP hardware") != std::string::npos);
    assert(fw.find("captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback)") != std::string::npos);
    assert(fw.find("extern \"C\" void TIM2_IRQHandler(void)") == std::string::npos);
    assert(fw.find("motionWatchdogArmed = false") != std::string::npos);
    assert(fw.find("calculateAdaptiveStepPeriodQ16(startupRevUs") != std::string::npos);
    assert(fw.find("pinMode(futureSensor2Pin, INPUT_PULLUP)") != std::string::npos);
    assert(fw.find("hardwareTimerMode   = true; // PRIMARY POLICY") != std::string::npos);
    assert(fw.find("menuState = 18; // Diagnostic Engine (TIM1 STEP primary / DDA temporary)") != std::string::npos);
    assert(fw.find("tempHwTimerMode") != std::string::npos);

    // Auxiliary safety/relay code must not abort TIM1 or clear the STEP queue.
    assert(safety.find("TIM2->CCER") == std::string::npos);
    assert(safety.find("TIM2->CR1") == std::string::npos);
    assert(safety.find("burstQueue.abortAll") == std::string::npos);
    assert(safety.find("GPIOB->BSRR = (1U << 1)") != std::string::npos);

    // UI auto-exit must not reload EEPROM while motion is active.
    auto pe = fw.find("if (pendingMenuExit)"); assert(pe != std::string::npos);
    auto pe2 = fw.find("// Classic DDA", pe); assert(pe2 != std::string::npos);
    const auto exitBlock = fw.substr(pe, pe2-pe);
    assert(exitBlock.find("\n        loadFromEEPROM();") == std::string::npos);

    std::cout << "[PASS] primary motion policy: PA0->PA8 isolated from auxiliary sensor/relay aborts.\n";
    return 0;
}
