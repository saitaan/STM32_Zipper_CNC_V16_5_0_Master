#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

static std::string readFirmware() {
    const char* paths[] = {
        "STM32_Zipper_CNC_V16_5_4/STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino",
        "STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino",
        "../STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino"
    };
    for (const char* p : paths) {
        std::ifstream f(p);
        if (f) { std::stringstream ss; ss << f.rdbuf(); return ss.str(); }
    }
    assert(false && "firmware not found");
    return {};
}

int main() {
    const std::string fw = readFirmware();
    assert(fw.find("V17.0.0-PA0-TIM2-CAPTURE-PA8-TIM1") != std::string::npos);
    assert(fw.find("captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback)") != std::string::npos);
    assert(fw.find("extern \"C\" void TIM2_IRQHandler(void)") == std::string::npos);
    assert(fw.find("motionWatchdogArmed = false") != std::string::npos);
    assert(fw.find("calculateAdaptiveStepPeriodQ16(startupRevUs") != std::string::npos);
    assert(fw.find("startHardwareTimerBurst()") != std::string::npos);

    // Verify DDA and auxiliary guards/relays are completely removed in V17.0.0
    assert(fw.find("hardwareTimerMode") == std::string::npos);
    assert(fw.find("tempHwTimerMode") == std::string::npos);
    assert(fw.find("safetyTimerCallback") == std::string::npos);
    assert(fw.find("futureSensor2Pin") == std::string::npos);

    // UI auto-exit must not reload EEPROM while motion is active.
    auto pe = fw.find("if (pendingMenuExit)"); assert(pe != std::string::npos);
    const auto exitBlock = fw.substr(pe, 600);
    assert(exitBlock.find("\n        loadFromEEPROM();") == std::string::npos);

    std::cout << "[PASS] primary motion policy: PA0->PA8 TIM1 hardware STEP engine verified.\n";
    return 0;
}
