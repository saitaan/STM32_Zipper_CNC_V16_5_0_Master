#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p /tmp/zipper-cnc-tests
count=0
for src in tests/test_*.cpp; do
  name="$(basename "$src" .cpp)"
  echo "[BUILD] $name"
  g++ -std=c++17 -O2 -Wall -Wextra -pedantic -Iinclude -Isrc -ISTM32_Zipper_CNC_V16_5_4_Firmware "$src" -o "/tmp/zipper-cnc-tests/$name"
  echo "[RUN]   $name"
  "/tmp/zipper-cnc-tests/$name"
  count=$((count + 1))
done
echo "Host tests completed: $count suites passed."
