#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

# Clean any stale legacy sketch folders or duplicate workflows
rm -rf STM32_Zipper_CNC_V16_5_1_Firmware STM32_Zipper_CNC_V16_5_0_Firmware 2>/dev/null || true
rm -f .github/workflows/compile.yml 2>/dev/null || true
mkdir -p /tmp/zipper-cnc-tests

MASTER_TESTS=(
  "test_source_consistency.cpp"
  "test_v17_steppulse_and_autosave.cpp"
  "test_settings_digital_watch_simulation.cpp"
  "test_comprehensive_suite.cpp"
  "test_pulsestep_persistence.cpp"
  "test_queue_formal.cpp"
  "test_tim2_capture_overrun_deep.cpp"
  "test_timer_overflow.cpp"
  "test_v17_all_bugfixes_hil.cpp"
)

count=0
for t in "${MASTER_TESTS[@]}"; do
  src="tests/$t"
  if [ ! -f "$src" ]; then
    echo "FATAL ERROR: Required regression test file is missing: $src" >&2
    exit 1
  fi
  name="$(basename "$src" .cpp)"
  echo "[BUILD] $name"
  g++ -std=c++17 -O2 -Wall -Wextra -pedantic -Iinclude -Isrc -ISTM32_Zipper_CNC_V16_5_4_Firmware "$src" -o "/tmp/zipper-cnc-tests/$name"
  echo "[RUN]   $name"
  "/tmp/zipper-cnc-tests/$name"
  count=$((count + 1))
done
echo "Host tests completed: $count/${#MASTER_TESTS[@]} master suites passed (100% GREEN)."
