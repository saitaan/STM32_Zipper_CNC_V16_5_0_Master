#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
# Clean any stale legacy sketch folders in the runner workspace so arduino-cli strictly compiles V17.0.0
rm -rf STM32_Zipper_CNC_V16_5_1_Firmware STM32_Zipper_CNC_V16_5_0_Firmware 2>/dev/null || true
mkdir -p /tmp/zipper-cnc-tests
count=0
for src in tests/test_*.cpp; do
  name="$(basename "$src" .cpp)"
  echo "[BUILD] $name"
  g++ -std=c++17 -O2 -Wall -Wextra -pedantic -Iinclude -Isrc -ISTM32_Zipper_CNC_V16_5_4_Firmware "$src" -o "/tmp/zipper-cnc-tests/$name"
  echo "[RUN]   $name"
  "/tmp/zipper-cnc-tests/$name"
  count=$((count + 1))
done
echo "Host tests completed: $count suites passed."
