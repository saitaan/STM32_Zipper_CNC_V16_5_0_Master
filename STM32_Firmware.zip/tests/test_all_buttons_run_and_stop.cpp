#include <iostream>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <string>

// =========================================================================
// COMPREHENSIVE ALL BUTTONS TEST SUITE (RUN VS STOP / STANDSTILL)
// Tests: btnMode (PB14), btnUp (PB13), btnDown (PB12), Dual Press, and UI Locks
// =========================================================================

#define FIXED_SCALE 1000000ULL
#define PULSE_STEP_MIN_FIXED 1000000ULL
#define PULSE_STEP_MAX_FIXED 500000000ULL

class ButtonSystemSimulator {
public:
    int menuState;             // 0: Main Screen, 1: Hidden Menu, 9: Diagnostic Menu
    bool isUiLocked;           // true = Locked, false = Unlocked
    uint32_t currentRPM;       // 0 = Standstill, >0 = Running
    int stepsRemaining;
    bool hwBurstActive;
    int infoIndex;
    int hiddenOption;             // Menu 9 subpage (8 = Opto Sink Test)

    int currentSize;           // 1 = #5, 2 = #8, 3 = #10
    uint64_t stepGearFixed;    // 100,000 (0.10), 1,000,000 (1.00), 10,000,000 (10.0), 100,000,000 (100)
    uint64_t currentPulsesFixed;
    bool pulseTimingInvalid;

    uint32_t simulatedMillis;

    // Button states
    bool modePressed;
    uint32_t modePressTime;
    uint32_t lastModeClickTime;
    bool pendingSingleClick;

    bool upPressedState;
    uint32_t upFirstPressTime;
    uint32_t lastUpRepeatTime;

    bool downPressedState;
    uint32_t downFirstPressTime;
    uint32_t lastDownRepeatTime;

    bool upDownPressed;
    uint32_t dualPressTime;

    // Hardware pin emulation
    bool pa8PinStateLow; // Active LOW output for PUL-

    // UI Feedback Banner
    std::string bannerLine1;
    std::string bannerLine2;

    ButtonSystemSimulator() {
        reset();
    }

    void reset() {
        menuState = 0;
        isUiLocked = false;
        currentRPM = 0;
        stepsRemaining = 0;
        hwBurstActive = false;
        infoIndex = 1;
        hiddenOption = 1;

        currentSize = 1; // Size #5
        stepGearFixed = 1000000ULL; // 1.00
        currentPulsesFixed = 60000000ULL; // Size #5 default (113.176848)
        pulseTimingInvalid = false;

        simulatedMillis = 1000;

        modePressed = false;
        modePressTime = 0;
        lastModeClickTime = 0;
        pendingSingleClick = false;

        upPressedState = false;
        upFirstPressTime = 0;
        lastUpRepeatTime = 0;

        downPressedState = false;
        downFirstPressTime = 0;
        lastDownRepeatTime = 0;

        upDownPressed = false;
        dualPressTime = 0;

        pa8PinStateLow = false;
        bannerLine1 = "";
        bannerLine2 = "";
    }

    void advanceMillis(uint32_t ms) {
        simulatedMillis += ms;
        processTimeouts();
    }

    void processTimeouts() {
        // Pending single-click timeout (350ms window)
        if (pendingSingleClick && (simulatedMillis - lastModeClickTime > 350UL)) {
            pendingSingleClick = false;
            if (isUiLocked && menuState == 0) {
                bannerLine1 = "KEYPAD LOCKED!  ";
                bannerLine2 = "DBL-CLICK [MODE]";
            } else if (!isUiLocked && menuState == 0) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (stepGearFixed == 100000ULL) stepGearFixed = 1000000ULL;
                    else if (stepGearFixed == 1000000ULL) stepGearFixed = 10000000ULL;
                    else stepGearFixed = 100000ULL; // 100 removed, cycles to 0.10
                    bannerLine1 = "GEAR CHANGED    ";
                } else {
                    bannerLine1 = "MACHINE RUNNING!";
                    bannerLine2 = "GEAR CHG BLOCKED";
                }
            }
        }
    }

    // MODE Button action
    void clickMode(uint32_t holdMs) {
        modePressTime = simulatedMillis;
        modePressed = true;
        simulatedMillis += holdMs;
        modePressed = false;

        uint32_t holdTime = holdMs;
        if (menuState == 0) {
            if (holdTime < 350UL) {
                // Short click: check for double-click
                if (pendingSingleClick && (simulatedMillis - lastModeClickTime < 350UL)) {
                    pendingSingleClick = false;
                    isUiLocked = !isUiLocked;
                    bannerLine1 = isUiLocked ? "KEYPAD LOCKED!  " : "KEYPAD UNLOCKED ";
                    lastModeClickTime = 0UL;
                } else {
                    lastModeClickTime = simulatedMillis;
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        pendingSingleClick = true;
                    } else {
                        pendingSingleClick = false;
                        if (!isUiLocked) {
                            bannerLine1 = "MACHINE RUNNING!";
                            bannerLine2 = "GEAR CHG BLOCKED";
                        }
                    }
                }
            } else if (holdTime >= 1500UL && holdTime < 5000UL && !isUiLocked) {
                // Size sequence switch
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    currentSize++;
                    if (currentSize > 3) currentSize = 1;
                    bannerLine1 = "SIZE CHANGED    ";
                } else {
                    bannerLine1 = "MACHINE RUNNING!";
                    bannerLine2 = "SIZE CHG BLOCKED";
                }
            } else if (holdTime >= 5000UL && !isUiLocked) {
                // Open Settings Menu
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    menuState = 1;
                    bannerLine1 = "MENU OPENED     ";
                } else {
                    bannerLine1 = "MACHINE RUNNING!";
                    bannerLine2 = "MENU LOCKED [L] ";
                }
            }
        }
    }

    // UP Button Action
    void pressUp(uint32_t holdMs = 50) {
        if (menuState == 9 && infoIndex == 8 && currentRPM == 0 && !hwBurstActive) {
            // Optocoupler test on Page 8: sinks PA8 LOW to GND
            pa8PinStateLow = true;
        }

        if (menuState == 0) {
            if (isUiLocked) {
                bannerLine1 = "KEYPAD LOCKED!  ";
            } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                currentPulsesFixed += stepGearFixed;
                if (currentPulsesFixed > PULSE_STEP_MAX_FIXED) currentPulsesFixed = PULSE_STEP_MAX_FIXED;
                bannerLine1 = "PULSE TUNED UP  ";
            } else {
                bannerLine1 = "MACHINE RUNNING!";
                bannerLine2 = "PULSE TUNE LOCK ";
            }
        } else if (menuState == 1) {
            hiddenOption++;
            if (hiddenOption > 13) hiddenOption = 1;
        } else if (menuState == 9 && infoIndex != 8 && infoIndex != 2) {
            infoIndex++;
            if (infoIndex > 13) infoIndex = 1;
        hiddenOption = 1;
        }

        simulatedMillis += holdMs;
        pa8PinStateLow = false; // Released
    }

    // DOWN Button Action
    void pressDown(uint32_t holdMs = 50) {
        if (menuState == 0) {
            if (isUiLocked) {
                bannerLine1 = "KEYPAD LOCKED!  ";
            } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                if (currentPulsesFixed > stepGearFixed + PULSE_STEP_MIN_FIXED) {
                    currentPulsesFixed -= stepGearFixed;
                } else {
                    currentPulsesFixed = PULSE_STEP_MIN_FIXED;
                }
                bannerLine1 = "PULSE TUNED DOWN";
            } else {
                bannerLine1 = "MACHINE RUNNING!";
                bannerLine2 = "PULSE TUNE LOCK ";
            }
        } else if (menuState == 1) {
            hiddenOption--;
            if (hiddenOption < 1) hiddenOption = 13;
        } else if (menuState == 9 && infoIndex != 8 && infoIndex != 2) {
            infoIndex--;
            if (infoIndex < 1) infoIndex = 13;
        }
        simulatedMillis += holdMs;
    }

    // Dual UP+DOWN Action
    void pressDualUpDown(uint32_t holdMs) {
        if (holdMs >= 10000UL) {
            if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                menuState = 3; // Factory Reset Menu
                bannerLine1 = "RESET MENU OPEN ";
            } else {
                bannerLine1 = "MACHINE RUNNING!";
                bannerLine2 = "RESET BLOCKED!  ";
            }
        }
        simulatedMillis += holdMs;
    }
};

int main() {
    std::cout << "================================================================================" << std::endl;
    std::cout << "  COMPREHENSIVE BUTTON BEHAVIOR TEST SUITE (RUN VS STOP VERIFICATION)           " << std::endl;
    std::cout << "  Target: STM32F103C8T6 Zipper CNC V16.5.9 Firmware                             " << std::endl;
    std::cout << "================================================================================" << std::endl;

    ButtonSystemSimulator sim;

    // =========================================================================
    // SECTION 1: STOP / STANDSTILL TESTS (currentRPM == 0)
    // =========================================================================
    std::cout << "\n--- SECTION 1: BUTTONS BEHAVIOR AT STANDSTILL (0 RPM / STOPPED) ---" << std::endl;
    sim.reset();
    sim.currentRPM = 0;
    sim.hwBurstActive = false;
    sim.stepsRemaining = 0;

    // 1.1 Double-Click MODE Toggles Keypad Lock/Unlock
    sim.isUiLocked = false;
    sim.clickMode(100); // Click 1
    sim.advanceMillis(150);
    sim.clickMode(100); // Click 2 (< 350ms)
    assert(sim.isUiLocked == true);
    assert(sim.bannerLine1 == "KEYPAD LOCKED!  ");
    std::cout << "[PASS] 1.1 Double-Click [MODE] Locks Keypad Successfully." << std::endl;

    sim.clickMode(100); // Click 1
    sim.advanceMillis(150);
    sim.clickMode(100); // Click 2 (< 350ms)
    assert(sim.isUiLocked == false);
    assert(sim.bannerLine1 == "KEYPAD UNLOCKED ");
    std::cout << "[PASS] 1.2 Double-Click [MODE] Unlocks Keypad Successfully." << std::endl;

    // 1.2 Single-Click MODE Cycles Tuning Gear at Standstill
    sim.isUiLocked = false;
    assert(sim.stepGearFixed == 1000000ULL); // Baseline 1.00
    sim.clickMode(100);
    sim.advanceMillis(400); // Wait for single-click resolution
    assert(sim.stepGearFixed == 10000000ULL); // Cycles to 10.0
    assert(sim.currentSize == 1); // Size strictly unchanged!

    sim.clickMode(100);
    sim.advanceMillis(400);
    assert(sim.stepGearFixed == 100000ULL); // 100 removed: cycles directly to 0.10

    sim.clickMode(100);
    sim.advanceMillis(400);
    assert(sim.stepGearFixed == 1000000ULL); // Cycles back to 1.00
    std::cout << "[PASS] 1.3 Single-Click [MODE] Cycles Gear (1.0 -> 10.0 -> 0.10 -> 1.0) Cleanly." << std::endl;

    // 1.3 1.5s to 8.0s Hold MODE Cycles Zipper Size at Standstill
    assert(sim.currentSize == 1); // Size #5
    sim.clickMode(2500); // 2.5s hold
    assert(sim.currentSize == 2); // Size #8
    assert(sim.stepGearFixed == 1000000ULL); // Gear strictly unchanged!

    sim.clickMode(2500);
    assert(sim.currentSize == 3); // Size #10

    sim.clickMode(2500);
    assert(sim.currentSize == 1); // Cycles back to Size #5
    std::cout << "[PASS] 1.4 Hold [MODE] (1.5-5s) Cycles Size (#5 -> #8 -> #10 -> #5) with Gear Constant." << std::endl;

    // 1.4 > 8.0s Hold MODE Enters Settings Menu
    sim.clickMode(5200); // 8.2s hold
    assert(sim.menuState == 1);
    std::cout << "[PASS] 1.5 Hold [MODE] (>5s) Enters Settings Menu at Standstill." << std::endl;
    sim.menuState = 0; // Return to main screen

    // 1.5 UP and DOWN Pulse Tuning at Standstill
    sim.stepGearFixed = 1000000ULL; // 1.00 step
    uint64_t initialPulses = sim.currentPulsesFixed;
    sim.pressUp();
    assert(sim.currentPulsesFixed == initialPulses + 1000000ULL);
    assert(sim.bannerLine1 == "PULSE TUNED UP  ");

    sim.pressDown();
    assert(sim.currentPulsesFixed == initialPulses);
    assert(sim.bannerLine1 == "PULSE TUNED DOWN");
    std::cout << "[PASS] 1.6 [UP] and [DOWN] Tune Pulses with Sub-Microstep Precision at Standstill." << std::endl;

    // 1.6 Keypad Lock Protection at Standstill
    sim.isUiLocked = true;
    uint64_t lockedPulses = sim.currentPulsesFixed;
    sim.pressUp();
    assert(sim.currentPulsesFixed == lockedPulses); // Pulses unchanged!
    assert(sim.bannerLine1 == "KEYPAD LOCKED!  ");

    sim.pressDown();
    assert(sim.currentPulsesFixed == lockedPulses); // Pulses unchanged!
    assert(sim.bannerLine1 == "KEYPAD LOCKED!  ");
    std::cout << "[PASS] 1.7 Keypad Lock [L] Completely Blocks Accidental UP/DOWN Presses." << std::endl;
    sim.isUiLocked = false;

    // 1.7 Dual Button [UP] + [DOWN] > 10s Factory Reset at Standstill
    sim.pressDualUpDown(10500);
    assert(sim.menuState == 3); // Reset menu
    std::cout << "[PASS] 1.8 Dual [UP]+[DOWN] (>10s) Opens Factory Reset at Standstill." << std::endl;
    sim.menuState = 0;

    // 1.8 Optocoupler Bench Test on Page 8: UP Sinks PA8 to GND
    sim.menuState = 9;
    sim.infoIndex = 8; // Page 8 Opto Test
    sim.pressUp(200);
    assert(sim.infoIndex == 8); // Page index did NOT decrement!
    std::cout << "[PASS] 1.9 Menu Page 8 Optocoupler Multimeter Test: [UP] Sinks PA8 without Page Jump." << std::endl;
    sim.menuState = 0;

    // =========================================================================
    // SECTION 2: RUNNING TESTS (currentRPM > 0, hwBurstActive == true)
    // =========================================================================
    std::cout << "\n--- SECTION 2: BUTTONS BEHAVIOR WHILE RUNNING (MACHINE AT 3000 RPM) ---" << std::endl;
    sim.reset();
    sim.currentRPM = 3000;
    sim.hwBurstActive = true;
    sim.stepsRemaining = 50;

    // 2.1 Single-Click MODE while RUNNING -> STRICTLY BLOCKED
    uint64_t runGear = sim.stepGearFixed;
    sim.clickMode(100);
    sim.advanceMillis(400);
    assert(sim.stepGearFixed == runGear); // Gear NOT changed!
    assert(sim.bannerLine1 == "MACHINE RUNNING!");
    assert(sim.bannerLine2 == "GEAR CHG BLOCKED");
    std::cout << "[PASS] 2.1 Single-Click [MODE] while RUNNING: Strictly Blocked (Gear Constant)." << std::endl;

    // 2.2 Hold MODE (1.5-5s) while RUNNING -> STRICTLY BLOCKED
    int runSize = sim.currentSize;
    sim.clickMode(2500);
    assert(sim.currentSize == runSize); // Size NOT changed! Needle safe!
    assert(sim.bannerLine1 == "MACHINE RUNNING!");
    assert(sim.bannerLine2 == "SIZE CHG BLOCKED");
    std::cout << "[PASS] 2.2 Hold [MODE] (1.5-5s) while RUNNING: Strictly Blocked (Needle Protected)." << std::endl;

    // 2.3 Hold MODE (>5s) while RUNNING -> STRICTLY BLOCKED
    assert(sim.menuState == 0);
    sim.clickMode(5500);
    assert(sim.menuState == 0); // Menu NOT opened!
    assert(sim.bannerLine1 == "MACHINE RUNNING!");
    assert(sim.bannerLine2 == "MENU LOCKED [L] ");
    std::cout << "[PASS] 2.3 Hold [MODE] (>5s) while RUNNING: Strictly Blocked (Menu Locked)." << std::endl;

    // 2.4 UP Button while RUNNING -> STRICTLY BLOCKED
    uint64_t runPulses = sim.currentPulsesFixed;
    sim.pressUp();
    assert(sim.currentPulsesFixed == runPulses); // Pulses NOT modified!
    assert(sim.bannerLine1 == "MACHINE RUNNING!");
    assert(sim.bannerLine2 == "PULSE TUNE LOCK ");
    std::cout << "[PASS] 2.4 [UP] Button while RUNNING: Strictly Blocked (Pulse Count Constant)." << std::endl;

    // 2.5 DOWN Button while RUNNING -> STRICTLY BLOCKED
    sim.pressDown();
    assert(sim.currentPulsesFixed == runPulses); // Pulses NOT modified!
    assert(sim.bannerLine1 == "MACHINE RUNNING!");
    assert(sim.bannerLine2 == "PULSE TUNE LOCK ");
    std::cout << "[PASS] 2.5 [DOWN] Button while RUNNING: Strictly Blocked (Pulse Count Constant)." << std::endl;

    // 2.6 Dual Button [UP]+[DOWN] (>10s) while RUNNING -> STRICTLY BLOCKED
    sim.pressDualUpDown(11000);
    assert(sim.menuState == 0); // Reset NOT triggered!
    assert(sim.bannerLine1 == "MACHINE RUNNING!");
    assert(sim.bannerLine2 == "RESET BLOCKED!  ");
    std::cout << "[PASS] 2.6 Dual [UP]+[DOWN] (>10s) while RUNNING: Strictly Blocked (Reset Forbidden)." << std::endl;

    std::cout << "\n================================================================================" << std::endl;
    std::cout << "  ALL BUTTON TESTS IN BOTH RUN AND STOP MODES PASSED (100% GREEN)!              " << std::endl;
    std::cout << "================================================================================" << std::endl;
    return 0;
}
