#include <iostream>
#include <iomanip>
#include <cassert>
#include <cmath>
#include "../include/motion_scheduler.h"

struct TestRatio {
    const char* name;
    uint32_t intPart;
    uint32_t num;
    uint32_t den;
};

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Fractional Ratios 1,000,000 Cycle Exact Convergence" << std::endl;
    std::cout << "==========================================================" << std::endl;

    TestRatio ratios[] = {
        {"1/2",   10, 1, 2},
        {"1/3",   10, 1, 3},
        {"2/3",   10, 2, 3},
        {"1/7",   10, 1, 7},
        {"3/7",   10, 3, 7},
        {"7/13",  10, 7, 13},
        {"13/29", 10, 13, 29},
        {"Size #5 (2.50mm / 113.176848)", 113, 176848, 1000000},
        {"Size #8 (3.00mm / 135.812218)", 135, 812218, 1000000},
        {"Size #10 (4.00mm / 181.082957)", 181, 82957, 1000000}
    };

    const uint32_t CYCLES = 1000000;

    for (const auto& r : ratios) {
        DdaAccumulator dda;
        uint32_t fracFixed = (uint32_t)(((uint64_t)r.num * FIXED_SCALE_FACTOR) / r.den);

        uint32_t actualPulses = 0;
        double maxFixedPhaseError = 0.0;

        for (uint32_t c = 1; c <= CYCLES; c++) {
            uint32_t generated = dda.step(r.intPart, fracFixed);
            actualPulses += generated;

            // Mathematical expected total based on 6-decimal fixed-point precision
            double expectedFixed = (double)c * ((double)r.intPart + (double)fracFixed / (double)FIXED_SCALE_FACTOR);
            double phaseErrFixed = std::abs((double)actualPulses - expectedFixed);
            if (phaseErrFixed > maxFixedPhaseError) {
                maxFixedPhaseError = phaseErrFixed;
            }

            // Invariant 1: Instantaneous phase ripple relative to fixed-point MUST be <= 1.0 pulse
            assert(phaseErrFixed < 1.000001);
        }

        // Invariant 2: Total cumulative drift relative to mathematical ideal over 1,000,000 cycles MUST be < 1.0 pulse
        double finalExpectedExact = (double)CYCLES * ((double)r.intPart + (double)r.num / (double)r.den);
        double finalDiffIdeal = std::abs((double)actualPulses - finalExpectedExact);

        std::cout << "[PASS] " << std::left << std::setw(32) << r.name
                  << " | Actual: " << std::setw(9) << actualPulses
                  << " | Max Phase Err: " << std::fixed << std::setprecision(4) << maxFixedPhaseError
                  << " | Final Ideal Diff: " << std::setprecision(4) << finalDiffIdeal << std::endl;

        assert(finalDiffIdeal < 1.0);
    }

    std::cout << "==========================================================" << std::endl;
    std::cout << "ALL FRACTIONAL RATIO TESTS PASSED (100% GREEN)" << std::endl;
    std::cout << "==========================================================" << std::endl;
    return 0;
}
