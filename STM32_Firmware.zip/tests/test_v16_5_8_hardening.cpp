#include <cassert>
#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

static bool feasible(int res, double dia, int rpm, int angle, int margin, double pulses) {
    (void)res; (void)dia;
    const double windowUs = (60000000.0 / rpm) * (angle / 360.0) * (1.0 - margin / 100.0);
    return pulses > 0.0 && windowUs > 0.0 && (windowUs / pulses) >= 8.0;
}

int main() {
    // Representative feasible and infeasible manual tuning boundaries.
    assert(feasible(6400, 45.0, 3000, 160, 10, 113.176848));
    assert(!feasible(51200, 15.0, 4000, 30, 25, 5000.0));
    assert(feasible(6400, 45.0, 3000, 160, 10, 1.0));

    std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
    std::stringstream ss; ss << f.rdbuf();
    const std::string s = ss.str();
    assert(s.find("TIM1->BDTR |= TIM_BDTR_MOE") != std::string::npos);
    assert(s.find("const int stepPin           = PA8") != std::string::npos);
    assert(s.find("captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback)") != std::string::npos);
    assert(s.find("extern \"C\" void TIM2_IRQHandler(void)") == std::string::npos);
    assert(s.find("stepTimingIntervalUs = median3u32") != std::string::npos);
    assert(s.find("calculateAdaptiveStepPeriodQ16(stepTimingIntervalUs") != std::string::npos);
    assert(s.find("CAPTURE HEALTH") == std::string::npos);
    assert(s.find("pulseTimingInvalid") != std::string::npos);
    assert(s.find("if (pulseTimingInvalid) {\n        return;") != std::string::npos);
    std::cout << "PASS V16.5.8 hardening regression\n";
    return 0;
}
