#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::ifstream f("STM32_Zipper_CNC_V16_5_4_Firmware/STM32_Zipper_CNC_V16_5_4_Firmware.ino");
    std::stringstream ss; ss << f.rdbuf();
    const std::string s = ss.str();
    assert(!s.empty());
    assert(s.find("extern \"C\" void TIM2_IRQHandler(void)") == std::string::npos);
    assert(s.find("captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback)") != std::string::npos);
    assert(s.find("captureTimer->setMode(1, TIMER_INPUT_CAPTURE_FALLING, proxSensorPin)") != std::string::npos);
    assert(s.find("attachInterrupt(digitalPinToInterrupt(proxSensorPin), sensorISR, FALLING)") == std::string::npos);
    assert(s.find("processSensorTrigger(captureTimestampUs)") != std::string::npos);
    assert(s.find("tim2CaptureOverrunCount++") != std::string::npos);
    assert(s.find("stepTimingIntervalUs = median3u32") != std::string::npos);
    assert(s.find("updateStepPeriodFromServoInterval(stepTimingIntervalUs") != std::string::npos);
    assert(s.find("calculateAdaptiveStepPeriodQ16(stepTimingIntervalUs") != std::string::npos);
    assert(s.find("diff = 0UL; // This edge re-baselines motion") != std::string::npos);
    assert(s.find("TIM2 input capture is disabled in this build") == std::string::npos);
    assert(s.find("servoCaptureDma") == std::string::npos);
    // This filter suppresses an isolated long interval: median(20,20,40)=20.
    auto median3 = [](unsigned a, unsigned b, unsigned c) {
        if (a > b) { auto t=a; a=b; b=t; }
        if (b > c) { auto t=b; b=c; c=t; }
        if (a > b) { auto t=a; a=b; b=t; }
        return b;
    };
    assert(median3(20000, 20000, 40000) == 20000);
    assert(median3(20000, 40000, 20000) == 20000);
    assert(median3(40000, 20000, 20000) == 20000);
    std::cout << "PASS sole TIM2 hardware-capture source + median STEP timing regression\n";
}
