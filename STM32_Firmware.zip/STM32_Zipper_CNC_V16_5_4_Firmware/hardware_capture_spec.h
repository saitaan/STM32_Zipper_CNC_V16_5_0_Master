#ifndef HARDWARE_CAPTURE_SPEC_H
#define HARDWARE_CAPTURE_SPEC_H

#include <stdint.h>
#include <stdbool.h>
#include <cstring>

// =========================================================================
// STM32F103C8T6 HARDWARE CAPTURE & TIMING SPECIFICATION (V16.5.9)
// =========================================================================
// 1. PIN & CHANNEL PHYSICAL MAPPING:
//    - PA0: cam/proximity input; TIM2_CH1 captures falling edges as the sole trigger source.
//    - PA8: stepper driver PUL-/STEP output; TIM1_CH1 active-low hardware PWM.
//    - PA2: stepper driver DIR output.
//
// 2. PRODUCTION TRIGGER TIMING:
//    - TIM2 CCR1 is the authoritative PA0 edge timestamp; EXTI is not attached.
//    - TIM2 runs at 1 MHz with update IRQ extending the 16-bit counter to 32 bits.
//    - One IRQ owns UIF/CC1IF/CC1OF handling and consumes CCR1 only when CC1IF is set.
//    - STEP scheduling uses a median of three accepted intervals once filled; raw
//      intervals remain responsible for trigger qualification and watchdog logic.
//    - A capture overrun is counted; hardware cannot reconstruct an edge overwritten
//      before the capture ISR services CCR1, so overrun remains a validation fault.
//
// 3. TIMER OWNERSHIP & CONTINUOUS TIMEBASE:
//    - TIM1: PA8 STEP pulse generation; ARR/CCR1 define STEP period/width.
//    - TIM2: PA0 input capture + 32-bit extended 1 MHz timestamp.
//    - TIM3: 1 kHz safety monitor.
//    - TIM4: independent 1 MHz background timebase with overflow extension where available.
//
// 4. TIMING METRICS (nominal 72 MHz STM32F103 clock):
//    - TIM1/TIM2/TIM4 prescaler 71 gives a nominal 1 MHz timer tick where configured.
//    - Configured machine speed ceiling defaults to 3000 RPM; settings permit up to 4000 RPM.
//    - RPM standstill timeout: > 2,000,000 us without an accepted trigger.
// =========================================================================

// Diagnostic model used by host tests. Production timing is implemented in the
// firmware sketch; this class does not drive timers or prove physical edge counts.
struct HardwareCaptureDiagnostics {
    uint32_t totalTriggersDetected;
    uint32_t hardwareCapturesRead;
    uint32_t captureOverruns;
    uint32_t noiseSpikesFiltered;
    uint32_t timeoutsDetected;
    uint32_t lastLatchedCCR;
    uint32_t lastTimestampUs;
    uint32_t lastIntervalUs;
    bool     isCaptureStreamDiscontinuous;
    uint32_t overcaptureTimestampUs;
    uint32_t overcaptureEventCount;
    uint32_t lowerBoundLostEdges;
    uint32_t knownLostPulses;
    uint32_t acceptedPulses;
    uint32_t resyncEvents;

};

class HardwareCaptureStreamEngine {
public:
    HardwareCaptureDiagnostics diag;

    HardwareCaptureStreamEngine() { memset(&diag, 0, sizeof(diag)); }

    void handleHardwareEdge(bool cc1of, uint16_t ccr1, uint32_t timestampUs, uint32_t blankingFloorUs = 1500UL) {
        diag.totalTriggersDetected++;
        if (cc1of) {
            diag.captureOverruns++;
            diag.overcaptureEventCount++;
            diag.lowerBoundLostEdges++;
            diag.knownLostPulses++;
            diag.isCaptureStreamDiscontinuous = true;
            diag.overcaptureTimestampUs = timestampUs;
        }
        diag.hardwareCapturesRead++;
        diag.lastLatchedCCR = ccr1;
        if (diag.lastTimestampUs > 0) {
            uint32_t interval = timestampUs - diag.lastTimestampUs;
            if (interval < blankingFloorUs) {
                diag.noiseSpikesFiltered++;
                return;
            }
            diag.lastIntervalUs = interval;
        }
        diag.acceptedPulses++;
        diag.lastTimestampUs = timestampUs;
        if (!cc1of && diag.isCaptureStreamDiscontinuous) {
            diag.isCaptureStreamDiscontinuous = false;
            diag.resyncEvents++;
        }
    }

    bool verifyConservationInvariant(uint32_t physicalEdges) const {
        return physicalEdges == (diag.acceptedPulses + diag.lowerBoundLostEdges + diag.noiseSpikesFiltered);
    }
};

#endif // HARDWARE_CAPTURE_SPEC_H
