#ifndef BURST_QUEUE_H
#define BURST_QUEUE_H

#include <stdint.h>
#include <stdbool.h>

// =========================================================================
// FORMALLY VERIFIED SINGLE-PRODUCER SINGLE-CONSUMER (SPSC) BURST QUEUE
// 1. Capacity: Exactly 16 entries (Power of 2 for fast, wrap-safe masking).
// 2. Lock-free SPSC: Producer updates 'head', Consumer updates 'tail'.
// 3. Invariant: submitted == consumed + queued + aborted + dropped
//    (Strict dropped == 0 for all in-capacity operating conditions).
// 4. Overrun: Explicitly detected and counted; never overwrites unconsumed data.
// =========================================================================

#define BURST_QUEUE_CAPACITY 16U
#define BURST_QUEUE_MASK     (BURST_QUEUE_CAPACITY - 1U)

struct BurstItem {
    uint32_t stepCount;
    uint8_t  direction;    // 0: NORMAL [FWD], 1: REVERSE [REV]
    uint32_t timestampUs;  // 32-bit hardware timestamp
    uint16_t periodUs;     // Integer timer period (diagnostic/backward compatible)
    uint32_t periodQ16;  // Q16.16 microsecond period for fractional scheduling
    uint16_t reserved;     // Alignment / future timing metadata
    uint32_t seq;          // Monotonic sequence identifier
};

class BurstQueue {
public:
    volatile uint32_t head;
    volatile uint32_t tail;
    BurstItem         buffer[BURST_QUEUE_CAPACITY];

    // Diagnostic & Invariant Tracking Counters
    volatile uint32_t submittedPulses;
    volatile uint32_t consumedPulses;
    volatile uint32_t abortedPulses;
    volatile uint32_t droppedPulses;
    volatile uint32_t overflowCount;
    volatile uint32_t burstEnqueuedCount;
    volatile uint32_t burstDequeuedCount;

    BurstQueue() : head(0), tail(0),
                   submittedPulses(0), consumedPulses(0), abortedPulses(0),
                   droppedPulses(0), overflowCount(0),
                   burstEnqueuedCount(0), burstDequeuedCount(0) {
        for (uint32_t i = 0; i < BURST_QUEUE_CAPACITY; i++) {
            buffer[i].stepCount   = 0;
            buffer[i].direction   = 0;
            buffer[i].timestampUs = 0;
            buffer[i].periodUs    = 0;
            buffer[i].periodQ16   = 0;
            buffer[i].reserved    = 0;
            buffer[i].seq         = 0;
        }
    }

    // Reset queue state (Standstill Gated)
    void reset() {
        head = 0;
        tail = 0;
        submittedPulses    = 0;
        consumedPulses     = 0;
        abortedPulses      = 0;
        droppedPulses      = 0;
        overflowCount      = 0;
        burstEnqueuedCount = 0;
        burstDequeuedCount = 0;
    }

    // Number of pending bursts in queue
    inline uint32_t count() const {
        return (head - tail);
    }

    inline bool isEmpty() const {
        return (head == tail);
    }

    inline bool isFull() const {
        return ((head - tail) >= BURST_QUEUE_CAPACITY);
    }

    // Total steps queued across all pending bursts
    inline uint32_t queuedSteps() const {
        uint32_t total = 0;
        uint32_t t = tail;
        uint32_t h = head;
        while (t != h) {
            total += buffer[t & BURST_QUEUE_MASK].stepCount;
            t++;
        }
        return total;
    }

    // Producer Enqueue (Called strictly from Trigger ISR)
    // Returns true on success, false on overflow
    bool enqueue(uint32_t steps, uint8_t dir, uint32_t ts, uint32_t seq, uint16_t periodUs = 0, uint32_t periodQ16 = 0) {
        if (steps == 0) return true;

        submittedPulses += steps;

        uint32_t currentHead = head;
        uint32_t currentTail = tail;

        if ((currentHead - currentTail) >= BURST_QUEUE_CAPACITY) {
            // Queue full: detect overflow, reject without silent overwrite!
            overflowCount++;
            droppedPulses += steps;
            return false;
        }

        uint32_t idx = currentHead & BURST_QUEUE_MASK;
        buffer[idx].stepCount   = steps;
        buffer[idx].direction   = dir;
        buffer[idx].timestampUs = ts;
        buffer[idx].periodUs    = periodUs;
        buffer[idx].periodQ16   = periodQ16;
        buffer[idx].reserved    = 0;
        buffer[idx].seq         = seq;

        burstEnqueuedCount++;

        // Atomic publish to consumer
        head = currentHead + 1U;
        return true;
    }

    // Consumer Dequeue (Called strictly from Step Timer Callback / Scheduler)
    // Returns true if an item was dequeued, false if queue is empty
    bool dequeue(BurstItem &outItem) {
        uint32_t currentHead = head;
        uint32_t currentTail = tail;

        if (currentTail == currentHead) {
            return false; // Queue empty
        }

        uint32_t idx = currentTail & BURST_QUEUE_MASK;
        outItem = buffer[idx];

        consumedPulses += outItem.stepCount;
        burstDequeuedCount++;

        // Atomic release to producer
        tail = currentTail + 1U;
        return true;
    }

    // Peek next item without consuming
    bool peek(BurstItem &outItem) const {
        uint32_t currentHead = head;
        uint32_t currentTail = tail;

        if (currentTail == currentHead) {
            return false;
        }

        outItem = buffer[currentTail & BURST_QUEUE_MASK];
        return true;
    }

    // Abort pending bursts on Emergency Stop
    // Flushes the queue while strictly recording aborted step count
    uint32_t abortAll() {
        uint32_t flushed = 0;
        uint32_t t = tail;
        uint32_t h = head;
        while (t != h) {
            flushed += buffer[t & BURST_QUEUE_MASK].stepCount;
            t++;
        }
        tail = head; // Atomic drain
        abortedPulses += flushed;
        return flushed;
    }

    // Verify Formal System Invariant
    // submitted == consumed + queued + aborted + dropped
    inline bool verifyInvariant() const {
        return (submittedPulses == (consumedPulses + queuedSteps() + abortedPulses + droppedPulses));
    }
};

#endif // BURST_QUEUE_H
