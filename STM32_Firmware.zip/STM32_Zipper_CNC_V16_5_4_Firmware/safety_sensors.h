#ifndef SAFETY_SENSORS_H
#define SAFETY_SENSORS_H

#include <stdint.h>
#include <stdbool.h>

// =========================================================================
// HARDWARE SAFETY SENSOR SPECIFICATION & QUALIFICATION ENGINE
// Target Pins:
//   - PA3: Tape Run-Out Optical Sensor (PC817 Ch 1, Active-HIGH fault; optional)
//   - PB0: Optional future Coil/Thread sensor; independently enabled by firmware
// Qualification Standard:
//   - Strictly 15 consecutive samples @ 1 kHz (15.0 ms anti-vibration window)
//   - Completely independent counters: pa3FaultCounterMs and pb0FaultCounterMs
//   - Zero cross-accumulation between sensors
//   - Saturating bounded counter behavior (max 15)
// =========================================================================

#define SENSOR_QUALIFICATION_MS 15U

// Future-ready Tape Guard state model.
// NOTE: SENSOR_HW_DIAGNOSTIC_PRESENT stays 0 on the current single-wire PA3 hardware.
// A true SENSOR_FAULT state requires a hardware diagnostic/open-wire signature; it is
// deliberately not guessed from PA3 alone because "sensor absent" and "tape end" can
// otherwise be electrically identical.
#define SENSOR_HW_DIAGNOSTIC_PRESENT 0U

enum TapeGuardState : uint8_t {
    TAPE_GUARD_DISABLED = 0,
    TAPE_GUARD_MONITORING = 1,
    TAPE_GUARD_TAPE_END = 2,
    TAPE_GUARD_SENSOR_FAULT = 3
};

inline TapeGuardState evaluateTapeGuardState(bool guardActive, bool tapeBroken, bool sensorHardwareFault = false) {
    if (!guardActive) return TAPE_GUARD_DISABLED;
#if SENSOR_HW_DIAGNOSTIC_PRESENT
    if (sensorHardwareFault) return TAPE_GUARD_SENSOR_FAULT;
#else
    (void)sensorHardwareFault;
#endif
    return tapeBroken ? TAPE_GUARD_TAPE_END : TAPE_GUARD_MONITORING;
}

// Core qualification update function executed at 1 kHz (every 1.0 ms)
// Used in production firmware safetyTimerCallback() and verified by test harness.
inline void updateSafetySensorCounters(bool guardActive,
                                       bool tapeBroken,
                                       bool coilBroken,
                                       volatile uint8_t &pa3Counter,
                                       volatile uint8_t &pb0Counter,
                                       bool &pa3Qualified,
                                       bool &pb0Qualified) {
    if (!guardActive) {
        pa3Counter = 0;
        pb0Counter = 0;
        pa3Qualified = false;
        pb0Qualified = false;
        return;
    }

    // 1. Independent PA3 Qualification (Tape Run-Out)
    // Increments only on continuous active fault state; resets immediately to 0 when inactive
    if (tapeBroken) {
        if (pa3Counter < SENSOR_QUALIFICATION_MS) {
            pa3Counter++;
        }
    } else {
        pa3Counter = 0;
    }

    // 2. Legacy PB0 qualification (retained for test/API compatibility; production guard does not use it)
    // Increments only on continuous active fault state; resets immediately to 0 when inactive
    if (coilBroken) {
        if (pb0Counter < SENSOR_QUALIFICATION_MS) {
            pb0Counter++;
        }
    } else {
        pb0Counter = 0;
    }

    // 3. Independent Qualification Flags
    pa3Qualified = (pa3Counter >= SENSOR_QUALIFICATION_MS);
    pb0Qualified = (pb0Counter >= SENSOR_QUALIFICATION_MS);
}

#endif // SAFETY_SENSORS_H
