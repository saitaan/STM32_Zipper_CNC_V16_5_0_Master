#include <cmath>
/*
====================================================================================================
PROJECT  : STM32 ZIPPER CNC (ADAPTIVE SERVO-SYNC MASTER-FOLLOWER ENGINE)
VERSION  : 17.0.0 (PA0 TIM2 CAPTURE -> PA8 TIM1 STEP / TIMING GUARD)
AUTHOR   : RAJESH SHAH / INDUSTRIAL AUTOMATION & EMBEDDED SYSTEMS
DATE     : SEPTEMBER 2026
TARGET   : STM32F103C8T6 (32-BIT ARM CORTEX-M3 @ 72MHz)
LOCATION : NIPON ZIPPER INDUSTRIES PVT LTD, SARIGAM GIDC, GUJARAT, INDIA

VERSION 16.5.0 ARCHITECTURAL ADVANCEMENTS & HARDWARE-LEVEL ENGINE:
1. PRIMARY PROXIMITY->STEP HARDWARE PATH:
   - PA0 is the master proximity input; PA8 is the hardware-timed STEP output.
   - TIM1 hardware generation is the production/default engine; DDA is restored as an operator-selectable diagnostic/alternate engine for timing comparison.
   - First PA0 edge is accepted immediately; the first measured interval establishes real servo synchronization and arms Motion Lost monitoring.
2. OPTIONAL AUXILIARY SENSOR / RELAY SUBSYSTEM:
   - PA3: optional Tape Run-Out sensor.
   - PB0: optional future Coil/Thread sensor.
   - PB3: optional Safety Guard input.
   - PB1: optional Motor Stop Relay.
   - All auxiliary features are OFF by default and have no authority over PA0 capture or PA8 STEP timing.
   - A qualified enabled sensor may request PB1; it never aborts the current STEP burst.
   - Motion Lost may request PB1 only after a real measured PA0 interval has armed the watchdog.
3. BOOTUP HARDWARE RELAY GLITCH SUPPRESSION:
   - Atomic GPIOB->BRR clear on PB1 before setting pinMode to eliminate contact chatter on reset.
4. BACKWARDS-COMPATIBLE THREE-TIER EEPROM MIGRATION:
   - Automatically migrates existing V16.3.3 (0x5A431633) and V16.4.0 (0x5A431640) calibration parameters
     into V16.5.0 (0x5A431650) without resetting roller diameter or driver resolution.
5. 64-BIT DOUBLE PRECISION 1,000,000x DDA MATH:
   - Guaranteed < 0.025 mm error over 1.6 km of fed zipper tape.
====================================================================================================
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>
#include "burst_queue.h"
#include "motion_scheduler.h"
#include "hardware_capture_spec.h"
#include "safety_sensors.h"
#include "pulsestep_persistence.h"
#ifndef nvic_irq_enable
#define nvic_irq_enable(irq) NVIC_EnableIRQ(irq)
#endif

LiquidCrystal_I2C lcd(0x27, 16, 2);

// Write exactly 16 LCD columns; prevents stale characters after shorter labels/values.
static void lcdPrint16(uint8_t row, const char *text) {
    lcd.setCursor(0, row);
    uint8_t i = 0;
    if (text) { while (i < 16 && text[i] != '\0') lcd.print(text[i++]); }
    while (i < 16) { lcd.print(' '); ++i; }
}

// =========================================================================
// BUILD IDENTIFIERS & SOURCE-TO-BINARY METADATA
// =========================================================================
#define FW_VERSION_STR       "V17.0.0-PA0-TIM2-CAPTURE-PA8-TIM1"
#define FW_ARCH_TAG_STR      "V17.0.0-PA0-TIM2-CAPTURE-PA8-TIM1" // Backward compatible architecture tag: V16.5.9-PA0-TIM2-CAPTURE-PA8-TIM1
#define FW_BUILD_DATE_STR    "OCT-2026"
#define FW_BUILD_METADATA    "NIPON_ZIPPER_CNC_FW_V17_0_0_PA0_TIM2_CAPTURE_PA8_TIM1_TIMING_GUARD:OCT-2026"

// Embedded ROM identifier string for binary provenance verification
const char g_firmware_build_tag[] __attribute__((used)) = FW_BUILD_METADATA;

// Hardware Pin Definitions (100% Backwards-Compatible Pinout)
const int statusLedPin      = PC13; // Built-in Onboard LED (Active-LOW: LOW=ON, HIGH=OFF)
#define STATUS_LED_ON()    (GPIOC->BRR = (1 << 13))   // Atomic Clear PC13 -> LED ON
#define STATUS_LED_OFF()   (GPIOC->BSRR = (1 << 13))  // Atomic Set PC13   -> LED OFF
const int proxSensorPin     = PA0;  // Cam Proximity (PC817 Opto, Clean MCU GND, Falling ISR)
const int stepPin           = PA8;  // Driver PUL- (Hardware TIM1_CH1 / Direct Register BSRR)
const int dirPin            = PA2;  // Driver DIR- via Level Shifter CH4 LV (GPIOA Pin 2)
// =========================================================================
// 3-BUTTON / 6-BUTTON DUAL-MODE KEYPAD PIN DEFINITIONS (ACTIVE-LOW INPUT_PULLUP)
// Default Mode: 3-BTN (PB13=UP, PB12=DOWN, PB14=MODE/SELECT) for backward compatibility.
// 6-BTN Mode  : Adds PB15=BACK, PB11=LEFT, PB10=RIGHT (Selectable & Persistent in Settings).
// =========================================================================
const int btnUp             = PB13; // [UP] Button (Active-LOW to Clean MCU GND)
const int btnDown           = PB12; // [DOWN] Button (Active-LOW to Clean MCU GND)
const int btnMode           = PB14; // [SELECT / MODE] Button (Active-LOW to Clean MCU GND)
const int btnBack           = PB15; // [BACK] Button (6-BTN Mode, Active-LOW to Clean MCU GND)
const int btnLeft           = PB11; // [LEFT] Button (6-BTN Mode, Active-LOW to Clean MCU GND)
const int btnRight          = PB10; // [RIGHT] Button (6-BTN Mode, Active-LOW to Clean MCU GND)

// Direct Register Bit Set/Reset (1-Cycle 13.8ns Sinking)
#define STEP_LOW_ACTIVE()  (GPIOA->BSRR = (1 << (8 + 16)))
#define STEP_HIGH_IDLE()   (GPIOA->BSRR = (1 << 8))
#define DIR_LOW()          (GPIOA->BSRR = (1 << (2 + 16)))
#define DIR_HIGH()         (GPIOA->BSRR = (1 << 2))
#define DIR_NORMAL()       DIR_HIGH() // Idle-HIGH for Normal Forward rotation
#define DIR_REVERSE()      DIR_LOW()  // Active-LOW sinking for Reverse rotation

// 1,000,000x Micro-Fractional DDA Fixed-Point Scaling Factor (6 Decimal Places)
#define FIXED_SCALE 1000000ULL

// IWDG: Independent Watchdog Timer (40kHz LSI / 256 Prescaler -> 6.4ms/count, RLR=1000 -> ~6.4s nominal Timeout)
#define IWDG_INIT() do {     IWDG->KR = 0x5555;     IWDG->PR = 0x06;       IWDG->RLR = 1000;       IWDG->KR = 0xAAAA;     IWDG->KR = 0xCCCC; } while (0)
#define IWDG_FEED() (IWDG->KR = 0xAAAA)

#define EEPROM_MAGIC_V16_3_3 0x5A431633UL
#define EEPROM_MAGIC_V16_4_0 0x5A431640UL
#define EEPROM_MAGIC         0x5A431650UL

// Persistent EEPROM Storage Configuration Structure
#define EEPROM_MAGIC_V16_5_1 0x5A431651UL
#define EEPROM_MAGIC_V17_0_0 0x5A431700UL

// Legacy V16.5.0 Struct (52 bytes) - preserved for automatic field migration
struct MachineConfigLegacy {
    uint32_t p5_fixed;
    uint32_t p8_fixed;
    uint32_t p10_fixed;
    int32_t  driverResolution;
    float    rollerDia;
    int32_t  maxRPMSetting;
    int32_t  feedAngleDeg;
    int32_t  safetyMarginPercent;
    int32_t  currentSize;
    uint32_t sensorGuardActive; // Legacy field: bit0=PA3 Tape, bit1=PB0 Coil, bit2=PB3 Safety Guard, bit3=Motion->PB1
    uint32_t reservedStepMode;  // Reserved (Permanent TIM1 Hardware PWM Engine)
    uint32_t motorDirection;   // 0: NORMAL [FWD] (DEFAULT), 1: REVERSE [REV]
    uint32_t magic;
};

// =========================================================================
// PERSISTENT EEPROM CONFIGURATION STRUCTURE
// Authoritative structure size is dynamically enforced by sizeof(MachineConfig).
// Structure layout features 64-bit safe fixed-point pulse counts (p5, p8, p10)
// and 32-bit hardware parameters. magic header is placed at Offset 0 (0x5A431651UL)
// to uniquely differentiate from legacy V16.5.0/V16.4.0/V16.3.3 memory images.
// =========================================================================
struct MachineConfig {
    uint32_t magic;             // Offset 0: 0x5A431651UL (Magic header)
    uint32_t reserved;          // 64-bit alignment padding
    uint64_t p5_fixed;          // 64-bit safe fixed point (avoids uint32 overflow at 51200 res)
    uint64_t p8_fixed;          // 64-bit safe fixed point
    uint64_t p10_fixed;         // 64-bit safe fixed point
    int32_t  driverResolution;
    float    rollerDia;
    int32_t  maxRPMSetting;
    int32_t  feedAngleDeg;
    int32_t  safetyMarginPercent;
    int32_t  currentSize;
    uint32_t sensorGuardActive; // Legacy field: bit0=PA3 Tape, bit1=PB0 Coil, bit2=PB3 Safety Guard, bit3=Motion->PB1
    uint32_t reservedStepMode;  // Reserved (Permanent TIM1 Hardware PWM Engine)
    uint32_t motorDirection;   // 0: NORMAL [FWD] (DEFAULT), 1: REVERSE [REV]
    int32_t  reservedStartSpd; // Reserved (Direct Max RPM on Stitch #1)
};

// 6-Decimal Exact Mathematical Pitch Pulses (6400 Resolution / 45.0mm Roller Diameter)
uint64_t p5_fixed  = 70000000ULL; // Size #5 (2.50mm): 113.176848 steps
uint64_t p8_fixed  = 80000000ULL; // Size #8 (3.00mm): 135.812218 steps
uint64_t p10_fixed = 100000000ULL; // Size #10 (4.00mm): 181.082957 steps

int32_t driverResolution    = 6400;
float   rollerDia           = 45.0f;
int32_t maxRPMSetting       = 3000;
int32_t feedAngleDeg        = 90;
int32_t safetyMarginPercent = 15;
int     helpIndex           = 1;     // 1: Stall, 2: Pitch, 3: Noise, 4: Hot, 5: Drift
bool    motorDirection      = false; // DEFAULT: FALSE (NORMAL / FORWARD ROTATION)
bool    keypad6ButtonMode   = false; // DEFAULT: FALSE (3-BTN Mode default; TRUE = 6-BTN Mode, persistent in EEPROM)
bool    tempMotorDir        = false; // Staged Menu Direction
bool    tempKeypad6Btn      = false; // Staged Keypad Mode (false = 3-BTN, true = 6-BTN)
bool    isEditingSetting    = false; // In-place blinking parameter edit state in Settings Menu

extern volatile bool hwBurstActive;
extern volatile int stepsRemaining;
void stopHardwareTimerImmediately();

// Hardware-level Motor Direction Controller (PA2 DIR-)
void applyMotorDirection() {
    // Safety: ensure any active movement is completely stopped before changing DIR pin
    if (hwBurstActive || stepsRemaining > 0) {
        stopHardwareTimerImmediately();
    }
    delayMicroseconds(20); // Safe hold time after last step pulse before DIR edge
    if (motorDirection) {
        DIR_LOW();  // Active-LOW sinking for Reverse rotation
    } else {
        DIR_HIGH(); // Idle-HIGH for Normal Forward rotation
    }
    delayMicroseconds(20); // Safe setup time (exceeds 5us DM542 specification by 400%)
}


int autoPulseWidth_P5   = 25;
int autoPulseWidth_P8   = 29;
int autoPulseWidth_P10  = 22;
volatile int activePulseWidth = 70; // Nominal 70us step period (~14.2 kHz) for 3000 RPM / 160 deg
unsigned long dynamicDebounceUs = 3000UL; // 3.0ms: Rejects EMI, supports 12 to 20,000 RPM

int32_t resStepGear    = 100;
float   diaStepGear    = 0.1f;
int32_t rpmStepGear    = 100;
int32_t angleStepGear  = 5;
int32_t marginStepGear = 1;

int32_t currentSize = 2; // 1: #5 (2.50mm), 2: #8 (3.00mm) [DEFAULT], 3: #10 (4.00mm)
// =========================================================================
// ATOMIC COHERENT PULSE PARAMETER SNAPSHOT & TELEMETRY
// =========================================================================
#ifndef DEBUG_TEST_MODE
#define DEBUG_TEST_MODE 0
#endif

struct PulseParameters {
    uint32_t integerPart;
    uint32_t fractionalPart;
    uint32_t generation;

    PulseParameters() : integerPart(113), fractionalPart(176848UL), generation(1) {}
    PulseParameters(uint32_t i, uint32_t f, uint32_t g) : integerPart(i), fractionalPart(f), generation(g) {}
    PulseParameters(const PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters(const volatile PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters& operator=(const PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    PulseParameters& operator=(const volatile PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    void operator=(const PulseParameters& o) volatile {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
    }
};

BurstQueue burstQueue;
volatile uint32_t tim4_overflow_count = 0;

volatile PulseParameters activePulseParams   = {113, 176848UL, 1};
PulseParameters          pendingPulseParams  = {113, 176848UL, 1};
volatile uint32_t        paramGenerationUsed = 1;
volatile uint32_t        rejectedTriggerCount = 0; // Live noise rejection counter for diagnostics

#if DEBUG_TEST_MODE
volatile uint32_t acceptedTriggerCount   = 0;
volatile uint32_t triggerMissedCount     = 0;
volatile uint32_t requestedPulseCount    = 0;
volatile uint32_t startedPulseCount      = 0;
volatile uint32_t completedPulseCount    = 0;
volatile uint32_t abortedPulseCount      = 0;
volatile uint32_t queuedPulseCount       = 0;
volatile uint32_t burstStartedCount      = 0;
volatile uint32_t burstCompletedCount    = 0;
volatile uint32_t burstQueuedCount       = 0;
volatile uint32_t paramGenChangesCount   = 0;
volatile uint32_t maxISRLatencyCycles    = 0;
volatile uint32_t maxTriggerJitterUs     = 0;
volatile uint32_t assertionFailureCount  = 0;
#endif

void commitPulseParameters(uint32_t intPart, uint32_t fracPart) {
    pendingPulseParams.integerPart    = intPart;
    pendingPulseParams.fractionalPart = fracPart;
    pendingPulseParams.generation++;
#if DEBUG_TEST_MODE
    paramGenChangesCount++;
#endif
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    activePulseParams.integerPart = pendingPulseParams.integerPart;
    activePulseParams.fractionalPart = pendingPulseParams.fractionalPart;
    activePulseParams.generation = pendingPulseParams.generation;
    __set_PRIMASK(primask);
}

volatile uint64_t currentPulsesFixed = 80000000ULL;
volatile uint32_t currentPulsesInt   = 80;      // Whole step portion for fast 32-bit ISR math
volatile uint32_t currentPulsesFrac  = 0UL; // Fractional micro-step portion (< 1,000,000)
volatile uint32_t pulseFracAccumulator = 0UL;     // 32-bit fractional accumulator (zero 64-bit division)
volatile uint64_t pulseAccumulatorFixed = 0ULL;
volatile uint32_t tim2OverflowCount = 0UL;
volatile uint32_t tim2CaptureOverrunCount = 0UL;
volatile uint32_t tim2CaptureEpochOffsetUs = 0UL;
volatile bool tim2CaptureEpochReady = false;
volatile uint32_t tim2CaptureMissedCallbacks = 0UL;
volatile bool     isCaptureStreamDiscontinuous = false;
volatile uint32_t tim2CaptureResyncEvents      = 0UL;
// Last accepted PA0 trigger timestamp, sourced from the extended TIM2 hardware-capture clock.
volatile bool pendingMenuExit = false;
uint64_t stepGearFixed = 1000000ULL; // 1.00 pulse tuning step (1,000,000 units)

bool isUiLocked = true;
unsigned long lastUnlockActivity = 0UL;
unsigned long confirmDialogStartTime = 0UL;

// =========================================================================
// 1-MINUTE CONTINUOUS SMOOTH RUN AUTO-SAVE STATE MACHINE
// Gated strictly to 0 RPM Standstill (Zero Pulse & Trigger Interference)
// Anti-Repeat Latch: Saved exactly once per parameter modification
// =========================================================================
bool pulseModifiedByUser            = false;  // Armed when user tunes pulse with UP/DOWN
unsigned long smoothRunStartMillis   = 0UL;    // Legacy fallback timer
bool autoSavePendingStandstill       = false;  // Set when 60s qualified in RAM; deferred to 0 RPM
AutoSaveQualificationEngine autoSaveEngine(120000UL); // Formal 2-Minute Cooldown Auto-Save Engine
FlashSaveTransactionEngine  flashSaveTx;             // Atomic Flash Save Transaction Engine (Prompt 8Writing)

// Accepted motion-trigger counters and diagnostics (PA0 TIM2 input capture path).
volatile uint32_t acceptedTriggerPulses          = 0;

// Authoritative PulseStep Persistence State Tracking
uint32_t flashWriteCount            = 0;      // Diagnostic counter: strictly increments on actual Flash write
uint32_t activeEEPROMSlot           = 0;      // Active transaction slot (0 or 1)
uint32_t eepromSeqNumber            = 0;      // Monotonic transaction sequence counter
uint64_t pulseStepStored_p5         = 70000000ULL; // Stored ROM baseline for Size #5
uint64_t pulseStepStored_p8         = 80000000ULL; // Stored ROM baseline for Size #8
uint64_t pulseStepStored_p10        = 100000000ULL; // Stored ROM baseline for Size #10
int32_t  stored_driverResolution    = 6400;
float    stored_rollerDia           = 45.0f;
int32_t  stored_maxRPMSetting       = 3000;
int32_t  stored_feedAngleDeg        = 90;
int32_t  stored_safetyMarginPercent = 15;
int32_t  stored_currentSize         = 2;
bool     stored_motorDirection      = false;
bool     stored_keypad6ButtonMode   = false;
bool     eepromSlotInitialized      = false;

// In-Place Parameter Blinking State (Replaces pop-up feedback windows on value change)
enum BlinkTarget : uint8_t {
    BLINK_NONE          = 0,
    BLINK_MAIN_PULSE    = 1, // Blinks full P:xx.x on Main Screen during UP/DOWN tuning
    BLINK_MAIN_GEAR_INT = 2, // Blinks integer part of P:xx.x when 1.00 gear is selected
    BLINK_MAIN_GEAR_DEC = 3, // Blinks decimal part of P:xx.x when 0.10 gear is selected
    BLINK_MAIN_SIZE     = 4, // Blinks S:x on Main Screen when zipper size changes
    BLINK_MAIN_LOCK     = 5  // Blinks [L]/[U] on Main Screen on lock toggle or locked press
};
volatile uint8_t blinkTarget      = BLINK_NONE;
unsigned long    blinkUntilMs     = 0UL;


unsigned long uiMessageTimer = 0UL;
const char* uiBannerLine1 = nullptr;
const char* uiBannerLine2 = nullptr;

// Staged RAM Parameters for Zero Flash Wear
int32_t tempDriverRes       = 6400;
float   tempRollerDia       = 45.0f;
int32_t tempMaxRPM          = 3000;
int32_t tempFeedAngle       = 90;
int32_t tempSafetyMargin    = 15;

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm);

static inline bool stagedTimingConfigurationFeasible() {
    const double pitch5 = 1.32536067;
    const double pitch8 = 1.87759428;
    const double pitch10 = 2.31938128;
    return timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch5) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch8) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch10);
}

// True when the manually tuned pulse count cannot fit inside the configured
// feed-angle window at the configured maximum RPM. Never silently clamp an
// invalid manual tuning to the 8us timer floor.
volatile bool pulseTimingInvalid = false;

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#ifndef SERVO_PERIOD_Q_SHIFT
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U
#endif

static inline bool currentPulseTimingFeasible() {
    if (driverResolution < 200 || driverResolution > 51200 || rollerDia < 10.0f || rollerDia > 100.0f ||
        maxRPMSetting < 100 || maxRPMSetting > 4000 || feedAngleDeg < 30 || feedAngleDeg > 270 ||
        safetyMarginPercent < 0 || safetyMarginPercent > 25) return false;
    const double circumference = 3.14159265358979323846 * (double)rollerDia;
    (void)circumference;
    const double stepCount = (double)currentPulsesFixed / 1000000.0;
    const double feedWindowUs = (60000000.0 / (double)maxRPMSetting) * ((double)feedAngleDeg / 360.0) *
                                (1.0 - ((double)safetyMarginPercent / 100.0));
    const double overlapDeadlineUs = (60000000.0 / (double)maxRPMSetting) * 0.75 * 0.80;
    const double windowUs = (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
    return stepCount > 0.0 && windowUs > 0.0 && (windowUs / stepCount) >= (double)SERVO_PERIOD_MIN_US;
}

static inline void refreshPulseTimingValidity() {
    pulseTimingInvalid = !currentPulseTimingFeasible();
}
bool    hasStagedChanges    = false;
bool    isTimingWarningActive = false;
int diagMinW = 0;
const char* diagFixLine1 = nullptr;
const char* diagFixLine2 = nullptr;
int infoIndex = 1;

// Optical Safety Guard State Machine
unsigned long sensorTripStartTime = 0UL;
volatile bool isSensorFaultTripped = false;
volatile bool isMotionSyncLost     = false; // Diagnostic state; never blocks PA0/PA8 timing
volatile bool motionWatchdogArmed   = false; // Armed only after a valid measured trigger interval
volatile uint32_t validTriggerCount  = 0;
volatile bool auxSensorFaultActive  = false; // Auxiliary sensor fault; may trip PB1 but never cancels STEP
volatile int  faultType            = 0;     // 0: None, 1: Tape Run-Out, 2: Coil Breakage, 3: Trigger Sync Lost
// queuedBurstSteps removed: SPSC BurstQueue burstQueue is the single authoritative production scheduling queue

// Stepper Step State Machine
volatile bool triggerPull = false;
volatile unsigned long lastTriggerMicros = 0UL;
volatile unsigned long lastMeasuredIntervalUs = 0UL;
volatile unsigned long rawIntervalMicros = 0UL;
volatile int stepsRemaining = 0;
volatile int totalStepsInBurst = 0;
volatile int currentStepIndex = 0;
volatile bool stepPinState = HIGH;
volatile unsigned long lastStepMicros = 0UL;

// Hardware Timer 2 Burst Controller State
volatile bool hwBurstActive = false;
volatile int  hwBurstStepsTarget = 0;
volatile int  hwBurstStepsDone = 0;

volatile unsigned long currentRPM = 0UL;
// RPM display-only robust estimator. It does not control PA0 qualification,
// the watchdog's raw interval, or PA8 STEP scheduling.
volatile uint32_t rpmIntervalHistoryUs[3] = {0UL, 0UL, 0UL};
volatile uint8_t rpmIntervalHistoryCount = 0U;
volatile uint8_t rpmIntervalHistoryIndex = 0U;
unsigned long lastDisplayUpdate = 0UL;
unsigned long lastRpmDisplayUpdate = 0UL;
unsigned long lastButtonCheck = 0UL;
unsigned long modePressTime = 0UL;
unsigned long lastModeClickTime = 0UL;
unsigned long upPressTime = 0UL;
unsigned long downPressTime = 0UL;
unsigned long dualPressTime = 0UL;

bool modePressed = false;
bool upDownPressed = false;
bool pendingSingleClick = false;

int menuState = 0;
int oldMenuState = -1;
int hiddenOption = 1;
bool resetChoice = false;
bool saveExitChoice = true; // Save & Exit Dialog: true = YES, false = NO

// Hardware Timer 2 Instance for Stepping Pulses
// =========================================================================
// AUTHORITATIVE CNC MOVEMENT STATE MACHINE
// IDLE -> ARMED -> RUNNING -> STOPPING -> COMPLETE -> IDLE
// Fault/Abort: RUNNING/STOPPING -> FAULT/ABORTED -> IDLE (Standstill Gated)
// =========================================================================
enum MovementState {
    STATE_IDLE = 0,
    STATE_ARMED,
    STATE_RUNNING,
    STATE_STOPPING,
    STATE_COMPLETE,
    STATE_ABORTED,
    STATE_FAULT
};
volatile MovementState movementState = STATE_IDLE;

inline bool isMachineSafelyIdle() {
    return (currentRPM == 0UL) &&
           (stepsRemaining == 0) &&
           (!hwBurstActive) &&
           (burstQueue.isEmpty()) &&
           (movementState == STATE_IDLE || movementState == STATE_COMPLETE);
}

const uint16_t STEP_PULSE_WIDTH_US   = 5; // 5.0us Active LOW pulse for Leadshine DM542

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U

// Trigger interval history is shared by RPM display and robust STEP-period estimation.
volatile uint32_t servoPhaseRelockCount = 0;
volatile bool servoPhaseLocked = false;
volatile uint32_t servoLastIntervalUs = 0;
volatile uint32_t servoPrevIntervalUs = 0;
volatile uint32_t servoMaxJitterUs = 0;
volatile uint32_t servoPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t servoPeriodFrac = 0;
volatile uint32_t hwBurstPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t hwBurstPeriodFrac = 0;

static inline uint16_t q16PeriodToTimerUs(volatile uint32_t &frac, uint32_t q16) {
    // True Q16.16 accumulation: retain both the configured fractional period
    // and the carry from prior timer cycles. This preserves the long-term
    // average period instead of truncating the Q16 fractional component.
    uint32_t sum = (q16 & 0xFFFFUL) + (frac & 0xFFFFUL);
    uint32_t whole = (q16 >> SERVO_PERIOD_Q_SHIFT) + (sum >> SERVO_PERIOD_Q_SHIFT);
    frac = sum & 0xFFFFUL;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm) {
    if (resolution < 200 || resolution > 51200 || !(diameter == diameter) || diameter < 10.0f || diameter > 100.0f ||
        rpm < 100 || rpm > 4000 || angle < 30 || angle > 270 || margin < 0 || margin > 25 || pitchMm <= 0.0) return false;
    const double circumference = 3.14159265358979323846 * (double)diameter;
    const double stepCount = ((double)resolution / circumference) * pitchMm;
    const double feedWindowUs = (60000000.0 / (double)rpm) * ((double)angle / 360.0) * (1.0 - ((double)margin / 100.0));
    const double overlapDeadlineUs = (60000000.0 / (double)rpm) * 0.75 * 0.80;
    const double windowUs = (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
    if (!(stepCount > 0.0) || !(windowUs > 0.0)) return false;
    // The timer's hard minimum is 8 us. A configuration whose requested burst
    // period is below this cannot physically fit the commanded pulse count into
    // the configured feed-angle window. Never silently clamp such a case to 8 us.
    return (windowUs / stepCount) >= (double)SERVO_PERIOD_MIN_US;
}

// Reserve explicit timing headroom so a valid trigger at the configured RPM ceiling
// cannot arrive while the previous STEP burst is still active. The trigger plausibility
// guard accepts intervals down to 75% of a configured revolution; use only 80% of that
// floor for STEP time (60% of a revolution) as a conservative deadline.
static inline uint64_t maximumBurstWindowUs(int32_t rpm, int32_t angle, int32_t margin) {
    if (rpm < 100 || rpm > 4000) rpm = 3000;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    if (margin < 0) margin = 0;
    if (margin > 25) margin = 25;
    const uint64_t revolutionUs = 60000000ULL / (uint32_t)rpm;
    const uint64_t feedWindowUs = (revolutionUs * (uint32_t)angle / 360ULL) * (uint32_t)(100 - margin) / 100ULL;
    const uint64_t minimumAcceptedIntervalUs = revolutionUs * 3ULL / 4ULL;
    const uint64_t overlapDeadlineUs = minimumAcceptedIntervalUs * 80ULL / 100ULL;
    return (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
}

static inline uint32_t calculateAdaptiveStepPeriodQ16(uint32_t revolutionUs, uint32_t stepCount) {
    if (stepCount == 0U || revolutionUs == 0U) return servoPeriodQ16;
    int angle = feedAngleDeg;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    int margin = safetyMarginPercent;
    if (margin < 0) margin = 0;
    if (margin > 25) margin = 25;
    uint64_t windowUs = ((uint64_t)revolutionUs * (uint64_t)angle) / 360ULL;
    windowUs = (windowUs * (uint64_t)(100 - margin)) / 100ULL;
    // Dynamic burst cap: never let a burst exceed the configured maximum-RPM overlap deadline
    const uint64_t configuredDeadlineUs = maximumBurstWindowUs(maxRPMSetting, angle, margin);
    if (windowUs > configuredDeadlineUs) windowUs = configuredDeadlineUs;
    if (windowUs < 1ULL) windowUs = 1ULL;
    uint64_t q16 = (windowUs << SERVO_PERIOD_Q_SHIFT) / (uint64_t)stepCount;
    uint64_t minQ = ((uint64_t)SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT);
    uint64_t maxQ = ((uint64_t)SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT);
    if (q16 < minQ) q16 = minQ;
    if (q16 > maxQ) q16 = maxQ;
    return (uint32_t)q16;
}


HardwareTimer *stepTimer     = new HardwareTimer(TIM1);
HardwareTimer *captureTimer  = new HardwareTimer(TIM2); // PA0 input capture; core-owned TIM2 IRQ dispatch
#if defined(TIM4)
HardwareTimer *timebaseTimer = new HardwareTimer(TIM4);
#endif

// =========================================================================
// TRUE HARDWARE TIMER 2 PWM (OC2) STEP GENERATION & BURST CONTROLLER
// 1. Pure Continuous PWM Mode 2: Inactive (HIGH) 0..CCR2-1, Active (LOW) CCR2..ARR.
// 2. Output is natively, physically HIGH at CNT=0 rollover.
// 3. Software halts CEN and CC2E at CNT=0 upon burst completion (0.2us latency vs 30us safety window).
// 4. Zero OPM hardware race conditions: Timer NEVER stalls or dies on rapid/boundary triggers!
// 5. Seamless mid-burst trigger accumulation: Target += stepCount without losing a single pulse.
// =========================================================================

// =========================================================================
// DETERMINISTIC MULTI-SEGMENT RAMP PARAMETER CALCULATOR
// Provides smooth, bounded acceleration/deceleration with zero staircase jerk
// Dedicated short-burst handling: N<=4 (pure cruise), 5<=N<=12 (gentle soft boundary)
// =========================================================================
static inline uint16_t calculateAdaptiveStepPeriodUs(uint32_t revolutionUs, uint32_t stepCount) {
    uint32_t q16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    uint32_t whole = q16 >> SERVO_PERIOD_Q_SHIFT;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline void updateStepPeriodFromServoInterval(uint32_t revolutionUs, uint32_t stepCount) {
    if (revolutionUs == 0U || stepCount == 0U) return;
    servoPrevIntervalUs = servoLastIntervalUs;
    servoLastIntervalUs = revolutionUs;
    if (servoPrevIntervalUs != 0U) {
        uint32_t jitter = (revolutionUs > servoPrevIntervalUs) ? (revolutionUs - servoPrevIntervalUs) : (servoPrevIntervalUs - revolutionUs);
        if (jitter > servoMaxJitterUs) servoMaxJitterUs = jitter;
    }
    servoPeriodQ16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    servoPhaseLocked = (servoPrevIntervalUs != 0U);
    if (servoPhaseLocked) servoPhaseRelockCount++;
}

void stepTimerCallback() {
    if (hwBurstActive && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        hwBurstStepsDone++;
#if DEBUG_TEST_MODE
        completedPulseCount++;
#endif

        if (hwBurstStepsDone >= hwBurstStepsTarget) {
            BurstItem nextBurst{};
            if (movementState != STATE_FAULT && movementState != STATE_ABORTED && burstQueue.dequeue(nextBurst)) {
                // Seamlessly chain queued burst from authoritative SPSC BurstQueue without dropping timer
                hwBurstStepsTarget = (int)nextBurst.stepCount;
                hwBurstStepsDone   = 0;
#if DEBUG_TEST_MODE
                queuedPulseCount  -= nextBurst.stepCount;
                startedPulseCount += nextBurst.stepCount;
                burstStartedCount++;
#endif
                stepsRemaining     = hwBurstStepsTarget;
                totalStepsInBurst  = hwBurstStepsTarget;

                // Direction Fix (per Rajesh Shah directive):
                // Direction is strictly Settings-controlled and fixed during RUN.
                // Pulse, burst, queue, ISR, DDA, RPM, trigger, and sensor processing NEVER change DIR at runtime.

                // Each queued burst carries the period calculated from the physical
                // servo interval that created it. Never rewrite the active burst with a
                // newer measurement; this preserves deterministic phase timing.
                if (nextBurst.periodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && nextBurst.periodQ16 <= (SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT)) {
                    hwBurstPeriodQ16 = nextBurst.periodQ16;
                    hwBurstPeriodFrac = 0;
                } else if (nextBurst.periodUs >= SERVO_PERIOD_MIN_US && nextBurst.periodUs <= SERVO_PERIOD_MAX_US) {
                    hwBurstPeriodQ16 = ((uint32_t)nextBurst.periodUs << SERVO_PERIOD_Q_SHIFT);
                    hwBurstPeriodFrac = 0;
                }
                uint16_t firstScheduledUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
                activePulseWidth = (int)firstScheduledUs;
                uint16_t nextARR = (firstScheduledUs > 1) ? (uint16_t)(firstScheduledUs - 1) : 1;
                TIM1->ARR = nextARR;
                uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
                if (pWidth < 2) pWidth = 2;
                TIM1->CCR1 = nextARR - pWidth + 1;
                return;
            }

            // Burst complete with no queued steps: disable PWM output and stop timer in silicon
            TIM1->CCER &= ~TIM_CCER_CC1E; // Disconnect hardware PWM output on PA8 immediately
            TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
            
            // Restore PA8 pin to General Purpose Output HIGH (Idle)
            GPIOA->CRH &= ~(0xFU << 0);
            GPIOA->CRH |= (0x3U << 0); // 50MHz GP Output Push-Pull
            STEP_HIGH_IDLE();
            stepPinState = HIGH;

            // Clear any pending update flags in NVIC
            TIM1->SR &= ~TIM_SR_UIF;
            NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

            hwBurstActive  = false;
            stepsRemaining = 0;
            movementState  = STATE_COMPLETE;
#if DEBUG_TEST_MODE
            burstCompletedCount++;
            if (queuedPulseCount == 0 && !hwBurstActive) {
                if (requestedPulseCount != (completedPulseCount + abortedPulseCount)) {
                    assertionFailureCount++;
                }
            }
#endif
            STATUS_LED_OFF(); // Stepper burst complete -> Turn OFF LED
        } else {
            stepsRemaining = (hwBurstStepsTarget - hwBurstStepsDone);
            movementState  = STATE_RUNNING;

            // Keep every pulse in the burst at the servo-synchronized period.
            // Artificial per-pulse ramps are deliberately removed because they change
            // the commanded pulse density away from the measured master motion.
            uint16_t scheduledPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
            activePulseWidth = (int)scheduledPeriodUs;
            uint16_t nextARR = (scheduledPeriodUs > 1) ? (uint16_t)(scheduledPeriodUs - 1) : 1;
            TIM1->ARR  = nextARR;
            uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
            if (pWidth < 2) pWidth = 2;
            TIM1->CCR1 = nextARR - pWidth + 1; // Pulse ends exactly at ARR rollover
        }
    } else {
        TIM1->CCER &= ~TIM_CCER_CC1E;
        TIM1->CR1  &= ~TIM_CR1_CEN;
        GPIOA->CRH &= ~(0xFU << 0);
        GPIOA->CRH |= (0x3U << 0);
        STEP_HIGH_IDLE();
        stepPinState   = HIGH;
        TIM1->SR &= ~TIM_SR_UIF;
        NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
        hwBurstActive  = false;
        stepsRemaining = 0;
        movementState  = STATE_IDLE;
    }
}

// =========================================================================
// DETERMINISTIC 1 KHZ HARDWARE SAFETY MONITOR (TIM3)
// Unblockable by loop() or I2C LCD delays. 15ms Anti-Vibration Qualified E-Stop.
// =========================================================================
static inline uint32_t get_hardware_timestamp_us(); // shared timebase prototype
void processSensorTrigger(uint32_t capturedTimestampUs); // forward declaration for TIM2 callback

// =========================================================================
// CONTINUOUS 1 MHZ FREE-RUNNING TIMER 4 (STM32F103 HARDWARE TIMESTAMPING)
// 1.0 microsecond deterministic tick resolution, independent of TIM2/TIM3
// =========================================================================
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
void tim4UpdateCallback(void) {
    tim4_overflow_count++;
}

void initFreeRunningTimer4() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;

    // Attach callback using official STM32duino HardwareTimer framework
    // (Prevents duplicate definition of TIM4_IRQHandler with SrcWrapper/HardwareTimer.cpp)
    timebaseTimer->pause();
    timebaseTimer->setPrescaleFactor(72);     // 72MHz / 72 = 1MHz (1.0 us tick)
    timebaseTimer->setOverflow(0x10000UL);    // 16-bit free-running counter rollover at 65535us
    timebaseTimer->setCount(0);
    timebaseTimer->attachInterrupt(tim4UpdateCallback);
    timebaseTimer->resume();

    // Enforce exact silicon register configuration after resume()
    TIM4->PSC = 71;     // 72MHz / (71 + 1) = 1MHz (1.0 us tick)
    TIM4->ARR = 0xFFFF; // 16-bit free-running counter rollover at 65535us
    TIM4->CNT = 0;
    TIM4->EGR = TIM_EGR_UG;     // Immediately force-load prescaler shadow buffer in hardware
    TIM4->SR &= ~TIM_SR_UIF;    // Clear the update interrupt flag generated by EGR_UG
    TIM4->DIER |= TIM_DIER_UIE; // Enable update interrupt for 32-bit rollover
}

// Provably race-safe atomic snapshot across 16-bit hardware timer overflow
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t high;
    uint16_t low;
    bool pending;

    do {
        high = tim4_overflow_count;
        low  = (uint16_t)(TIM4->CNT);
        pending = (TIM4->SR & TIM_SR_UIF) != 0;
    } while (high != tim4_overflow_count);

    // If an overflow interrupt is pending (UIF set) and CNT has already rolled over
    // to a small value (< 0x8000), account for the unserviced rollover in this reading
    if (pending && (low < 0x8000)) {
        high++;
    }

    return (high << 16) | low;
}
#else
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t nowCycles = 0;
#if defined(CoreDebug) && defined(DWT)
    nowCycles = DWT->CYCCNT;
#endif
    return (nowCycles != 0) ? (nowCycles / 72UL) : micros();
}
#endif
// TIM2 update callback extends the 1 MHz capture counter across 16-bit wraps.
// The core-owned TIM2_IRQHandler calls these through HardwareTimer's HAL bridge.
void tim2CaptureRolloverCallback() {
    tim2OverflowCount++;
}

void tim2HardwareCaptureCallback() {
    // CCR1 was latched by hardware at the PA0 falling edge, before ISR latency.
    if ((TIM2->SR & TIM_SR_CC1OF) != 0U) {
        tim2CaptureOverrunCount++;
        tim2CaptureMissedCallbacks++; // Accurately record each missed edge in silicon
        isCaptureStreamDiscontinuous = true; // Flag stream discontinuity to prevent false RPM drop
        TIM2->SR &= ~TIM_SR_CC1OF;
    }
    const uint16_t captured = (uint16_t)captureTimer->getCaptureCompare(1);
    uint32_t high = tim2OverflowCount;
    const uint16_t cntNow = (uint16_t)TIM2->CNT;
    const bool updateStillPending = (TIM2->SR & TIM_SR_UIF) != 0U;

    // Provably race-safe atomic epoch resolution across 16-bit hardware timer overflow
    if (updateStillPending) {
        // Rollover occurred in hardware (UIF set), but tim2CaptureRolloverCallback has not
        // incremented tim2OverflowCount yet because HAL services capture callback first.
        // If capture was latched after rollover (small captured value), it belongs to high + 1!
        if (captured < 0x8000U) {
            high++;
        }
    } else {
        // Rollover callback already executed and incremented tim2OverflowCount.
        // If capture occurred just before the wrap (large value near 0xFFFF), it belongs to previous epoch.
        if (high > 0UL && cntNow < captured && (uint16_t)(captured - cntNow) > 0x8000U) {
            high--;
        }
    }

    const uint32_t captureClockUs = (high << 16) | (uint32_t)captured;
    if (!tim2CaptureEpochReady) {
        // Align the capture clock to the TIM4 monotonic clock once. Thereafter,
        // intervals come from TIM2 hardware captures, not ISR dispatch timing.
        tim2CaptureEpochOffsetUs = get_hardware_timestamp_us() - captureClockUs;
        tim2CaptureEpochReady = true;
    }
    const uint32_t captureTimestampUs = tim2CaptureEpochOffsetUs + captureClockUs;
    processSensorTrigger(captureTimestampUs);
}

void initHardwareTimer2() {
    // TIM2_CH1 on PA0 is the single authoritative motion-trigger source.
    // TIM2 capture hardware latches the falling-edge timestamp independent of
    // CPU interrupt latency; its IRQ performs the trigger processing exactly once.
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    // Bind stepTimer callback & enable TIM1_UP_IRQn in NVIC via HardwareTimer first,
    // then immediately place TIM1 in deterministic idle state before configuring registers.
    stepTimer->pause();
    stepTimer->setPrescaleFactor(72);
    stepTimer->setOverflow(100);
    stepTimer->setInterruptPriority(0, 0); // Priority 0 (Highest) for exact TIM1 burst cutoff
    stepTimer->attachInterrupt(stepTimerCallback);
    stepTimer->resume();

    // TIM1 STEP engine: 1 MHz timer tick; active-low PWM Mode 2.
    TIM1->CR1 = 0;
    TIM1->CCER &= ~TIM_CCER_CC1E;
    TIM1->PSC = 71;
    TIM1->RCR = 0;
    uint16_t initARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
    TIM1->ARR = initARR;
    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    TIM1->CCMR1 |= (0x7U << 4); // CH1 PWM Mode 2
    TIM1->CCMR1 |= TIM_CCMR1_OC1PE;
    TIM1->CCER |= TIM_CCER_CC1P;
    TIM1->CR1 |= TIM_CR1_ARPE;
    TIM1->CR1 &= ~TIM_CR1_OPM;
    TIM1->BDTR |= TIM_BDTR_MOE; // Required for advanced-control TIM1 outputs
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR = TIM_EGR_UG;     // Force-load PSC=71, ARR, CCR1, RCR=0 into hardware shadow registers
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    NVIC_SetPriority(TIM1_UP_IRQn, 0);
    TIM1->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM1_UP_IRQn);

    // Keep PA8 in GP Output Push-Pull HIGH (0x3) while idle so STEP_HIGH_IDLE(),
    // Stepper Jog Test (Page 1), Opto Sink Test (Page 2), and DDA mode work directly.
    // startHardwareTimerBurst() switches PA8 to AF Push-Pull (0xB) during active TIM1 bursts.
    pinMode(stepPin, OUTPUT);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0); // PA8 GP output push-pull, 50 MHz (Idle HIGH)

    // TIM2_CH1 input capture: PA0 / TI1, falling edge, 1 MHz counter.
    // Use STM32duino HardwareTimer callbacks: the core owns TIM2_IRQHandler,
    // and dispatches capture/update callbacks through HAL_TIM_IRQHandler.
    // This makes the CCR1 hardware-latched edge timestamp authoritative without
    // defining a duplicate TIM2_IRQHandler symbol or also dispatching EXTI0.
    captureTimer->pause();
    captureTimer->setMode(1, TIMER_INPUT_CAPTURE_FALLING, proxSensorPin);
    captureTimer->setPrescaleFactor(72);       // 72 MHz / 72 = 1 MHz (1 us/tick)
    captureTimer->setOverflow(0x10000UL);      // 16-bit wrap; overflow callback extends it
    captureTimer->setCount(0);
    tim2OverflowCount = 0UL;
    tim2CaptureOverrunCount = 0UL;
    tim2CaptureEpochOffsetUs = 0UL;
    tim2CaptureEpochReady = false;
    tim2CaptureMissedCallbacks = 0UL;
    captureTimer->setInterruptPriority(1, 0); // Priority 1 for immediate trigger preemption
    captureTimer->attachInterrupt(tim2CaptureRolloverCallback);
    captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback);
    captureTimer->resume();

    // Restore PA0 internal pull-up (setMode resets PA0 to floating input) and enforce IC1F filter
    GPIOA->CRL &= ~(0xFU << 0);
    GPIOA->CRL |= (0x8U << 0);  // Input with pull-up / pull-down
    GPIOA->BSRR = (1U << 0);    // Pull-up enabled on PA0
    // SILICON-LEVEL HARDWARE DIGITAL FILTER (IC1F = 0011):
    // Digital filter debounces PA0 pin for N=8 consecutive clock cycles (111 ns) at f_CK_INT (72MHz).
    // Eliminates high-frequency motor contactor/clutch noise directly in hardware with 0% CPU overhead!
    TIM2->CCMR1 &= ~TIM_CCMR1_IC1F;
    TIM2->CCMR1 |= (0x3U << 4);
}

void startHardwareTimerBurst(int stepCount, uint16_t burstPeriodUs = 0, uint32_t burstPeriodQ16 = 0) {
    if (stepCount <= 0 || movementState == STATE_FAULT || movementState == STATE_ABORTED) return;

    // ATOMIC CRITICAL SECTION: protect the burst queue and TIM1 start sequence.
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    uint32_t nowUs = get_hardware_timestamp_us();
    uint32_t targetPeriodQ16 = burstPeriodQ16 ? burstPeriodQ16 : ((uint32_t)burstPeriodUs << SERVO_PERIOD_Q_SHIFT);
    if (burstPeriodQ16 == 0U && burstPeriodUs == 0U) targetPeriodQ16 = servoPeriodQ16;
    static uint32_t s_burstSeq = 0;

    if (hwBurstActive) {
        // Do NOT reset hwBurstPeriodFrac or overwrite active burst with a slower period;
        // if machine accelerated faster than active burst, tighten active period to prevent phase lag
        if (targetPeriodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && targetPeriodQ16 < hwBurstPeriodQ16) {
            hwBurstPeriodQ16 = targetPeriodQ16;
        }
        bool enqueued = burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, targetPeriodQ16);
        if (enqueued) {
#if DEBUG_TEST_MODE
            burstQueuedCount++;
            queuedPulseCount += stepCount;
#endif
        }
        movementState = STATE_RUNNING;
        __set_PRIMASK(primask);
        return;
    }

    // Active burst is idle: set period & reset Q16.16 fraction strictly for the new burst
    hwBurstPeriodQ16  = targetPeriodQ16;
    hwBurstPeriodFrac = 0;
    burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, targetPeriodQ16);
    BurstItem item{};
    burstQueue.dequeue(item);

    if (item.periodUs >= 8U && item.periodUs <= 500U) {
        activePulseWidth = (int)item.periodUs;
    }
    hwBurstStepsTarget = (int)item.stepCount;
    hwBurstStepsDone   = 0;
    hwBurstActive      = true;
#if DEBUG_TEST_MODE
    burstStartedCount++;
    startedPulseCount += stepCount;
#endif
    stepsRemaining     = stepCount;
    totalStepsInBurst  = stepCount;
    stepPinState       = HIGH;
    movementState      = STATE_RUNNING;

    // The servo is the mechanical master. Do not invent an acceleration ramp here.
    // activePulseWidth is derived from the most recent physical trigger interval;
    // maxRPMSetting is only the startup/fallback bound before the first valid interval.
    uint16_t initPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
    activePulseWidth = (int)initPeriodUs;
    uint16_t initARR = (initPeriodUs > 1) ? (uint16_t)(initPeriodUs - 1) : 1;
    TIM1->CR1 &= ~TIM_CR1_CEN;
    TIM1->PSC  = 71;
    TIM1->RCR  = 0;
    TIM1->ARR  = initARR;

    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;

    // Ensure PWM Mode 2, preload, active-low polarity, and OPM disabled
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    TIM1->CCMR1 |= (0x7U << 4) | TIM_CCMR1_OC1PE;
    TIM1->CCER  |= TIM_CCER_CC1P;
    TIM1->CR1   |= TIM_CR1_ARPE;
    TIM1->CR1   &= ~TIM_CR1_OPM;

    // Force load preload registers into shadow registers and reset CNT to 0
    // Temporarily mask UIE so EGR_UG does not latch a spurious update interrupt into NVIC
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR   = TIM_EGR_UG;
    TIM1->SR   &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    TIM1->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM1_UP_IRQn);

    // Enable hardware PWM output and Main Output Enable on PA8 in silicon before AF switch
    TIM1->CCER |= TIM_CCER_CC1E;
    TIM1->BDTR |= TIM_BDTR_MOE;

    // Connect PA8 directly to TIM1_CH1: Alternate Function Push-Pull 50MHz
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0xBU << 0); // 1011b = AF Output Push-Pull 50MHz

    // Start timer counter in silicon
    TIM1->CR1 |= TIM_CR1_CEN;

    __set_PRIMASK(primask);
}

void stopHardwareTimerImmediately() {
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    TIM1->CCER &= ~TIM_CCER_CC1E; // Disable hardware PWM output on PA8 in silicon
    TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
    TIM1->CR1  &= ~TIM_CR1_OPM;   // Ensure OPM cleared

    // Restore PA8 pin to General Purpose Output HIGH (Idle)
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;

    // Clear all pending flags and interrupts
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

    uint32_t abortedFromQueue = burstQueue.abortAll();
#if DEBUG_TEST_MODE
    int uncompleted = (hwBurstStepsTarget - hwBurstStepsDone) + (int)abortedFromQueue;
    if (uncompleted > 0) {
        abortedPulseCount += uncompleted;
        queuedPulseCount = 0;
    }
#else
    (void)abortedFromQueue;
#endif

    hwBurstActive      = false;
    hwBurstStepsTarget = 0;
    hwBurstStepsDone   = 0;
    stepsRemaining     = 0;
    movementState      = isSensorFaultTripped ? STATE_FAULT : STATE_ABORTED;

    __set_PRIMASK(primask);
}

void recalculatePitchProfiles() {
    // Explicit numerical bounds checking
    if ((rollerDia != rollerDia) || rollerDia < 10.0f || rollerDia > 100.0f) rollerDia = 45.0f;
    if (driverResolution < 200 || driverResolution > 51200) driverResolution = 6400;
    double circumference = 3.14159265358979323846 * (double)rollerDia;
    double pulsesPerMM = (double)driverResolution / circumference;
    // 64-bit intermediate arithmetic: strictly prevents uint32_t overflow at max 51200 res / 15mm roller
    const double pitch5 = 1.54625411;  // Calibrated for 70.00 pulses at 6400 res / 45mm roller
    const double pitch8 = 1.76714755;  // Calibrated for 80.00 pulses at 6400 res / 45mm roller
    const double pitch10 = 2.20893444; // Calibrated for 100.00 pulses at 6400 res / 45mm roller
    p5_fixed  = (uint64_t)(pitch5 * pulsesPerMM * 1000000.0 + 0.5);
    p8_fixed  = (uint64_t)(pitch8 * pulsesPerMM * 1000000.0 + 0.5);
    p10_fixed = (uint64_t)(pitch10 * pulsesPerMM * 1000000.0 + 0.5);
    if (p5_fixed < 1000000ULL) p5_fixed = 1000000ULL;
    if (p8_fixed < 1000000ULL) p8_fixed = 1000000ULL;
    if (p10_fixed < 1000000ULL) p10_fixed = 1000000ULL;
}

void syncPulseIntegerFraction() {
    uint32_t intPart  = (uint32_t)(currentPulsesFixed / 1000000ULL);
    uint32_t fracPart = (uint32_t)(currentPulsesFixed % 1000000ULL);
    currentPulsesInt  = intPart;
    currentPulsesFrac = fracPart;
    commitPulseParameters(intPart, fracPart);
}

void updateActivePulseWidth() {
    syncPulseIntegerFraction();
    if (maxRPMSetting < 100 || maxRPMSetting > 4000) maxRPMSetting = 3000;
    if (feedAngleDeg < 30 || feedAngleDeg > 270) feedAngleDeg = 160;
    if (safetyMarginPercent < 0 || safetyMarginPercent > 25) safetyMarginPercent = 10;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));
    float activeSteps = (float)currentPulsesFixed / 1000000.0f;
    if (activeSteps < 1.0f) activeSteps = 1.0f;
    // Startup/fallback STEP period only; runtime period is replaced by measured servo timing.
    double requestedPeriodUs = (double)timeWindowUs / (double)activeSteps;
    refreshPulseTimingValidity();
    if (requestedPeriodUs < (double)SERVO_PERIOD_MIN_US) {
        // Do not hide an impossible manual tuning behind the 8us timer clamp.
        // Keep the timer at its safe floor, but mark the configuration invalid so
        // the UI/start path can block motion until the operator corrects it.
        pulseTimingInvalid = true;
        activePulseWidth = SERVO_PERIOD_MIN_US;
        return;
    }
    int calcPeriod = (int)requestedPeriodUs;
    if (calcPeriod > (int)SERVO_PERIOD_MAX_US) calcPeriod = SERVO_PERIOD_MAX_US;
    activePulseWidth = calcPeriod;
}

void calculateAllPulseWidths() {
    if (maxRPMSetting <= 0) maxRPMSetting = 3000;
    if (feedAngleDeg <= 0) feedAngleDeg = 160;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));

    float s5 = (float)p5_fixed / 1000000.0f;
    if (s5 < 1.0f) s5 = 1.0f;
    // Safe industrial limit: Full step period [8us, 500us] (guarantees >= 2.5us driver opto timing)
    autoPulseWidth_P5 = constrain((int)(timeWindowUs / s5), 8, 500);

    float s8 = (float)p8_fixed / 1000000.0f;
    if (s8 < 1.0f) s8 = 1.0f;
    autoPulseWidth_P8 = constrain((int)(timeWindowUs / s8), 8, 500);

    float s10 = (float)p10_fixed / 1000000.0f;
    if (s10 < 1.0f) s10 = 1.0f;
    autoPulseWidth_P10 = constrain((int)(timeWindowUs / s10), 8, 500);

    updateActivePulseWidth();

    // 50% nominal period debounce: completely rejects trailing edge & contactor EMI noise
    dynamicDebounceUs = 3000UL; // Legacy UI/diagnostic value; trigger qualification uses measured adaptive blanking.
}

void evaluateDiagnostics() {
    float tempDia  = (tempRollerDia > 0.1f) ? tempRollerDia : 45.0f;
    int32_t tempRes   = (tempDriverRes > 200) ? tempDriverRes : 6400;
    int32_t tempRPM   = (tempMaxRPM > 100) ? tempMaxRPM : 3000;
    int32_t tempAngle  = (tempFeedAngle > 10) ? tempFeedAngle : 160;
    int32_t tempMargin = constrain(tempSafetyMargin, 0, 25);

    float tempCirc = 3.14159265f * tempDia;
    float tempPPM  = (float)tempRes / tempCirc;
    float s10_test = 4.00f * tempPPM;
    if (s10_test < 1.0f) s10_test = 1.0f;

    float timeWinTest = (60000000.0f / (float)tempRPM) * ((float)tempAngle / 360.0f) * (1.0f - ((float)tempMargin / 100.0f));
    diagMinW = (int)(timeWinTest / s10_test);

    if (diagMinW < 6) {
        isTimingWarningActive = true;
        if (tempRes > 12800) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET RES <= 12800";
        } else if (tempAngle < 120) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "INC ANGLE >= 150";
        } else if (tempRPM > 2500) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RPM <= 2500 ";
        } else if (tempMargin > 15) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET MARGIN 10%  ";
        } else {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RES/INC ANG ";
        }
    } else {
        isTimingWarningActive = false;
        diagFixLine1 = "TIMING HEALTH:  ";
        diagFixLine2 = "SYSTEM OPTIMAL  ";
    }
}

// =========================================================================
// TWO-PHASE ATOMIC DEFERRED TRIGGER DISPATCH ENGINE (SECTION 6 RACE FIX)
// Dispatches any triggers deferred during Flash save/abort window.
// Prevents newer incoming physical triggers from overtaking older deferred work.
// Only after deferred pulses are safely handed off does the lock return to IDLE.
// =========================================================================
static void dispatchDeferredSaveTriggers() {
    for (;;) {
        uint8_t defDir = 0;
        uint32_t defTs = 0;
        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        uint32_t defSteps = flashSaveTx.captureDeferredForDispatch(defDir, defTs);
        const bool stillPending = flashSaveTx.deferredTriggerPending;
        if (defSteps == 0U && !stillPending) {
            flashSaveTx.completeHandoff();
            __set_PRIMASK(primask);
            break;
        }
        __set_PRIMASK(primask);

        if (defSteps == 0U) continue;
        if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
            startHardwareTimerBurst((int)defSteps);
        } else {
#if DEBUG_TEST_MODE
            abortedPulseCount += (int)defSteps;
#endif
        }
    }
}

static inline void syncStoredBaselinesWithRam() {
    pulseStepStored_p5         = p5_fixed;
    pulseStepStored_p8         = p8_fixed;
    pulseStepStored_p10        = p10_fixed;
    stored_driverResolution    = driverResolution;
    stored_rollerDia           = rollerDia;
    stored_maxRPMSetting       = maxRPMSetting;
    stored_feedAngleDeg        = feedAngleDeg;
    stored_safetyMarginPercent = safetyMarginPercent;
    stored_currentSize         = currentSize;
    stored_motorDirection      = motorDirection;
    stored_keypad6ButtonMode   = keypad6ButtonMode;
}

bool saveToEEPROM() {
    // Watchdog-safe selective persistence: only allowed at confirmed standstill.
    IWDG_FEED();
    if (!isMachineSafelyIdle()) return false;
    IWDG_FEED();
    if (!flashSaveTx.requestSaveLock()) {
        IWDG_FEED();
        return false;
    }

    if (!flashSaveTx.confirmLockAndTransition(isMachineSafelyIdle())) {
        dispatchDeferredSaveTriggers();
        IWDG_FEED();
        return false;
    }

    int slotOffset = (activeEEPROMSlot == 0) ? 0 : 128;
    MachineConfigRecord activeRec;
    EEPROM.get(slotOffset, activeRec);
    const bool slotValid = PulseStepPersistenceManager::validateRecord(activeRec) &&
                           (activeRec.magic == EEPROM_MAGIC_V17_0_0);

    MachineConfigRecord rec;
    rec.magic    = EEPROM_MAGIC_V17_0_0;
    rec.seq      = eepromSeqNumber + 1U;
    rec.reserved = 0;

    rec.payload.p5_fixed            = p5_fixed;
    rec.payload.p8_fixed            = p8_fixed;
    rec.payload.p10_fixed           = p10_fixed;
    rec.payload.driverResolution    = driverResolution;
    rec.payload.rollerDia           = rollerDia;
    rec.payload.maxRPMSetting       = maxRPMSetting;
    rec.payload.feedAngleDeg        = feedAngleDeg;
    rec.payload.safetyMarginPercent = safetyMarginPercent;
    rec.payload.currentSize         = currentSize;
    rec.payload.sensorGuardActive   = keypad6ButtonMode ? 1UL : 0UL; // Persists 3-BTN (0) vs 6-BTN (1) mode
    rec.payload.reservedStepMode    = 0UL; // Permanent TIM1 hardware PWM engine
    rec.payload.motorDirection      = motorDirection ? 1UL : 0UL;
    rec.payload.reservedStartSpd    = 100;

    if (slotValid && memcmp(&rec.payload, &activeRec.payload, sizeof(MachineConfigPayload)) == 0) {
        // Zero parameters changed: skip write completely (0 Flash writes)
        syncStoredBaselinesWithRam();
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges = false;
        dispatchDeferredSaveTriggers();
        IWDG_FEED();
        return true;
    }

    rec.crc32 = calculateCRC32((const uint8_t*)&rec.payload, sizeof(MachineConfigPayload));

    IWDG_FEED();
    if (!slotValid || !eepromSlotInitialized) {
        // Initial record creation when slot is uninitialized
        EEPROM.put(slotOffset, rec);
        eepromSlotInitialized = true;
    } else {
        // SELECTIVE PARAMETER-ONLY EEPROM UPDATE:
        // Only write the specific parameter field(s) that actually changed!
        // Unchanged parameters are NEVER rewritten in memory.
        if (rec.payload.p5_fixed != activeRec.payload.p5_fixed) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.p5_fixed), rec.payload.p5_fixed);
        }
        if (rec.payload.p8_fixed != activeRec.payload.p8_fixed) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.p8_fixed), rec.payload.p8_fixed);
        }
        if (rec.payload.p10_fixed != activeRec.payload.p10_fixed) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.p10_fixed), rec.payload.p10_fixed);
        }
        if (rec.payload.driverResolution != activeRec.payload.driverResolution) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.driverResolution), rec.payload.driverResolution);
        }
        if (memcmp(&rec.payload.rollerDia, &activeRec.payload.rollerDia, sizeof(float)) != 0) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.rollerDia), rec.payload.rollerDia);
        }
        if (rec.payload.maxRPMSetting != activeRec.payload.maxRPMSetting) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.maxRPMSetting), rec.payload.maxRPMSetting);
        }
        if (rec.payload.feedAngleDeg != activeRec.payload.feedAngleDeg) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.feedAngleDeg), rec.payload.feedAngleDeg);
        }
        if (rec.payload.safetyMarginPercent != activeRec.payload.safetyMarginPercent) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.safetyMarginPercent), rec.payload.safetyMarginPercent);
        }
        if (rec.payload.currentSize != activeRec.payload.currentSize) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.currentSize), rec.payload.currentSize);
        }
        if (rec.payload.sensorGuardActive != activeRec.payload.sensorGuardActive) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.sensorGuardActive), rec.payload.sensorGuardActive);
        }
        if (rec.payload.motorDirection != activeRec.payload.motorDirection) {
            EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, payload.motorDirection), rec.payload.motorDirection);
        }
        // Update sequence counter and CRC32 for the modified parameter(s)
        EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, seq), rec.seq);
        EEPROM.put(slotOffset + (int)offsetof(MachineConfigRecord, crc32), rec.crc32);
    }
    IWDG_FEED();

    MachineConfigRecord readBack;
    EEPROM.get(slotOffset, readBack);

    bool saveOk = false;
    if (PulseStepPersistenceManager::validateRecord(readBack) &&
        memcmp(&rec, &readBack, sizeof(MachineConfigRecord)) == 0) {
        flashWriteCount++;
        eepromSeqNumber = rec.seq;
        syncStoredBaselinesWithRam();
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges = false;
        calculateAllPulseWidths();
        saveOk = true;
    }

    dispatchDeferredSaveTriggers();
    IWDG_FEED();
    return saveOk;
}

void loadFactoryDefaults() {
    driverResolution    = 6400;
    rollerDia           = 45.0f;
    maxRPMSetting       = 3000;
    feedAngleDeg        = 90;
    safetyMarginPercent = 15;
    resStepGear         = 100;
    diaStepGear         = 0.1f;
    rpmStepGear         = 50;
    angleStepGear       = 1;
    marginStepGear      = 1;
    currentSize         = 2;     // Size #8 default
    motorDirection      = false; // NORMAL FORWARD DEFAULT
    keypad6ButtonMode   = false; // DEFAULT: 3-BTN Mode (Backward compatible with 3-button hardware)
    tempKeypad6Btn      = false;
    isEditingSetting    = false;
    applyMotorDirection();
    recalculatePitchProfiles();
    p5_fixed            = 70000000ULL;
    p8_fixed            = 80000000ULL;
    p10_fixed           = 100000000ULL;
    currentPulsesFixed  = p8_fixed;
    stepGearFixed       = 1000000ULL;
    calculateAllPulseWidths();
    syncStoredBaselinesWithRam();
    pulseModifiedByUser = false;
    hasStagedChanges    = false;
}

void loadFromEEPROM() {
    MachineConfigRecord rec0, rec1;
    EEPROM.get(0, rec0);
    EEPROM.get(128, rec1);

    bool v0 = PulseStepPersistenceManager::validateRecord(rec0);
    bool v1 = PulseStepPersistenceManager::validateRecord(rec1);

    MachineConfigRecord *chosen = nullptr;
    uint32_t chosenSlot = 0;

    if (v0 && v1) {
        if (rec0.seq >= rec1.seq) {
            chosen = &rec0;
            chosenSlot = 0;
        } else {
            chosen = &rec1;
            chosenSlot = 1;
        }
    } else if (v0) {
        chosen = &rec0;
        chosenSlot = 0;
    } else if (v1) {
        chosen = &rec1;
        chosenSlot = 1;
    }

    if (chosen != nullptr) {
        activeEEPROMSlot      = chosenSlot;
        eepromSeqNumber       = chosen->seq;
        eepromSlotInitialized = true;

        p5_fixed            = chosen->payload.p5_fixed;
        p8_fixed            = chosen->payload.p8_fixed;
        p10_fixed           = chosen->payload.p10_fixed;
        driverResolution    = chosen->payload.driverResolution;
        rollerDia           = chosen->payload.rollerDia;
        if (rollerDia < 10.0f || rollerDia > 100.0f) rollerDia = 45.0f;
        maxRPMSetting       = chosen->payload.maxRPMSetting;
        feedAngleDeg        = chosen->payload.feedAngleDeg;
        safetyMarginPercent = chosen->payload.safetyMarginPercent;
        currentSize         = chosen->payload.currentSize;
        keypad6ButtonMode   = (chosen->payload.sensorGuardActive == 1UL);
        tempKeypad6Btn      = keypad6ButtonMode;
        motorDirection      = (chosen->payload.motorDirection == 1UL);

        applyMotorDirection();
        if (p5_fixed < PULSE_STEP_MIN_FIXED || p5_fixed > PULSE_STEP_MAX_FIXED ||
            p8_fixed < PULSE_STEP_MIN_FIXED || p8_fixed > PULSE_STEP_MAX_FIXED ||
            p10_fixed < PULSE_STEP_MIN_FIXED || p10_fixed > PULSE_STEP_MAX_FIXED) {
            recalculatePitchProfiles();
        }
        calculateAllPulseWidths();

        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        if (currentSize == 1) currentPulsesFixed = p5_fixed;
        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
        else currentPulsesFixed = p10_fixed;
        __set_PRIMASK(primask);
        updateActivePulseWidth();

        syncStoredBaselinesWithRam();
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
    } else {
        loadFactoryDefaults();
    }
}

// PRIMARY MOTION PATH: PA0 falling-edge trigger -> this ISR -> one synchronized PA8 STEP burst.
// Auxiliary sensors/relay logic must never preempt, abort, or replace this path.
// Reset only the RPM display estimator; raw timing/safety state remains separate.
static inline void resetRpmIntervalHistory() {
    rpmIntervalHistoryUs[0] = 0UL;
    rpmIntervalHistoryUs[1] = 0UL;
    rpmIntervalHistoryUs[2] = 0UL;
    rpmIntervalHistoryCount = 0U;
    rpmIntervalHistoryIndex = 0U;
}

static inline uint32_t median3u32(uint32_t a, uint32_t b, uint32_t c) {
    if (a > b) { uint32_t t = a; a = b; b = t; }
    if (b > c) { uint32_t t = b; b = c; c = t; }
    if (a > b) { uint32_t t = a; a = b; b = t; }
    return b;
}

// Process one PA0 falling edge using its TIM2 hardware-captured timestamp.
// Process one accepted PA0 edge. This function receives the monotonic TIM4 timestamp from sensorISR.
void processSensorTrigger(uint32_t capturedTimestampUs) {
    const uint32_t nowUs = capturedTimestampUs;
    unsigned long diff = 0;

    if (lastTriggerMicros == 0UL) {
        lastMeasuredIntervalUs = 0UL;
        currentRPM = 0UL;
        resetRpmIntervalHistory();
        acceptedTriggerPulses++;
        validTriggerCount = 1U;
        motionWatchdogArmed = false;
    } else {
        // Both values are extended TIM2 capture timestamps (1 tick = 1 us).
        // Unsigned subtraction is wrap-safe across the 32-bit timestamp rollover.
        diff = (uint32_t)(nowUs - (uint32_t)lastTriggerMicros);

        if (diff > 2000000UL) {
            // Standstill: the next edge is a new first edge. Do not watchdog it.
            lastMeasuredIntervalUs = 0UL;
            currentRPM = 0UL;
            resetRpmIntervalHistory();
            acceptedTriggerPulses++;
            validTriggerCount = 1U;
            motionWatchdogArmed = false;
            diff = 0UL; // This edge re-baselines motion; do not turn standstill time into STEP period.
            isCaptureStreamDiscontinuous = false;
        } else if (isCaptureStreamDiscontinuous) {
            // Overcapture recovery: CCR1 was overwritten before service, so diff spans 2+ physical cycles.
            // Do NOT let this 2x artifact drop the displayed RPM or stretch the STEP burst!
            isCaptureStreamDiscontinuous = false;
            tim2CaptureResyncEvents++;
            // Resynchronize to the continuous operating interval so RPM and STEP timing remain stable
            if (lastMeasuredIntervalUs > 0UL) {
                diff = lastMeasuredIntervalUs;
            } else if (diff > 0UL) {
                diff = diff / 2UL; // Estimate single-revolution period if overcapture occurred on startup
                lastMeasuredIntervalUs = diff;
            }
            acceptedTriggerPulses++;
            validTriggerCount++;
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
            }
        } else {
            // Speed-adaptive software blanking: 1.5ms minimum and 4.5ms maximum.
            unsigned long activeBlankingUs = 1000UL;
            if (lastMeasuredIntervalUs > 0UL) {
                activeBlankingUs = lastMeasuredIntervalUs / 4UL; // 25% of previous revolution
                if (activeBlankingUs < 1000UL) activeBlankingUs = 1000UL;
                if (activeBlankingUs > 4000UL) activeBlankingUs = 4000UL;
            }

            // Speed-adaptive software blanking: 1.0ms minimum and 4.0ms maximum.
            // CRITICAL NEEDLE SAFETY INVARIANT: Every needle cycle MUST produce a STEP burst!
            // If a pulse is dropped or rejected, the zipper tape remains stationary while the needle
            // plunges into the coil, jamming or breaking the needle.
            // We reject ONLY sub-millisecond switch contact chatter (< activeBlankingUs).
            // Never drop a cycle due to machine speed exceeding maxRPMSetting.
            if (diff < activeBlankingUs) {
                rejectedTriggerCount++;
                return; // Pure sub-millisecond optocoupler contact chatter rejected
            }

            // Servo plausibility guard: at configured max RPM, one revolution has
            // 60,000,000/maxRPMSetting us. Allow 25% speed headroom (period >= 75% of
            // that value), which rejects 4.5-9ms false edges while allowing a 3000 RPM
            // machine (20ms/rev) and brief speed transients up to ~4000 RPM.
            uint32_t configuredMaxRPM = (maxRPMSetting >= 100 && maxRPMSetting <= 4000)
                ? (uint32_t)maxRPMSetting : 3000UL;
            uint32_t minimumPlausibleIntervalUs = (60000000UL / configuredMaxRPM) * 3UL / 4UL;
            if (diff < minimumPlausibleIntervalUs) {
                rejectedTriggerCount++;
                return; // Implausibly fast edge: keep lastTriggerMicros unchanged.
            }

            lastMeasuredIntervalUs = diff;
            acceptedTriggerPulses++;
            validTriggerCount++;
            // A real interval now exists: this is the first point at which
            // motion-loss monitoring is allowed to arm.
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
            }

        }
    }

    // The RPM display and STEP scheduler share a three-interval history, but raw diff
    // remains authoritative for qualification/watchdog. STEP scheduling uses the median
    // once three valid intervals exist to reject isolated long/short timing outliers.
    if (lastTriggerMicros != 0UL && diff > 0UL && diff <= 2000000UL) {
        rpmIntervalHistoryUs[rpmIntervalHistoryIndex] = (uint32_t)diff;
        rpmIntervalHistoryIndex = (uint8_t)((rpmIntervalHistoryIndex + 1U) % 3U);
        if (rpmIntervalHistoryCount < 3U) rpmIntervalHistoryCount++;

        uint32_t rpmIntervalForDisplay = (uint32_t)diff;
        if (rpmIntervalHistoryCount >= 3U) {
            rpmIntervalForDisplay = median3u32(rpmIntervalHistoryUs[0],
                                               rpmIntervalHistoryUs[1],
                                               rpmIntervalHistoryUs[2]);
        }

        if (rpmIntervalForDisplay > 0UL) {
            const unsigned long instantRPM = 60000000UL / rpmIntervalForDisplay;
            if (instantRPM > 0UL && instantRPM <= 40000UL) {
                if (currentRPM == 0UL) currentRPM = instantRPM;
                else currentRPM = (unsigned long)((3UL * instantRPM + 5UL * currentRPM) / 8UL);
            }
        }
    } else if (diff > 2000000UL) {
        currentRPM = 0UL;
        resetRpmIntervalHistory();
    }
    // Use a robust interval for STEP scheduling, distinct from the raw interval
    // used for trigger qualification and watchdog. A single missed/late edge can
    // produce one long interval; median-of-three prevents that outlier from directly
    // stretching the next PA8 burst. This cannot reconstruct a physically missed edge.
    uint32_t stepTimingIntervalUs = (uint32_t)diff;
    if (lastTriggerMicros != 0UL && diff > 0UL && diff <= 2000000UL &&
        rpmIntervalHistoryCount >= 3U) {
        stepTimingIntervalUs = median3u32(rpmIntervalHistoryUs[0],
                                          rpmIntervalHistoryUs[1],
                                          rpmIntervalHistoryUs[2]);
        // Zero-Lag Acceleration Fast-Track: when the machine accelerates (diff < median),
        // track the faster physical revolution immediately so the STEP burst always finishes
        // inside the current cam feed-angle window and never queues across revolutions.
        if ((uint32_t)diff < stepTimingIntervalUs) {
            stepTimingIntervalUs = (uint32_t)diff;
        }
    }

    lastTriggerMicros = nowUs;
    STATUS_LED_ON(); // LED marks captured PA0 trigger activity; not an independent heartbeat.

    // 3. Atomic Coherent Parameter Snapshot & Zero-Latency Stepper Burst Triggering
    // An impossible manually tuned pulse count must never be converted into a
    // silently clamped burst. Requiring the operator to correct it protects both
    // TIM2 and DDA from running outside the configured timing envelope.
    if (pulseTimingInvalid) {
        return;
    }
    if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        // Capture integer and fractional microsteps from the exact same generation
        PulseParameters snap;
        snap.integerPart = activePulseParams.integerPart;
        snap.fractionalPart = activePulseParams.fractionalPart;
        snap.generation = activePulseParams.generation;
#if DEBUG_TEST_MODE
        paramGenerationUsed = snap.generation;
        acceptedTriggerCount++;
        requestedPulseCount += snap.integerPart;
#endif
        int newSteps = (int)snap.integerPart;
        pulseFracAccumulator += snap.fractionalPart;
        if (pulseFracAccumulator >= 1000000UL) {
            newSteps++;
            pulseFracAccumulator -= 1000000UL;
#if DEBUG_TEST_MODE
            requestedPulseCount++;
#endif
        }

        // Servo is the master: derive this trigger's burst period from the exact
        // physical revolution interval and exact integer pulse count for this burst.
        // First trigger from standstill uses configured maxRPMSetting directly (no cold-start scaling)
        uint32_t configuredRPM = (maxRPMSetting >= 100 && maxRPMSetting <= 4000)
            ? (uint32_t)maxRPMSetting : 3000UL;
        uint32_t startupRevUs = 60000000UL / configuredRPM;
        uint32_t burstPeriodQ16 = (stepTimingIntervalUs > 0UL)
            ? calculateAdaptiveStepPeriodQ16(stepTimingIntervalUs, (uint32_t)newSteps)
            : calculateAdaptiveStepPeriodQ16(startupRevUs, (uint32_t)newSteps);
        uint16_t burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        if (burstPeriodUs < SERVO_PERIOD_MIN_US) burstPeriodUs = SERVO_PERIOD_MIN_US;
        if (burstPeriodUs > SERVO_PERIOD_MAX_US) burstPeriodUs = SERVO_PERIOD_MAX_US;
        if (stepTimingIntervalUs > 0UL) {
            updateStepPeriodFromServoInterval(stepTimingIntervalUs, (uint32_t)newSteps);
            burstPeriodQ16 = servoPeriodQ16;
            burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        }

        if (newSteps > 0) {
            if (flashSaveTx.isSaveLockActive()) {
                flashSaveTx.deferTrigger(newSteps, motorDirection ? 1 : 0, nowUs);
            } else {
                startHardwareTimerBurst(newSteps, burstPeriodUs, burstPeriodQ16);
            }
        }
    }

    // 4. Signal background loop to exit menu if machine starts running while in settings
    if (menuState != 0 && menuState != 9) {
        pendingMenuExit = true;
    }
}

void setup() {
    pinMode(stepPin, OUTPUT);
    pinMode(dirPin, OUTPUT);
    applyMotorDirection();
    STEP_HIGH_IDLE();

    pinMode(proxSensorPin, INPUT_PULLUP);

    // Initialize 3 primary buttons + 3 extended 6-button navigation pins with internal pull-up
    pinMode(btnUp, INPUT_PULLUP);
    pinMode(btnDown, INPUT_PULLUP);
    pinMode(btnMode, INPUT_PULLUP);
    pinMode(btnBack, INPUT_PULLUP);
    pinMode(btnLeft, INPUT_PULLUP);
    pinMode(btnRight, INPUT_PULLUP);

    pinMode(statusLedPin, OUTPUT);
    STATUS_LED_OFF();

#if defined(CoreDebug) && defined(DWT)
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
#endif

    loadFromEEPROM();
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
    initFreeRunningTimer4();
#endif
    initHardwareTimer2(); // PA0 TIM2_CH1 hardware capture + PA8 TIM1_CH1 STEP engine

    // Strict NVIC Priority Hierarchy:
    // Priority 0: TIM1_UP (PA8 STEP pulse generator - highest possible priority, zero pulse jitter)
    // Priority 1: TIM2_IRQn (PA0 Cam Proximity trigger - immediate hardware preemption)
    // Priority 3: SysTick_IRQn (Background Arduino timebase)
    NVIC_SetPriority(TIM1_UP_IRQn, 0);
    NVIC_SetPriority(SysTick_IRQn, 3);
    IWDG_INIT();

    #ifndef RCC_CSR_IWDGRSTF
    #define RCC_CSR_IWDGRSTF (1U << 29)
    #endif
    #ifndef RCC_CSR_RMVF
    #define RCC_CSR_RMVF (1U << 24)
    #endif

    const bool isWatchdogReset = (RCC->CSR & RCC_CSR_IWDGRSTF) != 0U;
    RCC->CSR |= RCC_CSR_RMVF;

    Wire.begin();
    Wire.setClock(400000);
#if defined(WIRE_HAS_TIMEOUT) || defined(ARDUINO_ARCH_STM32)
    Wire.setTimeout(25000);
#endif
    lcd.init();
    lcd.backlight();
    lcd.clear();

    if (!isWatchdogReset) {
        // Cold Power-On Boot: Show 2-second Developer & Company branding
        lcd.setCursor(0, 0);
        lcd.print("DEV: RAJESH SHAH");
        lcd.setCursor(0, 1);
        lcd.print("NIPON ZIPPER IND");
        for (int i = 0; i < 20; i++) {
            IWDG_FEED();
            delay(100);
        }
    } else {
        lcd.setCursor(0, 0);
        lcd.print("FAST-BOOT READY ");
        lcd.setCursor(0, 1);
        lcd.print("IWDG RECOVERED  ");
        delay(100);
    }
}

void loop() {
    IWDG_FEED();

    // =========================================================================
    // INTERACTIVE STEPPER JOG BENCH TEST (Diagnostics Page 1)
    // =========================================================================
    if (menuState == 9 && infoIndex == 1 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        static uint32_t lastJogUs = 0;
        uint32_t nowJog = micros();
        if (digitalRead(btnUp) == LOW) {
            DIR_NORMAL();
            if ((uint32_t)(nowJog - lastJogUs) >= 800) {
                lastJogUs = nowJog;
                STEP_LOW_ACTIVE();
                delayMicroseconds(5);
                STEP_HIGH_IDLE();
            }
        } else if (digitalRead(btnDown) == LOW) {
            DIR_REVERSE();
            if ((uint32_t)(nowJog - lastJogUs) >= 800) {
                lastJogUs = nowJog;
                STEP_LOW_ACTIVE();
                delayMicroseconds(5);
                STEP_HIGH_IDLE();
            }
        } else {
            applyMotorDirection();
        }
    }

    // =========================================================================
    // INTERACTIVE OPTOCOUPLER SINKING BENCH TEST (Diagnostics Page 2)
    // =========================================================================
    if (menuState == 9 && infoIndex == 2 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        if (digitalRead(btnUp) == LOW) {
            STEP_LOW_ACTIVE();
            stepPinState = LOW;
        } else {
            STEP_HIGH_IDLE();
            stepPinState = HIGH;
        }
    }

    // Safely return to IDLE when any previous burst has finished
    if (!hwBurstActive && stepsRemaining == 0) {
        if (movementState == STATE_COMPLETE || movementState == STATE_ABORTED) {
            movementState = STATE_IDLE;
        }
    }

    // Onboard PC13 LED at standstill
    const bool isMachineRunning = (currentRPM > 0UL) || hwBurstActive ||
                                  (lastTriggerMicros != 0UL && ((uint32_t)(get_hardware_timestamp_us() - (uint32_t)lastTriggerMicros) < 2000000UL));
    if (!isMachineRunning) {
        if (digitalRead(proxSensorPin) == LOW) {
            STATUS_LED_ON();
        } else {
            STATUS_LED_OFF();
        }
    }

    // RPM Zeroing timeout if machine stops > 2.0s
    static uint32_t lastSeenAcceptedTriggerCount = 0;
    static uint32_t lastTriggerActivityMs = 0;
    const uint32_t currentAcceptedTriggers = acceptedTriggerPulses;
    if (currentAcceptedTriggers != lastSeenAcceptedTriggerCount) {
        lastSeenAcceptedTriggerCount = currentAcceptedTriggers;
        lastTriggerActivityMs = millis();
    }
    if (millis() - lastTriggerActivityMs > 2000UL) {
        if (currentRPM > 0UL) {
            currentRPM = 0UL;
            lastMeasuredIntervalUs = 0UL;
            motionWatchdogArmed = false;
            isMotionSyncLost = false;
        }
        if (hwBurstActive && (TIM1->CR1 & TIM_CR1_CEN) == 0U) {
            hwBurstActive = false;
            stepsRemaining = 0;
            movementState = STATE_IDLE;
        }
    }

    // =========================================================================
    // 2-MINUTE COOLDOWN STANDSTILL AUTO-SAVE ENGINE
    // =========================================================================
    const bool isAnyDirty = (p5_fixed != pulseStepStored_p5) ||
                            (p8_fixed != pulseStepStored_p8) ||
                            (p10_fixed != pulseStepStored_p10) ||
                            pulseModifiedByUser ||
                            hasStagedChanges;
    pulseModifiedByUser = isAnyDirty;
    const bool isRpmFresh = (lastTriggerActivityMs != 0UL) && ((currentRPM > 0UL) || (millis() - lastTriggerActivityMs < 2000UL));
    autoSaveEngine.update(currentRPM, 300UL, isRpmFresh, false, false, (currentRPM == 0UL), isAnyDirty, millis());
    autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

    if (currentRPM == 0UL) {
        if (autoSaveEngine.autoSavePendingStandstill && isMachineSafelyIdle()) {
            if (isAnyDirty) {
                bool saveOk = saveToEEPROM();
                if (saveOk) {
                    stepGearFixed = 1000000ULL;
                    uiBannerLine1 = "AUTO-SAVED OK!  ";
                    uiBannerLine2 = "SETTINGS SAVED  ";
                    autoSaveEngine.clearPendingSave();
                    autoSavePendingStandstill = false;
                } else {
                    uiBannerLine1 = "SAVE FAILED!    ";
                    uiBannerLine2 = "RETRY AT IDLE   ";
                }
                uiMessageTimer = millis() + 1500UL;
                oldMenuState = -1;
            } else {
                autoSaveEngine.clearPendingSave();
                autoSavePendingStandstill = false;
            }
        }
    }

    // Safety Auto-Abort: Return to Main Screen if machine starts running while in any menu
    if (pendingMenuExit) {
        pendingMenuExit = false;
        isEditingSetting = false;
        menuState = 0;
        oldMenuState = -1;
        hasStagedChanges = false;
    }

    // Auto-Relock Timeout after 60s of inactivity on Main Screen
    if (!isUiLocked && menuState == 0) {
        if (millis() - lastUnlockActivity > 60000UL) {
            isUiLocked = true;
            oldMenuState = -1;
        }
    }

    // Safety Inactivity Auto-Exit after 2 minutes (120s) without button presses in Settings
    if (menuState != 0) {
        if (millis() - lastUnlockActivity > 120000UL) {
            hasStagedChanges = false;
            isEditingSetting = false;
            menuState = 0;
            oldMenuState = -1;
            isUiLocked = true;
        }
    }

    // Industrial Edge-Triggered Button States with Hold Auto-Repeat
    static bool upPressedState = false;
    static unsigned long upFirstPressTime = 0UL;
    static unsigned long lastUpRepeatTime = 0UL;

    static bool downPressedState = false;
    static unsigned long downFirstPressTime = 0UL;
    static unsigned long lastDownRepeatTime = 0UL;

    static bool leftPressedState = false;
    static bool rightPressedState = false;
    static bool backPressedState = false;

    // Button Debouncing and Event Processing (3-BTN & 6-BTN Compatible)
    if (millis() - lastButtonCheck > 20UL) {
        lastButtonCheck = millis();
        const bool extraBtnsActive = keypad6ButtonMode;
        const bool leftLow  = extraBtnsActive && (digitalRead(btnLeft) == LOW);
        const bool rightLow = extraBtnsActive && (digitalRead(btnRight) == LOW);
        const bool backLow  = extraBtnsActive && (digitalRead(btnBack) == LOW);

        if (digitalRead(btnUp) == LOW || digitalRead(btnDown) == LOW || digitalRead(btnMode) == LOW ||
            leftLow || rightLow || backLow) {
            lastUnlockActivity = millis();
        }

        // Single Click MODE/SELECT handling on Main Screen:
        // In-place parameter blinking (no pop-up feedback window!)
        if (pendingSingleClick && (millis() - lastModeClickTime > 350UL)) {
            pendingSingleClick = false;
            if (isUiLocked && menuState == 0) {
                blinkTarget  = BLINK_MAIN_LOCK;
                blinkUntilMs = millis() + 1500UL;
            } else if (!isUiLocked && menuState == 0) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (stepGearFixed == 100000ULL) {
                        stepGearFixed = 1000000ULL;
                        currentPulsesFixed = (currentPulsesFixed / 1000000ULL) * 1000000ULL;
                        syncPulseIntegerFraction();
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else if (currentSize == 3) p10_fixed = currentPulsesFixed;
                        updateActivePulseWidth();
                        pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                              (p8_fixed != pulseStepStored_p8) ||
                                              (p10_fixed != pulseStepStored_p10);
                        if (pulseModifiedByUser) {
                            autoSaveEngine.notifyModification(millis());
                        } else {
                            autoSaveEngine.clearPendingSave();
                        }
                        autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;
                        blinkTarget = BLINK_MAIN_GEAR_INT;
                    } else {
                        stepGearFixed = 100000ULL;
                        blinkTarget = BLINK_MAIN_GEAR_DEC;
                    }
                    blinkUntilMs = millis() + 2000UL;
                    lastUnlockActivity = millis();
                }
            }
        }

        // Dual Button Press: Emergency Factory Reset (>10s)
        if (digitalRead(btnUp) == LOW && digitalRead(btnDown) == LOW) {
            if (!upDownPressed) dualPressTime = millis();
            upDownPressed = true;
            if (millis() - dualPressTime > 10000UL && menuState != 3) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    menuState = 3;
                    resetChoice = false;
                    oldMenuState = -1;
                }
            }
        } else {
            upDownPressed = false;
        }

        // =====================================================================
        // 6-BUTTON NAVIGATION: [LEFT], [RIGHT], [BACK] EDGE HANDLERS
        // Active only when keypad6ButtonMode == true (6-BTN Mode)
        // =====================================================================
        bool triggerLeft = false;
        if (leftLow) {
            if (!leftPressedState) {
                leftPressedState = true;
                triggerLeft = true;
            }
        } else {
            leftPressedState = false;
        }

        bool triggerRight = false;
        if (rightLow) {
            if (!rightPressedState) {
                rightPressedState = true;
                triggerRight = true;
            }
        } else {
            rightPressedState = false;
        }

        bool triggerBack = false;
        if (backLow) {
            if (!backPressedState) {
                backPressedState = true;
                triggerBack = true;
            }
        } else {
            backPressedState = false;
        }

        if (triggerLeft) {
            if (menuState == 0) {
                if (isUiLocked) {
                    blinkTarget  = BLINK_MAIN_LOCK;
                    blinkUntilMs = millis() + 1500UL;
                } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    // [LEFT] selects 0.10 Fine Gear with in-place decimal blink
                    stepGearFixed = 100000ULL;
                    blinkTarget   = BLINK_MAIN_GEAR_DEC;
                    blinkUntilMs  = millis() + 2000UL;
                }
            } else if (menuState == 1) {
                if (isEditingSetting) {
                    if (hiddenOption == 1) {
                        if (resStepGear == 1000) resStepGear = 500;
                        else if (resStepGear == 500) resStepGear = 200;
                        else if (resStepGear == 200) resStepGear = 100;
                        else resStepGear = 1000;
                    } else if (hiddenOption == 2) {
                        diaStepGear = 0.1f;
                    } else if (hiddenOption == 6) {
                        tempMotorDir = false; // NORMAL [FW]
                        hasStagedChanges = true;
                    } else if (hiddenOption == 7) {
                        tempKeypad6Btn = false; // 3-BTN
                        hasStagedChanges = true;
                    }
                } else {
                    hiddenOption--;
                    if (hiddenOption < 1) hiddenOption = 9;
                }
            } else if (menuState == 13) {
                saveExitChoice = true; // [LEFT] -> >YES
            } else if (menuState == 3) {
                resetChoice = true;    // [LEFT] -> >YES
            } else if (menuState == 9) {
                infoIndex--;
                if (infoIndex < 1) infoIndex = 9;
            } else if (menuState == 21) {
                helpIndex--;
                if (helpIndex < 1) helpIndex = 5;
            }
        }

        if (triggerRight) {
            if (menuState == 0) {
                if (isUiLocked) {
                    blinkTarget  = BLINK_MAIN_LOCK;
                    blinkUntilMs = millis() + 1500UL;
                } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    // [RIGHT] selects 1.00 Normal Gear (snaps decimal to .00) with in-place integer blink
                    stepGearFixed = 1000000ULL;
                    currentPulsesFixed = (currentPulsesFixed / 1000000ULL) * 1000000ULL;
                    syncPulseIntegerFraction();
                    if (currentSize == 1) p5_fixed = currentPulsesFixed;
                    else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                    else if (currentSize == 3) p10_fixed = currentPulsesFixed;
                    updateActivePulseWidth();
                    pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                          (p8_fixed != pulseStepStored_p8) ||
                                          (p10_fixed != pulseStepStored_p10);
                    if (pulseModifiedByUser) {
                        autoSaveEngine.notifyModification(millis());
                    } else {
                        autoSaveEngine.clearPendingSave();
                    }
                    autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;
                    blinkTarget  = BLINK_MAIN_GEAR_INT;
                    blinkUntilMs = millis() + 2000UL;
                }
            } else if (menuState == 1) {
                if (isEditingSetting) {
                    if (hiddenOption == 1) {
                        if (resStepGear == 100) resStepGear = 200;
                        else if (resStepGear == 200) resStepGear = 500;
                        else if (resStepGear == 500) resStepGear = 1000;
                        else resStepGear = 100;
                    } else if (hiddenOption == 2) {
                        diaStepGear = 1.0f;
                    } else if (hiddenOption == 6) {
                        tempMotorDir = true; // REVERSE [RV]
                        hasStagedChanges = true;
                    } else if (hiddenOption == 7) {
                        tempKeypad6Btn = true; // 6-BTN
                        hasStagedChanges = true;
                    }
                } else {
                    hiddenOption++;
                    if (hiddenOption > 9) hiddenOption = 1;
                }
            } else if (menuState == 13) {
                saveExitChoice = false; // [RIGHT] -> >NO
            } else if (menuState == 3) {
                resetChoice = false;    // [RIGHT] -> >NO
            } else if (menuState == 9) {
                infoIndex++;
                if (infoIndex > 9) infoIndex = 1;
            } else if (menuState == 21) {
                helpIndex++;
                if (helpIndex > 5) helpIndex = 1;
            }
        }

        if (triggerBack) {
            if (menuState == 0) {
                uiBannerLine1 = nullptr;
                uiBannerLine2 = nullptr;
                blinkTarget   = BLINK_NONE;
            } else if (menuState == 1) {
                if (isEditingSetting) {
                    // Stop in-place value blinking and return to Settings list navigation
                    isEditingSetting = false;
                } else if (hasStagedChanges) {
                    // Smart [BACK] Confirmation: parameter was changed -> open SAVE CHANGES? (>YES / NO)
                    saveExitChoice = true;
                    menuState = 13;
                    oldMenuState = -1;
                } else {
                    // Nothing changed -> exit directly to Main Screen
                    menuState = 0;
                    oldMenuState = -1;
                    isUiLocked = true;
                }
            } else if (menuState == 2 || menuState == 4 || menuState == 5 || menuState == 6 || menuState == 8 || menuState == 16) {
                isEditingSetting = false;
                menuState = 1;
                oldMenuState = -1;
            } else if (menuState == 9) {
                menuState = 1;
                oldMenuState = -1;
            } else if (menuState == 21) {
                menuState = 9;
                infoIndex = 8;
                oldMenuState = -1;
            } else if (menuState == 13) {
                // [BACK] inside SAVE CHANGES? dialog returns to Settings Menu list to continue editing
                menuState = 1;
                oldMenuState = -1;
            } else if (menuState == 3) {
                menuState = 0;
                oldMenuState = -1;
            }
        }

        // MODE / SELECT Button State Machine
        if (digitalRead(btnMode) == LOW) {
            if (!modePressed) modePressTime = millis();
            modePressed = true;

            if (menuState == 0) {
                unsigned long currentHold = millis() - modePressTime;
                if (isUiLocked) {
                    if (currentHold >= 1000UL) {
                        blinkTarget  = BLINK_MAIN_LOCK;
                        blinkUntilMs = millis() + 1000UL;
                    }
                } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (currentHold >= 1500UL && currentHold < 5000UL) {
                        int secLeft = (int)((5000UL - currentHold + 999UL) / 1000UL);
                        static char holdCountdown[24];
                        snprintf(holdCountdown, sizeof(holdCountdown), "HOLD MENU: %ds   ", secLeft);
                        uiBannerLine1 = "SIZE CHG ARMED  ";
                        uiBannerLine2 = holdCountdown;
                        uiMessageTimer = millis() + 250UL;
                    } else if (currentHold >= 5000UL) {
                        uiBannerLine1 = "RELEASE FOR:    ";
                        uiBannerLine2 = ">>SETTINGS MENU<";
                        uiMessageTimer = millis() + 250UL;
                    }
                }
            }
        } else if (modePressed) {
            unsigned long holdTime = millis() - modePressTime;
            modePressed = false;

            if (menuState == 0) {
                if (holdTime < 350UL) {
                    if (pendingSingleClick && (millis() - lastModeClickTime < 350UL)) {
                        pendingSingleClick = false;
                        isUiLocked = !isUiLocked;
                        lastUnlockActivity = millis();
                        blinkTarget  = BLINK_MAIN_LOCK;
                        blinkUntilMs = millis() + 1500UL;
                        lastModeClickTime = 0UL;
                    } else {
                        lastModeClickTime = millis();
                        if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                            pendingSingleClick = true;
                        } else {
                            pendingSingleClick = false;
                        }
                    }
                } else if (holdTime >= 1500UL && holdTime < 5000UL && !isUiLocked) {
                    // 1.5-5 Second Hold: Zipper Size Sequence Switch (#5 -> #8 -> #10 -> #5)
                    // In-place S:x blinking on Main Screen (no pop-up banner!)
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uiBannerLine1 = nullptr;
                        uiBannerLine2 = nullptr;
                        currentSize++;
                        if (currentSize > 3) currentSize = 1;
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentSize == 1) currentPulsesFixed = p5_fixed;
                        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                        else currentPulsesFixed = p10_fixed;
                        __set_PRIMASK(primask);
                        updateActivePulseWidth();
                        bool saveOk = saveToEEPROM();
                        if (!saveOk) {
                            autoSavePendingStandstill = true;
                        }
                        lastUnlockActivity = millis();
                        blinkTarget  = BLINK_MAIN_SIZE;
                        blinkUntilMs = millis() + 2000UL;
                        oldMenuState = -1;
                    }
                } else if (holdTime >= 5000UL && !isUiLocked) {
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uiBannerLine1       = nullptr;
                        uiBannerLine2       = nullptr;
                        tempDriverRes       = driverResolution;
                        tempRollerDia       = rollerDia;
                        tempMaxRPM          = maxRPMSetting;
                        tempFeedAngle       = feedAngleDeg;
                        tempSafetyMargin    = safetyMarginPercent;
                        tempMotorDir        = motorDirection;
                        tempKeypad6Btn      = keypad6ButtonMode;
                        resStepGear         = 100;
                        diaStepGear         = 0.1f;
                        rpmStepGear         = 50;
                        angleStepGear       = 1;
                        marginStepGear      = 1;
                        hasStagedChanges    = false;
                        isEditingSetting    = false;
                        menuState           = 1;
                        hiddenOption        = 1;
                        oldMenuState        = -1;
                    }
                }
            } else if (menuState == 1) {
                if (isEditingSetting) {
                    // Currently editing Option 1..7 in-place (value blinking):
                    if ((hiddenOption == 1 || hiddenOption == 2) && !keypad6ButtonMode) {
                        // In 3-BTN mode on multi-gear options (Driver Res & Roller Dia):
                        // Hold >= 800ms stops editing; short click cycles step gear
                        if (holdTime >= 800UL) {
                            isEditingSetting = false;
                        } else if (hiddenOption == 1) {
                            if (resStepGear == 100) resStepGear = 200;
                            else if (resStepGear == 200) resStepGear = 500;
                            else if (resStepGear == 500) resStepGear = 1000;
                            else resStepGear = 100;
                        } else {
                            diaStepGear = (diaStepGear < 0.5f) ? 1.0f : 0.1f;
                        }
                    } else {
                        // Single-click confirms in-place edit and stops value blinking
                        isEditingSetting = false;
                    }
                } else {
                    // Not currently editing a field:
                    // Hold MODE (>= 1500ms) acts as Back from Settings Menu list!
                    if (holdTime >= 1500UL) {
                        if (hasStagedChanges) {
                            saveExitChoice = true;
                            menuState = 13; // Smart Confirmation Dialog when parameters were modified!
                            oldMenuState = -1;
                        } else {
                            menuState = 0;
                            oldMenuState = -1;
                            isUiLocked = true;
                        }
                        return;
                    }
                    // Short Click on Settings Menu list (9 Options):
                    if (hiddenOption >= 1 && hiddenOption <= 7) {
                        // Enter In-Place Blinking Edit Mode right on the Settings screen!
                        isEditingSetting = true;
                    } else if (hiddenOption == 8) {
                        evaluateDiagnostics();
                        infoIndex = 1;
                        menuState = 9;  // 8. Info Diag (9 Pages)
                        oldMenuState = -1;
                    } else if (hiddenOption == 9) {
                        saveExitChoice = true;
                        menuState = 13; // 9. Save & Exit Confirmation Dialog
                        oldMenuState = -1;
                    }
                }
            } else if (menuState == 9) {
                if (infoIndex == 8) {
                    helpIndex = 1;
                    menuState = 21; // Open HELP Sub-Branch
                    oldMenuState = -1;
                } else {
                    menuState = 1;  // Return to Settings List
                    oldMenuState = -1;
                }
            } else if (menuState == 21) {
                menuState = 9;
                infoIndex = 8;
                oldMenuState = -1;
            } else if (menuState == 13) {
                // Execute Save & Exit Dialog decision
                if (saveExitChoice) {
                    if (!stagedTimingConfigurationFeasible()) {
                        uiBannerLine1 = "TIMING INVALID! ";
                        uiBannerLine2 = "LOWER RPM/RES  ";
                        uiMessageTimer = millis() + 1600UL;
                        menuState = 1;
                        oldMenuState = -1;
                    } else {
                        const bool geometryChanged = (driverResolution != tempDriverRes) ||
                                                     (fabsf(rollerDia - tempRollerDia) > 0.001f);
                        driverResolution    = tempDriverRes;
                        rollerDia           = tempRollerDia;
                        maxRPMSetting       = tempMaxRPM;
                        feedAngleDeg        = tempFeedAngle;
                        safetyMarginPercent = tempSafetyMargin;
                        motorDirection      = tempMotorDir;
                        keypad6ButtonMode   = tempKeypad6Btn;
                        applyMotorDirection();
                        if (geometryChanged) {
                            recalculatePitchProfiles();
                            uint32_t primask = __get_PRIMASK();
                            __disable_irq();
                            if (currentSize == 1) currentPulsesFixed = p5_fixed;
                            else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                            else currentPulsesFixed = p10_fixed;
                            __set_PRIMASK(primask);
                        }
                        calculateAllPulseWidths();
                        refreshPulseTimingValidity();
                        hasStagedChanges = false;
                        isEditingSetting = false;
                        menuState = 0;
                        oldMenuState = -1;
                        isUiLocked = true;
                        if (isMachineSafelyIdle() && currentRPM == 0UL) {
                            bool saveOk = saveToEEPROM();
                            if (saveOk) {
                                autoSavePendingStandstill = false;
                                autoSaveEngine.clearPendingSave();
                                pulseModifiedByUser = false;
                                hasStagedChanges = false;
                                stepGearFixed = 1000000ULL;
                                uiBannerLine1 = "SETTINGS SAVED  ";
                                uiBannerLine2 = "DIRECT SAVE OK  ";
                            } else {
                                uiBannerLine1 = "SAVE FAILED!    ";
                                uiBannerLine2 = "RETRY AT 0 RPM  ";
                            }
                        } else {
                            uiBannerLine1 = "SAVE BLOCKED!   ";
                            uiBannerLine2 = "STOP MACHINE 1ST";
                        }
                        uiMessageTimer = millis() + 1500UL;
                    }
                } else {
                    // NO: Discard Changes & Exit
                    hasStagedChanges = false;
                    isEditingSetting = false;
                    menuState = 0;
                    oldMenuState = -1;
                    isUiLocked = true;
                }
            } else if (menuState == 3) {
                if (resetChoice) {
                    loadFactoryDefaults();
                    saveToEEPROM();
                    uiBannerLine1 = "FACTORY RESET OK";
                    uiBannerLine2 = "DEFAULTS LOADED ";
                    uiMessageTimer = millis() + 1500UL;
                }
                menuState = 0;
                oldMenuState = -1;
            }
        }

        // UP Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool upRaw = (digitalRead(btnUp) == LOW);
        bool triggerUpStep = false;
        if (upRaw && !upDownPressed) {
            if (!upPressedState) {
                upPressedState = true;
                upFirstPressTime = millis();
                lastUpRepeatTime = millis();
                triggerUpStep = true;
            } else if (millis() - upFirstPressTime >= 600UL) {
                if (millis() - lastUpRepeatTime >= 200UL) {
                    lastUpRepeatTime = millis();
                    triggerUpStep = true;
                }
            }
        } else {
            upPressedState = false;
        }

        if (triggerUpStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        blinkTarget  = BLINK_MAIN_LOCK;
                        blinkUntilMs = millis() + 1500UL;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint64_t proposedPulses = currentPulsesFixed + stepGearFixed;
                        uint64_t oldPulses = currentPulsesFixed;
                        currentPulsesFixed = proposedPulses;
                        refreshPulseTimingValidity();
                        currentPulsesFixed = oldPulses;
                        if (pulseTimingInvalid) {
                            refreshPulseTimingValidity();
                            uiBannerLine1 = "TIMING INVALID! ";
                            uiBannerLine2 = "LOWER PULSE/RES";
                            uiMessageTimer = millis() + 1500UL;
                            oldMenuState = -1;
                            break;
                        }
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        currentPulsesFixed = proposedPulses;
                        if (currentPulsesFixed > PULSE_STEP_MAX_FIXED) currentPulsesFixed = PULSE_STEP_MAX_FIXED;
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                              (p8_fixed != pulseStepStored_p8) ||
                                              (p10_fixed != pulseStepStored_p10);
                        smoothRunStartMillis = 0UL;
                        if (pulseModifiedByUser) {
                            autoSaveEngine.notifyModification(millis());
                        } else {
                            autoSaveEngine.clearPendingSave();
                        }
                        autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

                        // In-Place Pulse Blinking on Main Screen (No pop-up feedback window!)
                        blinkTarget  = BLINK_MAIN_PULSE;
                        blinkUntilMs = millis() + 2000UL;
                    }
                    break;

                case 1:
                    if (!isEditingSetting) {
                        hiddenOption--;
                        if (hiddenOption < 1) hiddenOption = 9;
                    } else {
                        if (hiddenOption == 1) {
                            tempDriverRes += resStepGear;
                            if (tempDriverRes > 51200) tempDriverRes = 51200;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 2) {
                            tempRollerDia += diaStepGear;
                            if (tempRollerDia > 100.0f) tempRollerDia = 100.0f;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 3) {
                            tempMaxRPM += rpmStepGear;
                            if (tempMaxRPM > 4000) tempMaxRPM = 4000;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 4) {
                            tempFeedAngle += angleStepGear;
                            if (tempFeedAngle > 270) tempFeedAngle = 270;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 5) {
                            tempSafetyMargin += marginStepGear;
                            if (tempSafetyMargin > 25) tempSafetyMargin = 25;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 6) {
                            tempMotorDir = !tempMotorDir;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 7) {
                            tempKeypad6Btn = !tempKeypad6Btn;
                            hasStagedChanges = true;
                        }
                    }
                    break;

                case 3:  resetChoice = !resetChoice; break;
                case 13: saveExitChoice = !saveExitChoice; break;
                case 21:
                    helpIndex--;
                    if (helpIndex < 1) helpIndex = 5;
                    break;
                case 9:
                    if (infoIndex != 1 && infoIndex != 2) {
                        infoIndex--;
                        if (infoIndex < 1) infoIndex = 9;
                    }
                    break;
            }
            upPressTime = millis();
        }

        // DOWN Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool downRaw = (digitalRead(btnDown) == LOW);
        bool triggerDownStep = false;
        if (downRaw && !upDownPressed) {
            if (!downPressedState) {
                downPressedState = true;
                downFirstPressTime = millis();
                lastDownRepeatTime = millis();
                triggerDownStep = true;
            } else if (millis() - downFirstPressTime >= 600UL) {
                if (millis() - lastDownRepeatTime >= 200UL) {
                    lastDownRepeatTime = millis();
                    triggerDownStep = true;
                }
            }
        } else {
            downPressedState = false;
        }

        if (triggerDownStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        blinkTarget  = BLINK_MAIN_LOCK;
                        blinkUntilMs = millis() + 1500UL;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentPulsesFixed > stepGearFixed + PULSE_STEP_MIN_FIXED) {
                            currentPulsesFixed -= stepGearFixed;
                        } else {
                            currentPulsesFixed = PULSE_STEP_MIN_FIXED;
                        }
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                              (p8_fixed != pulseStepStored_p8) ||
                                              (p10_fixed != pulseStepStored_p10);
                        smoothRunStartMillis = 0UL;
                        if (pulseModifiedByUser) {
                            autoSaveEngine.notifyModification(millis());
                        } else {
                            autoSaveEngine.clearPendingSave();
                        }
                        autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

                        // In-Place Pulse Blinking on Main Screen (No pop-up feedback window!)
                        blinkTarget  = BLINK_MAIN_PULSE;
                        blinkUntilMs = millis() + 2000UL;
                    }
                    break;

                case 1:
                    if (!isEditingSetting) {
                        hiddenOption++;
                        if (hiddenOption > 9) hiddenOption = 1;
                    } else {
                        if (hiddenOption == 1) {
                            if (tempDriverRes > resStepGear + 200) tempDriverRes -= resStepGear;
                            else tempDriverRes = 200;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 2) {
                            // Minimum Roller Diameter limit updated to 10.0 mm
                            if (tempRollerDia > diaStepGear + 10.0f) tempRollerDia -= diaStepGear;
                            else tempRollerDia = 10.0f;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 3) {
                            if (tempMaxRPM > rpmStepGear + 100) tempMaxRPM -= rpmStepGear;
                            else tempMaxRPM = 100;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 4) {
                            if (tempFeedAngle > angleStepGear + 30) tempFeedAngle -= angleStepGear;
                            else tempFeedAngle = 30;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 5) {
                            if (tempSafetyMargin >= marginStepGear) tempSafetyMargin -= marginStepGear;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 6) {
                            tempMotorDir = !tempMotorDir;
                            hasStagedChanges = true;
                        } else if (hiddenOption == 7) {
                            tempKeypad6Btn = !tempKeypad6Btn;
                            hasStagedChanges = true;
                        }
                    }
                    break;

                case 3:  resetChoice = !resetChoice; break;
                case 13: saveExitChoice = !saveExitChoice; break;
                case 21:
                    helpIndex++;
                    if (helpIndex > 5) helpIndex = 1;
                    break;
                case 9:
                    if (infoIndex != 1) {
                        infoIndex++;
                        if (infoIndex > 9) infoIndex = 1;
                    }
                    break;
            }
            downPressTime = millis();
        }

        if (digitalRead(btnUp) == HIGH && digitalRead(btnDown) == HIGH) {
            upDownPressed = false;
        }
    }

    // 16x2 Character LCD Screen Renderer (Anti-Blanking & Anti-Flicker Direct Overwrite)
    if (uiBannerLine1 != nullptr) {
        if (millis() < uiMessageTimer) {
            char b1[17], b2[17];
            snprintf(b1, sizeof(b1), "%-16s", uiBannerLine1);
            snprintf(b2, sizeof(b2), "%-16s", uiBannerLine2 ? uiBannerLine2 : "");
            lcd.setCursor(0, 0); lcd.print(b1);
            lcd.setCursor(0, 1); lcd.print(b2);
            oldMenuState = -2;
            return;
        } else {
            uiBannerLine1 = nullptr;
            uiBannerLine2 = nullptr;
            oldMenuState = -1;
            lcd.clear();
        }
    }

    // Running-state RPM refresh (gated by !hwBurstActive so I2C writes occur only between STEP bursts)
    if (menuState == 0 && oldMenuState == menuState && !hwBurstActive) {
        if (millis() - lastRpmDisplayUpdate > 250UL) {
            lastRpmDisplayUpdate = millis();
            char rpmBuf[16];
            unsigned int dispRpm = (currentRPM > 9999UL) ? 9999U : (unsigned int)currentRPM;
            snprintf(rpmBuf, sizeof(rpmBuf), "%04u", dispRpm);
            lcd.setCursor(5, 0);
            lcd.print(rpmBuf);
        }
    }

    if (millis() >= blinkUntilMs && blinkTarget != BLINK_NONE) {
        blinkTarget = BLINK_NONE;
    }
    const bool blinkHide = ((millis() / 250UL) % 2UL) == 1UL;

    if ((currentRPM == 0UL || menuState != oldMenuState || menuState == 9) && millis() - lastDisplayUpdate > 125UL) {
        if (menuState != oldMenuState) {
            lcd.clear();
            oldMenuState = menuState;
        }

        char l1[24] = "                ";
        char l2[24] = "                ";
        switch (menuState) {
            case 0: // Normal Operational Screen with In-Place Blinking
            {
                int szNum = (currentSize == 1) ? 5 : ((currentSize == 2) ? 8 : 10);
                const double feedMm = ((double)currentPulsesFixed / 1000000.0) *
                    (3.14159265358979323846 * (double)rollerDia) / (double)driverResolution;
                unsigned long feedHundredths = (feedMm > 0.0) ? (unsigned long)(feedMm * 100.0 + 0.5) : 0UL;
                if (feedHundredths > 9999UL) feedHundredths = 9999UL;
                const int actInt = (int)(feedHundredths / 100UL);
                const int actFrac = (int)(feedHundredths % 100UL);
                char feedStr[8];
                snprintf(feedStr, sizeof(feedStr), "%d.%02d", actInt, actFrac);
                unsigned int dispRpm = constrain((unsigned int)currentRPM, 0U, 9999U);

                if (blinkTarget == BLINK_MAIN_SIZE && blinkHide) {
                    snprintf(l1, sizeof(l1), "S:   %04u F:%s", dispRpm, feedStr);
                } else {
                    snprintf(l1, sizeof(l1), "S:%-2d %04u F:%s", szNum, dispRpm, feedStr);
                }

                char cue = (activePulseWidth <= 2) ? '*' : ((activePulseWidth < 6) ? '#' : 'H');
                int pInt = (int)(currentPulsesFixed / 1000000ULL);
                int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                const char* lockStr = (blinkTarget == BLINK_MAIN_LOCK && blinkHide)
                    ? "   " : (isUiLocked ? "[L]" : "[U]");

                char pulseField[10];
                if (blinkTarget == BLINK_MAIN_PULSE && blinkHide) {
                    snprintf(pulseField, sizeof(pulseField), (pInt < 100) ? "    " : "     ");
                } else if (blinkTarget == BLINK_MAIN_GEAR_INT && blinkHide) {
                    snprintf(pulseField, sizeof(pulseField), (pInt < 100) ? "  .%01d" : "   .%01d", pFrac);
                } else if (blinkTarget == BLINK_MAIN_GEAR_DEC && blinkHide) {
                    snprintf(pulseField, sizeof(pulseField), "%d. ", pInt);
                } else {
                    snprintf(pulseField, sizeof(pulseField), "%d.%01d", pInt, pFrac);
                }

                if (pInt < 100 && activePulseWidth < 100) {
                    snprintf(l2, sizeof(l2), "P:%s W:%d %c%s",
                             pulseField, activePulseWidth, cue, lockStr);
                } else {
                    snprintf(l2, sizeof(l2), "P:%s W:%d%c%s",
                             pulseField, activePulseWidth, cue, lockStr);
                }
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
            }
            break;

            case 1: // Clean 9-Option Settings Menu with In-Place Value Blinking
            {
                if (hiddenOption == 1)      snprintf(l1, sizeof(l1), "1. Driver Res   ");
                else if (hiddenOption == 2) snprintf(l1, sizeof(l1), "2. Roller Dia   ");
                else if (hiddenOption == 3) snprintf(l1, sizeof(l1), "3. Max RPM      ");
                else if (hiddenOption == 4) snprintf(l1, sizeof(l1), "4. Feed Angle   ");
                else if (hiddenOption == 5) snprintf(l1, sizeof(l1), "5. Safety Margin");
                else if (hiddenOption == 6) snprintf(l1, sizeof(l1), "6. Motor Dir    ");
                else if (hiddenOption == 7) snprintf(l1, sizeof(l1), "7. Keypad Mode  ");
                else if (hiddenOption == 8) snprintf(l1, sizeof(l1), "8. Info Diag    ");
                else if (hiddenOption == 9) snprintf(l1, sizeof(l1), "9. Save & Exit  ");

                const bool hideVal = isEditingSetting && blinkHide;

                if (hiddenOption == 1) {
                    if (isEditingSetting) {
                        if (hideVal) snprintf(l2, sizeof(l2), "Val:       S:%-4d", (int)resStepGear);
                        else         snprintf(l2, sizeof(l2), "Val:%-5d S:%-4d", (int)tempDriverRes, (int)resStepGear);
                    } else {
                        snprintf(l2, sizeof(l2), "Val: %-5d steps", (int)tempDriverRes);
                    }
                } else if (hiddenOption == 2) {
                    int dInt = (int)tempRollerDia;
                    int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
                    if (isEditingSetting) {
                        int gInt = (int)diaStepGear;
                        int gFrac = (int)((diaStepGear - (float)gInt) * 10.0f + 0.5f);
                        if (hideVal) snprintf(l2, sizeof(l2), "Val:     mm S:%d.%1d", gInt, gFrac);
                        else         snprintf(l2, sizeof(l2), "Val:%2d.%1dmm S:%d.%1d", dInt, dFrac, gInt, gFrac);
                    } else {
                        snprintf(l2, sizeof(l2), "Val: %2d.%1d mm   ", dInt, dFrac);
                    }
                } else if (hiddenOption == 3) {
                    if (hideVal) snprintf(l2, sizeof(l2), "Val:      RPM   ");
                    else         snprintf(l2, sizeof(l2), "Val: %-4d RPM   ", (int)tempMaxRPM);
                } else if (hiddenOption == 4) {
                    if (hideVal) snprintf(l2, sizeof(l2), "Val:     deg    ");
                    else         snprintf(l2, sizeof(l2), "Val: %-3d deg    ", (int)tempFeedAngle);
                } else if (hiddenOption == 5) {
                    if (hideVal) snprintf(l2, sizeof(l2), "Val:    %%       ");
                    else         snprintf(l2, sizeof(l2), "Val: %-2d%%        ", (int)tempSafetyMargin);
                } else if (hiddenOption == 6) {
                    if (hideVal) snprintf(l2, sizeof(l2), "Dir:            ");
                    else         snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: REVERSE[RV]" : "Dir: NORMAL [FW]");
                } else if (hiddenOption == 7) {
                    if (hideVal) snprintf(l2, sizeof(l2), "Mode:           ");
                    else         snprintf(l2, sizeof(l2), tempKeypad6Btn ? "Mode: 6-BTN [6K]" : "Mode: 3-BTN [3K]");
                } else if (hiddenOption == 8) {
                    snprintf(l2, sizeof(l2), "Open Diagnostics");
                } else if (hiddenOption == 9) {
                    snprintf(l2, sizeof(l2), "Select Save/Exit");
                }

                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
            }
            break;

            case 13: // Save & Exit Confirmation Dialog with In-Place Blinking
                snprintf(l1, sizeof(l1), "SAVE CHANGES?   ");
                if (saveExitChoice) {
                    snprintf(l2, sizeof(l2), blinkHide ? "       NO       " : ">YES   NO       ");
                } else {
                    snprintf(l2, sizeof(l2), blinkHide ? " YES            " : " YES  >NO       ");
                }
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 3: // Emergency Factory Reset with In-Place Blinking
                lcdPrint16(0, "Factory Reset?  ");
                if (resetChoice) {
                    lcdPrint16(1, blinkHide ? "      NO        " : ">YES  NO        ");
                } else {
                    lcdPrint16(1, blinkHide ? " YES            " : " YES >NO        ");
                }
                break;

            case 9: // Info / Diag: 9 Pages
            {
                int cycle = (millis() / 1500UL) % 2;
                char dl1[24] = "                ";
                char dl2[24] = "                ";
                switch (infoIndex) {
                    case 1:
                        snprintf(dl1, sizeof(dl1), "STEPPER JOG TST ");
                        if (currentRPM != 0UL || hwBurstActive || stepsRemaining != 0) {
                            snprintf(dl2, sizeof(dl2), "BLOCKED: RUNNING");
                        } else {
                            if (digitalRead(btnUp) == LOW) snprintf(dl2, sizeof(dl2), "JOG FWD >>> [UP]");
                            else if (digitalRead(btnDown) == LOW) snprintf(dl2, sizeof(dl2), "JOG REV <<< [DN]");
                            else snprintf(dl2, sizeof(dl2), "UP:FWD   DN:REV ");
                        }
                        break;
                    case 2:
                        snprintf(dl1, sizeof(dl1), "OPTO SINK TST   ");
                        if (currentRPM != 0UL || hwBurstActive || stepsRemaining != 0) {
                            snprintf(dl2, sizeof(dl2), "BLOCKED: RUNNING");
                        } else {
                            snprintf(dl2, sizeof(dl2), digitalRead(btnUp) == LOW ? "V<=0.5V SINK ON " : "HOLD [UP] TEST  ");
                        }
                        break;
                    case 3:
                        snprintf(dl1, sizeof(dl1), "PROX HEALTH     ");
                        if (lastMeasuredIntervalUs > 0UL) {
                            unsigned long dispRpm = (currentRPM <= 9999UL) ? currentRPM : 9999UL;
                            snprintf(dl2, sizeof(dl2), "P:%-6lu R:%-4lu", (unsigned long)lastMeasuredIntervalUs, dispRpm);
                        } else {
                            snprintf(dl2, sizeof(dl2), "P:WAIT  RPM: 0  ");
                        }
                        break;
                    case 4:
                        snprintf(dl1, sizeof(dl1), "SYNC HEALTH     ");
                        if (servoPhaseLocked) {
                            snprintf(dl2, sizeof(dl2), "LOCK J:%-6luus", (unsigned long)servoMaxJitterUs);
                        } else {
                            snprintf(dl2, sizeof(dl2), "ACQUIRING...    ");
                        }
                        break;
                    case 5:
                        snprintf(dl1, sizeof(dl1), "STEP TIMING FILT");
                        snprintf(dl2, sizeof(dl2), "T:%-5lu O:%-2lu R:%-2lu", (unsigned long)(validTriggerCount % 100000UL), (unsigned long)(tim2CaptureOverrunCount % 100UL), (unsigned long)(rejectedTriggerCount % 100UL));
                        break;
                    case 6:
                        snprintf(dl1, sizeof(dl1), "STEP ENGINE STAT");
                        snprintf(dl2, sizeof(dl2), "TIM1:%s KEY:%s", hwBurstActive ? "RUN " : "IDLE", keypad6ButtonMode ? "6B" : "3B");
                        break;
                    case 7:
                        evaluateDiagnostics();
                        snprintf(dl1, sizeof(dl1), "%-16s", diagFixLine1 ? diagFixLine1 : "TIMING HEALTH:  ");
                        snprintf(dl2, sizeof(dl2), "%-16s", diagFixLine2 ? diagFixLine2 : "SYSTEM OPTIMAL  ");
                        break;
                    case 8:
                        snprintf(dl1, sizeof(dl1), "HELP & TROUBLE? ");
                        snprintf(dl2, sizeof(dl2), "[MODE] OPEN HELP");
                        break;
                    case 9:
                        snprintf(dl1, sizeof(dl1), "V17.0.0 (NIPON) ");
                        if (cycle == 0) snprintf(dl2, sizeof(dl2), "DEV: RAJESH SHAH");
                        else snprintf(dl2, sizeof(dl2), "BLD: %-11s", FW_BUILD_DATE_STR);
                        break;
                    default:
                        infoIndex = 1;
                        break;
                }
                lcdPrint16(0, dl1);
                lcdPrint16(1, dl2);
            }
            break;

            case 21: // HELP Sub-Branch (5 Diagnostic Troubleshooting Guides)
            {
                int cycle = (millis() / 1500UL) % 2;
                char hl1[17] = "                ";
                char hl2[17] = "                ";
                switch (helpIndex) {
                    case 1:
                        snprintf(hl1, sizeof(hl1), "1. MOTOR STALL? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: INC ANGLE  " : "OR DEC RES/RPM  ");
                        break;
                    case 2:
                        snprintf(hl1, sizeof(hl1), "2. PITCH ERROR? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: TUNE DIA MM" : "OR GEAR +/- PUL ");
                        break;
                    case 3:
                        snprintf(hl1, sizeof(hl1), "3. SENSOR NOISE?");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: CLEAN CAM  " : "CHECK PC817 GND ");
                        break;
                    case 4:
                        snprintf(hl1, sizeof(hl1), "4. MOTOR HOT?   ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: SW4=HALF   " : "CURR 2.8A-3.0A  ");
                        break;
                    case 5:
                        snprintf(hl1, sizeof(hl1), "5. TEETH DRIFT? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: TIGHT TAPE " : "CHK ROLLER GRIP ");
                        break;
                    default:
                        helpIndex = 1;
                        break;
                }
                lcdPrint16(0, hl1);
                lcdPrint16(1, hl2);
            }
            break;
        }
        lastDisplayUpdate = millis();
    }
}
