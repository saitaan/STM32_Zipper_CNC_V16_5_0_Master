#include <cmath>
/*
====================================================================================================
PROJECT  : STM32 ZIPPER CNC (ADAPTIVE SERVO-SYNC MASTER-FOLLOWER ENGINE)
VERSION  : 17.0.0 (PA0 TIM2 CAPTURE -> PA8 TIM1 STEP / TIMING GUARD)
AUTHOR   : RAJESH SHAH / INDUSTRIAL AUTOMATION & EMBEDDED SYSTEMS
DATE     : SEPTEMBER 2026
TARGET   : STM32F103C8T6 (32-BIT ARM CORTEX-M3 @ 72MHz)
LOCATION : NIPON ZIPPER INDUSTRIES PVT LTD, SARIGAM GIDC, GUJARAT, INDIA

VERSION 16.5.0 ARCHITECTURAL ADVANCEMENTS & HARDWARE-LEVEL ENGINE:
1. PRIMARY PROXIMITY->STEP HARDWARE PATH:
   - PA0 is the master proximity input; PA8 is the hardware-timed STEP output.
   - TIM1 hardware generation is the production/default engine; DDA is restored as an operator-selectable diagnostic/alternate engine for timing comparison.
   - First PA0 edge is accepted immediately; the first measured interval establishes real servo synchronization and arms Motion Lost monitoring.
2. OPTIONAL AUXILIARY SENSOR / RELAY SUBSYSTEM:
   - PA3: optional Tape Run-Out sensor.
   - PB0: optional future Coil/Thread sensor.
   - PB3: optional Safety Guard input.
   - PB1: optional Motor Stop Relay.
   - All auxiliary features are OFF by default and have no authority over PA0 capture or PA8 STEP timing.
   - A qualified enabled sensor may request PB1; it never aborts the current STEP burst.
   - Motion Lost may request PB1 only after a real measured PA0 interval has armed the watchdog.
3. BOOTUP HARDWARE RELAY GLITCH SUPPRESSION:
   - Atomic GPIOB->BRR clear on PB1 before setting pinMode to eliminate contact chatter on reset.
4. BACKWARDS-COMPATIBLE THREE-TIER EEPROM MIGRATION:
   - Automatically migrates existing V16.3.3 (0x5A431633) and V16.4.0 (0x5A431640) calibration parameters
     into V16.5.0 (0x5A431650) without resetting roller diameter or driver resolution.
5. 64-BIT DOUBLE PRECISION 1,000,000x DDA MATH:
   - Guaranteed < 0.025 mm error over 1.6 km of fed zipper tape.
====================================================================================================
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>
#include "burst_queue.h"
#include "motion_scheduler.h"
#include "hardware_capture_spec.h"
#include "safety_sensors.h"
#include "pulsestep_persistence.h"
#ifndef nvic_irq_enable
#define nvic_irq_enable(irq) NVIC_EnableIRQ(irq)
#endif

LiquidCrystal_I2C lcd(0x27, 16, 2);

// Write exactly 16 LCD columns; prevents stale characters after shorter labels/values.
static void lcdPrint16(uint8_t row, const char *text) {
    lcd.setCursor(0, row);
    uint8_t i = 0;
    if (text) { while (i < 16 && text[i] != '\0') lcd.print(text[i++]); }
    while (i < 16) { lcd.print(' '); ++i; }
}

// =========================================================================
// BUILD IDENTIFIERS & SOURCE-TO-BINARY METADATA
// =========================================================================
#define FW_VERSION_STR       "V17.0.0-PA0-TIM2-CAPTURE-PA8-TIM1"
#define FW_ARCH_TAG_STR      "V17.0.0-PA0-TIM2-CAPTURE-PA8-TIM1" // Backward compatible architecture tag: V16.5.9-PA0-TIM2-CAPTURE-PA8-TIM1
#define FW_BUILD_DATE_STR    "OCT-2026"
#define FW_BUILD_METADATA    "NIPON_ZIPPER_CNC_FW_V17_0_0_PA0_TIM2_CAPTURE_PA8_TIM1_TIMING_GUARD:OCT-2026"

// Embedded ROM identifier string for binary provenance verification
const char g_firmware_build_tag[] __attribute__((used)) = FW_BUILD_METADATA;

// Hardware Pin Definitions (100% Backwards-Compatible Pinout)
const int statusLedPin      = PC13; // Built-in Onboard LED (Active-LOW: LOW=ON, HIGH=OFF)
#define STATUS_LED_ON()    (GPIOC->BRR = (1 << 13))   // Atomic Clear PC13 -> LED ON
#define STATUS_LED_OFF()   (GPIOC->BSRR = (1 << 13))  // Atomic Set PC13   -> LED OFF
const int proxSensorPin     = PA0;  // Cam Proximity (PC817 Opto, Clean MCU GND, Falling ISR)
const int stepPin           = PA8;  // Driver PUL- (Hardware TIM1_CH1 / Direct Register BSRR)
const int dirPin            = PA2;  // Driver DIR- via Level Shifter CH4 LV (GPIOA Pin 2)
// =========================================================================
// SENSOR POLARITY & FAIL-SAFE LOGIC DEFINITIONS
// Industrial optical sensors via PC817 optocoupler with STM32 INPUT_PULLUP:
// - NORMAL STATE (Tape/Coil Present): Sensor actively conducts, pulling pin LOW (0V).
// - FAULT STATE (Tape Run-Out / Break / Cable Cut): Optocoupler OFF, pin pulled HIGH (3.3V).
// Fail-safe: Wire break, disconnected sensor, or power loss safely trips E-Stop.
// =========================================================================
#define SENSOR_STATE_NORMAL     LOW   // Sunk to GND (0V) by conducting PC817 phototransistor
#define SENSOR_STATE_FAULT      HIGH  // Pulled to 3.3V by internal pull-up (Fail-Safe Open)

const int tapeSensorPin     = PA3;  // Tape Run-Out Optical Sensor (PC817 Ch 1: Normal=LOW, Fault/Broken=HIGH)
const int coilSensorPin     = PB0;  // Coil Breakage Fiber Sensor (PC817 Ch 2: Normal=LOW, Fault/Broken=HIGH)
const int mainMotorRelayPin = PB1;  // Optional Main Motor Stop Relay (Active-HIGH Trip / NC Clutch Loop)
const int futureSensor2Pin  = PB3;  // Future auxiliary sensor #2; intentionally OFF by default
const int btnUp             = PB13; // UP Button (Swapped to match physical panel wiring)
const int btnDown           = PB12; // DOWN Button (Swapped to match physical panel wiring)
const int btnMode           = PB14; // MODE Multi-Function Button (Active-LOW to Clean MCU GND)

// Direct Register Bit Set/Reset (1-Cycle 13.8ns Sinking)
#define STEP_LOW_ACTIVE()  (GPIOA->BSRR = (1 << (8 + 16)))
#define STEP_HIGH_IDLE()   (GPIOA->BSRR = (1 << 8))
#define DIR_LOW()          (GPIOA->BSRR = (1 << (2 + 16)))
#define DIR_HIGH()         (GPIOA->BSRR = (1 << 2))
#define DIR_NORMAL()       DIR_HIGH() // Idle-HIGH for Normal Forward rotation
#define DIR_REVERSE()      DIR_LOW()  // Active-LOW sinking for Reverse rotation

// 1,000,000x Micro-Fractional DDA Fixed-Point Scaling Factor (6 Decimal Places)
#define FIXED_SCALE 1000000ULL

// IWDG: Independent Watchdog Timer (40kHz LSI / 256 Prescaler -> 6.4ms/count, RLR=1000 -> ~6.4s nominal Timeout)
#define IWDG_INIT() do {     IWDG->KR = 0x5555;     IWDG->PR = 0x06;       IWDG->RLR = 1000;       IWDG->KR = 0xAAAA;     IWDG->KR = 0xCCCC; } while (0)
#define IWDG_FEED() (IWDG->KR = 0xAAAA)

#define EEPROM_MAGIC_V16_3_3 0x5A431633UL
#define EEPROM_MAGIC_V16_4_0 0x5A431640UL
#define EEPROM_MAGIC         0x5A431650UL

// Persistent EEPROM Storage Configuration Structure
#define EEPROM_MAGIC_V16_5_1 0x5A431651UL
#define EEPROM_MAGIC_V17_0_0 0x5A431700UL

// Legacy V16.5.0 Struct (52 bytes) - preserved for automatic field migration
struct MachineConfigLegacy {
    uint32_t p5_fixed;
    uint32_t p8_fixed;
    uint32_t p10_fixed;
    int32_t  driverResolution;
    float    rollerDia;
    int32_t  maxRPMSetting;
    int32_t  feedAngleDeg;
    int32_t  safetyMarginPercent;
    int32_t  currentSize;
    uint32_t sensorGuardActive; // Legacy field: bit0=PA3 Tape, bit1=PB0 Coil, bit2=PB3 Safety Guard, bit3=Motion->PB1
    uint32_t hardwareTimerMode; // 0: AUTONOMOUS HW TIMER (DEFAULT), 1: CLASSIC DDA ENGINE
    uint32_t motorDirection;   // 0: NORMAL [FWD] (DEFAULT), 1: REVERSE [REV]
    uint32_t magic;
};

// =========================================================================
// PERSISTENT EEPROM CONFIGURATION STRUCTURE
// Authoritative structure size is dynamically enforced by sizeof(MachineConfig).
// Structure layout features 64-bit safe fixed-point pulse counts (p5, p8, p10)
// and 32-bit hardware parameters. magic header is placed at Offset 0 (0x5A431651UL)
// to uniquely differentiate from legacy V16.5.0/V16.4.0/V16.3.3 memory images.
// =========================================================================
struct MachineConfig {
    uint32_t magic;             // Offset 0: 0x5A431651UL (Magic header)
    uint32_t reserved;          // 64-bit alignment padding
    uint64_t p5_fixed;          // 64-bit safe fixed point (avoids uint32 overflow at 51200 res)
    uint64_t p8_fixed;          // 64-bit safe fixed point
    uint64_t p10_fixed;         // 64-bit safe fixed point
    int32_t  driverResolution;
    float    rollerDia;
    int32_t  maxRPMSetting;
    int32_t  feedAngleDeg;
    int32_t  safetyMarginPercent;
    int32_t  currentSize;
    uint32_t sensorGuardActive; // Legacy field: bit0=PA3 Tape, bit1=PB0 Coil, bit2=PB3 Safety Guard, bit3=Motion->PB1
    uint32_t hardwareTimerMode; // 0: AUTONOMOUS HW TIMER (DEFAULT), 1: CLASSIC DDA ENGINE
    uint32_t motorDirection;   // 0: NORMAL [FWD] (DEFAULT), 1: REVERSE [REV]
    int32_t  startSpeedPercent;// Stitch #1 soft-start % (10 to 100, default 100)
};

// 6-Decimal Exact Mathematical Pitch Pulses (6400 Resolution / 45.0mm Roller Diameter)
uint64_t p5_fixed  = 70000000ULL; // Size #5 (2.50mm): 113.176848 steps
uint64_t p8_fixed  = 80000000ULL; // Size #8 (3.00mm): 135.812218 steps
uint64_t p10_fixed = 100000000ULL; // Size #10 (4.00mm): 181.082957 steps

int32_t driverResolution    = 6400;
float   rollerDia           = 45.0f;
int32_t maxRPMSetting       = 3000;
int32_t feedAngleDeg        = 90;
int32_t safetyMarginPercent = 15;
int32_t startSpeedPercent   = 100; // Stitch #1 soft-start speed % (10% to 100%, default 100%)
int32_t tempStartSpeed      = 100; // Staged Start Speed
int     sensorSubIndex      = 1;  // 1: Tape Guard, 2: Coil Guard, 3: Safety Guard, 4: Motion Relay
int     helpIndex           = 1;  // 1: Stall, 2: Pitch, 3: Noise, 4: Hot, 5: Drift
bool    sensorGuardActive   = false; // PA3 Tape Guard; OFF by default
bool    coilGuardActive     = false; // PB0 future Coil/Thread sensor; OFF by default
bool    pb3GuardActive      = false; // PB3 Safety Guard input; OFF by default
bool    motionRelayEnabled  = false; // Motion-sync -> PB1 relay; OFF by default
// IMPORTANT: Auxiliary features never own the PA0->PA8 timing path. They may request PB1 only.
volatile bool hardwareTimerMode   = true;  // DEFAULT: TRUE (TIM1 STEP HARDWARE ENGINE); FALSE = DDA DEBUG ENGINE

bool    motorDirection      = false; // DEFAULT: FALSE (NORMAL / FORWARD ROTATION)
#define SENSOR_FEATURE_PA3_TAPE       (1UL << 0)
#define SENSOR_FEATURE_PB0_COIL       (1UL << 1)
#define SENSOR_FEATURE_PB3_FUTURE     (1UL << 2)
#define SENSOR_FEATURE_MOTION_RELAY   (1UL << 3)

static inline uint32_t sensorFeatureMask() {
    return (sensorGuardActive ? SENSOR_FEATURE_PA3_TAPE : 0UL) |
           (coilGuardActive ? SENSOR_FEATURE_PB0_COIL : 0UL) |
           (pb3GuardActive ? SENSOR_FEATURE_PB3_FUTURE : 0UL) |
           (motionRelayEnabled ? SENSOR_FEATURE_MOTION_RELAY : 0UL);
}

static inline void applySensorFeatureMask(uint32_t mask) {
    sensorGuardActive  = (mask & SENSOR_FEATURE_PA3_TAPE) != 0UL;
    coilGuardActive    = (mask & SENSOR_FEATURE_PB0_COIL) != 0UL;
    pb3GuardActive     = (mask & SENSOR_FEATURE_PB3_FUTURE) != 0UL;
    motionRelayEnabled = (mask & SENSOR_FEATURE_MOTION_RELAY) != 0UL;
}

bool    tempMotorDir        = false; // Staged Menu Direction

extern volatile bool hwBurstActive;
extern volatile int stepsRemaining;
void stopHardwareTimerImmediately();

// Hardware-level Motor Direction Controller (PA2 DIR-)
void applyMotorDirection() {
    // Safety: ensure any active movement is completely stopped before changing DIR pin
    if (hwBurstActive || stepsRemaining > 0) {
        stopHardwareTimerImmediately();
    }
    delayMicroseconds(20); // Safe hold time after last step pulse before DIR edge
    if (motorDirection) {
        DIR_LOW();  // Active-LOW sinking for Reverse rotation
    } else {
        DIR_HIGH(); // Idle-HIGH for Normal Forward rotation
    }
    delayMicroseconds(20); // Safe setup time (exceeds 5us DM542 specification by 400%)
}


int autoPulseWidth_P5   = 25;
int autoPulseWidth_P8   = 29;
int autoPulseWidth_P10  = 22;
volatile int activePulseWidth = 70; // Nominal 70us step period (~14.2 kHz) for 3000 RPM / 160 deg
unsigned long dynamicDebounceUs = 3000UL; // 3.0ms: Rejects EMI, supports 12 to 20,000 RPM

int32_t resStepGear    = 100;
float   diaStepGear    = 0.1f;
int32_t rpmStepGear    = 100;
int32_t angleStepGear  = 5;
int32_t marginStepGear = 1;

int32_t currentSize = 2; // 1: #5 (2.50mm), 2: #8 (3.00mm) [DEFAULT], 3: #10 (4.00mm)
// =========================================================================
// ATOMIC COHERENT PULSE PARAMETER SNAPSHOT & TELEMETRY
// =========================================================================
#ifndef DEBUG_TEST_MODE
#define DEBUG_TEST_MODE 0
#endif

struct PulseParameters {
    uint32_t integerPart;
    uint32_t fractionalPart;
    uint32_t generation;

    PulseParameters() : integerPart(113), fractionalPart(176848UL), generation(1) {}
    PulseParameters(uint32_t i, uint32_t f, uint32_t g) : integerPart(i), fractionalPart(f), generation(g) {}
    PulseParameters(const PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters(const volatile PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters& operator=(const PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    PulseParameters& operator=(const volatile PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    void operator=(const PulseParameters& o) volatile {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
    }
};

BurstQueue burstQueue;
volatile uint32_t tim4_overflow_count = 0;

volatile PulseParameters activePulseParams   = {113, 176848UL, 1};
PulseParameters          pendingPulseParams  = {113, 176848UL, 1};
volatile uint32_t        paramGenerationUsed = 1;
volatile uint32_t        rejectedTriggerCount = 0; // Live noise rejection counter for diagnostics

#if DEBUG_TEST_MODE
volatile uint32_t acceptedTriggerCount   = 0;
volatile uint32_t triggerMissedCount     = 0;
volatile uint32_t requestedPulseCount    = 0;
volatile uint32_t startedPulseCount      = 0;
volatile uint32_t completedPulseCount    = 0;
volatile uint32_t abortedPulseCount      = 0;
volatile uint32_t queuedPulseCount       = 0;
volatile uint32_t burstStartedCount      = 0;
volatile uint32_t burstCompletedCount    = 0;
volatile uint32_t burstQueuedCount       = 0;
volatile uint32_t paramGenChangesCount   = 0;
volatile uint32_t maxISRLatencyCycles    = 0;
volatile uint32_t maxTriggerJitterUs     = 0;
volatile uint32_t assertionFailureCount  = 0;
#endif

void commitPulseParameters(uint32_t intPart, uint32_t fracPart) {
    pendingPulseParams.integerPart    = intPart;
    pendingPulseParams.fractionalPart = fracPart;
    pendingPulseParams.generation++;
#if DEBUG_TEST_MODE
    paramGenChangesCount++;
#endif
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    activePulseParams.integerPart = pendingPulseParams.integerPart;
    activePulseParams.fractionalPart = pendingPulseParams.fractionalPart;
    activePulseParams.generation = pendingPulseParams.generation;
    __set_PRIMASK(primask);
}

volatile uint64_t currentPulsesFixed = 80000000ULL;
volatile uint32_t currentPulsesInt   = 80;      // Whole step portion for fast 32-bit ISR math
volatile uint32_t currentPulsesFrac  = 0UL; // Fractional micro-step portion (< 1,000,000)
volatile uint32_t pulseFracAccumulator = 0UL;     // 32-bit fractional accumulator (zero 64-bit division)
volatile uint64_t pulseAccumulatorFixed = 0ULL;
volatile uint32_t tim2OverflowCount = 0UL;
volatile uint32_t tim2CaptureOverrunCount = 0UL;
volatile uint32_t tim2CaptureEpochOffsetUs = 0UL;
volatile bool tim2CaptureEpochReady = false;
volatile uint32_t tim2CaptureMissedCallbacks = 0UL;
volatile bool     isCaptureStreamDiscontinuous = false;
volatile uint32_t tim2CaptureResyncEvents      = 0UL;
// Last accepted PA0 trigger timestamp, sourced from the extended TIM2 hardware-capture clock.
volatile bool pendingMenuExit = false;
uint64_t stepGearFixed = 1000000ULL; // 1.00 pulse tuning step (1,000,000 units)

bool isUiLocked = true;
unsigned long lastUnlockActivity = 0UL;
unsigned long confirmDialogStartTime = 0UL;

// =========================================================================
// 1-MINUTE CONTINUOUS SMOOTH RUN AUTO-SAVE STATE MACHINE
// Gated strictly to 0 RPM Standstill (Zero Pulse & Trigger Interference)
// Anti-Repeat Latch: Saved exactly once per parameter modification
// =========================================================================
bool pulseModifiedByUser            = false;  // Armed when user tunes pulse with UP/DOWN
unsigned long smoothRunStartMillis   = 0UL;    // Legacy fallback timer
bool autoSavePendingStandstill       = false;  // Set when 60s qualified in RAM; deferred to 0 RPM
AutoSaveQualificationEngine autoSaveEngine(120000UL); // Formal 2-Minute Cooldown Auto-Save Engine
FlashSaveTransactionEngine  flashSaveTx;             // Atomic Flash Save Transaction Engine (Prompt 8Writing)

// Accepted motion-trigger counters and diagnostics (PA0 TIM2 input capture path).
volatile uint32_t acceptedTriggerPulses          = 0;

// Authoritative PulseStep Persistence State Tracking
uint32_t flashWriteCount            = 0;      // Diagnostic counter: strictly increments on actual Flash write
uint32_t activeEEPROMSlot           = 0;      // Active transaction slot (0 or 1)
uint32_t eepromSeqNumber            = 0;      // Monotonic transaction sequence counter
uint64_t pulseStepStored_p5         = 70000000ULL; // Stored ROM baseline for Size #5
uint64_t pulseStepStored_p8         = 80000000ULL; // Stored ROM baseline for Size #8
uint64_t pulseStepStored_p10        = 100000000ULL; // Stored ROM baseline for Size #10


unsigned long uiMessageTimer = 0UL;
const char* uiBannerLine1 = nullptr;
const char* uiBannerLine2 = nullptr;

// Staged RAM Parameters for Zero Flash Wear
int32_t tempDriverRes       = 6400;
float   tempRollerDia       = 45.0f;
int32_t tempMaxRPM          = 3000;
int32_t tempFeedAngle       = 90;
int32_t tempSafetyMargin    = 15;

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm);

static inline bool stagedTimingConfigurationFeasible() {
    const double pitch5 = 1.32536067;
    const double pitch8 = 1.87759428;
    const double pitch10 = 2.31938128;
    return timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch5) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch8) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch10);
}

// True when the manually tuned pulse count cannot fit inside the configured
// feed-angle window at the configured maximum RPM. Never silently clamp an
// invalid manual tuning to the 8us timer floor.
volatile bool pulseTimingInvalid = false;

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#ifndef SERVO_PERIOD_Q_SHIFT
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U
#endif

static inline bool currentPulseTimingFeasible() {
    if (driverResolution < 200 || driverResolution > 51200 || rollerDia < 15.0f || rollerDia > 100.0f ||
        maxRPMSetting < 100 || maxRPMSetting > 4000 || feedAngleDeg < 30 || feedAngleDeg > 270 ||
        safetyMarginPercent < 0 || safetyMarginPercent > 25) return false;
    const double circumference = 3.14159265358979323846 * (double)rollerDia;
    (void)circumference;
    const double stepCount = (double)currentPulsesFixed / 1000000.0;
    const double feedWindowUs = (60000000.0 / (double)maxRPMSetting) * ((double)feedAngleDeg / 360.0) *
                                (1.0 - ((double)safetyMarginPercent / 100.0));
    const double overlapDeadlineUs = (60000000.0 / (double)maxRPMSetting) * 0.75 * 0.80;
    const double windowUs = (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
    return stepCount > 0.0 && windowUs > 0.0 && (windowUs / stepCount) >= (double)SERVO_PERIOD_MIN_US;
}

static inline void refreshPulseTimingValidity() {
    pulseTimingInvalid = !currentPulseTimingFeasible();
}
bool    tempSensorGuard     = false;
bool    tempCoilGuard        = false;
bool    tempPb3Guard         = false;
bool    tempMotionRelay      = false;
bool    tempHwTimerMode     = true;  // staged engine selection: true=TIM1 hardware STEP, false=DDA diagnostic
bool    hasStagedChanges    = false;
bool    isTimingWarningActive = false;
int diagMinW = 0;
const char* diagFixLine1 = nullptr;
const char* diagFixLine2 = nullptr;
int infoIndex = 1;

// Optical Safety Guard State Machine
unsigned long sensorTripStartTime = 0UL;
volatile bool isSensorFaultTripped = false;
volatile bool isMotionSyncLost     = false; // Diagnostic state; never blocks PA0/PA8 timing
volatile bool motionWatchdogArmed   = false; // Armed only after a valid measured trigger interval
volatile uint32_t validTriggerCount  = 0;
volatile bool auxSensorFaultActive  = false; // Auxiliary sensor fault; may trip PB1 but never cancels STEP
volatile int  faultType            = 0;     // 0: None, 1: Tape Run-Out, 2: Coil Breakage, 3: Trigger Sync Lost
// queuedBurstSteps removed: SPSC BurstQueue burstQueue is the single authoritative production scheduling queue

// Stepper Step State Machine
volatile bool triggerPull = false;
volatile unsigned long lastTriggerMicros = 0UL;
volatile unsigned long lastMeasuredIntervalUs = 0UL;
volatile unsigned long rawIntervalMicros = 0UL;
volatile int stepsRemaining = 0;
volatile int totalStepsInBurst = 0;
volatile int currentStepIndex = 0;
volatile bool stepPinState = HIGH;
volatile unsigned long lastStepMicros = 0UL;

// Hardware Timer 2 Burst Controller State
volatile bool hwBurstActive = false;
volatile int  hwBurstStepsTarget = 0;
volatile int  hwBurstStepsDone = 0;

volatile unsigned long currentRPM = 0UL;
// RPM display-only robust estimator. It does not control PA0 qualification,
// the watchdog's raw interval, or PA8 STEP scheduling.
volatile uint32_t rpmIntervalHistoryUs[3] = {0UL, 0UL, 0UL};
volatile uint8_t rpmIntervalHistoryCount = 0U;
volatile uint8_t rpmIntervalHistoryIndex = 0U;
unsigned long lastDisplayUpdate = 0UL;
unsigned long lastRpmDisplayUpdate = 0UL;
unsigned long lastButtonCheck = 0UL;
unsigned long modePressTime = 0UL;
unsigned long lastModeClickTime = 0UL;
unsigned long upPressTime = 0UL;
unsigned long downPressTime = 0UL;
unsigned long dualPressTime = 0UL;

bool modePressed = false;
bool upDownPressed = false;
bool pendingSingleClick = false;

int menuState = 0;
int oldMenuState = -1;
int hiddenOption = 1;
bool resetChoice = false;
bool saveExitChoice = true; // Save & Exit Dialog: true = YES, false = NO

// Hardware Timer 2 Instance for Stepping Pulses
// =========================================================================
// AUTHORITATIVE CNC MOVEMENT STATE MACHINE
// IDLE -> ARMED -> RUNNING -> STOPPING -> COMPLETE -> IDLE
// Fault/Abort: RUNNING/STOPPING -> FAULT/ABORTED -> IDLE (Standstill Gated)
// =========================================================================
enum MovementState {
    STATE_IDLE = 0,
    STATE_ARMED,
    STATE_RUNNING,
    STATE_STOPPING,
    STATE_COMPLETE,
    STATE_ABORTED,
    STATE_FAULT
};
volatile MovementState movementState = STATE_IDLE;

inline bool isMachineSafelyIdle() {
    return (currentRPM == 0UL) &&
           (stepsRemaining == 0) &&
           (!hwBurstActive) &&
           (burstQueue.isEmpty()) &&
           (movementState == STATE_IDLE || movementState == STATE_COMPLETE);
}

const uint16_t STEP_PULSE_WIDTH_US   = 5; // 5.0us Active LOW pulse for Leadshine DM542

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U

// Trigger interval history is shared by RPM display and robust STEP-period estimation.
volatile uint32_t servoPhaseRelockCount = 0;
volatile bool servoPhaseLocked = false;
volatile uint32_t servoLastIntervalUs = 0;
volatile uint32_t servoPrevIntervalUs = 0;
volatile uint32_t servoMaxJitterUs = 0;
volatile uint32_t servoPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t servoPeriodFrac = 0;
volatile uint32_t hwBurstPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t hwBurstPeriodFrac = 0;

static inline uint16_t q16PeriodToTimerUs(volatile uint32_t &frac, uint32_t q16) {
    // True Q16.16 accumulation: retain both the configured fractional period
    // and the carry from prior timer cycles. This preserves the long-term
    // average period instead of truncating the Q16 fractional component.
    uint32_t sum = (q16 & 0xFFFFUL) + (frac & 0xFFFFUL);
    uint32_t whole = (q16 >> SERVO_PERIOD_Q_SHIFT) + (sum >> SERVO_PERIOD_Q_SHIFT);
    frac = sum & 0xFFFFUL;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm) {
    if (resolution < 200 || resolution > 51200 || !(diameter == diameter) || diameter < 15.0f || diameter > 100.0f ||
        rpm < 100 || rpm > 4000 || angle < 30 || angle > 270 || margin < 0 || margin > 25 || pitchMm <= 0.0) return false;
    const double circumference = 3.14159265358979323846 * (double)diameter;
    const double stepCount = ((double)resolution / circumference) * pitchMm;
    const double feedWindowUs = (60000000.0 / (double)rpm) * ((double)angle / 360.0) * (1.0 - ((double)margin / 100.0));
    const double overlapDeadlineUs = (60000000.0 / (double)rpm) * 0.75 * 0.80;
    const double windowUs = (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
    if (!(stepCount > 0.0) || !(windowUs > 0.0)) return false;
    // The timer's hard minimum is 8 us. A configuration whose requested burst
    // period is below this cannot physically fit the commanded pulse count into
    // the configured feed-angle window. Never silently clamp such a case to 8 us.
    return (windowUs / stepCount) >= (double)SERVO_PERIOD_MIN_US;
}

// Reserve explicit timing headroom so a valid trigger at the configured RPM ceiling
// cannot arrive while the previous STEP burst is still active. The trigger plausibility
// guard accepts intervals down to 75% of a configured revolution; use only 80% of that
// floor for STEP time (60% of a revolution) as a conservative deadline.
static inline uint64_t maximumBurstWindowUs(int32_t rpm, int32_t angle, int32_t margin) {
    if (rpm < 100 || rpm > 4000) rpm = 3000;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    if (margin < 0) margin = 0;
    if (margin > 25) margin = 25;
    const uint64_t revolutionUs = 60000000ULL / (uint32_t)rpm;
    const uint64_t feedWindowUs = (revolutionUs * (uint32_t)angle / 360ULL) * (uint32_t)(100 - margin) / 100ULL;
    const uint64_t minimumAcceptedIntervalUs = revolutionUs * 3ULL / 4ULL;
    const uint64_t overlapDeadlineUs = minimumAcceptedIntervalUs * 80ULL / 100ULL;
    return (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
}

static inline uint32_t calculateAdaptiveStepPeriodQ16(uint32_t revolutionUs, uint32_t stepCount) {
    if (stepCount == 0U || revolutionUs == 0U) return servoPeriodQ16;
    int angle = feedAngleDeg;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    int margin = safetyMarginPercent;
    if (margin < 0) margin = 0;
    if (margin > 25) margin = 25;
    uint64_t windowUs = ((uint64_t)revolutionUs * (uint64_t)angle) / 360ULL;
    windowUs = (windowUs * (uint64_t)(100 - margin)) / 100ULL;
    // Dynamic burst cap: never let a burst exceed the configured maximum-RPM overlap deadline
    const uint64_t configuredDeadlineUs = maximumBurstWindowUs(maxRPMSetting, angle, margin);
    if (windowUs > configuredDeadlineUs) windowUs = configuredDeadlineUs;
    if (windowUs < 1ULL) windowUs = 1ULL;
    uint64_t q16 = (windowUs << SERVO_PERIOD_Q_SHIFT) / (uint64_t)stepCount;
    uint64_t minQ = ((uint64_t)SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT);
    uint64_t maxQ = ((uint64_t)SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT);
    if (q16 < minQ) q16 = minQ;
    if (q16 > maxQ) q16 = maxQ;
    return (uint32_t)q16;
}


HardwareTimer *stepTimer     = new HardwareTimer(TIM1);
HardwareTimer *captureTimer  = new HardwareTimer(TIM2); // PA0 input capture; core-owned TIM2 IRQ dispatch
HardwareTimer *safetyTimer   = new HardwareTimer(TIM3);
#if defined(TIM4)
HardwareTimer *timebaseTimer = new HardwareTimer(TIM4);
#endif
volatile uint8_t pa3FaultCounterMs   = 0; // Independent 15ms consecutive qualification counter for PA3 (Tape)
volatile uint8_t pb0FaultCounterMs   = 0; // Independent 15ms consecutive qualification counter for PB0 (Coil)

// =========================================================================
// TRUE HARDWARE TIMER 2 PWM (OC2) STEP GENERATION & BURST CONTROLLER
// 1. Pure Continuous PWM Mode 2: Inactive (HIGH) 0..CCR2-1, Active (LOW) CCR2..ARR.
// 2. Output is natively, physically HIGH at CNT=0 rollover.
// 3. Software halts CEN and CC2E at CNT=0 upon burst completion (0.2us latency vs 30us safety window).
// 4. Zero OPM hardware race conditions: Timer NEVER stalls or dies on rapid/boundary triggers!
// 5. Seamless mid-burst trigger accumulation: Target += stepCount without losing a single pulse.
// =========================================================================

// =========================================================================
// DETERMINISTIC MULTI-SEGMENT RAMP PARAMETER CALCULATOR
// Provides smooth, bounded acceleration/deceleration with zero staircase jerk
// Dedicated short-burst handling: N<=4 (pure cruise), 5<=N<=12 (gentle soft boundary)
// =========================================================================
static inline uint16_t calculateAdaptiveStepPeriodUs(uint32_t revolutionUs, uint32_t stepCount) {
    uint32_t q16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    uint32_t whole = q16 >> SERVO_PERIOD_Q_SHIFT;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline void updateStepPeriodFromServoInterval(uint32_t revolutionUs, uint32_t stepCount) {
    if (revolutionUs == 0U || stepCount == 0U) return;
    servoPrevIntervalUs = servoLastIntervalUs;
    servoLastIntervalUs = revolutionUs;
    if (servoPrevIntervalUs != 0U) {
        uint32_t jitter = (revolutionUs > servoPrevIntervalUs) ? (revolutionUs - servoPrevIntervalUs) : (servoPrevIntervalUs - revolutionUs);
        if (jitter > servoMaxJitterUs) servoMaxJitterUs = jitter;
    }
    servoPeriodQ16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    servoPhaseLocked = (servoPrevIntervalUs != 0U);
    if (servoPhaseLocked) servoPhaseRelockCount++;
}

void stepTimerCallback() {
    if (hwBurstActive && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        hwBurstStepsDone++;
#if DEBUG_TEST_MODE
        completedPulseCount++;
#endif

        if (hwBurstStepsDone >= hwBurstStepsTarget) {
            BurstItem nextBurst{};
            if (movementState != STATE_FAULT && movementState != STATE_ABORTED && burstQueue.dequeue(nextBurst)) {
                // Seamlessly chain queued burst from authoritative SPSC BurstQueue without dropping timer
                hwBurstStepsTarget = (int)nextBurst.stepCount;
                hwBurstStepsDone   = 0;
#if DEBUG_TEST_MODE
                queuedPulseCount  -= nextBurst.stepCount;
                startedPulseCount += nextBurst.stepCount;
                burstStartedCount++;
#endif
                stepsRemaining     = hwBurstStepsTarget;
                totalStepsInBurst  = hwBurstStepsTarget;

                // Direction Fix (per Rajesh Shah directive):
                // Direction is strictly Settings-controlled and fixed during RUN.
                // Pulse, burst, queue, ISR, DDA, RPM, trigger, and sensor processing NEVER change DIR at runtime.

                // Each queued burst carries the period calculated from the physical
                // servo interval that created it. Never rewrite the active burst with a
                // newer measurement; this preserves deterministic phase timing.
                if (nextBurst.periodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && nextBurst.periodQ16 <= (SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT)) {
                    hwBurstPeriodQ16 = nextBurst.periodQ16;
                    hwBurstPeriodFrac = 0;
                    activePulseWidth = (int)(hwBurstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
                } else if (nextBurst.periodUs >= SERVO_PERIOD_MIN_US && nextBurst.periodUs <= SERVO_PERIOD_MAX_US) {
                    activePulseWidth = (int)nextBurst.periodUs;
                    hwBurstPeriodQ16 = ((uint32_t)activePulseWidth << SERVO_PERIOD_Q_SHIFT);
                    hwBurstPeriodFrac = 0;
                }
                uint16_t nextARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
                TIM1->ARR = nextARR;
                uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
                if (pWidth < 2) pWidth = 2;
                TIM1->CCR1 = nextARR - pWidth + 1;
                return;
            }

            // Burst complete with no queued steps: disable PWM output and stop timer in silicon
            TIM1->CCER &= ~TIM_CCER_CC1E; // Disconnect hardware PWM output on PA8 immediately
            TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
            
            // Restore PA8 pin to General Purpose Output HIGH (Idle)
            GPIOA->CRH &= ~(0xFU << 0);
            GPIOA->CRH |= (0x3U << 0); // 50MHz GP Output Push-Pull
            STEP_HIGH_IDLE();
            stepPinState = HIGH;

            // Clear any pending update flags in NVIC
            TIM1->SR &= ~TIM_SR_UIF;
            NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

            hwBurstActive  = false;
            stepsRemaining = 0;
            movementState  = STATE_COMPLETE;
#if DEBUG_TEST_MODE
            burstCompletedCount++;
            if (queuedPulseCount == 0 && !hwBurstActive) {
                if (requestedPulseCount != (completedPulseCount + abortedPulseCount)) {
                    assertionFailureCount++;
                }
            }
#endif
            STATUS_LED_OFF(); // Stepper burst complete -> Turn OFF LED
        } else {
            stepsRemaining = (hwBurstStepsTarget - hwBurstStepsDone);
            movementState  = STATE_RUNNING;

            // Keep every pulse in the burst at the servo-synchronized period.
            // Artificial per-pulse ramps are deliberately removed because they change
            // the commanded pulse density away from the measured master motion.
            uint16_t scheduledPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
            activePulseWidth = (int)scheduledPeriodUs;
            uint16_t nextARR = (scheduledPeriodUs > 1) ? (uint16_t)(scheduledPeriodUs - 1) : 1;
            TIM1->ARR  = nextARR;
            uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
            if (pWidth < 2) pWidth = 2;
            TIM1->CCR1 = nextARR - pWidth + 1; // Pulse ends exactly at ARR rollover
        }
    } else {
        TIM1->CCER &= ~TIM_CCER_CC1E;
        TIM1->CR1  &= ~TIM_CR1_CEN;
        GPIOA->CRH &= ~(0xFU << 0);
        GPIOA->CRH |= (0x3U << 0);
        STEP_HIGH_IDLE();
        stepPinState   = HIGH;
        TIM1->SR &= ~TIM_SR_UIF;
        NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
        hwBurstActive  = false;
        stepsRemaining = 0;
        movementState  = STATE_IDLE;
    }
}

// =========================================================================
// DETERMINISTIC 1 KHZ HARDWARE SAFETY MONITOR (TIM3)
// Unblockable by loop() or I2C LCD delays. 15ms Anti-Vibration Qualified E-Stop.
// =========================================================================
static inline uint32_t get_hardware_timestamp_us(); // shared timebase prototype
void processSensorTrigger(uint32_t capturedTimestampUs); // forward declaration for TIM2 callback

void safetyTimerCallback() {
    // IMPORTANT ARCHITECTURE RULE:
    // PA0 TIM2 hardware capture triggers motion; TIM1 independently generates PA8 STEP.
    // Auxiliary sensors and PB1 relay logic NEVER stop/abort/cancel the STEP engine.
    // A qualified auxiliary fault may request PB1, allowing the servo/clutch to stop;
    // any already-scheduled STEP burst is allowed to finish deterministically.

    const bool tapeBroken = sensorGuardActive && ((GPIOA->IDR & (1U << 3)) != 0U);
    const bool coilBroken = coilGuardActive && ((GPIOB->IDR & (1U << 0)) != 0U);
    const bool pb3Broken  = pb3GuardActive  && ((GPIOB->IDR & (1U << 3)) != 0U);

    bool pa3Qualified = false;
    bool pb0Qualified = false;
    bool pb3Qualified = false;
    if (sensorGuardActive || coilGuardActive || pb3GuardActive) {
        updateSafetySensorCounters((sensorGuardActive || coilGuardActive), tapeBroken, coilBroken,
                                   pa3FaultCounterMs, pb0FaultCounterMs,
                                   pa3Qualified, pb0Qualified);
        // PB3 uses the same 15 ms qualification window without sharing a counter.
        static uint8_t pb3FaultCounterMs = 0;
        if (pb3Broken) {
            if (pb3FaultCounterMs < SENSOR_QUALIFICATION_MS) pb3FaultCounterMs++;
        } else {
            pb3FaultCounterMs = 0;
        }
        pb3Qualified = (pb3FaultCounterMs >= SENSOR_QUALIFICATION_MS);
    } else {
        pa3FaultCounterMs = 0;
        pb0FaultCounterMs = 0;
    }

    const bool anyAuxFault = pa3Qualified || pb0Qualified || pb3Qualified;
    if (anyAuxFault && (sensorGuardActive || coilGuardActive || pb3GuardActive)) {
        auxSensorFaultActive = true;
        isSensorFaultTripped = true;
        if (pa3Qualified) faultType = 1;
        else if (pb0Qualified) faultType = 2;
        else faultType = 4;

        // Auxiliary sensor -> PB1 ONLY. Do not stop the timebase, abort the queue, or change movementState.
        if (motionRelayEnabled) {
            GPIOB->BSRR = (1U << 1);
        }
        uiBannerLine1 = pa3Qualified ? "! TAPE RUN-OUT !" :
                        (pb0Qualified ? "! COIL SENSOR ! " : "! PB3 SENSOR !  ");
        uiBannerLine2 = motionRelayEnabled ? "AUX STOP RELAY  " : "STEP PATH SAFE  ";
        uiMessageTimer = millis() + 2500UL;
        oldMenuState = -1;
    }

    // Motion watchdog is optional and is deliberately DISARMED until two valid
    // proximity edges establish a real physical period. This prevents a first-run
    // false "Motion Lost" before the servo/proximity stream has established sync.
    if (motionRelayEnabled && motionWatchdogArmed && currentRPM > 100UL &&
        !isMotionSyncLost) {
        const uint32_t watchdogNowUs = get_hardware_timestamp_us();
        const uint32_t elapsedSinceTrigger = watchdogNowUs - (uint32_t)lastTriggerMicros;
        unsigned long syncTimeoutUs = (lastMeasuredIntervalUs > 0UL)
            ? (lastMeasuredIntervalUs * 4UL + 50000UL) : 300000UL;
        if (syncTimeoutUs < 300000UL) syncTimeoutUs = 300000UL;
        if (elapsedSinceTrigger > syncTimeoutUs) {
            isMotionSyncLost = true;
            faultType = 3;
            // PB1 relay request only. Never stop the timebase or clear the STEP queue here.
            GPIOB->BSRR = (1U << 1);
            uiBannerLine1 = "! SYNC TIMEOUT !";
            uiBannerLine2 = "RELAY STOP ONLY ";
            uiMessageTimer = millis() + 3000UL;
            oldMenuState = -1;
        }
    }

    // Standstill recovery releases PB1 only when the machine has genuinely stopped.
    // A new valid PA0 TIM2 hardware-capture stream then re-arms synchronization.
    if (currentRPM == 0UL) {
        if (isMotionSyncLost) {
            isMotionSyncLost = false;
            motionWatchdogArmed = false;
        }
        if (!tapeBroken && !coilBroken && !pb3Broken) {
            auxSensorFaultActive = false;
            isSensorFaultTripped = false;
            if (motionRelayEnabled || !sensorGuardActive || !coilGuardActive || !pb3GuardActive) {
                GPIOB->BRR = (1U << 1);
            }
            if (movementState == STATE_FAULT) movementState = STATE_IDLE;
        }
    }
}


// =========================================================================
// CONTINUOUS 1 MHZ FREE-RUNNING TIMER 4 (STM32F103 HARDWARE TIMESTAMPING)
// 1.0 microsecond deterministic tick resolution, independent of TIM2/TIM3
// =========================================================================
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
void tim4UpdateCallback(void) {
    tim4_overflow_count++;
}

void initFreeRunningTimer4() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;

    // Attach callback using official STM32duino HardwareTimer framework
    // (Prevents duplicate definition of TIM4_IRQHandler with SrcWrapper/HardwareTimer.cpp)
    timebaseTimer->pause();
    timebaseTimer->setPrescaleFactor(72);     // 72MHz / 72 = 1MHz (1.0 us tick)
    timebaseTimer->setOverflow(0x10000UL);    // 16-bit free-running counter rollover at 65535us
    timebaseTimer->setCount(0);
    timebaseTimer->attachInterrupt(tim4UpdateCallback);
    timebaseTimer->resume();

    // Enforce exact silicon register configuration after resume()
    TIM4->PSC = 71;     // 72MHz / (71 + 1) = 1MHz (1.0 us tick)
    TIM4->ARR = 0xFFFF; // 16-bit free-running counter rollover at 65535us
    TIM4->CNT = 0;
    TIM4->EGR = TIM_EGR_UG;     // Immediately force-load prescaler shadow buffer in hardware
    TIM4->SR &= ~TIM_SR_UIF;    // Clear the update interrupt flag generated by EGR_UG
    TIM4->DIER |= TIM_DIER_UIE; // Enable update interrupt for 32-bit rollover
}

// Provably race-safe atomic snapshot across 16-bit hardware timer overflow
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t high;
    uint16_t low;
    bool pending;

    do {
        high = tim4_overflow_count;
        low  = (uint16_t)(TIM4->CNT);
        pending = (TIM4->SR & TIM_SR_UIF) != 0;
    } while (high != tim4_overflow_count);

    // If an overflow interrupt is pending (UIF set) and CNT has already rolled over
    // to a small value (< 0x8000), account for the unserviced rollover in this reading
    if (pending && (low < 0x8000)) {
        high++;
    }

    return (high << 16) | low;
}
#else
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t nowCycles = 0;
#if defined(CoreDebug) && defined(DWT)
    nowCycles = DWT->CYCCNT;
#endif
    return (nowCycles != 0) ? (nowCycles / 72UL) : micros();
}
#endif
void initHardwareSafetyTimer3() {
    // 1. Enable TIM3 peripheral clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    // Attach callback with HardwareTimer wrapper first so resume() does not clobber PSC/ARR
    safetyTimer->pause();
    safetyTimer->setPrescaleFactor(72);
    safetyTimer->setOverflow(1000);
    safetyTimer->setCount(0);
    safetyTimer->attachInterrupt(safetyTimerCallback);
    safetyTimer->resume();

    // 2. Prescaler: 72MHz / (71 + 1) = 1MHz (1 tick = 1.0 microsecond)
    TIM3->PSC = 71;
    // Auto-reload: 1000 ticks = 1000 microseconds = 1.0ms (1 kHz sampling)
    TIM3->ARR = 999;
    TIM3->CNT = 0;
    TIM3->EGR = TIM_EGR_UG;     // Force-load prescaler shadow buffer in hardware
    TIM3->SR &= ~TIM_SR_UIF;    // Clear update flag

    // Enable update interrupt
    TIM3->DIER |= TIM_DIER_UIE;
}

// TIM2 update callback extends the 1 MHz capture counter across 16-bit wraps.
// The core-owned TIM2_IRQHandler calls these through HardwareTimer's HAL bridge.
void tim2CaptureRolloverCallback() {
    tim2OverflowCount++;
}

void tim2HardwareCaptureCallback() {
    // CCR1 was latched by hardware at the PA0 falling edge, before ISR latency.
    if ((TIM2->SR & TIM_SR_CC1OF) != 0U) {
        tim2CaptureOverrunCount++;
        tim2CaptureMissedCallbacks++; // Accurately record each missed edge in silicon
        isCaptureStreamDiscontinuous = true; // Flag stream discontinuity to prevent false RPM drop
        TIM2->SR &= ~TIM_SR_CC1OF;
    }
    const uint16_t captured = (uint16_t)captureTimer->getCaptureCompare(1);
    uint32_t high = tim2OverflowCount;
    const uint16_t cntNow = (uint16_t)TIM2->CNT;
    const bool updateStillPending = (TIM2->SR & TIM_SR_UIF) != 0U;

    // Provably race-safe atomic epoch resolution across 16-bit hardware timer overflow
    if (updateStillPending) {
        // Rollover occurred in hardware (UIF set), but tim2CaptureRolloverCallback has not
        // incremented tim2OverflowCount yet because HAL services capture callback first.
        // If capture was latched after rollover (small captured value), it belongs to high + 1!
        if (captured < 0x8000U) {
            high++;
        }
    } else {
        // Rollover callback already executed and incremented tim2OverflowCount.
        // If capture occurred just before the wrap (large value near 0xFFFF), it belongs to previous epoch.
        if (high > 0UL && cntNow < captured && (uint16_t)(captured - cntNow) > 0x8000U) {
            high--;
        }
    }

    const uint32_t captureClockUs = (high << 16) | (uint32_t)captured;
    if (!tim2CaptureEpochReady) {
        // Align the capture clock to the TIM4 monotonic clock once. Thereafter,
        // intervals come from TIM2 hardware captures, not ISR dispatch timing.
        tim2CaptureEpochOffsetUs = get_hardware_timestamp_us() - captureClockUs;
        tim2CaptureEpochReady = true;
    }
    const uint32_t captureTimestampUs = tim2CaptureEpochOffsetUs + captureClockUs;
    processSensorTrigger(captureTimestampUs);
}

void initHardwareTimer2() {
    // TIM2_CH1 on PA0 is the single authoritative motion-trigger source.
    // TIM2 capture hardware latches the falling-edge timestamp independent of
    // CPU interrupt latency; its IRQ performs the trigger processing exactly once.
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    // Bind stepTimer callback & enable TIM1_UP_IRQn in NVIC via HardwareTimer first,
    // then immediately place TIM1 in deterministic idle state before configuring registers.
    stepTimer->pause();
    stepTimer->setPrescaleFactor(72);
    stepTimer->setOverflow(100);
    stepTimer->attachInterrupt(stepTimerCallback);
    stepTimer->resume();

    // TIM1 STEP engine: 1 MHz timer tick; active-low PWM Mode 2.
    TIM1->CR1 = 0;
    TIM1->CCER &= ~TIM_CCER_CC1E;
    TIM1->PSC = 71;
    TIM1->RCR = 0;
    uint16_t initARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
    TIM1->ARR = initARR;
    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    TIM1->CCMR1 |= (0x7U << 4); // CH1 PWM Mode 2
    TIM1->CCMR1 |= TIM_CCMR1_OC1PE;
    TIM1->CCER |= TIM_CCER_CC1P;
    TIM1->CR1 |= TIM_CR1_ARPE;
    TIM1->CR1 &= ~TIM_CR1_OPM;
    TIM1->BDTR |= TIM_BDTR_MOE; // Required for advanced-control TIM1 outputs
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR = TIM_EGR_UG;     // Force-load PSC=71, ARR, CCR1, RCR=0 into hardware shadow registers
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    TIM1->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM1_UP_IRQn);

    // Keep PA8 in GP Output Push-Pull HIGH (0x3) while idle so STEP_HIGH_IDLE(),
    // Stepper Jog Test (Page 1), Opto Sink Test (Page 2), and DDA mode work directly.
    // startHardwareTimerBurst() switches PA8 to AF Push-Pull (0xB) during active TIM1 bursts.
    pinMode(stepPin, OUTPUT);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0); // PA8 GP output push-pull, 50 MHz (Idle HIGH)

    // TIM2_CH1 input capture: PA0 / TI1, falling edge, 1 MHz counter.
    // Use STM32duino HardwareTimer callbacks: the core owns TIM2_IRQHandler,
    // and dispatches capture/update callbacks through HAL_TIM_IRQHandler.
    // This makes the CCR1 hardware-latched edge timestamp authoritative without
    // defining a duplicate TIM2_IRQHandler symbol or also dispatching EXTI0.
    captureTimer->pause();
    captureTimer->setMode(1, TIMER_INPUT_CAPTURE_FALLING, proxSensorPin);
    captureTimer->setPrescaleFactor(72);       // 72 MHz / 72 = 1 MHz (1 us/tick)
    captureTimer->setOverflow(0x10000UL);      // 16-bit wrap; overflow callback extends it
    captureTimer->setCount(0);
    tim2OverflowCount = 0UL;
    tim2CaptureOverrunCount = 0UL;
    tim2CaptureEpochOffsetUs = 0UL;
    tim2CaptureEpochReady = false;
    tim2CaptureMissedCallbacks = 0UL;
    captureTimer->setInterruptPriority(1, 0); // Priority 1 for immediate trigger preemption
    captureTimer->attachInterrupt(tim2CaptureRolloverCallback);
    captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback);
    captureTimer->resume();

    // Restore PA0 internal pull-up (setMode resets PA0 to floating input) and enforce IC1F filter
    GPIOA->CRL &= ~(0xFU << 0);
    GPIOA->CRL |= (0x8U << 0);  // Input with pull-up / pull-down
    GPIOA->BSRR = (1U << 0);    // Pull-up enabled on PA0
    // SILICON-LEVEL HARDWARE DIGITAL FILTER (IC1F = 0011):
    // Digital filter debounces PA0 pin for N=8 consecutive clock cycles (111 ns) at f_CK_INT (72MHz).
    // Eliminates high-frequency motor contactor/clutch noise directly in hardware with 0% CPU overhead!
    TIM2->CCMR1 &= ~TIM_CCMR1_IC1F;
    TIM2->CCMR1 |= (0x3U << 4);
}

void startHardwareTimerBurst(int stepCount, uint16_t burstPeriodUs = 0, uint32_t burstPeriodQ16 = 0) {
    if (stepCount <= 0 || movementState == STATE_FAULT || movementState == STATE_ABORTED) return;

    // ATOMIC CRITICAL SECTION: protect the burst queue and TIM1 start sequence.
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    uint32_t nowUs = get_hardware_timestamp_us();
    hwBurstPeriodQ16 = burstPeriodQ16 ? burstPeriodQ16 : ((uint32_t)burstPeriodUs << SERVO_PERIOD_Q_SHIFT);
    if (burstPeriodQ16 == 0U && burstPeriodUs == 0U) hwBurstPeriodQ16 = servoPeriodQ16;
    hwBurstPeriodFrac = 0;
    static uint32_t s_burstSeq = 0;

    if (hwBurstActive) {
        // Enqueue into authoritative production SPSC BurstQueue
        bool enqueued = burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, (uint32_t)hwBurstPeriodQ16);
        if (enqueued) {
#if DEBUG_TEST_MODE
            burstQueuedCount++;
            queuedPulseCount += stepCount;
#endif
        }
        movementState = STATE_RUNNING;
        __set_PRIMASK(primask);
        return;
    }

    // Active burst is idle: enqueue into BurstQueue and immediately dequeue to start TIM1
    burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, (uint32_t)hwBurstPeriodQ16);
    BurstItem item{};
    burstQueue.dequeue(item);

    if (item.periodUs >= 8U && item.periodUs <= 500U) {
        activePulseWidth = (int)item.periodUs;
    }
    hwBurstStepsTarget = (int)item.stepCount;
    hwBurstStepsDone   = 0;
    hwBurstActive      = true;
#if DEBUG_TEST_MODE
    burstStartedCount++;
    startedPulseCount += stepCount;
#endif
    stepsRemaining     = stepCount;
    totalStepsInBurst  = stepCount;
    stepPinState       = HIGH;
    movementState      = STATE_RUNNING;

    // The servo is the mechanical master. Do not invent an acceleration ramp here.
    // activePulseWidth is derived from the most recent physical trigger interval;
    // maxRPMSetting is only the startup/fallback bound before the first valid interval.
    uint16_t initPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
    activePulseWidth = (int)initPeriodUs;
    uint16_t initARR = (initPeriodUs > 1) ? (uint16_t)(initPeriodUs - 1) : 1;
    TIM1->CR1 &= ~TIM_CR1_CEN;
    TIM1->PSC  = 71;
    TIM1->RCR  = 0;
    TIM1->ARR  = initARR;

    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;

    // Ensure PWM Mode 2, preload, active-low polarity, and OPM disabled
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    TIM1->CCMR1 |= (0x7U << 4) | TIM_CCMR1_OC1PE;
    TIM1->CCER  |= TIM_CCER_CC1P;
    TIM1->CR1   |= TIM_CR1_ARPE;
    TIM1->CR1   &= ~TIM_CR1_OPM;

    // Force load preload registers into shadow registers and reset CNT to 0
    // Temporarily mask UIE so EGR_UG does not latch a spurious update interrupt into NVIC
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR   = TIM_EGR_UG;
    TIM1->SR   &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    TIM1->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM1_UP_IRQn);

    // Enable hardware PWM output and Main Output Enable on PA8 in silicon before AF switch
    TIM1->CCER |= TIM_CCER_CC1E;
    TIM1->BDTR |= TIM_BDTR_MOE;

    // Connect PA8 directly to TIM1_CH1: Alternate Function Push-Pull 50MHz
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0xBU << 0); // 1011b = AF Output Push-Pull 50MHz

    // Start timer counter in silicon
    TIM1->CR1 |= TIM_CR1_CEN;

    __set_PRIMASK(primask);
}

void stopHardwareTimerImmediately() {
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    TIM1->CCER &= ~TIM_CCER_CC1E; // Disable hardware PWM output on PA8 in silicon
    TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
    TIM1->CR1  &= ~TIM_CR1_OPM;   // Ensure OPM cleared

    // Restore PA8 pin to General Purpose Output HIGH (Idle)
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;

    // Clear all pending flags and interrupts
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

    uint32_t abortedFromQueue = burstQueue.abortAll();
#if DEBUG_TEST_MODE
    int uncompleted = (hwBurstStepsTarget - hwBurstStepsDone) + (int)abortedFromQueue;
    if (uncompleted > 0) {
        abortedPulseCount += uncompleted;
        queuedPulseCount = 0;
    }
#else
    (void)abortedFromQueue;
#endif

    hwBurstActive      = false;
    hwBurstStepsTarget = 0;
    hwBurstStepsDone   = 0;
    stepsRemaining     = 0;
    movementState      = isSensorFaultTripped ? STATE_FAULT : STATE_ABORTED;

    __set_PRIMASK(primask);
}

void recalculatePitchProfiles() {
    // Explicit numerical bounds checking
    if ((rollerDia != rollerDia) || rollerDia < 15.0f || rollerDia > 100.0f) rollerDia = 45.0f;
    if (driverResolution < 200 || driverResolution > 51200) driverResolution = 6400;
    double circumference = 3.14159265358979323846 * (double)rollerDia;
    double pulsesPerMM = (double)driverResolution / circumference;
    // 64-bit intermediate arithmetic: strictly prevents uint32_t overflow at max 51200 res / 15mm roller
    const double pitch5 = 1.54625411;  // Calibrated for 70.00 pulses at 6400 res / 45mm roller
    const double pitch8 = 1.76714755;  // Calibrated for 80.00 pulses at 6400 res / 45mm roller
    const double pitch10 = 2.20893444; // Calibrated for 100.00 pulses at 6400 res / 45mm roller
    p5_fixed  = (uint64_t)(pitch5 * pulsesPerMM * 1000000.0 + 0.5);
    p8_fixed  = (uint64_t)(pitch8 * pulsesPerMM * 1000000.0 + 0.5);
    p10_fixed = (uint64_t)(pitch10 * pulsesPerMM * 1000000.0 + 0.5);
    if (p5_fixed < 1000000ULL) p5_fixed = 1000000ULL;
    if (p8_fixed < 1000000ULL) p8_fixed = 1000000ULL;
    if (p10_fixed < 1000000ULL) p10_fixed = 1000000ULL;
}

void syncPulseIntegerFraction() {
    uint32_t intPart  = (uint32_t)(currentPulsesFixed / 1000000ULL);
    uint32_t fracPart = (uint32_t)(currentPulsesFixed % 1000000ULL);
    currentPulsesInt  = intPart;
    currentPulsesFrac = fracPart;
    commitPulseParameters(intPart, fracPart);
}

void updateActivePulseWidth() {
    syncPulseIntegerFraction();
    if (maxRPMSetting < 100 || maxRPMSetting > 4000) maxRPMSetting = 3000;
    if (feedAngleDeg < 30 || feedAngleDeg > 270) feedAngleDeg = 160;
    if (safetyMarginPercent < 0 || safetyMarginPercent > 25) safetyMarginPercent = 10;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));
    float activeSteps = (float)currentPulsesFixed / 1000000.0f;
    if (activeSteps < 1.0f) activeSteps = 1.0f;
    // Startup/fallback STEP period only; runtime period is replaced by measured servo timing.
    double requestedPeriodUs = (double)timeWindowUs / (double)activeSteps;
    refreshPulseTimingValidity();
    if (requestedPeriodUs < (double)SERVO_PERIOD_MIN_US) {
        // Do not hide an impossible manual tuning behind the 8us timer clamp.
        // Keep the timer at its safe floor, but mark the configuration invalid so
        // the UI/start path can block motion until the operator corrects it.
        pulseTimingInvalid = true;
        activePulseWidth = SERVO_PERIOD_MIN_US;
        return;
    }
    int calcPeriod = (int)requestedPeriodUs;
    if (calcPeriod > (int)SERVO_PERIOD_MAX_US) calcPeriod = SERVO_PERIOD_MAX_US;
    activePulseWidth = calcPeriod;
}

void calculateAllPulseWidths() {
    if (maxRPMSetting <= 0) maxRPMSetting = 3000;
    if (feedAngleDeg <= 0) feedAngleDeg = 160;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));

    float s5 = (float)p5_fixed / 1000000.0f;
    if (s5 < 1.0f) s5 = 1.0f;
    // Safe industrial limit: Full step period [8us, 500us] (guarantees >= 2.5us driver opto timing)
    autoPulseWidth_P5 = constrain((int)(timeWindowUs / s5), 8, 500);

    float s8 = (float)p8_fixed / 1000000.0f;
    if (s8 < 1.0f) s8 = 1.0f;
    autoPulseWidth_P8 = constrain((int)(timeWindowUs / s8), 8, 500);

    float s10 = (float)p10_fixed / 1000000.0f;
    if (s10 < 1.0f) s10 = 1.0f;
    autoPulseWidth_P10 = constrain((int)(timeWindowUs / s10), 8, 500);

    updateActivePulseWidth();

    // 50% nominal period debounce: completely rejects trailing edge & contactor EMI noise
    dynamicDebounceUs = 3000UL; // Legacy UI/diagnostic value; trigger qualification uses measured adaptive blanking.
}

void evaluateDiagnostics() {
    float tempDia  = (tempRollerDia > 0.1f) ? tempRollerDia : 45.0f;
    int32_t tempRes   = (tempDriverRes > 200) ? tempDriverRes : 6400;
    int32_t tempRPM   = (tempMaxRPM > 100) ? tempMaxRPM : 3000;
    int32_t tempAngle  = (tempFeedAngle > 10) ? tempFeedAngle : 160;
    int32_t tempMargin = constrain(tempSafetyMargin, 0, 25);

    float tempCirc = 3.14159265f * tempDia;
    float tempPPM  = (float)tempRes / tempCirc;
    float s10_test = 4.00f * tempPPM;
    if (s10_test < 1.0f) s10_test = 1.0f;

    float timeWinTest = (60000000.0f / (float)tempRPM) * ((float)tempAngle / 360.0f) * (1.0f - ((float)tempMargin / 100.0f));
    diagMinW = (int)(timeWinTest / s10_test);

    if (diagMinW < 6) {
        isTimingWarningActive = true;
        if (tempRes > 12800) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET RES <= 12800";
        } else if (tempAngle < 120) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "INC ANGLE >= 150";
        } else if (tempRPM > 2500) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RPM <= 2500 ";
        } else if (tempMargin > 15) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET MARGIN 10%  ";
        } else {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RES/INC ANG ";
        }
    } else {
        isTimingWarningActive = false;
        diagFixLine1 = "TIMING HEALTH:  ";
        diagFixLine2 = "SYSTEM OPTIMAL  ";
    }
}

// =========================================================================
// TWO-PHASE ATOMIC DEFERRED TRIGGER DISPATCH ENGINE (SECTION 6 RACE FIX)
// Dispatches any triggers deferred during Flash save/abort window.
// Prevents newer incoming physical triggers from overtaking older deferred work.
// Only after deferred pulses are safely handed off does the lock return to IDLE.
// =========================================================================
static void dispatchDeferredSaveTriggers() {
    for (;;) {
        uint8_t defDir = 0;
        uint32_t defTs = 0;
        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        uint32_t defSteps = flashSaveTx.captureDeferredForDispatch(defDir, defTs);
        const bool stillPending = flashSaveTx.deferredTriggerPending;
        if (defSteps == 0U && !stillPending) {
            // Close the handoff while IRQs are masked so no ISR can enqueue between
            // the final empty check and SAVE_LOCK_IDLE.
            flashSaveTx.completeHandoff();
            __set_PRIMASK(primask);
            break;
        }
        __set_PRIMASK(primask);

        if (defSteps == 0U) continue;
        if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
            if (hardwareTimerMode) {
                startHardwareTimerBurst((int)defSteps);
            } else {
                primask = __get_PRIMASK();
                __disable_irq();
                stepsRemaining += (int)defSteps;
                totalStepsInBurst = stepsRemaining;
                __set_PRIMASK(primask);
            }
        } else {
#if DEBUG_TEST_MODE
            abortedPulseCount += (int)defSteps;
#endif
        }
    }
}

bool saveToEEPROM() {
    // Watchdog-safe persistence: only allowed at confirmed standstill.
    IWDG_FEED();
    // 1. Request Atomic Save Lock (SAVE_LOCK_IDLE -> SAVE_LOCK_ACQUIRING)
    if (!isMachineSafelyIdle()) return false;
    IWDG_FEED();
    if (!flashSaveTx.requestSaveLock()) {
        IWDG_FEED();
        return false;
    }

    // 2. Authoritative Safe-Save Precondition Check & Lock Confirmation
    if (!flashSaveTx.confirmLockAndTransition(isMachineSafelyIdle())) {
        dispatchDeferredSaveTriggers();
        IWDG_FEED();
        return false; // Prohibited while machine moving or safety fault active
    }

    // 3. Prepare Candidate Dual-Slot Record
    uint32_t targetSlot = 1 - activeEEPROMSlot;
    int targetOffset = (targetSlot == 0) ? 0 : 128;
    uint32_t nextSeq = eepromSeqNumber + 1;

    MachineConfigRecord rec;
    rec.magic    = EEPROM_MAGIC_V17_0_0;
    rec.seq      = nextSeq;
    rec.reserved = 0;

    rec.payload.p5_fixed            = p5_fixed;
    rec.payload.p8_fixed            = p8_fixed;
    rec.payload.p10_fixed           = p10_fixed;
    rec.payload.driverResolution    = driverResolution;
    rec.payload.rollerDia           = rollerDia;
    rec.payload.maxRPMSetting       = maxRPMSetting;
    rec.payload.feedAngleDeg        = feedAngleDeg;
    rec.payload.safetyMarginPercent = safetyMarginPercent;
    rec.payload.currentSize         = currentSize;
    rec.payload.sensorGuardActive   = sensorFeatureMask();
    rec.payload.hardwareTimerMode   = 0; // Primary STEP engine is TIM1 hardware; DDA remains diagnostic-only.
    rec.payload.motorDirection      = motorDirection ? 1 : 0;
    rec.payload.startSpeedPercent   = startSpeedPercent;

    // 4. Complete-Payload Equality Check against active persisted payload (Section 6)
    MachineConfigRecord activeRec;
    int activeOffset = (activeEEPROMSlot == 0) ? 0 : 128;
    EEPROM.get(activeOffset, activeRec);
    if (PulseStepPersistenceManager::validateRecord(activeRec) &&
        memcmp(&rec.payload, &activeRec.payload, sizeof(MachineConfigPayload)) == 0) {
        // Complete serialized payload identical: synchronize baseline flags & skip Flash write (0 writes)
        pulseStepStored_p5  = p5_fixed;
        pulseStepStored_p8  = p8_fixed;
        pulseStepStored_p10 = p10_fixed;
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
        dispatchDeferredSaveTriggers();
        IWDG_FEED();
        return true;
    }

    rec.crc32 = calculateCRC32((const uint8_t*)&rec.payload, sizeof(MachineConfigPayload));

    // 5. Flash Programming is permitted ONLY after the authoritative standstill gate.
    // PA0 trigger path is active, but a physical machine must not be moving during persistence.
    IWDG_FEED();
    EEPROM.put(targetOffset, rec);
    IWDG_FEED();

    // 6. Verification Read-back
    MachineConfigRecord readBack;
    EEPROM.get(targetOffset, readBack);

    bool saveOk = false;
    if (PulseStepPersistenceManager::validateRecord(readBack) &&
        memcmp(&rec, &readBack, sizeof(MachineConfigRecord)) == 0) {
        // Successfully verified in ROM
        flashWriteCount++;
        activeEEPROMSlot = targetSlot;
        eepromSeqNumber  = nextSeq;

        // Synchronize stored baseline
        pulseStepStored_p5  = p5_fixed;
        pulseStepStored_p8  = p8_fixed;
        pulseStepStored_p10 = p10_fixed;
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
        calculateAllPulseWidths();
        saveOk = true;
    }

    // 7. Atomic Handoff and Dispatch of Any Triggers Deferred During Save Window (Section 6)
    dispatchDeferredSaveTriggers();
    IWDG_FEED();
    return saveOk;
}

void loadFactoryDefaults() {
    driverResolution    = 6400;
    rollerDia           = 45.0f;
    maxRPMSetting       = 3000;
    feedAngleDeg        = 90;
    safetyMarginPercent = 15;
    startSpeedPercent   = 100;
    tempStartSpeed      = 100;
    resStepGear         = 100;
    diaStepGear         = 0.1f;
    rpmStepGear         = 50;
    angleStepGear       = 1;
    marginStepGear      = 1;
    currentSize         = 2; // Size #8 default
    sensorGuardActive   = false;
    coilGuardActive     = false;
    pb3GuardActive      = false;
    motionRelayEnabled  = false; // All auxiliary stop features OFF by default
    hardwareTimerMode   = true;  // AUTONOMOUS HARDWARE ENGINE DEFAULT
    motorDirection      = false; // NORMAL FORWARD DEFAULT
    applyMotorDirection();
    recalculatePitchProfiles();
    p5_fixed            = 70000000ULL;
    p8_fixed            = 80000000ULL;
    p10_fixed           = 100000000ULL;
    currentPulsesFixed  = p8_fixed;
    stepGearFixed       = 1000000ULL;
    calculateAllPulseWidths();
    pulseStepStored_p5  = p5_fixed;
    pulseStepStored_p8  = p8_fixed;
    pulseStepStored_p10 = p10_fixed;
    pulseModifiedByUser = false;
    hasStagedChanges    = false;
}

void loadFromEEPROM() {
    MachineConfigRecord rec0, rec1;
    EEPROM.get(0, rec0);
    EEPROM.get(128, rec1);

    bool v0 = PulseStepPersistenceManager::validateRecord(rec0);
    bool v1 = PulseStepPersistenceManager::validateRecord(rec1);

    MachineConfigRecord *chosen = nullptr;
    uint32_t chosenSlot = 0;

    if (v0 && v1) {
        if (rec0.seq >= rec1.seq) {
            chosen = &rec0;
            chosenSlot = 0;
        } else {
            chosen = &rec1;
            chosenSlot = 1;
        }
    } else if (v0) {
        chosen = &rec0;
        chosenSlot = 0;
    } else if (v1) {
        chosen = &rec1;
        chosenSlot = 1;
    }

    if (chosen != nullptr) {
        // Valid transactional record found
        activeEEPROMSlot = chosenSlot;
        eepromSeqNumber  = chosen->seq;

        p5_fixed            = chosen->payload.p5_fixed;
        p8_fixed            = chosen->payload.p8_fixed;
        p10_fixed           = chosen->payload.p10_fixed;
        driverResolution    = chosen->payload.driverResolution;
        rollerDia           = chosen->payload.rollerDia;
        maxRPMSetting       = chosen->payload.maxRPMSetting;
        feedAngleDeg        = chosen->payload.feedAngleDeg;
        safetyMarginPercent = chosen->payload.safetyMarginPercent;
        currentSize         = chosen->payload.currentSize;
        applySensorFeatureMask(chosen->payload.sensorGuardActive);
        hardwareTimerMode   = true; // PRIMARY POLICY: every boot starts on TIM1 STEP hardware; DDA remains diagnostic-only.
        motorDirection      = (chosen->payload.motorDirection == 1);
        startSpeedPercent   = (chosen->payload.startSpeedPercent >= 10 && chosen->payload.startSpeedPercent <= 100) ? chosen->payload.startSpeedPercent : 100;

        applyMotorDirection();
        // Preserve stored user-tuned p5_fixed, p8_fixed, p10_fixed from EEPROM!
        // Only fall back to recalculatePitchProfiles() if a stored pulse count is out of valid range.
        if (p5_fixed < PULSE_STEP_MIN_FIXED || p5_fixed > PULSE_STEP_MAX_FIXED ||
            p8_fixed < PULSE_STEP_MIN_FIXED || p8_fixed > PULSE_STEP_MAX_FIXED ||
            p10_fixed < PULSE_STEP_MIN_FIXED || p10_fixed > PULSE_STEP_MAX_FIXED) {
            recalculatePitchProfiles();
        }
        calculateAllPulseWidths();

        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        if (currentSize == 1) currentPulsesFixed = p5_fixed;
        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
        else currentPulsesFixed = p10_fixed;
        __set_PRIMASK(primask);
        updateActivePulseWidth();

        pulseStepStored_p5  = p5_fixed;
        pulseStepStored_p8  = p8_fixed;
        pulseStepStored_p10 = p10_fixed;
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
    } else {
        // Check legacy single-slot format (V16.5.0 / V16.4.0 / V16.3.3)
        MachineConfigLegacy leg;
        EEPROM.get(0, leg);
        if (leg.magic == EEPROM_MAGIC || (leg.driverResolution >= 200 && (leg.rollerDia == leg.rollerDia) && leg.rollerDia > 0.1f)) {
            p5_fixed            = (uint64_t)leg.p5_fixed;
            p8_fixed            = (uint64_t)leg.p8_fixed;
            p10_fixed           = (uint64_t)leg.p10_fixed;
            driverResolution    = leg.driverResolution;
            rollerDia           = leg.rollerDia;
            maxRPMSetting       = (leg.maxRPMSetting >= 100 && leg.maxRPMSetting <= 4000) ? leg.maxRPMSetting : 3000;
            feedAngleDeg        = (leg.feedAngleDeg >= 30 && leg.feedAngleDeg <= 270) ? leg.feedAngleDeg : 160;
            safetyMarginPercent = (leg.safetyMarginPercent <= 25) ? leg.safetyMarginPercent : 10;
            currentSize         = (leg.currentSize >= 1 && leg.currentSize <= 3) ? leg.currentSize : 1;
            startSpeedPercent   = 100;
            sensorGuardActive   = false;
            coilGuardActive     = false;
            pb3GuardActive      = false;
            motionRelayEnabled  = false;
            hardwareTimerMode   = true;
            motorDirection      = false;
            applyMotorDirection();
            if (p5_fixed < PULSE_STEP_MIN_FIXED || p5_fixed > PULSE_STEP_MAX_FIXED ||
                p8_fixed < PULSE_STEP_MIN_FIXED || p8_fixed > PULSE_STEP_MAX_FIXED ||
                p10_fixed < PULSE_STEP_MIN_FIXED || p10_fixed > PULSE_STEP_MAX_FIXED) {
                recalculatePitchProfiles();
            }
            uint32_t primask = __get_PRIMASK();
            __disable_irq();
            if (currentSize == 1) currentPulsesFixed = p5_fixed;
            else if (currentSize == 2) currentPulsesFixed = p8_fixed;
            else currentPulsesFixed = p10_fixed;
            __set_PRIMASK(primask);
            calculateAllPulseWidths();

            // Migrated baseline:
            pulseStepStored_p5  = p5_fixed;
            pulseStepStored_p8  = p8_fixed;
            pulseStepStored_p10 = p10_fixed;
            pulseModifiedByUser = false;
            autoSavePendingStandstill = false;
            hasStagedChanges    = false;
        } else {
            loadFactoryDefaults();
        }
    }
}

// PRIMARY MOTION PATH: PA0 falling-edge trigger -> this ISR -> one synchronized PA8 STEP burst.
// Auxiliary sensors/relay logic must never preempt, abort, or replace this path.
// Reset only the RPM display estimator; raw timing/safety state remains separate.
static inline void resetRpmIntervalHistory() {
    rpmIntervalHistoryUs[0] = 0UL;
    rpmIntervalHistoryUs[1] = 0UL;
    rpmIntervalHistoryUs[2] = 0UL;
    rpmIntervalHistoryCount = 0U;
    rpmIntervalHistoryIndex = 0U;
}

static inline uint32_t median3u32(uint32_t a, uint32_t b, uint32_t c) {
    if (a > b) { uint32_t t = a; a = b; b = t; }
    if (b > c) { uint32_t t = b; b = c; c = t; }
    if (a > b) { uint32_t t = a; a = b; b = t; }
    return b;
}

// Process one PA0 falling edge using its TIM2 hardware-captured timestamp.
// Process one accepted PA0 edge. This function receives the monotonic TIM4 timestamp from sensorISR.
void processSensorTrigger(uint32_t capturedTimestampUs) {
    const uint32_t nowUs = capturedTimestampUs;
    unsigned long diff = 0;

    if (lastTriggerMicros == 0UL) {
        lastMeasuredIntervalUs = 0UL;
        currentRPM = 0UL;
        resetRpmIntervalHistory();
        acceptedTriggerPulses++;
        validTriggerCount = 1U;
        motionWatchdogArmed = false;
    } else {
        // Both values are extended TIM2 capture timestamps (1 tick = 1 us).
        // Unsigned subtraction is wrap-safe across the 32-bit timestamp rollover.
        diff = (uint32_t)(nowUs - (uint32_t)lastTriggerMicros);

        if (diff > 2000000UL) {
            // Standstill: the next edge is a new first edge. Do not watchdog it.
            lastMeasuredIntervalUs = 0UL;
            currentRPM = 0UL;
            resetRpmIntervalHistory();
            acceptedTriggerPulses++;
            validTriggerCount = 1U;
            motionWatchdogArmed = false;
            diff = 0UL; // This edge re-baselines motion; do not turn standstill time into STEP period.
            isCaptureStreamDiscontinuous = false;
        } else if (isCaptureStreamDiscontinuous) {
            // Overcapture recovery: CCR1 was overwritten before service, so diff spans 2+ physical cycles.
            // Do NOT let this 2x artifact drop the displayed RPM or stretch the STEP burst!
            isCaptureStreamDiscontinuous = false;
            tim2CaptureResyncEvents++;
            // Resynchronize to the continuous operating interval so RPM and STEP timing remain stable
            if (lastMeasuredIntervalUs > 0UL) {
                diff = lastMeasuredIntervalUs;
            } else if (diff > 0UL) {
                diff = diff / 2UL; // Estimate single-revolution period if overcapture occurred on startup
                lastMeasuredIntervalUs = diff;
            }
            acceptedTriggerPulses++;
            validTriggerCount++;
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
                if (motionRelayEnabled) GPIOB->BRR = (1U << 1);
            }
        } else {
            // Speed-adaptive software blanking: 1.5ms minimum and 4.5ms maximum.
            unsigned long activeBlankingUs = 1000UL;
            if (lastMeasuredIntervalUs > 0UL) {
                activeBlankingUs = lastMeasuredIntervalUs / 4UL; // 25% of previous revolution
                if (activeBlankingUs < 1000UL) activeBlankingUs = 1000UL;
                if (activeBlankingUs > 4000UL) activeBlankingUs = 4000UL;
            }

            // Speed-adaptive software blanking: 1.0ms minimum and 4.0ms maximum.
            // CRITICAL NEEDLE SAFETY INVARIANT: Every needle cycle MUST produce a STEP burst!
            // If a pulse is dropped or rejected, the zipper tape remains stationary while the needle
            // plunges into the coil, jamming or breaking the needle.
            // We reject ONLY sub-millisecond switch contact chatter (< activeBlankingUs).
            // Never drop a cycle due to machine speed exceeding maxRPMSetting.
            if (diff < activeBlankingUs) {
                rejectedTriggerCount++;
                return; // Pure sub-millisecond optocoupler contact chatter rejected
            }

            // Servo plausibility guard: at configured max RPM, one revolution has
            // 60,000,000/maxRPMSetting us. Allow 25% speed headroom (period >= 75% of
            // that value), which rejects 4.5-9ms false edges while allowing a 3000 RPM
            // machine (20ms/rev) and brief speed transients up to ~4000 RPM.
            uint32_t configuredMaxRPM = (maxRPMSetting >= 100 && maxRPMSetting <= 4000)
                ? (uint32_t)maxRPMSetting : 3000UL;
            uint32_t minimumPlausibleIntervalUs = (60000000UL / configuredMaxRPM) * 3UL / 4UL;
            if (diff < minimumPlausibleIntervalUs) {
                rejectedTriggerCount++;
                return; // Implausibly fast edge: keep lastTriggerMicros unchanged.
            }

            lastMeasuredIntervalUs = diff;
            acceptedTriggerPulses++;
            validTriggerCount++;
            // A real interval now exists: this is the first point at which
            // motion-loss monitoring is allowed to arm.
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
                if (motionRelayEnabled) GPIOB->BRR = (1U << 1);
            }

        }
    }

    // The RPM display and STEP scheduler share a three-interval history, but raw diff
    // remains authoritative for qualification/watchdog. STEP scheduling uses the median
    // once three valid intervals exist to reject isolated long/short timing outliers.
    if (lastTriggerMicros != 0UL && diff > 0UL && diff <= 2000000UL) {
        rpmIntervalHistoryUs[rpmIntervalHistoryIndex] = (uint32_t)diff;
        rpmIntervalHistoryIndex = (uint8_t)((rpmIntervalHistoryIndex + 1U) % 3U);
        if (rpmIntervalHistoryCount < 3U) rpmIntervalHistoryCount++;

        uint32_t rpmIntervalForDisplay = (uint32_t)diff;
        if (rpmIntervalHistoryCount >= 3U) {
            rpmIntervalForDisplay = median3u32(rpmIntervalHistoryUs[0],
                                               rpmIntervalHistoryUs[1],
                                               rpmIntervalHistoryUs[2]);
        }

        if (rpmIntervalForDisplay > 0UL) {
            const unsigned long instantRPM = 60000000UL / rpmIntervalForDisplay;
            if (instantRPM > 0UL && instantRPM <= 40000UL) {
                if (currentRPM == 0UL) currentRPM = instantRPM;
                else currentRPM = (unsigned long)((3UL * instantRPM + 5UL * currentRPM) / 8UL);
            }
        }
    } else if (diff > 2000000UL) {
        currentRPM = 0UL;
        resetRpmIntervalHistory();
    }
    // Use a robust interval for STEP scheduling, distinct from the raw interval
    // used for trigger qualification and watchdog. A single missed/late edge can
    // produce one long interval; median-of-three prevents that outlier from directly
    // stretching the next PA8 burst. This cannot reconstruct a physically missed edge.
    uint32_t stepTimingIntervalUs = (uint32_t)diff;
    if (lastTriggerMicros != 0UL && diff > 0UL && diff <= 2000000UL &&
        rpmIntervalHistoryCount >= 3U) {
        stepTimingIntervalUs = median3u32(rpmIntervalHistoryUs[0],
                                          rpmIntervalHistoryUs[1],
                                          rpmIntervalHistoryUs[2]);
    }

    lastTriggerMicros = nowUs;
    STATUS_LED_ON(); // LED marks captured PA0 trigger activity; not an independent heartbeat.

    // 3. Atomic Coherent Parameter Snapshot & Zero-Latency Stepper Burst Triggering
    // An impossible manually tuned pulse count must never be converted into a
    // silently clamped burst. Requiring the operator to correct it protects both
    // TIM2 and DDA from running outside the configured timing envelope.
    if (pulseTimingInvalid) {
        return;
    }
    if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        // Capture integer and fractional microsteps from the exact same generation
        PulseParameters snap;
        snap.integerPart = activePulseParams.integerPart;
        snap.fractionalPart = activePulseParams.fractionalPart;
        snap.generation = activePulseParams.generation;
#if DEBUG_TEST_MODE
        paramGenerationUsed = snap.generation;
        acceptedTriggerCount++;
        requestedPulseCount += snap.integerPart;
#endif
        int newSteps = (int)snap.integerPart;
        pulseFracAccumulator += snap.fractionalPart;
        if (pulseFracAccumulator >= 1000000UL) {
            newSteps++;
            pulseFracAccumulator -= 1000000UL;
#if DEBUG_TEST_MODE
            requestedPulseCount++;
#endif
        }

        // Servo is the master: derive this trigger's burst period from the exact
        // physical revolution interval and exact integer pulse count for this burst.
        // First trigger has no interval yet: soft-start percentage (10% to 100% of maxRPMSetting)
        // prevents stepper torque slip and needle collisions during machine cold start.
        uint32_t effectiveStartRPM = ((uint32_t)maxRPMSetting * (uint32_t)startSpeedPercent) / 100UL;
        if (effectiveStartRPM < 300UL) effectiveStartRPM = 300UL;
        if (effectiveStartRPM > (uint32_t)maxRPMSetting) effectiveStartRPM = (uint32_t)maxRPMSetting;
        uint32_t startupRevUs = (effectiveStartRPM > 0UL)
            ? (uint32_t)(60000000UL / effectiveStartRPM) : 20000UL;
        uint32_t burstPeriodQ16 = (stepTimingIntervalUs > 0UL)
            ? calculateAdaptiveStepPeriodQ16(stepTimingIntervalUs, (uint32_t)newSteps)
            : calculateAdaptiveStepPeriodQ16(startupRevUs, (uint32_t)newSteps);
        uint16_t burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        if (burstPeriodUs < SERVO_PERIOD_MIN_US) burstPeriodUs = SERVO_PERIOD_MIN_US;
        if (burstPeriodUs > SERVO_PERIOD_MAX_US) burstPeriodUs = SERVO_PERIOD_MAX_US;
        if (stepTimingIntervalUs > 0UL) {
            updateStepPeriodFromServoInterval(stepTimingIntervalUs, (uint32_t)newSteps);
            burstPeriodQ16 = servoPeriodQ16;
            burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        }

        if (newSteps > 0) {
            if (flashSaveTx.isSaveLockActive()) {
                // Defer incoming trigger during save window without losing it!
                flashSaveTx.deferTrigger(newSteps, motorDirection ? 1 : 0, nowUs);
            } else if (hardwareTimerMode) {
                startHardwareTimerBurst(newSteps, burstPeriodUs, burstPeriodQ16);
            } else {
                uint32_t primask = __get_PRIMASK();
                __disable_irq();
                if (stepsRemaining == 0) {
                    stepsRemaining = newSteps;
                    totalStepsInBurst = stepsRemaining;
                    currentStepIndex = 0;
                    lastStepMicros = micros();
                } else {
                    stepsRemaining += newSteps;
                    totalStepsInBurst = stepsRemaining;
                }
                __set_PRIMASK(primask);
            }
        }
    }

    // 4. Signal background loop to exit menu if machine starts running while in settings
    // Keep the explicitly selected Info/Diag page visible during motion.
    // Every other menu remains subject to the original automatic safety exit.
    if (menuState != 0 && menuState != 9) {
        pendingMenuExit = true;
    }
}

void setup() {
    // Hardware Safety: Ensure Main Motor Relay Pin (PB1) is driven LOW in hardware before setting OUTPUT
    GPIOB->BRR = (1 << 1); // Atomic Clear PB1 LOW
    pinMode(mainMotorRelayPin, OUTPUT);
    digitalWrite(mainMotorRelayPin, LOW);

    pinMode(stepPin, OUTPUT);
    pinMode(dirPin, OUTPUT);
    applyMotorDirection();
    STEP_HIGH_IDLE();

    pinMode(proxSensorPin, INPUT_PULLUP);
    pinMode(tapeSensorPin, INPUT_PULLUP);
    pinMode(coilSensorPin, INPUT_PULLUP);
    pinMode(futureSensor2Pin, INPUT_PULLUP);

    pinMode(btnUp, INPUT_PULLUP);
    pinMode(btnDown, INPUT_PULLUP);
    pinMode(btnMode, INPUT_PULLUP);

    pinMode(statusLedPin, OUTPUT);
    STATUS_LED_OFF(); // Built-in LED initial state: OFF

    // Initialize ARM Cortex-M3 DWT Cycle Counter for Sub-Microsecond Hardware Timestamping
#if defined(CoreDebug) && defined(DWT)
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
#endif

    // Load configuration and arm the primary motion path before any UI splash.
    // This guarantees that servo/proximity activity is never hidden behind a boot delay.
    loadFromEEPROM();
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
    initFreeRunningTimer4(); // Start watchdog/UI epoch before arming the capture source.
#endif
    initHardwareTimer2();    // PA0 TIM2_CH1 hardware capture is the sole trigger dispatcher.
    initHardwareSafetyTimer3();

    // No PA0 EXTI attachment: sensor events are dispatched only by TIM2 capture callback.
    // Strict NVIC Priority Hierarchy:
    // Priority 0: TIM1_UP (PA8 STEP pulse generator - highest possible priority, zero pulse jitter)
    // Priority 1: TIM2_IRQn (PA0 Cam Proximity trigger - immediate hardware preemption)
    // Priority 2: TIM3_IRQn (PA3/PB0 Auxiliary safety timer)
    // Priority 3: SysTick_IRQn (Background Arduino timebase)
    NVIC_SetPriority(TIM1_UP_IRQn, 0);
    NVIC_SetPriority(TIM3_IRQn, 2);
    NVIC_SetPriority(SysTick_IRQn, 3);
    IWDG_INIT();

    #ifndef RCC_CSR_IWDGRSTF
    #define RCC_CSR_IWDGRSTF (1U << 29)
    #endif
    #ifndef RCC_CSR_RMVF
    #define RCC_CSR_RMVF (1U << 24)
    #endif

    const bool isWatchdogReset = (RCC->CSR & RCC_CSR_IWDGRSTF) != 0U;
    RCC->CSR |= RCC_CSR_RMVF; // Clear reset status flags

    Wire.begin();
    Wire.setClock(400000);
#if defined(WIRE_HAS_TIMEOUT) || defined(ARDUINO_ARCH_STM32)
    Wire.setTimeout(25000);
#endif
    lcd.init();
    lcd.backlight();
    lcd.clear();

    if (!isWatchdogReset) {
        // Cold Power-On Boot: Show 2-second Developer & Company branding
        lcd.setCursor(0, 0);
        lcd.print("DEV: RAJESH SHAH");
        lcd.setCursor(0, 1);
        lcd.print("NIPON ZIPPER IND");
        for (int i = 0; i < 20; i++) {
            IWDG_FEED();
            delay(100);
        }
    } else {
        // Fast-boot on Watchdog recovery: instant ready banner (< 100ms)
        lcd.setCursor(0, 0);
        lcd.print("FAST-BOOT READY ");
        lcd.setCursor(0, 1);
        lcd.print("IWDG RECOVERED  ");
        delay(100);
    }
}

void loop() {
    IWDG_FEED();

    // =========================================================================
    // INTERACTIVE STEPPER JOG BENCH TEST (Menu 9, Option 2)
    // Allows technician to verify motor FWD and REV directly without proximity sensor!
    // =========================================================================
    if (menuState == 9 && infoIndex == 1 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        static uint32_t lastJogUs = 0;
        uint32_t nowJog = micros();
        if (digitalRead(btnUp) == LOW) {
            // Forward Jog (1.2 kHz smooth testing speed)
            DIR_NORMAL();
            if ((uint32_t)(nowJog - lastJogUs) >= 800) {
                lastJogUs = nowJog;
                STEP_LOW_ACTIVE();
                delayMicroseconds(5);
                STEP_HIGH_IDLE();
            }
        } else if (digitalRead(btnDown) == LOW) {
            // Reverse Jog (1.2 kHz smooth testing speed)
            DIR_REVERSE();
            if ((uint32_t)(nowJog - lastJogUs) >= 800) {
                lastJogUs = nowJog;
                STEP_LOW_ACTIVE();
                delayMicroseconds(5);
                STEP_HIGH_IDLE();
            }
        } else {
            applyMotorDirection(); // Restore configured direction when released
        }
    }

    // =========================================================================
    // INTERACTIVE OPTOCOUPLER SINKING BENCH TEST (Menu 9, Option 8)
    // Allows technician to verify PUL- <= 0.5V with standard Digital Multimeter
    // =========================================================================
    if (menuState == 9 && infoIndex == 2 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        if (digitalRead(btnUp) == LOW) {
            STEP_LOW_ACTIVE(); // Force PA8 LOW (Sinks DM542 PUL- to GND)
            stepPinState = LOW;
        } else {
            STEP_HIGH_IDLE();  // Release to Idle HIGH (+5V through optocoupler)
            stepPinState = HIGH;
        }
    }

    // Safely return to IDLE when any previous burst or abort has finished
    if (!hwBurstActive && stepsRemaining == 0) {
        if (movementState == STATE_COMPLETE || movementState == STATE_ABORTED) {
            movementState = STATE_IDLE; // Safely return to IDLE when machine is at rest
        }
    }

    // Onboard PC13 LED:
    // When machine is running, PC13 is controlled strictly by TIM2 trigger ISR (STATUS_LED_ON)
    // and TIM1 burst completion (STATUS_LED_OFF). Loop polling is gated strictly to STANDSTILL (0 RPM)
    // for manual handwheel alignment, eliminating any asynchronous interference or missed blinks during RUN!
    const bool isMachineRunning = (currentRPM > 0UL) || hwBurstActive ||
                                  (lastTriggerMicros != 0UL && ((uint32_t)(get_hardware_timestamp_us() - (uint32_t)lastTriggerMicros) < 2000000UL));
    if (!isMachineRunning) {
        if (digitalRead(proxSensorPin) == LOW) {
            STATUS_LED_ON();  // Cam detected in front of sensor at standstill (manual handwheel alignment)
        } else {
            STATUS_LED_OFF(); // Cam clear at standstill
        }
    }

    // =========================================================================
    // SAFETY GUARD STATUS & BYPASS CONTROLLER
    // Real-time sensor sampling & E-stop executed by 1 kHz TIM3 hardware interrupt.
    // =========================================================================
    // Auxiliary sensor state is deliberately isolated from the PA0->PA8 motion path.
    // If all auxiliary features are OFF, clear any stale relay/fault state.
    if (!sensorGuardActive && !coilGuardActive && !pb3GuardActive && !motionRelayEnabled) {
        auxSensorFaultActive = false;
        isSensorFaultTripped = false;
        GPIOB->BRR = (1U << 1);
        pa3FaultCounterMs = 0;
        pb0FaultCounterMs = 0;
    }

    // RPM Zeroing timeout if machine stops > 2.0s
    // Passive monitoring outside ISR: zero CPU overhead on TIM2
    static uint32_t lastSeenAcceptedTriggerCount = 0;
    static uint32_t lastTriggerActivityMs = 0;
    const uint32_t currentAcceptedTriggers = acceptedTriggerPulses;
    if (currentAcceptedTriggers != lastSeenAcceptedTriggerCount) {
        lastSeenAcceptedTriggerCount = currentAcceptedTriggers;
        lastTriggerActivityMs = millis();
    }
    if (millis() - lastTriggerActivityMs > 2000UL) {
        if (currentRPM > 0UL) {
            currentRPM = 0UL;
            lastMeasuredIntervalUs = 0UL; // Reset measured interval on standstill
            motionWatchdogArmed = false;
            isMotionSyncLost = false;
            // Keep oldMenuState intact to prevent lcd.clear() full redraw glitch on startup!
        }
        // Safety recovery: if >2.0s have elapsed with zero triggers, no sub-12ms burst can still be active
        if (hwBurstActive && (TIM1->CR1 & TIM_CR1_CEN) == 0U) {
            hwBurstActive = false;
            stepsRemaining = 0;
            movementState = STATE_IDLE;
        }
    }

    // =========================================================================
    // 2-MINUTE COOLDOWN STANDSTILL AUTO-SAVE ENGINE
    // Gated strictly to 0 RPM Standstill (Zero Pulse & Trigger Interference)
    // Anti-Repeat Latch: Saved exactly once per parameter modification
    // =========================================================================
    const bool isAnyDirty = (p5_fixed != pulseStepStored_p5) ||
                            (p8_fixed != pulseStepStored_p8) ||
                            (p10_fixed != pulseStepStored_p10) ||
                            pulseModifiedByUser ||
                            hasStagedChanges;
    pulseModifiedByUser = isAnyDirty;
    const bool isRpmFresh = (lastTriggerActivityMs != 0UL) && ((currentRPM > 0UL) || (millis() - lastTriggerActivityMs < 2000UL));
    autoSaveEngine.update(currentRPM, 300UL, isRpmFresh, false, false, (currentRPM == 0UL), isAnyDirty, millis());
    autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

    if (currentRPM == 0UL) {
        if (autoSaveEngine.autoSavePendingStandstill && isMachineSafelyIdle()) {
            if (isAnyDirty) {
                bool saveOk = saveToEEPROM();
                if (saveOk) {
                    stepGearFixed = 1000000ULL; // Reset gear to 1.00 pulse on save
                    uiBannerLine1 = "AUTO-SAVED OK!  ";
                    uiBannerLine2 = "SETTINGS SAVED  ";
                    autoSaveEngine.clearPendingSave();
                    autoSavePendingStandstill = false;
                } else {
                    uiBannerLine1 = "SAVE FAILED!    ";
                    uiBannerLine2 = "RETRY AT IDLE   ";
                    // Retain pending status for safe retry at next standstill
                }
                uiMessageTimer = millis() + 1500UL;
                oldMenuState = -1;
            } else {
                autoSaveEngine.clearPendingSave();
                autoSavePendingStandstill = false;
            }
        }
    }

    // Safety Auto-Abort: Return to Main Screen if machine starts running while in any menu
    if (pendingMenuExit) {
        pendingMenuExit = false;
        // Do NOT reload EEPROM here: loadFromEEPROM() calls applyMotorDirection(),
        // which can intentionally stop an active STEP burst. Once PA0 starts the
        // machine, the primary motion path must never be interrupted by UI exit logic.
        // Staged menu values were never applied while the machine was running, so
        // simply discard the staged UI state and return to the main screen.
        menuState = 0;
        oldMenuState = -1;
        hasStagedChanges = false;
    }

    // Classic DDA Software Fallback Stepper Execution (Active only when hardwareTimerMode == false)
    if (!hardwareTimerMode && stepsRemaining > 0) {
        unsigned long currentMicros = micros();
        // DDA is a service fallback only.  It follows the most recently measured
        // physical Proximity interval and does NOT invent an acceleration/deceleration ramp.
        unsigned long activeStepPeriod = (unsigned long)activePulseWidth;
        // In DDA mode, each toggle is half of the step period (50% duty cycle)
        unsigned long halfPeriod = activeStepPeriod / 2UL;
        if (halfPeriod < 3UL) halfPeriod = 3UL; // Minimum 3us half-period (6us step period)

        if (currentMicros - lastStepMicros >= halfPeriod) {
            if (stepPinState == HIGH) {
                STEP_LOW_ACTIVE();
                stepPinState = LOW;
            } else {
                STEP_HIGH_IDLE();
                stepPinState = HIGH;
                stepsRemaining--;
                currentStepIndex++;
                if (stepsRemaining <= 0) {
                    stepsRemaining = 0;
                    movementState = STATE_COMPLETE;
                    STATUS_LED_OFF();
                } else if (stepsRemaining % 100 == 0) {
                    IWDG_FEED();
                }
            }

            if (currentMicros - lastStepMicros > (halfPeriod * 3UL) / 2UL) {
                lastStepMicros = currentMicros;
            } else {
                lastStepMicros += halfPeriod;
            }
        }
        return;
    }

// Manual Save Confirmation Dialog (menuState 12) eliminated per Rajesh Shah directive
    // Auto-Relock Timeout after 60s of inactivity on Main Screen
    if (!isUiLocked && menuState == 0) {
        if (millis() - lastUnlockActivity > 60000UL) {
            isUiLocked = true;
            oldMenuState = -1;
        }
    }

    // Safety Inactivity Auto-Exit after 2 minutes (120s) without button presses in Settings
    if (menuState != 0) {
        if (millis() - lastUnlockActivity > 120000UL) {
            hasStagedChanges = false;
            menuState = 0;
            oldMenuState = -1;
            isUiLocked = true;
            uiBannerLine1 = "MENU TIMEOUT    ";
            uiBannerLine2 = "CHANGES CANCELED";
            uiMessageTimer = millis() + 1500UL;
        }
    }

    // Industrial Edge-Triggered Button States with Hold Auto-Repeat
static bool upPressedState = false;
static unsigned long upFirstPressTime = 0UL;
static unsigned long lastUpRepeatTime = 0UL;

static bool downPressedState = false;
static unsigned long downFirstPressTime = 0UL;
static unsigned long lastDownRepeatTime = 0UL;

    // Button Debouncing and Event Processing
    if (millis() - lastButtonCheck > 20UL) {
        lastButtonCheck = millis();
        if (digitalRead(btnUp) == LOW || digitalRead(btnDown) == LOW || digitalRead(btnMode) == LOW) {
            lastUnlockActivity = millis();
        }

        // Single Click MODE handling: Pulse Tuning Gear Change (0.10 -> 1.00 -> 10.0 -> 100 Pulses)
        if (pendingSingleClick && (millis() - lastModeClickTime > 350UL)) {
            pendingSingleClick = false;
            if (isUiLocked && menuState == 0) {
                uiBannerLine1 = "KEYPAD LOCKED!  ";
                uiBannerLine2 = "DBL-CLICK [MODE]";
                uiMessageTimer = millis() + 1500UL;
                oldMenuState = -1;
            } else if (!isUiLocked && menuState == 0) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (stepGearFixed == 100000ULL) {
                        stepGearFixed = 1000000ULL;
                        // Snap pulse decimal to .00 when gearing up
                        currentPulsesFixed = (currentPulsesFixed / 1000000ULL) * 1000000ULL;
                        syncPulseIntegerFraction();
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else if (currentSize == 3) p10_fixed = currentPulsesFixed;
                        updateActivePulseWidth();
                        pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                              (p8_fixed != pulseStepStored_p8) ||
                                              (p10_fixed != pulseStepStored_p10);
                        if (pulseModifiedByUser) {
                            autoSaveEngine.notifyModification(millis());
                        } else {
                            autoSaveEngine.clearPendingSave();
                        }
                        autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;
                        uiBannerLine1 = "GEAR: 1.00 PULSE";
                    } else {
                        // 10.0 gear removed: toggles directly between 0.10 and 1.00
                        stepGearFixed = 100000ULL;
                        uiBannerLine1 = "GEAR: 0.10 PULSE";
                    }
                    uiBannerLine2 = "FINE TUNING OK  ";
                    uiMessageTimer = millis() + 1500UL;
                    lastUnlockActivity = millis();
                    oldMenuState = -1;
                } else {
                    uiBannerLine1 = "MACHINE RUNNING!";
                    uiBannerLine2 = "GEAR CHG BLOCKED";
                    uiMessageTimer = millis() + 1500UL;
                    oldMenuState = -1;
                }
            }
        }

        // Dual Button Press: Emergency Factory Reset (>10s)
        if (digitalRead(btnUp) == LOW && digitalRead(btnDown) == LOW) {
            if (!upDownPressed) dualPressTime = millis();
            upDownPressed = true;
            if (millis() - dualPressTime > 10000UL && menuState != 3) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    menuState = 3;
                    resetChoice = false;
                    oldMenuState = -1;
                } else {
                    uiBannerLine1 = "MACHINE RUNNING!";
                    uiBannerLine2 = "RESET BLOCKED!  ";
                    uiMessageTimer = millis() + 1500UL;
                    oldMenuState = -1;
                }
            }
        } else {
            upDownPressed = false;
        }

        // MODE Button State Machine
        if (digitalRead(btnMode) == LOW) {
            if (!modePressed) modePressTime = millis();
            modePressed = true;

            // Live visual countdown feedback during button hold on main screen (eliminates guesswork & size-switch trap)
            if (menuState == 0) {
                unsigned long currentHold = millis() - modePressTime;
                if (isUiLocked) {
                    if (currentHold >= 1000UL) {
                        uiBannerLine1 = "KEYPAD LOCKED!  ";
                        uiBannerLine2 = "DBL-CLICK [MODE]";
                        uiMessageTimer = millis() + 600UL;
                    }
                } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (currentHold >= 1500UL && currentHold < 5000UL) {
                        int secLeft = (int)((5000UL - currentHold + 999UL) / 1000UL);
                        static char holdCountdown[17];
                        snprintf(holdCountdown, sizeof(holdCountdown), "HOLD MENU: %ds   ", secLeft);
                        uiBannerLine1 = "SIZE CHG ARMED  ";
                        uiBannerLine2 = holdCountdown;
                        uiMessageTimer = millis() + 250UL;
                    } else if (currentHold >= 5000UL) {
                        uiBannerLine1 = "RELEASE FOR:    ";
                        uiBannerLine2 = ">>SETTINGS MENU<";
                        uiMessageTimer = millis() + 250UL;
                    }
                }
            }
        } else if (modePressed) {
            unsigned long holdTime = millis() - modePressTime;
            modePressed = false;

            if (menuState == 0) {
                if (holdTime < 350UL) {
                    if (pendingSingleClick && (millis() - lastModeClickTime < 350UL)) {
                        pendingSingleClick = false;
                        isUiLocked = !isUiLocked;
                        lastUnlockActivity = millis();
                        uiBannerLine1 = isUiLocked ? "KEYPAD LOCKED!  " : "KEYPAD UNLOCKED ";
                        uiBannerLine2 = isUiLocked ? "*[L] ACTIVE     " : "*[U] ACTIVE     ";
                        uiMessageTimer = millis() + 1500UL;
                        oldMenuState = -1;
                        lastModeClickTime = 0UL;
                    } else {
                        lastModeClickTime = millis();
                        if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                            pendingSingleClick = true;
                        } else {
                            pendingSingleClick = false;
                            if (!isUiLocked) {
                                uiBannerLine1 = "MACHINE RUNNING!";
                                uiBannerLine2 = "GEAR CHG BLOCKED";
                                uiMessageTimer = millis() + 1500UL;
                                oldMenuState = -1;
                            }
                        }
                    }
                } else if (holdTime >= 1500UL && holdTime < 5000UL && !isUiLocked) {
                    // 1.5-8 Second Hold: Zipper Size Sequence Switch (#5 -> #8 -> #10 -> #5)
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        currentSize++;
                        if (currentSize > 3) currentSize = 1;
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentSize == 1) currentPulsesFixed = p5_fixed;
                        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                        else currentPulsesFixed = p10_fixed;
                        __set_PRIMASK(primask);
                        updateActivePulseWidth();
                        bool saveOk = saveToEEPROM(); // Standstill size commit with verified return
                        lastUnlockActivity = millis();
                        double sPitch = ((double)currentPulsesFixed / 1000000.0) * (3.14159265358979323846 * (double)rollerDia) / (double)driverResolution;
                        int sInt = constrain((int)sPitch, 0, 99);
                        int sFrac = constrain((int)((sPitch - (float)sInt) * 100.0f + 0.5f), 0, 99);
                        if (sFrac >= 100) { sInt++; sFrac -= 100; }
                        static char sizeL2[40];
                        snprintf(sizeL2, sizeof(sizeL2), "LEN: %d.%02dmm  OK ", sInt, sFrac);

                        if (saveOk) {
                            if (currentSize == 1)      uiBannerLine1 = "ACTIVE: SIZE #5 ";
                            else if (currentSize == 2) uiBannerLine1 = "ACTIVE: SIZE #8 ";
                            else                       uiBannerLine1 = "ACTIVE: SIZE #10";
                            uiBannerLine2 = sizeL2;
                        } else {
                            autoSavePendingStandstill = true;
                            uiBannerLine1 = "SIZE CHG (RAM)  ";
                            uiBannerLine2 = sizeL2;
                        }
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "SIZE CHG BLOCKED";
                        uiMessageTimer = millis() + 1500UL;
                        oldMenuState = -1;
                    }
                } else if (holdTime >= 5000UL && !isUiLocked) {
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        tempDriverRes       = driverResolution;
                        tempRollerDia       = rollerDia;
                        tempMaxRPM          = maxRPMSetting;
                        tempStartSpeed      = startSpeedPercent;
                        tempFeedAngle       = feedAngleDeg;
                        tempSafetyMargin    = safetyMarginPercent;
                        tempSensorGuard     = sensorGuardActive;
                        tempCoilGuard        = coilGuardActive;
                        tempPb3Guard         = pb3GuardActive;
                        tempMotionRelay      = motionRelayEnabled;
                        tempHwTimerMode     = hardwareTimerMode;
                        tempMotorDir        = motorDirection;
                        hasStagedChanges    = false;
                        menuState = 1;
                        hiddenOption = 1;
                        oldMenuState = -1;
                    } else {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "MENU LOCKED [L] ";
                        uiMessageTimer = millis() + 1500UL;
                        oldMenuState = -1;
                    }
                }
            } else if (menuState == 1) {
                // Quick Back to Main Screen on Hold MODE (>= 1500ms)
                if (holdTime >= 1500UL) {
                    menuState = 0;
                    oldMenuState = -1;
                    isUiLocked = true;
                    uiBannerLine1 = "MAIN SCREEN     ";
                    uiBannerLine2 = "QUICK BACK OK   ";
                    uiMessageTimer = millis() + 800UL;
                    return;
                }
                // Hidden Menu Navigation (10 Items)
                if (hiddenOption == 1)      menuState = 2;  // 1. Driver Res
                else if (hiddenOption == 2) { menuState = 4; diaStepGear = 0.1f; } // 2. Roller Dia (0.1 <-> 1.0)
                else if (hiddenOption == 3) { menuState = 5; rpmStepGear = 50; }   // 3. Max RPM (fixed 50)
                else if (hiddenOption == 4) { menuState = 6; angleStepGear = 1; }  // 4. Feed Angle (fixed 1)
                else if (hiddenOption == 5) { menuState = 8; marginStepGear = 1; } // 5. Safety Margin (fixed 1)
                else if (hiddenOption == 6) menuState = 16; // 6. Motor Direction
                else if (hiddenOption == 7) menuState = 18; // Diagnostic Engine (TIM1 STEP primary / DDA temporary)
                else if (hiddenOption == 8) {
                    sensorSubIndex = 1;
                    menuState = 20; // 8. Sensors Sub-Branch (Tape, Coil, Safety, Motion Relay)
                    oldMenuState = -1;
                } else if (hiddenOption == 9) {
                    evaluateDiagnostics();
                    infoIndex = 1;
                    menuState = 9;  // 9. Info / Diag Screen
                    oldMenuState = -1;
                } else if (hiddenOption == 10) {
                    // 10. Unified Save & Exit Dialog: Opens confirmation screen with >YES / >NO
                    saveExitChoice = true; // Default to >YES
                    menuState = 13;        // Save & Exit Confirmation Dialog
                    oldMenuState = -1;
                }
            } else if (menuState == 2 || menuState == 4) {
                // Multi-gear sub-menus (Driver Res & Roller Dia):
                // Hold MODE (>= 800ms) to exit back to Settings Menu list.
                // Short Click (< 800ms) cycles the step gear [MD]!
                if (holdTime >= 800UL) {
                    menuState = 1;
                    oldMenuState = -1;
                    uiBannerLine1 = "EXITING SUB-MENU";
                    uiBannerLine2 = "BACK TO LIST >>>";
                    uiMessageTimer = millis() + 600UL;
                } else {
                    if (menuState == 2) {
                        if (resStepGear == 100) resStepGear = 200;
                        else if (resStepGear == 200) resStepGear = 500;
                        else if (resStepGear == 500) resStepGear = 1000;
                        else resStepGear = 100;
                    } else if (menuState == 4) {
                        // 0.5 mm removed: cycles strictly between 0.1 and 1.0 mm!
                        if (diaStepGear < 0.5f) diaStepGear = 1.0f;
                        else diaStepGear = 0.1f;
                    }
                    oldMenuState = -1;
                }
            } else if (menuState == 5 || menuState == 7 || menuState == 6 || menuState == 8 || menuState == 16 || menuState == 18) {
                // Fixed single-gear options (Max RPM, Start Spd, Feed Angle, Safety Margin, Motor Dir, STEP Engine):
                // Single-Click [MODE] acts as Confirm & Back to Settings List for streamlined navigation!
                menuState = 1;
                oldMenuState = -1;
            } else if (menuState == 20) {
                // Sensors Sub-Branch:
                // Hold MODE (>= 800ms) returns back to Settings List.
                // Click [MODE] enters that sensor edit sub-item!
                if (holdTime >= 800UL) {
                    menuState = 1;
                    oldMenuState = -1;
                } else {
                    if (sensorSubIndex == 1) menuState = 10;      // Tape Guard
                    else if (sensorSubIndex == 2) menuState = 11; // Coil Guard
                    else if (sensorSubIndex == 3) menuState = 12; // Safety Guard
                    else if (sensorSubIndex == 4) menuState = 14; // Motion Relay
                    oldMenuState = -1;
                }
            } else if (menuState == 10 || menuState == 11 || menuState == 12 || menuState == 14) {
                // Inside individual sensor edit: Single-Click [MODE] confirms & returns to Sensors Sub-Branch!
                menuState = 20;
                oldMenuState = -1;
            } else if (menuState == 9) {
                // Diagnostics Menu:
                // Page 8 ([MODE] OPEN HELP): Click [MODE] opens HELP sub-branch!
                // Any other page: Click [MODE] exits back to Settings List.
                if (infoIndex == 8) {
                    helpIndex = 1;
                    menuState = 21; // Open HELP Sub-Branch
                    oldMenuState = -1;
                } else {
                    menuState = 1;  // Return to Settings List
                    oldMenuState = -1;
                }
            } else if (menuState == 21) {
                // HELP Sub-Branch: Single-Click [MODE] returns to Diagnostics Page 8!
                menuState = 9;
                infoIndex = 8;
                oldMenuState = -1;
            } else if (menuState == 13) {
                // Execute Save & Exit Dialog decision
                if (saveExitChoice) {
                    // YES: Apply & Save Staged Settings
                    if (!stagedTimingConfigurationFeasible()) {
                        uiBannerLine1 = "TIMING INVALID! ";
                        uiBannerLine2 = "LOWER RPM/RES  ";
                        uiMessageTimer = millis() + 1600UL;
                        menuState = 1;
                        oldMenuState = -1;
                    } else {
                        const bool geometryChanged = (driverResolution != tempDriverRes) ||
                                                     (fabsf(rollerDia - tempRollerDia) > 0.001f);
                        driverResolution    = tempDriverRes;
                        rollerDia           = tempRollerDia;
                        maxRPMSetting       = tempMaxRPM;
                        startSpeedPercent   = tempStartSpeed;
                        feedAngleDeg        = tempFeedAngle;
                        safetyMarginPercent = tempSafetyMargin;
                        sensorGuardActive   = tempSensorGuard;
                        coilGuardActive     = tempCoilGuard;
                        pb3GuardActive      = tempPb3Guard;
                        motionRelayEnabled  = tempMotionRelay;
                        if (!motionRelayEnabled) { GPIOB->BRR = (1U << 1); motionWatchdogArmed = false; isMotionSyncLost = false; }
                        hardwareTimerMode   = tempHwTimerMode;
                        if (!hardwareTimerMode) {
                            hwBurstActive = false;
                            TIM1->DIER &= ~TIM_DIER_CC1IE;
                            TIM1->CCER &= ~TIM_CCER_CC1E;
                            TIM1->CR1  &= ~TIM_CR1_CEN;
                            GPIOA->CRH &= ~(0xFU << 0);
                            GPIOA->CRH |= (0x3U << 0);
                            STEP_HIGH_IDLE();
                            stepPinState = HIGH;
                        }
                        tempHwTimerMode     = hardwareTimerMode;
                        motorDirection      = tempMotorDir;
                        applyMotorDirection();
                        if (geometryChanged) {
                            recalculatePitchProfiles();
                            uint32_t primask = __get_PRIMASK();
                            __disable_irq();
                            if (currentSize == 1) currentPulsesFixed = p5_fixed;
                            else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                            else currentPulsesFixed = p10_fixed;
                            __set_PRIMASK(primask);
                        }
                        calculateAllPulseWidths();
                        refreshPulseTimingValidity();
                        hasStagedChanges    = false;
                        menuState = 0;
                        oldMenuState = -1;
                        isUiLocked = true;
                        if (isMachineSafelyIdle() && currentRPM == 0UL) {
                            bool saveOk = saveToEEPROM();
                            if (saveOk) {
                                autoSavePendingStandstill = false;
                                autoSaveEngine.clearPendingSave();
                                pulseModifiedByUser = false;
                                hasStagedChanges = false;
                                stepGearFixed = 1000000ULL; // Reset gear to 1.00 pulse on save
                                uiBannerLine1 = "SETTINGS SAVED  ";
                                uiBannerLine2 = "DIRECT SAVE OK  ";
                            } else {
                                uiBannerLine1 = "SAVE FAILED!    ";
                                uiBannerLine2 = "RETRY AT 0 RPM  ";
                            }
                        } else {
                            uiBannerLine1 = "SAVE BLOCKED!   ";
                            uiBannerLine2 = "STOP MACHINE 1ST";
                        }
                        uiMessageTimer = millis() + 1500UL;
                    }
                } else {
                    // NO: Discard Changes & Exit
                    hasStagedChanges = false;
                    menuState = 0;
                    oldMenuState = -1;
                    isUiLocked = true;
                    uiBannerLine1 = "CHANGES CANCELED";
                    uiBannerLine2 = "ORIGINAL KEPT   ";
                    uiMessageTimer = millis() + 1500UL;
                }

            } else if (menuState == 3) {
                if (resetChoice) {
                    loadFactoryDefaults();
                    uiBannerLine1 = "FACTORY RESET OK";
                    uiBannerLine2 = "DEFAULTS LOADED ";
                    uiMessageTimer = millis() + 1500UL;
                }
                menuState = 0;
                oldMenuState = -1;
            }
        }

                // UP Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool upRaw = (digitalRead(btnUp) == LOW);
        bool triggerUpStep = false;
        if (upRaw && !upDownPressed) {
            if (!upPressedState) {
                upPressedState = true;
                upFirstPressTime = millis();
                lastUpRepeatTime = millis();
                triggerUpStep = true; // Immediate 1-step on press!
            } else if (millis() - upFirstPressTime >= 600UL) {
                if (millis() - lastUpRepeatTime >= 200UL) {
                    lastUpRepeatTime = millis();
                    triggerUpStep = true; // Auto-repeat!
                }
            }
        } else {
            upPressedState = false;
        }

        if (triggerUpStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        uiBannerLine1 = "KEYPAD LOCKED!  ";
                        uiBannerLine2 = "DBL-CLICK [MODE]";
                        uiMessageTimer = millis() + 1500UL;
                        oldMenuState = -1;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint64_t proposedPulses = currentPulsesFixed + stepGearFixed;
                        uint64_t oldPulses = currentPulsesFixed;
                        currentPulsesFixed = proposedPulses;
                        refreshPulseTimingValidity();
                        currentPulsesFixed = oldPulses;
                        if (pulseTimingInvalid) {
                            refreshPulseTimingValidity();
                            uiBannerLine1 = "TIMING INVALID! ";
                            uiBannerLine2 = "LOWER PULSE/RES";
                            uiMessageTimer = millis() + 1500UL;
                            oldMenuState = -1;
                            break;
                        }
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        currentPulsesFixed = proposedPulses;
                        if (currentPulsesFixed > PULSE_STEP_MAX_FIXED) currentPulsesFixed = PULSE_STEP_MAX_FIXED;
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                              (p8_fixed != pulseStepStored_p8) ||
                                              (p10_fixed != pulseStepStored_p10);
                        smoothRunStartMillis = 0UL;
                        if (pulseModifiedByUser) {
                            autoSaveEngine.notifyModification(millis());
                        } else {
                            autoSaveEngine.clearPendingSave();
                        }
                        autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

                        static char tuningL1[40];
                        static char tuningL2[40];
                        unsigned long pInt = (unsigned long)(currentPulsesFixed / 1000000ULL);
                        unsigned long pFrac = (unsigned long)((currentPulsesFixed % 1000000ULL) / 10000ULL);
                        const double feedMm = ((double)currentPulsesFixed / 1000000.0) *
                            (3.14159265358979323846 * (double)rollerDia) / (double)driverResolution;
                        unsigned long feedHundredths = (feedMm > 0.0) ? (unsigned long)(feedMm * 100.0 + 0.5) : 0UL;
                        if (feedHundredths > 9999UL) feedHundredths = 9999UL;
                        const int fInt = (int)(feedHundredths / 100UL);
                        const int fFrac = (int)(feedHundredths % 100UL);
                        snprintf(tuningL1, sizeof(tuningL1), "FEED: %d.%02d mm   ", fInt, fFrac);
                        snprintf(tuningL2, sizeof(tuningL2), "P:%lu.%02lu +[UP]   ", pInt, pFrac);
                        uiBannerLine1 = tuningL1;
                        uiBannerLine2 = tuningL2;
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else if (currentRPM > 0UL || stepsRemaining > 0 || hwBurstActive) {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "PULSE TUNE LOCK ";
                        uiMessageTimer = millis() + 1500UL;
                        oldMenuState = -1;
                    }
                    break;
                case 1:
                    hiddenOption--;
                    if (hiddenOption < 1) hiddenOption = 10;
                    break;
                case 2:
                    tempDriverRes += resStepGear;
                    if (tempDriverRes > 51200) tempDriverRes = 51200;
                    hasStagedChanges = true;
                    break;
                case 3: resetChoice = true; break;
                case 13: saveExitChoice = true; break;
                case 4:
                    tempRollerDia += diaStepGear;
                    if (tempRollerDia > 100.0f) tempRollerDia = 100.0f;
                    hasStagedChanges = true;
                    break;
                case 5:
                    tempMaxRPM += rpmStepGear;
                    if (tempMaxRPM > 4000) tempMaxRPM = 4000;
                    hasStagedChanges = true;
                    break;
                case 7:
                    if (tempStartSpeed < 100) tempStartSpeed++;
                    hasStagedChanges = true;
                    break;
                case 6:
                    tempFeedAngle += angleStepGear;
                    if (tempFeedAngle > 270) tempFeedAngle = 270;
                    hasStagedChanges = true;
                    break;
                case 8:
                    tempSafetyMargin += marginStepGear;
                    if (tempSafetyMargin > 25) tempSafetyMargin = 25;
                    hasStagedChanges = true;
                    break;
                case 10: tempSensorGuard = true; hasStagedChanges = true; break;
                case 11: tempCoilGuard = true; hasStagedChanges = true; break;
                case 12: tempPb3Guard = true; hasStagedChanges = true; break;
                case 14: tempMotionRelay = true; hasStagedChanges = true; break;
                case 16: tempMotorDir = false; hasStagedChanges = true; break;
                case 18: tempHwTimerMode = true; hasStagedChanges = true; break; // [UP] selects TIM1 Hardware PWM
                case 20:
                    sensorSubIndex--;
                    if (sensorSubIndex < 1) sensorSubIndex = 4;
                    break;
                case 21:
                    helpIndex--;
                    if (helpIndex < 1) helpIndex = 5;
                    break;
                case 9:
                    // [UP] moves to previous page (Page 1/2 held for test)
                    if (infoIndex != 1 && infoIndex != 2) {
                        infoIndex--;
                        if (infoIndex < 1) infoIndex = 9;
                    }
                    break;
// Obsolete manual Save Settings Confirmation Dialog (case 7) removed
            }
            upPressTime = millis();
        }

        // DOWN Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool downRaw = (digitalRead(btnDown) == LOW);
        bool triggerDownStep = false;
        if (downRaw && !upDownPressed) {
            if (!downPressedState) {
                downPressedState = true;
                downFirstPressTime = millis();
                lastDownRepeatTime = millis();
                triggerDownStep = true; // Immediate 1-step on press!
            } else if (millis() - downFirstPressTime >= 600UL) {
                if (millis() - lastDownRepeatTime >= 200UL) {
                    lastDownRepeatTime = millis();
                    triggerDownStep = true; // Auto-repeat!
                }
            }
        } else {
            downPressedState = false;
        }

        if (triggerDownStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        uiBannerLine1 = "KEYPAD LOCKED!  ";
                        uiBannerLine2 = "DBL-CLICK [MODE]";
                        uiMessageTimer = millis() + 1500UL;
                        oldMenuState = -1;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentPulsesFixed > stepGearFixed + PULSE_STEP_MIN_FIXED) {
                            currentPulsesFixed -= stepGearFixed;
                        } else {
                            currentPulsesFixed = PULSE_STEP_MIN_FIXED; // Minimum 1.00 pulse clamp
                        }
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                              (p8_fixed != pulseStepStored_p8) ||
                                              (p10_fixed != pulseStepStored_p10);
                        smoothRunStartMillis = 0UL;
                        if (pulseModifiedByUser) {
                            autoSaveEngine.notifyModification(millis());
                        } else {
                            autoSaveEngine.clearPendingSave();
                        }
                        autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

                        static char tuningL1[40];
                        static char tuningL2[40];
                        unsigned long pInt = (unsigned long)(currentPulsesFixed / 1000000ULL);
                        unsigned long pFrac = (unsigned long)((currentPulsesFixed % 1000000ULL) / 10000ULL);
                        const double feedMm = ((double)currentPulsesFixed / 1000000.0) *
                            (3.14159265358979323846 * (double)rollerDia) / (double)driverResolution;
                        unsigned long feedHundredths = (feedMm > 0.0) ? (unsigned long)(feedMm * 100.0 + 0.5) : 0UL;
                        if (feedHundredths > 9999UL) feedHundredths = 9999UL;
                        const int fInt = (int)(feedHundredths / 100UL);
                        const int fFrac = (int)(feedHundredths % 100UL);
                        snprintf(tuningL1, sizeof(tuningL1), "FEED: %d.%02d mm   ", fInt, fFrac);
                        snprintf(tuningL2, sizeof(tuningL2), "P:%lu.%02lu -[DN]   ", pInt, pFrac);
                        uiBannerLine1 = tuningL1;
                        uiBannerLine2 = tuningL2;
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else if (currentRPM > 0UL || stepsRemaining > 0 || hwBurstActive) {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "PULSE TUNE LOCK ";
                        uiMessageTimer = millis() + 1500UL;
                        oldMenuState = -1;
                    }
                    break;
// case 12 manual confirmation removed
                case 1:
                    hiddenOption++;
                    if (hiddenOption > 10) hiddenOption = 1;
                    break;
                case 2:
                    if (tempDriverRes > resStepGear + 200) tempDriverRes -= resStepGear;
                    else tempDriverRes = 200;
                    hasStagedChanges = true;
                    break;
                case 3: resetChoice = false; break;
                case 13: saveExitChoice = false; break;
                case 4:
                    if (tempRollerDia > diaStepGear + 15.0f) tempRollerDia -= diaStepGear;
                    else tempRollerDia = 15.0f;
                    hasStagedChanges = true;
                    break;
                case 5:
                    if (tempMaxRPM > rpmStepGear + 100) tempMaxRPM -= rpmStepGear;
                    else tempMaxRPM = 100;
                    hasStagedChanges = true;
                    break;
                case 7:
                    if (tempStartSpeed > 10) tempStartSpeed--;
                    hasStagedChanges = true;
                    break;
                case 6:
                    if (tempFeedAngle > angleStepGear + 30) tempFeedAngle -= angleStepGear;
                    else tempFeedAngle = 30;
                    hasStagedChanges = true;
                    break;
                case 8:
                    if (tempSafetyMargin >= marginStepGear) tempSafetyMargin -= marginStepGear;
                    hasStagedChanges = true;
                    break;
                case 10: tempSensorGuard = false; hasStagedChanges = true; break;
                case 11: tempCoilGuard = false; hasStagedChanges = true; break;
                case 12: tempPb3Guard = false; hasStagedChanges = true; break;
                case 14: tempMotionRelay = false; hasStagedChanges = true; break;
                case 16: tempMotorDir = true; hasStagedChanges = true; break;
                case 18: tempHwTimerMode = false; hasStagedChanges = true; break; // [DN] selects DDA Diagnostic
                case 20:
                    sensorSubIndex++;
                    if (sensorSubIndex > 4) sensorSubIndex = 1;
                    break;
                case 21:
                    helpIndex++;
                    if (helpIndex > 5) helpIndex = 1;
                    break;
                case 9:
                    // [DOWN] moves to next page (Page 1 held for reverse jog test)
                    if (infoIndex != 1) {
                        infoIndex++;
                        if (infoIndex > 9) infoIndex = 1;
                    }
                    break;
// Obsolete case 7 removed
            }
            downPressTime = millis();
        }

        if (digitalRead(btnUp) == HIGH && digitalRead(btnDown) == HIGH) {
            upDownPressed = false;
        }
    }

    // 16x2 Character LCD Screen Renderer (Anti-Blanking & Anti-Flicker Direct Overwrite)
    if (uiBannerLine1 != nullptr) {
        if (millis() < uiMessageTimer) {
            char b1[17], b2[17];
            snprintf(b1, sizeof(b1), "%-16s", uiBannerLine1);
            snprintf(b2, sizeof(b2), "%-16s", uiBannerLine2 ? uiBannerLine2 : "");
            lcd.setCursor(0, 0); lcd.print(b1);
            lcd.setCursor(0, 1); lcd.print(b2);
            oldMenuState = -2;
            return;
        } else {
            uiBannerLine1 = nullptr;
            uiBannerLine2 = nullptr;
            oldMenuState = -1;
            lcd.clear();
        }
    }

    // Running-state RPM refresh. Refresh the RPM field even at 0000 so a stopped
    // machine cannot leave a stale speed on screen. The full stationary redraw
    // below remains responsible for all other fields and menu transitions.
    if (menuState == 0 && oldMenuState == menuState) {
        if (millis() - lastRpmDisplayUpdate > 250UL) {
            lastRpmDisplayUpdate = millis();
            char rpmBuf[16];
            unsigned int dispRpm = (currentRPM > 9999UL) ? 9999U : (unsigned int)currentRPM;
            snprintf(rpmBuf, sizeof(rpmBuf), "%04u", dispRpm);
            lcd.setCursor(5, 0);
            lcd.print(rpmBuf);
        }
        // Do not return from loop while RPM is non-zero: button handling,
        // watchdog service, and other cooperative tasks must continue running.
    }

    // Stationary redraw is only needed at standstill or after a menu transition.
    // While running, the RPM field above is refreshed independently without
    // repeatedly redrawing the entire LCD.
    if ((currentRPM == 0UL || menuState != oldMenuState || menuState == 9) && millis() - lastDisplayUpdate > 150UL) {
        if (menuState != oldMenuState) {
            lcd.clear();
            oldMenuState = menuState;
        }

        char l1[24] = "                ";
        char l2[24] = "                ";
        switch (menuState) {
            case 0: // Normal Operational Screen
            {
                int szNum = (currentSize == 1) ? 5 : ((currentSize == 2) ? 8 : 10);
                // The displayed FEED is a calculated roller-travel estimate, not
                // the nominal zipper-size pitch. Round once to hundredths so a
                // value such as 1.999 mm displays as 2.00 mm (not 1.99 mm).
                const double feedMm = ((double)currentPulsesFixed / 1000000.0) *
                    (3.14159265358979323846 * (double)rollerDia) / (double)driverResolution;
                unsigned long feedHundredths = (feedMm > 0.0) ? (unsigned long)(feedMm * 100.0 + 0.5) : 0UL;
                if (feedHundredths > 9999UL) feedHundredths = 9999UL;
                const int actInt = (int)(feedHundredths / 100UL);
                const int actFrac = (int)(feedHundredths % 100UL);
                char feedStr[6];
                snprintf(feedStr, sizeof(feedStr), "%d.%02d", actInt, actFrac);
                unsigned int dispRpm = constrain((unsigned int)currentRPM, 0U, 9999U);
                snprintf(l1, sizeof(l1), "S:%-2d %04u F:%s", szNum, dispRpm, feedStr);
                char cue = (activePulseWidth <= 2) ? '*' : ((activePulseWidth < 6) ? '#' : (hardwareTimerMode ? 'H' : 'u'));
                int pInt = (int)(currentPulsesFixed / 1000000ULL);
                int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                if (pInt < 100 && activePulseWidth < 100) {
                    snprintf(l2, sizeof(l2), "P:%d.%01d W:%d %c%s",
                             pInt, pFrac, activePulseWidth, cue, isUiLocked ? "[L]" : "[U]");
                } else {
                    snprintf(l2, sizeof(l2), "P:%d.%01d W:%d%c%s",
                             pInt, pFrac, activePulseWidth, cue, isUiLocked ? "[L]" : "[U]");
                }
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
            }
            break;

            case 1: // Hidden Settings Staged Menu List (10 Options)
            {
                if (hiddenOption == 1)      snprintf(l1, sizeof(l1), "1. Driver Res   ");
                else if (hiddenOption == 2) snprintf(l1, sizeof(l1), "2. Roller Dia   ");
                else if (hiddenOption == 3) snprintf(l1, sizeof(l1), "3. Max RPM      ");
                else if (hiddenOption == 4) snprintf(l1, sizeof(l1), "4. Feed Angle   ");
                else if (hiddenOption == 5) snprintf(l1, sizeof(l1), "5. Safety Margin");
                else if (hiddenOption == 6) snprintf(l1, sizeof(l1), "6. Motor Dir    ");
                else if (hiddenOption == 7) snprintf(l1, sizeof(l1), "7. STEP Engine  ");
                else if (hiddenOption == 8) snprintf(l1, sizeof(l1), "8. Sensors      ");
                else if (hiddenOption == 9) snprintf(l1, sizeof(l1), "9. Info Diag    ");
                else if (hiddenOption == 10)snprintf(l1, sizeof(l1), "10. Save & Exit ");

                if (hiddenOption == 1)      snprintf(l2, sizeof(l2), "Val: %-5d steps", (int)tempDriverRes);
                else if (hiddenOption == 2) {
                    int dInt = (int)tempRollerDia;
                    int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
                    snprintf(l2, sizeof(l2), "Val: %2d.%1d mm  ", dInt, dFrac);
                }
                else if (hiddenOption == 3) snprintf(l2, sizeof(l2), "Val: %-4d RPM  ", (int)tempMaxRPM);
                else if (hiddenOption == 4) snprintf(l2, sizeof(l2), "Val: %-3d deg   ", (int)tempFeedAngle);
                else if (hiddenOption == 5) snprintf(l2, sizeof(l2), "Val: %-2d%%     ", (int)tempSafetyMargin);
                else if (hiddenOption == 6) snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: REVERSE[RV]" : "Dir: NORMAL [FW]");
                else if (hiddenOption == 7) snprintf(l2, sizeof(l2), tempHwTimerMode ? "TIM1: HW PRIMARY" : "DDA: DIAG TEMP ");
                else if (hiddenOption == 8) snprintf(l2, sizeof(l2), "Sub-Menu (4 Aux)");
                else if (hiddenOption == 9) snprintf(l2, sizeof(l2), "Open Diagnostics");
                else if (hiddenOption == 10)snprintf(l2, sizeof(l2), "Select Save/Exit");

                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
            }
            break;

            case 2: // Edit Driver Resolution
                snprintf(l1, sizeof(l1), "Res: %-5d stp", (int)tempDriverRes);
                snprintf(l2, sizeof(l2), "S:%-3d [MD] HLD:EX", (int)resStepGear);
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 13: // Save & Exit Confirmation Dialog
                snprintf(l1, sizeof(l1), "SAVE CHANGES?   ");
                snprintf(l2, sizeof(l2), saveExitChoice ? ">YES   NO       " : " YES  >NO       ");
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 3: // Emergency Factory Reset
                lcdPrint16(0, "Factory Reset?  ");
                lcdPrint16(1, resetChoice ? ">YES  NO         " : " YES >NO         ");
                break;

            case 4: // Edit Roller Diameter
            {
                int dInt = (int)tempRollerDia;
                int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
                snprintf(l1, sizeof(l1), "Dia: %2d.%1d mm  ", dInt, dFrac);
                int gInt = (int)diaStepGear;
                int gFrac = (int)((diaStepGear - (float)gInt) * 10.0f + 0.5f);
                snprintf(l2, sizeof(l2), "S:%d.%1d [MD] HLD:EX", gInt, gFrac);
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
            }
            break;

            case 5: // Edit Max RPM
                snprintf(l1, sizeof(l1), "Max RPM: %-4d   ", (int)tempMaxRPM);
                snprintf(l2, sizeof(l2), "S:50  [MD] BACK ");
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 7: // Edit Start Speed %
                snprintf(l1, sizeof(l1), "Start Spd: %-3d%% ", (int)tempStartSpeed);
                snprintf(l2, sizeof(l2), "S:1%%  [MD] BACK ");
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 6: // Edit Feed Angle
                snprintf(l1, sizeof(l1), "Angle: %-3d deg ", (int)tempFeedAngle);
                snprintf(l2, sizeof(l2), "S:1   [MD] BACK ");
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 8: // Edit Safety Margin
                snprintf(l1, sizeof(l1), "Safety Margin:  ");
                snprintf(l2, sizeof(l2), "S:1%%  [MD] BACK ");
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 20: // Sensors Sub-Branch Menu
                if (sensorSubIndex == 1)      snprintf(l1, sizeof(l1), "1. Tape Guard   ");
                else if (sensorSubIndex == 2) snprintf(l1, sizeof(l1), "2. Coil Guard   ");
                else if (sensorSubIndex == 3) snprintf(l1, sizeof(l1), "3. Safety Guard ");
                else if (sensorSubIndex == 4) snprintf(l1, sizeof(l1), "4. Motion Relay ");

                if (sensorSubIndex == 1)      snprintf(l2, sizeof(l2), tempSensorGuard ? "PA3: >ON  [MD:ED]" : "PA3: >OFF [MD:ED]");
                else if (sensorSubIndex == 2) snprintf(l2, sizeof(l2), tempCoilGuard ? "PB0: >ON  [MD:ED]" : "PB0: >OFF [MD:ED]");
                else if (sensorSubIndex == 3) snprintf(l2, sizeof(l2), tempPb3Guard ? "PB3: >ON  [MD:ED]" : "PB3: >OFF [MD:ED]");
                else if (sensorSubIndex == 4) snprintf(l2, sizeof(l2), tempMotionRelay ? "PB1: >ON  [MD:ED]" : "PB1: >OFF [MD:ED]");
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 10:
                snprintf(l1, sizeof(l1), "Tape Guard:     ");
                snprintf(l2, sizeof(l2), tempSensorGuard ? "PA3: >ON  [UP]" : "PA3: >OFF [DN]");
                lcdPrint16(0, l1); lcdPrint16(1, l2); break;
            case 11:
                snprintf(l1, sizeof(l1), "Coil Guard:     ");
                snprintf(l2, sizeof(l2), tempCoilGuard ? "PB0: >ON  [UP]" : "PB0: >OFF [DN]");
                lcdPrint16(0, l1); lcdPrint16(1, l2); break;
            case 12:
                snprintf(l1, sizeof(l1), "Safety Guard:   ");
                snprintf(l2, sizeof(l2), tempPb3Guard ? "PB3: >ON  [UP]" : "PB3: >OFF [DN]");
                lcdPrint16(0, l1); lcdPrint16(1, l2); break;
            case 14:
                snprintf(l1, sizeof(l1), "Motion Relay:   ");
                snprintf(l2, sizeof(l2), tempMotionRelay ? "PB1: >ON  [UP]" : "PB1: >OFF [DN]");
                lcdPrint16(0, l1); lcdPrint16(1, l2); break;
            case 16:
                snprintf(l1, sizeof(l1), "Motor Direction:");
                snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: >REV  [DN] " : "Dir: >FWD  [UP] ");
                lcdPrint16(0, l1); lcdPrint16(1, l2); break;

            case 18:
                snprintf(l1, sizeof(l1), "STEP ENGINE:    ");
                snprintf(l2, sizeof(l2), tempHwTimerMode ? "TIM1: >HW  [UP] " : "DDA: >ALT [DN]  ");
                lcdPrint16(0, l1); lcdPrint16(1, l2); break;

            case 9: // Info / Diag: 9 Pages (Jog, Opto, Live Health, HELP sub-branch, System Info)
            {
                int cycle = (millis() / 1500UL) % 2;
                char dl1[24] = "                ";
                char dl2[24] = "                ";
                switch (infoIndex) {
                    case 1: // Stepper Jog Bench Test
                        snprintf(dl1, sizeof(dl1), "STEPPER JOG TST ");
                        if (currentRPM != 0UL || hwBurstActive || stepsRemaining != 0) {
                            snprintf(dl2, sizeof(dl2), "BLOCKED: RUNNING");
                        } else {
                            if (digitalRead(btnUp) == LOW) snprintf(dl2, sizeof(dl2), "JOG FWD >>> [UP]");
                            else if (digitalRead(btnDown) == LOW) snprintf(dl2, sizeof(dl2), "JOG REV <<< [DN]");
                            else snprintf(dl2, sizeof(dl2), "UP:FWD   DN:REV ");
                        }
                        break;
                    case 2: // Optocoupler Sinking Bench Test
                        snprintf(dl1, sizeof(dl1), "OPTO SINK TST   ");
                        if (currentRPM != 0UL || hwBurstActive || stepsRemaining != 0) {
                            snprintf(dl2, sizeof(dl2), "BLOCKED: RUNNING");
                        } else {
                            snprintf(dl2, sizeof(dl2), digitalRead(btnUp) == LOW ? "V<=0.5V SINK ON " : "HOLD [UP] TEST  ");
                        }
                        break;
                    case 3: // Proximity Sensor Health
                        snprintf(dl1, sizeof(dl1), "PROX HEALTH     ");
                        if (lastMeasuredIntervalUs > 0UL) {
                            unsigned long dispRpm = (currentRPM <= 9999UL) ? currentRPM : 9999UL;
                            snprintf(dl2, sizeof(dl2), "P:%-6lu R:%-4lu", (unsigned long)lastMeasuredIntervalUs, dispRpm);
                        } else {
                            snprintf(dl2, sizeof(dl2), "P:WAIT  RPM: 0  ");
                        }
                        break;
                    case 4: // Synchronization Health
                        snprintf(dl1, sizeof(dl1), "SYNC HEALTH     ");
                        if (isMotionSyncLost) {
                            snprintf(dl2, sizeof(dl2), "FAULT:SYNC LOST ");
                        } else if (servoPhaseLocked) {
                            snprintf(dl2, sizeof(dl2), "LOCK J:%-6luus", (unsigned long)servoMaxJitterUs);
                        } else {
                            snprintf(dl2, sizeof(dl2), "ACQUIRING...    ");
                        }
                        break;
                    case 5: // Step Timing Filter
                        snprintf(dl1, sizeof(dl1), "STEP TIMING FILT");
                        snprintf(dl2, sizeof(dl2), "T:%-5lu O:%-2lu R:%-2lu", (unsigned long)(validTriggerCount % 100000UL), (unsigned long)(tim2CaptureOverrunCount % 100UL), (unsigned long)(rejectedTriggerCount % 100UL));
                        break;
                    case 6: // Step & Guard Live Status
                        snprintf(dl1, sizeof(dl1), "STEP / GUARD    ");
                        if (!sensorGuardActive) {
                            snprintf(dl2, sizeof(dl2), "STEP:%s G:OFF  ", hwBurstActive ? "RUN" : "IDLE");
                        } else if (digitalRead(tapeSensorPin) == HIGH) {
                            snprintf(dl2, sizeof(dl2), "STEP:%s TAPE-END", hwBurstActive ? "RUN" : "IDLE");
                        } else {
                            snprintf(dl2, sizeof(dl2), "STEP:%s TAPE:OK ", hwBurstActive ? "RUN" : "IDLE");
                        }
                        break;
                    case 7: // Live Timing Feasibility Health
                        evaluateDiagnostics();
                        snprintf(dl1, sizeof(dl1), "%-16s", diagFixLine1 ? diagFixLine1 : "TIMING HEALTH:  ");
                        snprintf(dl2, sizeof(dl2), "%-16s", diagFixLine2 ? diagFixLine2 : "SYSTEM OPTIMAL  ");
                        break;
                    case 8: // HELP Sub-Branch Gateway
                        snprintf(dl1, sizeof(dl1), "HELP & TROUBLE? ");
                        snprintf(dl2, sizeof(dl2), "[MODE] OPEN HELP");
                        break;
                    case 9: // System Info & Firmware Identity (Moved to end)
                        snprintf(dl1, sizeof(dl1), "V17.0.0 (NIPON) ");
                        if (cycle == 0) snprintf(dl2, sizeof(dl2), "DEV: RAJESH SHAH");
                        else snprintf(dl2, sizeof(dl2), "BLD: %-11s", FW_BUILD_DATE_STR);
                        break;
                    default:
                        infoIndex = 1;
                        break;
                }
                lcdPrint16(0, dl1);
                lcdPrint16(1, dl2);
            }
            break;

            case 21: // HELP Sub-Branch (5 Diagnostic Troubleshooting Guides)
            {
                int cycle = (millis() / 1500UL) % 2;
                char hl1[17] = "                ";
                char hl2[17] = "                ";
                switch (helpIndex) {
                    case 1:
                        snprintf(hl1, sizeof(hl1), "1. MOTOR STALL? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: INC ANGLE  " : "OR DEC RES/RPM  ");
                        break;
                    case 2:
                        snprintf(hl1, sizeof(hl1), "2. PITCH ERROR? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: TUNE DIA MM" : "OR GEAR +/- PUL ");
                        break;
                    case 3:
                        snprintf(hl1, sizeof(hl1), "3. SENSOR NOISE?");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: CLEAN CAM  " : "CHECK PC817 GND ");
                        break;
                    case 4:
                        snprintf(hl1, sizeof(hl1), "4. MOTOR HOT?   ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: SW4=HALF   " : "CURR 2.8A-3.0A  ");
                        break;
                    case 5:
                        snprintf(hl1, sizeof(hl1), "5. TEETH DRIFT? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: TIGHT TAPE " : "CHK ROLLER GRIP ");
                        break;
                    default:
                        helpIndex = 1;
                        break;
                }
                lcdPrint16(0, hl1);
                lcdPrint16(1, hl2);
            }
            break;

// case 12 manual confirmation screen removed

// Obsolete case 7 display dialog removed
        }
        lastDisplayUpdate = millis();
    }
}
