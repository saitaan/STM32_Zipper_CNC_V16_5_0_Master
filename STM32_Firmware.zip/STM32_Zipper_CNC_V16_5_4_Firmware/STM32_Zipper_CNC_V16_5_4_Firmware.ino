#include <cmath>
#include <cstddef>
#include <cstdint>
/*
====================================================================================================
PROJECT  : STM32 ZIPPER CNC (ADAPTIVE SERVO-SYNC MASTER-FOLLOWER ENGINE)
VERSION  : 17.0.0 (PA0 TIM2 CAPTURE -> PA8 TIM1 STEP / TIMING GUARD)
AUTHOR   : RAJESH SHAH / INDUSTRIAL AUTOMATION & EMBEDDED SYSTEMS
DATE     : SEPTEMBER 2026
TARGET   : STM32F103C8T6 (32-BIT ARM CORTEX-M3 @ 72MHz)
LOCATION : NIPON ZIPPER INDUSTRIES PVT LTD, SARIGAM GIDC, GUJARAT, INDIA

VERSION 16.5.0 ARCHITECTURAL ADVANCEMENTS & HARDWARE-LEVEL ENGINE:
1. PRIMARY PROXIMITY->STEP HARDWARE PATH:
   - PA0 is the master proximity input; PA8 is the hardware-timed STEP output.
   - TIM1 hardware generation is the production/default engine; DDA is restored as an operator-selectable diagnostic/alternate engine for timing comparison.
   - First PA0 edge is accepted immediately; the first measured interval establishes real servo synchronization and arms Motion Lost monitoring.
2. OPTIONAL AUXILIARY SENSOR / RELAY SUBSYSTEM:
   - PA3: optional Tape Run-Out sensor.
   - PB0: optional future Coil/Thread sensor.
   - PB3: optional Safety Guard input.
   - PB1: optional Motor Stop Relay.
   - All auxiliary features are OFF by default and have no authority over PA0 capture or PA8 STEP timing.
   - A qualified enabled sensor may request PB1; it never aborts the current STEP burst.
   - Motion Lost may request PB1 only after a real measured PA0 interval has armed the watchdog.
3. BOOTUP HARDWARE RELAY GLITCH SUPPRESSION:
   - Atomic GPIOB->BRR clear on PB1 before setting pinMode to eliminate contact chatter on reset.
4. BACKWARDS-COMPATIBLE THREE-TIER EEPROM MIGRATION:
   - Automatically migrates existing V16.3.3 (0x5A431633) and V16.4.0 (0x5A431640) calibration parameters
     into V16.5.0 (0x5A431650) without resetting roller diameter or driver resolution.
5. 64-BIT DOUBLE PRECISION 1,000,000x DDA MATH:
   - Guaranteed < 0.025 mm error over 1.6 km of fed zipper tape.
====================================================================================================
*/

#ifndef HOST_SIMULATION_TEST
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>
#endif
#include "burst_queue.h"
#include "motion_scheduler.h"
#include "hardware_capture_spec.h"
#include "pulsestep_persistence.h"
#ifndef nvic_irq_enable
#define nvic_irq_enable(irq) NVIC_EnableIRQ(irq)
#endif

#ifndef HOST_SIMULATION_TEST
// Deterministic Zero-Blink HD44780 PCF8574 I2C Driver (Drop-in replacement for LiquidCrystal_I2C)
// Eliminates the standard LiquidCrystal_I2C library's constructor _backlightval = 0x00 bug AND
// eliminates its hardcoded delay(1000) 1-second blank screen at power-on!
class FastLiquidCrystal_I2C {
private:
    uint8_t _addr;
    uint8_t _backlightval; // Locked to 0x08 (Backlight ON) from constructor time!

    inline void expanderWrite(uint8_t data) {
        Wire.beginTransmission(_addr);
        Wire.write((uint8_t)(data | _backlightval));
        Wire.endTransmission();
    }

    inline void pulseEnable(uint8_t data) {
        expanderWrite((uint8_t)(data | 0x04U));  // EN HIGH (P2)
        delayMicroseconds(2);
        expanderWrite((uint8_t)(data & ~0x04U)); // EN LOW  (P2)
        delayMicroseconds(45);
    }

    inline void write4bits(uint8_t nibbleUpper) {
        expanderWrite(nibbleUpper);
        pulseEnable(nibbleUpper);
    }

    inline void send(uint8_t value, uint8_t mode) {
        uint8_t highnib = value & 0xF0U;
        uint8_t lownib  = (uint8_t)((value << 4) & 0xF0U);
        write4bits((uint8_t)(highnib | mode));
        write4bits((uint8_t)(lownib  | mode));
    }

public:
    FastLiquidCrystal_I2C(uint8_t addr, uint8_t, uint8_t)
        : _addr(addr), _backlightval(0x08U) {}

    inline void command(uint8_t value) { send(value, 0x00U); }
    inline void writeChar(uint8_t value) { send(value, 0x01U); }

    // Initializes HD44780 in ~60ms (instead of 1050ms!) with Backlight continuously ON (0x08)
    void init() {
        _backlightval = 0x08U;
        expanderWrite(0x00U); // Keeps P3=HIGH (Backlight ON), RS=0, RW=0, EN=0
        delay(55);            // Wait 55ms for 5V rail > 4.5V (HD44780 spec: >40ms)
        sync4BitModeNoClear();
        clear();
    }

    // Re-synchronizes 4-bit mode & display config WITHOUT clearing DDRAM (zero flicker!)
    void sync4BitModeNoClear() {
        write4bits(0x30U);
        delayMicroseconds(4500);
        write4bits(0x30U);
        delayMicroseconds(4500);
        write4bits(0x30U);
        delayMicroseconds(150);
        write4bits(0x20U);    // 4-bit interface
        command(0x28U);       // 4-bit, 2 lines, 5x8 font
        command(0x0CU);       // Display ON, Cursor OFF, Blink OFF
        command(0x06U);       // Entry mode: left-to-right, no shift
    }

    void clear() {
        command(0x01U);
        delayMicroseconds(2000);
    }

    void setCursor(uint8_t col, uint8_t row) {
        static const uint8_t row_offsets[2] = { 0x00U, 0x40U };
        if (row > 1U) row = 1U;
        if (col > 15U) col = 15U;
        command((uint8_t)(0x80U | (col + row_offsets[row])));
    }

    void print(const char *str) {
        if (!str) return;
        while (*str) {
            writeChar((uint8_t)(*str++));
        }
    }

    void backlight() {
        _backlightval = 0x08U;
        expanderWrite(0x00U);
    }

    void noBacklight() {
        _backlightval = 0x00U;
        expanderWrite(0x00U);
    }
};
FastLiquidCrystal_I2C lcd(0x27, 16, 2);
#else
LiquidCrystal_I2C lcd(0x27, 16, 2);
#endif

// Write exactly 16 LCD columns; prevents stale characters after shorter labels/values.
static char s_lcdShadow[2][17] = {{0}, {0}};
static bool s_lcdShadowValid[2] = {false, false};

static inline void invalidateLcdShadow() {
    s_lcdShadowValid[0] = false;
    s_lcdShadowValid[1] = false;
}

static void lcdPrint16(uint8_t row, const char *text) {
    if (row > 1) return;
    char buf[17];
    snprintf(buf, sizeof(buf), "%-16.16s", text ? text : "");
    if (!s_lcdShadowValid[row]) {
        lcd.setCursor(0, row);
        lcd.print(buf);
        memcpy(s_lcdShadow[row], buf, 17);
        s_lcdShadowValid[row] = true;
        return;
    }
    // Selective character-span update: only transmit the exact changed slice [firstDiff..lastDiff]
    int firstDiff = -1;
    int lastDiff  = -1;
    for (int i = 0; i < 16; i++) {
        if (s_lcdShadow[row][i] != buf[i]) {
            if (firstDiff < 0) firstDiff = i;
            lastDiff = i;
        }
    }
    if (firstDiff < 0) return; // Zero characters changed -> 0 I2C writes!
    char slice[17];
    int len = lastDiff - firstDiff + 1;
    memcpy(slice, &buf[firstDiff], (size_t)len);
    slice[len] = '\0';
    lcd.setCursor((uint8_t)firstDiff, row);
    lcd.print(slice);
    memcpy(s_lcdShadow[row], buf, 17);
}

// =========================================================================
// BUILD IDENTIFIERS & SOURCE-TO-BINARY METADATA
// =========================================================================
#define FW_VERSION_STR       "V17.0.0-PA0-TIM2-CAPTURE-PA8-TIM1"
#define FW_ARCH_TAG_STR      "V17.0.0-PA0-TIM2-CAPTURE-PA8-TIM1" // Backward compatible architecture tag: V16.5.9-PA0-TIM2-CAPTURE-PA8-TIM1
#define FW_BUILD_DATE_STR    "OCT-2026"
#define FW_BUILD_METADATA    "NIPON_ZIPPER_CNC_FW_V17_0_0_PA0_TIM2_CAPTURE_PA8_TIM1_TIMING_GUARD:OCT-2026"

// Embedded ROM identifier string for binary provenance verification
const char g_firmware_build_tag[] __attribute__((used)) = FW_BUILD_METADATA;

// Hardware Pin Definitions (100% Backwards-Compatible Pinout)
const int statusLedPin      = PC13; // Built-in Onboard LED (Active-LOW: LOW=ON, HIGH=OFF)
#define STATUS_LED_ON()    (GPIOC->BRR = (1 << 13))   // Atomic Clear PC13 -> LED ON
#define STATUS_LED_OFF()   (GPIOC->BSRR = (1 << 13))  // Atomic Set PC13   -> LED OFF
const int proxSensorPin     = PA0;  // Cam Proximity (PC817 Opto, Clean MCU GND, Falling ISR)
const int stepPin           = PA8;  // Driver PUL- (Hardware TIM1_CH1 / Direct Register BSRR)
const int dirPin            = PA2;  // Driver DIR- via Level Shifter CH4 LV (GPIOA Pin 2)
const int motorEnaPin       = PB1;  // Stepper Driver ENA- (Active LOW = Run, HIGH = Sleep)
#define MOTOR_ENA_ACTIVE()  (GPIOB->BSRR = (1U << (1 + 16))) // Atomic PB1 LOW  (Driver Enabled)
#define MOTOR_ENA_SLEEP()   (GPIOB->BSRR = (1U << 1))        // Atomic PB1 HIGH (Driver Sleep)
bool isBacklightCurrentlyOn = true;
bool isMotorCurrentlyAsleep = false;
// =========================================================================
// 3-BUTTON / 6-BUTTON DUAL-MODE KEYPAD PIN DEFINITIONS (ACTIVE-LOW INPUT_PULLUP)
// Default Mode: 3-BTN (PB13=UP, PB12=DOWN, PB14=MODE/SELECT) for backward compatibility.
// 6-BTN Mode  : Adds PB15=BACK, PB11=LEFT, PB10=RIGHT (Selectable & Persistent in Settings).
// =========================================================================
const int btnUp             = PB13; // [UP] Button (Active-LOW to Clean MCU GND)
const int btnDown           = PB12; // [DOWN] Button (Active-LOW to Clean MCU GND)
const int btnMode           = PB14; // [SELECT / MODE] Button (Active-LOW to Clean MCU GND)
const int btnBack           = PB15; // [BACK] Button (6-BTN Mode, Active-LOW to Clean MCU GND)
const int btnLeft           = PB11; // [LEFT] Button (6-BTN Mode, Active-LOW to Clean MCU GND)
const int btnRight          = PB10; // [RIGHT] Button (6-BTN Mode, Active-LOW to Clean MCU GND)

// Direct Register Bit Set/Reset (1-Cycle 13.8ns Sinking)
#define STEP_LOW_ACTIVE()  (GPIOA->BSRR = (1 << (8 + 16)))
#define STEP_HIGH_IDLE()   (GPIOA->BSRR = (1 << 8))
#define DIR_LOW()          (GPIOA->BSRR = (1 << (2 + 16)))
#define DIR_HIGH()         (GPIOA->BSRR = (1 << 2))
#define DIR_NORMAL()       DIR_HIGH() // Idle-HIGH for Normal Forward rotation
#define DIR_REVERSE()      DIR_LOW()  // Active-LOW sinking for Reverse rotation

// 1,000,000x Micro-Fractional DDA Fixed-Point Scaling Factor (6 Decimal Places)
#define FIXED_SCALE 1000000ULL

// IWDG: Independent Watchdog Timer (40kHz LSI / 256 Prescaler -> 6.4ms/count, RLR=1000 -> ~6.4s nominal Timeout)
#define IWDG_INIT() do {     IWDG->KR = 0x5555;     IWDG->PR = 0x06;       IWDG->RLR = 1000;       IWDG->KR = 0xAAAA;     IWDG->KR = 0xCCCC; } while (0)
#define IWDG_FEED() (IWDG->KR = 0xAAAA)

// Authoritative EEPROM payload & dual-slot record structures are defined in pulsestep_persistence.h

// 6-Decimal Exact Mathematical Pitch Pulses (6400 Resolution / 45.0mm Roller Diameter)
uint64_t p5_fixed  = 70000000ULL; // Size #5 (2.50mm): 113.176848 steps
uint64_t p8_fixed  = 80000000ULL; // Size #8 (3.00mm): 135.812218 steps
uint64_t p10_fixed = 100000000ULL; // Size #10 (4.00mm): 181.082957 steps

// Discrete Hardware Stepper Driver (DM542) DIP-Switch Resolutions
const int32_t DRIVER_RES_TABLE[] = {
    400, 800, 1000, 1600, 2000, 3200, 4000, 5000, 6400, 8000, 10000, 12800, 20000, 25600, 40000, 51200
};
const uint8_t DRIVER_RES_TABLE_SIZE = sizeof(DRIVER_RES_TABLE) / sizeof(DRIVER_RES_TABLE[0]);

static inline int getDriverResIndex(int32_t res) {
    for (int i = 0; i < (int)DRIVER_RES_TABLE_SIZE; i++) {
        if (DRIVER_RES_TABLE[i] == res) return i;
    }
    // Nearest fallback
    int best = 8; // 6400 default
    int32_t bestDiff = 999999;
    for (int i = 0; i < (int)DRIVER_RES_TABLE_SIZE; i++) {
        int32_t d = abs(DRIVER_RES_TABLE[i] - res);
        if (d < bestDiff) { bestDiff = d; best = i; }
    }
    return best;
}
int32_t driverResolution    = 6400;
float   rollerDia           = 45.0f;
int32_t maxRPMSetting       = 3000;
int32_t feedAngleDeg        = 90;
int32_t safetyMarginPercent = 15;
int     helpIndex           = 1;     // 1: Stall, 2: Pitch, 3: Noise, 4: Hot, 5: Drift
bool    motorDirection      = false; // DEFAULT: FALSE (NORMAL / FORWARD ROTATION)
bool    keypad6ButtonMode   = false; // DEFAULT: FALSE (3-BTN Mode default; TRUE = 6-BTN Mode, persistent in EEPROM)
bool    tempMotorDir        = false; // Staged Menu Direction
bool    tempKeypad6Btn      = false; // Staged Keypad Mode (false = 3-BTN, true = 6-BTN)
uint32_t autoLockSec            = 30UL;  // Default: 30 sec (0: OFF, 10..300s)
uint32_t lastEnabledAutoLockSec = 30UL;  // Remembers last active Auto-Lock seconds when toggled OFF/ON
int32_t  backlightSec           = 0;     // Default: 0 = ALWAYS ON (10..300s, 999: OFF)
uint32_t motorSleepMin          = 0UL;   // Default: 0 = OFF (30..300 min)
#define MAIN_INLINE_EDIT_TIMEOUT_MS 10000UL // 10s idle timeout for Main Screen Watch Inline Editor

uint32_t tempAutoLockSec   = 30UL;
int32_t  tempBacklightSec  = 0;
uint32_t tempMotorSleepMin = 0UL;


bool isEditingMainDecimal  = false; // Main Screen Digital Watch Inline Editor active
uint8_t mainEditCursor     = 0;     // 0: .10 decimal, 1: Units (1s), 2: Tens (10s)
bool unlockPendingDown     = false; // Sequential unlock: true when MODE was pressed and waiting for DOWN
unsigned long unlockPromptUntil = 0UL;
unsigned long lastButtonPressTime = 0UL;
unsigned long lastMotionOrButtonTime = 0UL;
bool    isEditingSetting    = false;
uint8_t settingDigitCursor   = 0; // Digital Watch cursor position (0: Units/Dec, 1: Tens/Int, 2: Hundreds) // In-place blinking parameter edit state in Settings Menu

extern volatile bool hwBurstActive;
extern volatile int stepsRemaining;
void stopHardwareTimerImmediately();
void startHardwareTimerBurst(int stepCount, uint16_t burstPeriodUs, uint32_t burstPeriodQ16);
void startHardwareTimerBurst(int stepCount);

// Hardware-level Motor Direction Controller (PA2 DIR-)
void applyMotorDirection() {
    // Safety: ensure any active movement is completely stopped before changing DIR pin
    if (hwBurstActive || stepsRemaining > 0) {
        stopHardwareTimerImmediately();
    }
    delayMicroseconds(20); // Safe hold time after last step pulse before DIR edge
    if (motorDirection) {
        DIR_LOW();  // Active-LOW sinking for Reverse rotation
    } else {
        DIR_HIGH(); // Idle-HIGH for Normal Forward rotation
    }
    delayMicroseconds(20); // Safe setup time (exceeds 5us DM542 specification by 400%)
}


int autoPulseWidth_P5   = 25;
int autoPulseWidth_P8   = 29;
int autoPulseWidth_P10  = 22;
volatile int activePulseWidth = 70; // Nominal 70us step period (~14.2 kHz) for 3000 RPM / 160 deg

int32_t currentSize = 2; // 1: #5 (2.50mm), 2: #8 (3.00mm) [DEFAULT], 3: #10 (4.00mm)
// =========================================================================
// ATOMIC COHERENT PULSE PARAMETER SNAPSHOT & TELEMETRY
// =========================================================================
#ifndef DEBUG_TEST_MODE
#define DEBUG_TEST_MODE 0
#endif

struct PulseParameters {
    uint32_t integerPart;
    uint32_t fractionalPart;
    uint32_t generation;

    PulseParameters() : integerPart(113), fractionalPart(176848UL), generation(1) {}
    PulseParameters(uint32_t i, uint32_t f, uint32_t g) : integerPart(i), fractionalPart(f), generation(g) {}
    PulseParameters(const PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters(const volatile PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters& operator=(const PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    PulseParameters& operator=(const volatile PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    void operator=(const PulseParameters& o) volatile {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
    }
};

BurstQueue burstQueue;
volatile uint32_t tim4_overflow_count = 0;

volatile PulseParameters activePulseParams   = {113, 176848UL, 1};
PulseParameters          pendingPulseParams  = {113, 176848UL, 1};
volatile uint32_t        paramGenerationUsed = 1;
volatile uint32_t        rejectedTriggerCount = 0; // Live noise rejection counter for diagnostics

#if DEBUG_TEST_MODE
volatile uint32_t acceptedTriggerCount   = 0;
volatile uint32_t triggerMissedCount     = 0;
volatile uint32_t requestedPulseCount    = 0;
volatile uint32_t startedPulseCount      = 0;
volatile uint32_t completedPulseCount    = 0;
volatile uint32_t abortedPulseCount      = 0;
volatile uint32_t queuedPulseCount       = 0;
volatile uint32_t burstStartedCount      = 0;
volatile uint32_t burstCompletedCount    = 0;
volatile uint32_t burstQueuedCount       = 0;
volatile uint32_t paramGenChangesCount   = 0;
volatile uint32_t maxISRLatencyCycles    = 0;
volatile uint32_t maxTriggerJitterUs     = 0;
volatile uint32_t assertionFailureCount  = 0;
#endif

void commitPulseParameters(uint32_t intPart, uint32_t fracPart) {
    pendingPulseParams.integerPart    = intPart;
    pendingPulseParams.fractionalPart = fracPart;
    pendingPulseParams.generation++;
#if DEBUG_TEST_MODE
    paramGenChangesCount++;
#endif
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    activePulseParams.integerPart = pendingPulseParams.integerPart;
    activePulseParams.fractionalPart = pendingPulseParams.fractionalPart;
    activePulseParams.generation = pendingPulseParams.generation;
    __set_PRIMASK(primask);
}

volatile uint64_t currentPulsesFixed = 80000000ULL;
volatile uint32_t currentPulsesInt   = 80;      // Whole step portion for fast 32-bit ISR math
volatile uint32_t currentPulsesFrac  = 0UL; // Fractional micro-step portion (< 1,000,000)
volatile uint32_t pulseFracAccumulator = 0UL;     // 32-bit fractional accumulator (zero 64-bit division)
volatile uint32_t tim2OverflowCount = 0UL;
volatile uint32_t tim2CaptureOverrunCount = 0UL;
volatile uint32_t tim2CaptureEpochOffsetUs = 0UL;
volatile bool tim2CaptureEpochReady = false;
volatile uint32_t tim2CaptureMissedCallbacks = 0UL;
volatile bool     isCaptureStreamDiscontinuous = false;
volatile uint32_t tim2CaptureResyncEvents      = 0UL;
// Last accepted PA0 trigger timestamp, sourced from the extended TIM2 hardware-capture clock.
volatile bool pendingMenuExit = false;

bool isUiLocked = false; // Unlocked on boot; locks ONLY via autoLockSec timer
unsigned long lastUnlockActivity = 0UL;

// =========================================================================
// 1-MINUTE CONTINUOUS SMOOTH RUN AUTO-SAVE STATE MACHINE
// Gated strictly to 0 RPM Standstill (Zero Pulse & Trigger Interference)
// Anti-Repeat Latch: Saved exactly once per parameter modification
// =========================================================================
bool pulseModifiedByUser            = false;  // Armed when user tunes pulse with UP/DOWN
bool autoSavePendingStandstill       = false;  // Set when 60s qualified in RAM; deferred to 0 RPM
AutoSaveQualificationEngine autoSaveEngine(120000UL); // Formal 2-Minute Cooldown Auto-Save Engine
FlashSaveTransactionEngine  flashSaveTx;             // Atomic Flash Save Transaction Engine (Prompt 8Writing)

// Accepted motion-trigger counters and diagnostics (PA0 TIM2 input capture path).
volatile uint32_t acceptedTriggerPulses          = 0;

// Authoritative PulseStep Persistence State Tracking
uint32_t flashWriteCount            = 0;      // Diagnostic counter: strictly increments on actual Flash write
uint32_t activeEEPROMSlot           = 0;      // Active transaction slot (0 or 1)
uint32_t eepromSeqNumber            = 0;      // Monotonic transaction sequence counter
uint64_t pulseStepStored_p5         = 70000000ULL; // Stored ROM baseline for Size #5
uint64_t pulseStepStored_p8         = 80000000ULL; // Stored ROM baseline for Size #8
uint64_t pulseStepStored_p10        = 100000000ULL; // Stored ROM baseline for Size #10
bool     eepromSlotInitialized      = false;

// In-Place Parameter Blinking State (Replaces pop-up feedback windows on value change)
enum BlinkTarget : uint8_t {
    BLINK_NONE          = 0,
    BLINK_MAIN_PULSE    = 1, // Blinks full P:xx.x on Main Screen
    BLINK_MAIN_GEAR_INT = 2, // Blinks integer part of P:xx.x on direct UP/DOWN (+/-1.0)
    BLINK_MAIN_GEAR_DEC = 3, // Blinks .10 decimal digit in Main Inline Editor (cursor 0)
    BLINK_MAIN_SIZE     = 4, // Blinks S:x on Main Screen when zipper size changes
    BLINK_MAIN_LOCK     = 5, // Blinks [L]/[U] on Main Screen
    BLINK_MAIN_UNITS    = 6, // Blinks Units digit (1s) in Main Inline Editor (cursor 1)
    BLINK_MAIN_TENS     = 7, // Blinks Tens digit (10s) in Main Inline Editor (cursor 2)
    BLINK_MAIN_HUNDREDS = 8  // Blinks Hundreds digit (100s) in Main Inline Editor (cursor 3)
};
unsigned long lastEditKeyPressMs = 0UL; // Keeps edited digit 100% solid for 400ms after UP/DOWN press!
volatile uint8_t blinkTarget      = BLINK_NONE;
unsigned long    blinkUntilMs     = 0UL;

static inline void setMainEditCursorAndBlink(uint8_t cur) {
    isEditingMainDecimal = true;
    mainEditCursor       = (uint8_t)(cur % 4U);
    if (mainEditCursor == 0U)      blinkTarget = BLINK_MAIN_GEAR_DEC;
    else if (mainEditCursor == 1U) blinkTarget = BLINK_MAIN_UNITS;
    else if (mainEditCursor == 2U) blinkTarget = BLINK_MAIN_TENS;
    else                           blinkTarget = BLINK_MAIN_HUNDREDS;
    blinkUntilMs       = millis() + MAIN_INLINE_EDIT_TIMEOUT_MS;
    lastEditKeyPressMs = millis();
}


unsigned long uiMessageTimer = 0UL;
const char* uiBannerLine1 = nullptr;
const char* uiBannerLine2 = nullptr;

// Staged RAM Parameters for Zero Flash Wear
int32_t tempDriverRes       = 6400;
float   tempRollerDia       = 45.0f;
int32_t tempMaxRPM          = 3000;
int32_t tempFeedAngle       = 90;
int32_t tempSafetyMargin    = 15;

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm);

static inline bool stagedTimingConfigurationFeasible() {
    const double pitch5  = 1.54625411; // V17.0.0 Calibrated for 70.00 pulses at 6400 res / 45mm roller
    const double pitch8  = 1.76714755; // V17.0.0 Calibrated for 80.00 pulses at 6400 res / 45mm roller
    const double pitch10 = 2.20893444; // V17.0.0 Calibrated for 100.00 pulses at 6400 res / 45mm roller
    return timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch5) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch8) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch10);
}

// True when the manually tuned pulse count cannot fit inside the configured
// feed-angle window at the configured maximum RPM. Never silently clamp an
// invalid manual tuning to the 8us timer floor.
volatile bool pulseTimingInvalid = false;
volatile bool isTimingOverrun    = false; // Latches active burst queue saturation

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#ifndef SERVO_PERIOD_Q_SHIFT
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U
#endif

static inline bool currentPulseTimingFeasible() {
    if (driverResolution < 200 || driverResolution > 51200 || rollerDia < 10.0f || rollerDia > 100.0f ||
        maxRPMSetting < 100 || maxRPMSetting > 4000 || feedAngleDeg < 30 || feedAngleDeg > 270 ||
        safetyMarginPercent < 0 || safetyMarginPercent > 29) return false;
    const double circumference = 3.14159265358979323846 * (double)rollerDia;
    (void)circumference;
    const double stepCount = (double)currentPulsesFixed / 1000000.0;
    const double feedWindowUs = (60000000.0 / (double)maxRPMSetting) * ((double)feedAngleDeg / 360.0) *
                                (1.0 - ((double)safetyMarginPercent / 100.0));
    const double overlapDeadlineUs = (60000000.0 / (double)maxRPMSetting) * 0.75 * 0.80;
    const double windowUs = (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
    return stepCount > 0.0 && windowUs > 0.0 && (windowUs / stepCount) >= (double)SERVO_PERIOD_MIN_US;
}

static inline void refreshPulseTimingValidity() {
    pulseTimingInvalid = !currentPulseTimingFeasible();
}
bool    hasStagedChanges    = false;
bool    isTimingWarningActive = false;
int diagMinW = 0;
const char* diagFixLine1 = nullptr;
const char* diagFixLine2 = nullptr;
int infoIndex = 1;

// Motion Sync Watchdog & Diagnostic State
volatile bool isMotionSyncLost     = false; // Diagnostic state; never blocks PA0/PA8 timing
volatile bool motionWatchdogArmed   = false; // Armed only after a valid measured trigger interval
volatile uint32_t validTriggerCount  = 0;
volatile int  faultType            = 0;     // 0: None, 3: Trigger Sync Lost

// Stepper Step State Machine
volatile unsigned long lastTriggerMicros = 0UL;
volatile unsigned long lastMeasuredIntervalUs = 0UL;
volatile int stepsRemaining = 0;
volatile int totalStepsInBurst = 0;
volatile bool stepPinState = HIGH;

// Hardware Timer 2 Burst Controller State
volatile bool hwBurstActive = false;
volatile int  hwBurstStepsTarget = 0;
volatile int  hwBurstStepsDone = 0;

volatile unsigned long currentRPM = 0UL;
// RPM display-only robust estimator. It does not control PA0 qualification,
// the watchdog's raw interval, or PA8 STEP scheduling.
volatile uint32_t rpmIntervalHistoryUs[3] = {0UL, 0UL, 0UL};
volatile uint8_t rpmIntervalHistoryCount = 0U;
volatile uint8_t rpmIntervalHistoryIndex = 0U;
unsigned long lastDisplayUpdate = 0UL;
unsigned long lastRpmDisplayUpdate = 0UL;
unsigned long lastButtonCheck = 0UL;
unsigned long modePressTime = 0UL;
unsigned long lastModeClickTime = 0UL;
unsigned long dualPressTime = 0UL;

bool modePressed = false;
bool upDownPressed = false;
bool pendingSingleClick = false;
bool pendingMenuSingleClick = false;
unsigned long lastMenuModeClickTime = 0UL;

int menuState = 0;
int oldMenuState = -1;
int hiddenOption = 1;
bool resetChoice = false;
bool saveExitChoice = true; // Save & Exit Dialog: true = YES, false = NO

// Hardware Timer 2 Instance for Stepping Pulses
// =========================================================================
// AUTHORITATIVE CNC MOVEMENT STATE MACHINE
// IDLE -> ARMED -> RUNNING -> STOPPING -> COMPLETE -> IDLE
// Fault/Abort: RUNNING/STOPPING -> FAULT/ABORTED -> IDLE (Standstill Gated)
// =========================================================================
enum MovementState {
    STATE_IDLE = 0,
    STATE_ARMED,
    STATE_RUNNING,
    STATE_STOPPING,
    STATE_COMPLETE,
    STATE_ABORTED,
    STATE_FAULT
};
volatile MovementState movementState = STATE_IDLE;

inline bool isMachineSafelyIdle() {
    return (currentRPM == 0UL) &&
           (stepsRemaining == 0) &&
           (!hwBurstActive) &&
           (burstQueue.isEmpty()) &&
           (movementState == STATE_IDLE || movementState == STATE_COMPLETE);
}

const uint16_t STEP_PULSE_WIDTH_US   = 5; // 5.0us Active LOW pulse for Leadshine DM542

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U

// Trigger interval history is shared by RPM display and robust STEP-period estimation.
volatile uint32_t servoPhaseRelockCount = 0;
volatile bool servoPhaseLocked = false;
volatile uint32_t servoLastIntervalUs = 0;
volatile uint32_t servoPrevIntervalUs = 0;
volatile uint32_t servoMaxJitterUs = 0;
volatile uint32_t servoPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t hwBurstPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t hwBurstPeriodFrac = 0;

static inline uint16_t q16PeriodToTimerUs(volatile uint32_t &frac, uint32_t q16) {
    // True Q16.16 accumulation: retain both the configured fractional period
    // and the carry from prior timer cycles. This preserves the long-term
    // average period instead of truncating the Q16 fractional component.
    uint32_t sum = (q16 & 0xFFFFUL) + (frac & 0xFFFFUL);
    uint32_t whole = (q16 >> SERVO_PERIOD_Q_SHIFT) + (sum >> SERVO_PERIOD_Q_SHIFT);
    frac = sum & 0xFFFFUL;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, double pitchMm) {
    if (resolution < 200 || resolution > 51200 || !(diameter == diameter) || diameter < 10.0f || diameter > 100.0f ||
        rpm < 100 || rpm > 4000 || angle < 30 || angle > 270 || margin < 0 || margin > 29 || pitchMm <= 0.0) return false;
    const double circumference = 3.14159265358979323846 * (double)diameter;
    const double stepCount = ((double)resolution / circumference) * pitchMm;
    const double feedWindowUs = (60000000.0 / (double)rpm) * ((double)angle / 360.0) * (1.0 - ((double)margin / 100.0));
    const double overlapDeadlineUs = (60000000.0 / (double)rpm) * 0.75 * 0.80;
    const double windowUs = (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
    if (!(stepCount > 0.0) || !(windowUs > 0.0)) return false;
    // The timer's hard minimum is 8 us. A configuration whose requested burst
    // period is below this cannot physically fit the commanded pulse count into
    // the configured feed-angle window. Never silently clamp such a case to 8 us.
    return (windowUs / stepCount) >= (double)SERVO_PERIOD_MIN_US;
}

// Reserve explicit timing headroom so a valid trigger at the configured RPM ceiling
// cannot arrive while the previous STEP burst is still active. The trigger plausibility
// guard accepts intervals down to 75% of a configured revolution; use only 80% of that
// floor for STEP time (60% of a revolution) as a conservative deadline.
static inline uint64_t maximumBurstWindowUs(int32_t rpm, int32_t angle, int32_t margin) {
    if (rpm < 100 || rpm > 4000) rpm = 3000;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    if (margin < 0) margin = 0;
    if (margin > 29) margin = 29;
    const uint64_t revolutionUs = 60000000ULL / (uint32_t)rpm;
    const uint64_t feedWindowUs = (revolutionUs * (uint32_t)angle / 360ULL) * (uint32_t)(100 - margin) / 100ULL;
    const uint64_t minimumAcceptedIntervalUs = revolutionUs * 3ULL / 4ULL;
    const uint64_t overlapDeadlineUs = minimumAcceptedIntervalUs * 80ULL / 100ULL;
    return (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
}

static inline uint32_t calculateAdaptiveStepPeriodQ16(uint32_t revolutionUs, uint32_t stepCount) {
    if (stepCount == 0U || revolutionUs == 0U) return servoPeriodQ16;
    int angle = feedAngleDeg;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    int margin = safetyMarginPercent;
    if (margin < 0) margin = 0;
    if (margin > 29) margin = 29;
    uint64_t windowUs = ((uint64_t)revolutionUs * (uint64_t)angle) / 360ULL;
    windowUs = (windowUs * (uint64_t)(100 - margin)) / 100ULL;
    // Dynamic burst cap: never let a burst exceed the configured maximum-RPM overlap deadline
    const uint64_t configuredDeadlineUs = maximumBurstWindowUs(maxRPMSetting, angle, margin);
    if (windowUs > configuredDeadlineUs) windowUs = configuredDeadlineUs;
    if (windowUs < 1ULL) windowUs = 1ULL;
    uint64_t q16 = (windowUs << SERVO_PERIOD_Q_SHIFT) / (uint64_t)stepCount;
    uint64_t minQ = ((uint64_t)SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT);
    uint64_t maxQ = ((uint64_t)SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT);
    if (q16 < minQ) q16 = minQ;
    if (q16 > maxQ) q16 = maxQ;
    return (uint32_t)q16;
}


HardwareTimer *stepTimer     = new HardwareTimer(TIM1);
HardwareTimer *captureTimer  = new HardwareTimer(TIM2); // PA0 input capture; core-owned TIM2 IRQ dispatch
#if defined(TIM4)
HardwareTimer *timebaseTimer = new HardwareTimer(TIM4);
#endif

// =========================================================================
// TRUE HARDWARE TIMER 2 PWM (OC2) STEP GENERATION & BURST CONTROLLER
// 1. Pure Continuous PWM Mode 2: Inactive (HIGH) 0..CCR2-1, Active (LOW) CCR2..ARR.
// 2. Output is natively, physically HIGH at CNT=0 rollover.
// 3. Software halts CEN and CC2E at CNT=0 upon burst completion (0.2us latency vs 30us safety window).
// 4. Zero OPM hardware race conditions: Timer NEVER stalls or dies on rapid/boundary triggers!
// 5. Seamless mid-burst trigger accumulation: Target += stepCount without losing a single pulse.
// =========================================================================

// =========================================================================
// DETERMINISTIC MULTI-SEGMENT RAMP PARAMETER CALCULATOR
// Provides smooth, bounded acceleration/deceleration with zero staircase jerk
// Dedicated short-burst handling: N<=4 (pure cruise), 5<=N<=12 (gentle soft boundary)
// =========================================================================
static inline void updateStepPeriodFromServoInterval(uint32_t revolutionUs, uint32_t stepCount) {
    if (revolutionUs == 0U || stepCount == 0U) return;
    servoPrevIntervalUs = servoLastIntervalUs;
    servoLastIntervalUs = revolutionUs;
    if (servoPrevIntervalUs != 0U) {
        uint32_t jitter = (revolutionUs > servoPrevIntervalUs) ? (revolutionUs - servoPrevIntervalUs) : (servoPrevIntervalUs - revolutionUs);
        if (jitter > servoMaxJitterUs) servoMaxJitterUs = jitter;
    }
    servoPeriodQ16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    servoPhaseLocked = (servoPrevIntervalUs != 0U);
    if (servoPhaseLocked) servoPhaseRelockCount++;
}

void stepTimerCallback() {
    if (hwBurstActive && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        hwBurstStepsDone++;
#if DEBUG_TEST_MODE
        completedPulseCount++;
#endif

        if (hwBurstStepsDone >= hwBurstStepsTarget) {
            BurstItem nextBurst{};
            if (movementState != STATE_FAULT && movementState != STATE_ABORTED && burstQueue.dequeue(nextBurst)) {
                // Seamlessly chain queued burst from authoritative SPSC BurstQueue without dropping timer
                hwBurstStepsTarget = (int)nextBurst.stepCount;
                hwBurstStepsDone   = 0;
#if DEBUG_TEST_MODE
                queuedPulseCount  -= nextBurst.stepCount;
                startedPulseCount += nextBurst.stepCount;
                burstStartedCount++;
#endif
                stepsRemaining     = hwBurstStepsTarget;
                totalStepsInBurst  = hwBurstStepsTarget;

                // Direction Fix (per Rajesh Shah directive):
                // Direction is strictly Settings-controlled and fixed during RUN.
                // Pulse, burst, queue, ISR, DDA, RPM, trigger, and sensor processing NEVER change DIR at runtime.

                // Each queued burst carries the period calculated from the physical
                // servo interval that created it. Never rewrite the active burst with a
                // newer measurement; this preserves deterministic phase timing.
                if (nextBurst.periodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && nextBurst.periodQ16 <= (SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT)) {
                    hwBurstPeriodQ16 = nextBurst.periodQ16;
                    hwBurstPeriodFrac = 0;
                } else if (nextBurst.periodUs >= SERVO_PERIOD_MIN_US && nextBurst.periodUs <= SERVO_PERIOD_MAX_US) {
                    hwBurstPeriodQ16 = ((uint32_t)nextBurst.periodUs << SERVO_PERIOD_Q_SHIFT);
                    hwBurstPeriodFrac = 0;
                }
                uint16_t firstScheduledUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
                activePulseWidth = (int)firstScheduledUs;
                uint16_t nextARR = (firstScheduledUs > 1) ? (uint16_t)(firstScheduledUs - 1) : 1;
                TIM1->ARR = nextARR;
                uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
                if (pWidth < 2) pWidth = 2;
                TIM1->CCR1 = nextARR - pWidth + 1;
                return;
            }

            // Burst complete with no queued steps: disable PWM output and stop timer in silicon
            TIM1->CCER &= ~TIM_CCER_CC1E; // Disconnect hardware PWM output on PA8 immediately
            TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
            
            // Restore PA8 pin to General Purpose Output HIGH (Idle)
            GPIOA->CRH &= ~(0xFU << 0);
            GPIOA->CRH |= (0x3U << 0); // 50MHz GP Output Push-Pull
            STEP_HIGH_IDLE();
            stepPinState = HIGH;

            // Clear any pending update flags in NVIC
            TIM1->SR &= ~TIM_SR_UIF;
            NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

            hwBurstActive  = false;
            stepsRemaining = 0;
            movementState  = STATE_COMPLETE;
#if DEBUG_TEST_MODE
            burstCompletedCount++;
            if (queuedPulseCount == 0 && !hwBurstActive) {
                if (requestedPulseCount != (completedPulseCount + abortedPulseCount)) {
                    assertionFailureCount++;
                }
            }
#endif
            STATUS_LED_OFF(); // Stepper burst complete -> Turn OFF LED
        } else {
            stepsRemaining = (hwBurstStepsTarget - hwBurstStepsDone);
            movementState  = STATE_RUNNING;

            // Keep every pulse in the burst at the servo-synchronized period.
            // Artificial per-pulse ramps are deliberately removed because they change
            // the commanded pulse density away from the measured master motion.
            uint16_t scheduledPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
            activePulseWidth = (int)scheduledPeriodUs;
            uint16_t nextARR = (scheduledPeriodUs > 1) ? (uint16_t)(scheduledPeriodUs - 1) : 1;
            TIM1->ARR  = nextARR;
            uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
            if (pWidth < 2) pWidth = 2;
            TIM1->CCR1 = nextARR - pWidth + 1; // Pulse ends exactly at ARR rollover
        }
    } else {
        TIM1->CCER &= ~TIM_CCER_CC1E;
        TIM1->CR1  &= ~TIM_CR1_CEN;
        GPIOA->CRH &= ~(0xFU << 0);
        GPIOA->CRH |= (0x3U << 0);
        STEP_HIGH_IDLE();
        stepPinState   = HIGH;
        TIM1->SR &= ~TIM_SR_UIF;
        NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
        hwBurstActive  = false;
        stepsRemaining = 0;
        movementState  = STATE_IDLE;
    }
}

// =========================================================================
// DETERMINISTIC 1 KHZ HARDWARE SAFETY MONITOR (TIM3)
// Unblockable by loop() or I2C LCD delays. 15ms Anti-Vibration Qualified E-Stop.
// =========================================================================
static inline uint32_t get_hardware_timestamp_us(); // shared timebase prototype
void processSensorTrigger(uint32_t capturedTimestampUs); // forward declaration for TIM2 callback

// =========================================================================
// CONTINUOUS 1 MHZ FREE-RUNNING TIMER 4 (STM32F103 HARDWARE TIMESTAMPING)
// 1.0 microsecond deterministic tick resolution, independent of TIM2/TIM3
// =========================================================================
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
void tim4UpdateCallback(void) {
    tim4_overflow_count++;
}

void initFreeRunningTimer4() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;

    // Attach callback using official STM32duino HardwareTimer framework
    // (Prevents duplicate definition of TIM4_IRQHandler with SrcWrapper/HardwareTimer.cpp)
    timebaseTimer->pause();
    timebaseTimer->setPrescaleFactor(72);     // 72MHz / 72 = 1MHz (1.0 us tick)
    timebaseTimer->setOverflow(0x10000UL);    // 16-bit free-running counter rollover at 65535us
    timebaseTimer->setCount(0);
    timebaseTimer->attachInterrupt(tim4UpdateCallback);
    timebaseTimer->resume();

    // Enforce exact silicon register configuration after resume()
    TIM4->PSC = 71;     // 72MHz / (71 + 1) = 1MHz (1.0 us tick)
    TIM4->ARR = 0xFFFF; // 16-bit free-running counter rollover at 65535us
    TIM4->CNT = 0;
    TIM4->EGR = TIM_EGR_UG;     // Immediately force-load prescaler shadow buffer in hardware
    TIM4->SR &= ~TIM_SR_UIF;    // Clear the update interrupt flag generated by EGR_UG
    TIM4->DIER |= TIM_DIER_UIE; // Enable update interrupt for 32-bit rollover
}

// Provably race-safe atomic snapshot across 16-bit hardware timer overflow
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t high;
    uint16_t low;
    bool pending;

    do {
        high = tim4_overflow_count;
        low  = (uint16_t)(TIM4->CNT);
        pending = (TIM4->SR & TIM_SR_UIF) != 0;
    } while (high != tim4_overflow_count);

    // If an overflow interrupt is pending (UIF set) and CNT has already rolled over
    // to a small value (< 0x8000), account for the unserviced rollover in this reading
    if (pending && (low < 0x8000)) {
        high++;
    }

    return (high << 16) | low;
}
#else
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t nowCycles = 0;
#if defined(CoreDebug) && defined(DWT)
    nowCycles = DWT->CYCCNT;
#endif
    return (nowCycles != 0) ? (nowCycles / 72UL) : micros();
}
#endif
// TIM2 update callback extends the 1 MHz capture counter across 16-bit wraps.
// The core-owned TIM2_IRQHandler calls these through HardwareTimer's HAL bridge.
void tim2CaptureRolloverCallback() {
    tim2OverflowCount++;
}

void tim2WakeOnceCallback(); // Forward declaration for 1-time sleep wake ISR hook

void tim2HardwareCaptureCallback() {
    // ZERO-CHECK MOTION CAPTURE ISR:
    // No motor sleep check is executed here during normal operation (0 CPU cycles overhead).
    // CCR1 was latched by hardware at the PA0 falling edge, before ISR latency.
    if ((TIM2->SR & TIM_SR_CC1OF) != 0U) {
        tim2CaptureOverrunCount++;
        tim2CaptureMissedCallbacks++; // Accurately record each missed edge in silicon
        isCaptureStreamDiscontinuous = true; // Flag stream discontinuity to prevent false RPM drop
        TIM2->SR &= ~TIM_SR_CC1OF;
    }
    const uint16_t captured = (uint16_t)captureTimer->getCaptureCompare(1);
    uint32_t high = tim2OverflowCount;
    const uint16_t cntNow = (uint16_t)TIM2->CNT;
    const bool updateStillPending = (TIM2->SR & TIM_SR_UIF) != 0U;

    // Provably race-safe atomic epoch resolution across 16-bit hardware timer overflow
    if (updateStillPending) {
        // Rollover occurred in hardware (UIF set), but tim2CaptureRolloverCallback has not
        // incremented tim2OverflowCount yet because HAL services capture callback first.
        // If capture was latched after rollover (small captured value), it belongs to high + 1!
        if (captured < 0x8000U) {
            high++;
        }
    } else {
        // Rollover callback already executed and incremented tim2OverflowCount.
        // If capture occurred just before the wrap (large value near 0xFFFF), it belongs to previous epoch.
        if (high > 0UL && cntNow < captured && (uint16_t)(captured - cntNow) > 0x8000U) {
            high--;
        }
    }

    const uint32_t captureClockUs = (high << 16) | (uint32_t)captured;
    if (!tim2CaptureEpochReady) {
        // Align the capture clock to the TIM4 monotonic clock once. Thereafter,
        // intervals come from TIM2 hardware captures, not ISR dispatch timing.
        tim2CaptureEpochOffsetUs = get_hardware_timestamp_us() - captureClockUs;
        tim2CaptureEpochReady = true;
    }
    const uint32_t captureTimestampUs = tim2CaptureEpochOffsetUs + captureClockUs;
    processSensorTrigger(captureTimestampUs);
}

// Dedicated 1-Time Wake Callback attached ONLY while motor is in Standstill Sleep Mode:
void tim2WakeOnceCallback() {
    MOTOR_ENA_ACTIVE(); // 1-cycle (13.8 ns) hardware wake on PB1
    isMotorCurrentlyAsleep = false;
    captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback); // Restore zero-check running ISR immediately!
    tim2HardwareCaptureCallback();
}

void initHardwareTimer2() {
    // TIM2_CH1 on PA0 is the single authoritative motion-trigger source.
    // TIM2 capture hardware latches the falling-edge timestamp independent of
    // CPU interrupt latency; its IRQ performs the trigger processing exactly once.
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    // Bind stepTimer callback & enable TIM1_UP_IRQn in NVIC via HardwareTimer first,
    // then immediately place TIM1 in deterministic idle state before configuring registers.
    stepTimer->pause();
    stepTimer->setPrescaleFactor(72);
    stepTimer->setOverflow(100);
    stepTimer->setInterruptPriority(0, 0); // Priority 0 (Highest) for exact TIM1 burst cutoff
    stepTimer->attachInterrupt(stepTimerCallback);
    stepTimer->resume();

    // TIM1 STEP engine: 1 MHz timer tick; active-low PWM Mode 2.
    TIM1->CR1 = 0;
    TIM1->CCER &= ~TIM_CCER_CC1E;
    TIM1->PSC = 71;
    TIM1->RCR = 0;
    uint16_t initARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
    TIM1->ARR = initARR;
    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    TIM1->CCMR1 |= (0x7U << 4); // CH1 PWM Mode 2
    TIM1->CCMR1 |= TIM_CCMR1_OC1PE;
    TIM1->CCER |= TIM_CCER_CC1P;
    TIM1->CR1 |= TIM_CR1_ARPE;
    TIM1->CR1 &= ~TIM_CR1_OPM;
    TIM1->BDTR |= TIM_BDTR_MOE; // Required for advanced-control TIM1 outputs
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR = TIM_EGR_UG;     // Force-load PSC=71, ARR, CCR1, RCR=0 into hardware shadow registers
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    NVIC_SetPriority(TIM1_UP_IRQn, 0);
    TIM1->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM1_UP_IRQn);

    // Keep PA8 in GP Output Push-Pull HIGH (0x3) while idle so STEP_HIGH_IDLE(),
    // Stepper Jog Test (Page 1), Opto Sink Test (Page 2), and DDA mode work directly.
    // startHardwareTimerBurst() switches PA8 to AF Push-Pull (0xB) during active TIM1 bursts.
    pinMode(stepPin, OUTPUT);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0); // PA8 GP output push-pull, 50 MHz (Idle HIGH)

    // TIM2_CH1 input capture: PA0 / TI1, falling edge, 1 MHz counter.
    // Use STM32duino HardwareTimer callbacks: the core owns TIM2_IRQHandler,
    // and dispatches capture/update callbacks through HAL_TIM_IRQHandler.
    // This makes the CCR1 hardware-latched edge timestamp authoritative without
    // defining a duplicate TIM2_IRQHandler symbol or also dispatching EXTI0.
    captureTimer->pause();
    captureTimer->setMode(1, TIMER_INPUT_CAPTURE_FALLING, proxSensorPin);
    captureTimer->setPrescaleFactor(72);       // 72 MHz / 72 = 1 MHz (1 us/tick)
    captureTimer->setOverflow(0x10000UL);      // 16-bit wrap; overflow callback extends it
    captureTimer->setCount(0);
    tim2OverflowCount = 0UL;
    tim2CaptureOverrunCount = 0UL;
    tim2CaptureEpochOffsetUs = 0UL;
    tim2CaptureEpochReady = false;
    tim2CaptureMissedCallbacks = 0UL;
    captureTimer->setInterruptPriority(1, 0); // Priority 1 for immediate trigger preemption
    captureTimer->attachInterrupt(tim2CaptureRolloverCallback);
    captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback);
    captureTimer->resume();

    // Restore PA0 internal pull-up (setMode resets PA0 to floating input) and enforce IC1F filter
    GPIOA->CRL &= ~(0xFU << 0);
    GPIOA->CRL |= (0x8U << 0);  // Input with pull-up / pull-down
    GPIOA->BSRR = (1U << 0);    // Pull-up enabled on PA0
    // SILICON-LEVEL HARDWARE DIGITAL FILTER (IC1F = 0011):
    // Digital filter debounces PA0 pin for N=8 consecutive clock cycles (111 ns) at f_CK_INT (72MHz).
    // Eliminates high-frequency motor contactor/clutch noise directly in hardware with 0% CPU overhead!
    TIM2->CCMR1 &= ~TIM_CCMR1_IC1F;
    TIM2->CCMR1 |= (0x3U << 4);
}

void startHardwareTimerBurst(int stepCount) {
    startHardwareTimerBurst(stepCount, 0U, 0U);
}

void startHardwareTimerBurst(int stepCount, uint16_t burstPeriodUs, uint32_t burstPeriodQ16) {
    if (stepCount <= 0 || movementState == STATE_FAULT || movementState == STATE_ABORTED) return;

    // ATOMIC CRITICAL SECTION: protect TIM1 hardware start sequence.
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    uint32_t targetPeriodQ16 = burstPeriodQ16 ? burstPeriodQ16 : ((uint32_t)burstPeriodUs << SERVO_PERIOD_Q_SHIFT);
    if (burstPeriodQ16 == 0U && burstPeriodUs == 0U) targetPeriodQ16 = servoPeriodQ16;
    static uint32_t s_burstSeq = 0;

    if (hwBurstActive) {
        // Rare mid-burst overlap path: only read timestamp & enqueue if previous burst is still active
        uint32_t nowUs = get_hardware_timestamp_us();
        if (targetPeriodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && targetPeriodQ16 < hwBurstPeriodQ16) {
            hwBurstPeriodQ16 = targetPeriodQ16;
        }
        bool enqueued = burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, targetPeriodQ16);
        if (enqueued) {
#if DEBUG_TEST_MODE
            burstQueuedCount++;
            queuedPulseCount += stepCount;
#endif
        } else {
            // Queue saturation / timing overrun: previous burst exceeded mechanical revolution window!
            rejectedTriggerCount++;
            isTimingWarningActive = true;
            isTimingOverrun       = true;
        }
        movementState = STATE_RUNNING;
        __set_PRIMASK(primask);
        return;
    }

    // ULTRA-FAST DIRECT REGISTER PATH (Zero Queue Enqueue/Dequeue Overhead when Idle!):
    hwBurstPeriodQ16   = targetPeriodQ16;
    hwBurstPeriodFrac  = 0;
    hwBurstStepsTarget = stepCount;
    hwBurstStepsDone   = 0;
    hwBurstActive      = true;
#if DEBUG_TEST_MODE
    burstStartedCount++;
    startedPulseCount += stepCount;
#endif
    stepsRemaining     = stepCount;
    totalStepsInBurst  = stepCount;
    stepPinState       = HIGH;
    movementState      = STATE_RUNNING;

    // The servo is the mechanical master. Do not invent an acceleration ramp here.
    // activePulseWidth is derived from the most recent physical trigger interval;
    // maxRPMSetting is only the startup/fallback bound before the first valid interval.
    uint16_t initPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
    activePulseWidth = (int)initPeriodUs;
    uint16_t initARR = (initPeriodUs > 1) ? (uint16_t)(initPeriodUs - 1) : 1;
    TIM1->CR1 &= ~TIM_CR1_CEN;
    TIM1->PSC  = 71;
    TIM1->RCR  = 0;
    TIM1->ARR  = initARR;

    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;

    // Ensure PWM Mode 2, preload, active-low polarity, and OPM disabled
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    TIM1->CCMR1 |= (0x7U << 4) | TIM_CCMR1_OC1PE;
    TIM1->CCER  |= TIM_CCER_CC1P;
    TIM1->CR1   |= TIM_CR1_ARPE;
    TIM1->CR1   &= ~TIM_CR1_OPM;

    // Force load preload registers into shadow registers and reset CNT to 0
    // Temporarily mask UIE so EGR_UG does not latch a spurious update interrupt into NVIC
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR   = TIM_EGR_UG;
    TIM1->SR   &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    TIM1->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM1_UP_IRQn);

    // Enable hardware PWM output and Main Output Enable on PA8 in silicon before AF switch
    TIM1->CCER |= TIM_CCER_CC1E;
    TIM1->BDTR |= TIM_BDTR_MOE;

    // Connect PA8 directly to TIM1_CH1: Alternate Function Push-Pull 50MHz
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0xBU << 0); // 1011b = AF Output Push-Pull 50MHz

    // Start timer counter in silicon
    TIM1->CR1 |= TIM_CR1_CEN;

    __set_PRIMASK(primask);
}

void stopHardwareTimerImmediately() {
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    TIM1->CCER &= ~TIM_CCER_CC1E; // Disable hardware PWM output on PA8 in silicon
    TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
    TIM1->CR1  &= ~TIM_CR1_OPM;   // Ensure OPM cleared

    // Restore PA8 pin to General Purpose Output HIGH (Idle)
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;

    // Clear all pending flags and interrupts
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

    uint32_t abortedFromQueue = burstQueue.abortAll();
#if DEBUG_TEST_MODE
    int uncompleted = (hwBurstStepsTarget - hwBurstStepsDone) + (int)abortedFromQueue;
    if (uncompleted > 0) {
        abortedPulseCount += uncompleted;
        queuedPulseCount = 0;
    }
#else
    (void)abortedFromQueue;
#endif

    hwBurstActive      = false;
    hwBurstStepsTarget = 0;
    hwBurstStepsDone   = 0;
    stepsRemaining     = 0;
    movementState      = STATE_ABORTED;

    __set_PRIMASK(primask);
}

void recalculatePitchProfiles() {
    // Explicit numerical bounds checking
    if ((rollerDia != rollerDia) || rollerDia < 10.0f || rollerDia > 100.0f) rollerDia = 45.0f;
    if (driverResolution < 200 || driverResolution > 51200) driverResolution = 6400;
    double circumference = 3.14159265358979323846 * (double)rollerDia;
    double pulsesPerMM = (double)driverResolution / circumference;
    // 64-bit intermediate arithmetic: strictly prevents uint32_t overflow at max 51200 res / 15mm roller
    const double pitch5 = 1.54625411;  // Calibrated for 70.00 pulses at 6400 res / 45mm roller
    const double pitch8 = 1.76714755;  // Calibrated for 80.00 pulses at 6400 res / 45mm roller
    const double pitch10 = 2.20893444; // Calibrated for 100.00 pulses at 6400 res / 45mm roller
    p5_fixed  = (uint64_t)(pitch5 * pulsesPerMM * 1000000.0 + 0.5);
    p8_fixed  = (uint64_t)(pitch8 * pulsesPerMM * 1000000.0 + 0.5);
    p10_fixed = (uint64_t)(pitch10 * pulsesPerMM * 1000000.0 + 0.5);
    if (p5_fixed < 1000000ULL) p5_fixed = 1000000ULL;
    if (p8_fixed < 1000000ULL) p8_fixed = 1000000ULL;
    if (p10_fixed < 1000000ULL) p10_fixed = 1000000ULL;
}

void syncPulseIntegerFraction() {
    uint32_t intPart  = (uint32_t)(currentPulsesFixed / 1000000ULL);
    uint32_t fracPart = (uint32_t)(currentPulsesFixed % 1000000ULL);
    currentPulsesInt  = intPart;
    currentPulsesFrac = fracPart;
    commitPulseParameters(intPart, fracPart);
}

void updateActivePulseWidth() {
    syncPulseIntegerFraction();
    if (maxRPMSetting < 100 || maxRPMSetting > 4000) maxRPMSetting = 3000;
    if (feedAngleDeg < 30 || feedAngleDeg > 270) feedAngleDeg = 90;
    if (safetyMarginPercent < 0 || safetyMarginPercent > 29) safetyMarginPercent = 15;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));
    float activeSteps = (float)currentPulsesFixed / 1000000.0f;
    if (activeSteps < 1.0f) activeSteps = 1.0f;
    // Startup/fallback STEP period only; runtime period is replaced by measured servo timing.
    double requestedPeriodUs = (double)timeWindowUs / (double)activeSteps;
    refreshPulseTimingValidity();
    if (requestedPeriodUs < (double)SERVO_PERIOD_MIN_US) {
        // Do not hide an impossible manual tuning behind the 8us timer clamp.
        // Keep the timer at its safe floor, but mark the configuration invalid so
        // the UI/start path can block motion until the operator corrects it.
        pulseTimingInvalid = true;
        activePulseWidth = SERVO_PERIOD_MIN_US;
        return;
    }
    int calcPeriod = (int)requestedPeriodUs;
    if (calcPeriod > (int)SERVO_PERIOD_MAX_US) calcPeriod = SERVO_PERIOD_MAX_US;
    activePulseWidth = calcPeriod;
}

void calculateAllPulseWidths() {
    if (maxRPMSetting <= 0) maxRPMSetting = 3000;
    if (feedAngleDeg <= 0) feedAngleDeg = 90;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));

    float s5 = (float)p5_fixed / 1000000.0f;
    if (s5 < 1.0f) s5 = 1.0f;
    // Safe industrial limit: Full step period [8us, 500us] (guarantees >= 2.5us driver opto timing)
    autoPulseWidth_P5 = constrain((int)(timeWindowUs / s5), 8, 500);

    float s8 = (float)p8_fixed / 1000000.0f;
    if (s8 < 1.0f) s8 = 1.0f;
    autoPulseWidth_P8 = constrain((int)(timeWindowUs / s8), 8, 500);

    float s10 = (float)p10_fixed / 1000000.0f;
    if (s10 < 1.0f) s10 = 1.0f;
    autoPulseWidth_P10 = constrain((int)(timeWindowUs / s10), 8, 500);

    updateActivePulseWidth();

}

void evaluateDiagnostics() {
    float tempDia  = (tempRollerDia >= 10.0f && tempRollerDia <= 100.0f) ? tempRollerDia : 45.0f;
    int32_t tempRes   = (tempDriverRes >= 200 && tempDriverRes <= 51200) ? tempDriverRes : 6400;
    int32_t tempRPM   = (tempMaxRPM >= 100 && tempMaxRPM <= 4000) ? tempMaxRPM : 3000;
    int32_t tempAngle  = (tempFeedAngle >= 30 && tempFeedAngle <= 270) ? tempFeedAngle : 90;
    int32_t tempMargin = constrain(tempSafetyMargin, 0, 29);

    float tempCirc = 3.14159265f * tempDia;
    float tempPPM  = (float)tempRes / tempCirc;
    float s10_test = 2.20893444f * tempPPM;
    if (s10_test < 1.0f) s10_test = 1.0f;

    float timeWinTest = (60000000.0f / (float)tempRPM) * ((float)tempAngle / 360.0f) * (1.0f - ((float)tempMargin / 100.0f));
    diagMinW = (int)(timeWinTest / s10_test);

    if (diagMinW < 6) {
        isTimingWarningActive = true;
        if (tempRes > 12800) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET RES <= 12800";
        } else if (tempAngle < 120) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "INC ANGLE >= 150";
        } else if (tempRPM > 2500) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RPM <= 2500 ";
        } else if (tempMargin > 15) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET MARGIN 10%  ";
        } else {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RES/INC ANG ";
        }
    } else {
        isTimingWarningActive = false;
        diagFixLine1 = "TIMING HEALTH:  ";
        diagFixLine2 = "SYSTEM OPTIMAL  ";
    }
}

// =========================================================================
// TWO-PHASE ATOMIC DEFERRED TRIGGER DISPATCH ENGINE (SECTION 6 RACE FIX)
// Dispatches any triggers deferred during Flash save/abort window.
// Prevents newer incoming physical triggers from overtaking older deferred work.
// Only after deferred pulses are safely handed off does the lock return to IDLE.
// =========================================================================
static void dispatchDeferredSaveTriggers() {
    for (;;) {
        uint8_t defDir = 0;
        uint32_t defTs = 0;
        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        uint32_t defSteps = flashSaveTx.captureDeferredForDispatch(defDir, defTs);
        const bool stillPending = flashSaveTx.deferredTriggerPending;
        if (defSteps == 0U && !stillPending) {
            flashSaveTx.completeHandoff();
            __set_PRIMASK(primask);
            break;
        }
        __set_PRIMASK(primask);

        if (defSteps == 0U) continue;
        if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
            startHardwareTimerBurst((int)defSteps);
        } else {
#if DEBUG_TEST_MODE
            abortedPulseCount += (int)defSteps;
#endif
        }
    }
}

static inline void syncStoredBaselinesWithRam() {
    pulseStepStored_p5         = p5_fixed;
    pulseStepStored_p8         = p8_fixed;
    pulseStepStored_p10        = p10_fixed;
}

bool saveToEEPROM() {
    // Watchdog-safe selective persistence: only allowed at confirmed standstill.
    IWDG_FEED();
    if (!isMachineSafelyIdle()) return false;
    IWDG_FEED();
    if (!flashSaveTx.requestSaveLock()) {
        IWDG_FEED();
        return false;
    }

    if (!flashSaveTx.confirmLockAndTransition(isMachineSafelyIdle())) {
        dispatchDeferredSaveTriggers();
        IWDG_FEED();
        return false;
    }

    // TRUE DUAL-SLOT PING-PONG STORAGE:
    // Write strictly to the ALTERNATE slot so the current active slot remains 100% intact as fail-safe rollback!
    uint32_t targetSlot = (activeEEPROMSlot == 0) ? 1U : 0U;
    int targetOffset    = (targetSlot == 0) ? 0 : 128;
    int currentOffset   = (activeEEPROMSlot == 0) ? 0 : 128;

    MachineConfigRecord activeRec;
    EEPROM.get(currentOffset, activeRec);
    const bool currentSlotValid = PulseStepPersistenceManager::validateRecord(activeRec) &&
                                  (activeRec.magic == EEPROM_MAGIC_V17_0_0);

    MachineConfigRecord rec;
    memset(&rec, 0, sizeof(MachineConfigRecord));
    rec.magic    = EEPROM_MAGIC_V17_0_0;
    rec.seq      = (currentSlotValid ? activeRec.seq : eepromSeqNumber) + 1U;
    rec.reserved = 0;

    rec.payload.p5_fixed            = p5_fixed;
    rec.payload.p8_fixed            = p8_fixed;
    rec.payload.p10_fixed           = p10_fixed;
    rec.payload.driverResolution    = driverResolution;
    rec.payload.rollerDia           = rollerDia;
    rec.payload.maxRPMSetting       = maxRPMSetting;
    rec.payload.feedAngleDeg        = feedAngleDeg;
    rec.payload.safetyMarginPercent = safetyMarginPercent;
    rec.payload.currentSize         = currentSize;
    rec.payload.sensorGuardActive   = keypad6ButtonMode ? 1UL : 0UL; // Persists 3-BTN (0) vs 6-BTN (1) mode
    rec.payload.autoLockSec         = autoLockSec;
    rec.payload.motorDirection      = motorDirection ? 1UL : 0UL;
    rec.payload.backlightSec        = backlightSec;
    rec.payload.motorSleepMin       = motorSleepMin;

    if (currentSlotValid && memcmp(&rec.payload, &activeRec.payload, sizeof(MachineConfigPayload)) == 0) {
        // Zero parameters changed: skip write completely (0 Flash writes)
        syncStoredBaselinesWithRam();
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges = false;
        dispatchDeferredSaveTriggers();
        IWDG_FEED();
        return true;
    }

    rec.crc32 = calculateCRC32((const uint8_t*)&rec.payload, sizeof(MachineConfigPayload));

    // Abort save immediately if any PA0 trigger arrived or machine moved!
    if (!isMachineSafelyIdle() || flashSaveTx.lockState != SAVE_LOCK_LOCKED) {
        flashSaveTx.abortLock();
        IWDG_FEED();
        return false;
    }

    IWDG_FEED();
    MachineConfigRecord targetRec;
    EEPROM.get(targetOffset, targetRec);
    const bool targetSlotValid = PulseStepPersistenceManager::validateRecord(targetRec) &&
                                 (targetRec.magic == EEPROM_MAGIC_V17_0_0);

    if (!targetSlotValid || !eepromSlotInitialized) {
        // Initial record creation in alternate slot
        EEPROM.put(targetOffset, rec);
    } else {
        // SELECTIVE PARAMETER-ONLY EEPROM UPDATE (Ping-Pong Alternate Slot):
        // Only write changed field(s) via offsetof to protect Flash cells while maintaining ping-pong!
        if (rec.payload.p5_fixed != targetRec.payload.p5_fixed) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.p5_fixed), rec.payload.p5_fixed);
        }
        if (rec.payload.p8_fixed != targetRec.payload.p8_fixed) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.p8_fixed), rec.payload.p8_fixed);
        }
        if (rec.payload.p10_fixed != targetRec.payload.p10_fixed) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.p10_fixed), rec.payload.p10_fixed);
        }
        if (rec.payload.driverResolution != targetRec.payload.driverResolution) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.driverResolution), rec.payload.driverResolution);
        }
        if (memcmp(&rec.payload.rollerDia, &targetRec.payload.rollerDia, sizeof(float)) != 0) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.rollerDia), rec.payload.rollerDia);
        }
        if (rec.payload.maxRPMSetting != targetRec.payload.maxRPMSetting) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.maxRPMSetting), rec.payload.maxRPMSetting);
        }
        if (rec.payload.feedAngleDeg != targetRec.payload.feedAngleDeg) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.feedAngleDeg), rec.payload.feedAngleDeg);
        }
        if (rec.payload.safetyMarginPercent != targetRec.payload.safetyMarginPercent) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.safetyMarginPercent), rec.payload.safetyMarginPercent);
        }
        if (rec.payload.currentSize != targetRec.payload.currentSize) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.currentSize), rec.payload.currentSize);
        }
        if (rec.payload.sensorGuardActive != targetRec.payload.sensorGuardActive) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.sensorGuardActive), rec.payload.sensorGuardActive);
        }
        if (rec.payload.motorDirection != targetRec.payload.motorDirection) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.motorDirection), rec.payload.motorDirection);
        }
        if (rec.payload.autoLockSec != targetRec.payload.autoLockSec) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.autoLockSec), rec.payload.autoLockSec);
        }
        if (rec.payload.backlightSec != targetRec.payload.backlightSec) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.backlightSec), rec.payload.backlightSec);
        }
        if (rec.payload.motorSleepMin != targetRec.payload.motorSleepMin) {
            EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, payload.motorSleepMin), rec.payload.motorSleepMin);
        }
        // Update sequence counter and CRC32 in target alternate slot
        EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, seq), rec.seq);
        EEPROM.put(targetOffset + (int)offsetof(MachineConfigRecord, crc32), rec.crc32);
    }
    IWDG_FEED();

    MachineConfigRecord readBack;
    EEPROM.get(targetOffset, readBack);

    bool saveOk = false;
    if (PulseStepPersistenceManager::validateRecord(readBack) &&
        memcmp(&rec, &readBack, sizeof(MachineConfigRecord)) == 0) {
        flashWriteCount++;
        activeEEPROMSlot       = targetSlot; // Ping-pong slot swap: targetSlot is now authoritative!
        eepromSeqNumber        = rec.seq;
        eepromSlotInitialized  = true;
        syncStoredBaselinesWithRam();
        pulseModifiedByUser    = false;
        autoSavePendingStandstill = false;
        hasStagedChanges       = false;
        calculateAllPulseWidths();
        saveOk = true;
    }

    dispatchDeferredSaveTriggers();
    IWDG_FEED();
    return saveOk;
}

void loadFactoryDefaults() {
    driverResolution       = 6400;
    rollerDia              = 45.0f;
    maxRPMSetting          = 3000;
    feedAngleDeg           = 90;
    safetyMarginPercent    = 15;
    currentSize            = 2;     // Size #8 default
    motorDirection         = false; // NORMAL FORWARD DEFAULT
    keypad6ButtonMode      = false; // DEFAULT: 3-BTN Mode (Backward compatible with 3-button hardware)
    autoLockSec            = 30UL;  // DEFAULT: 30s Auto-Lock ON (0 = OFF)
    lastEnabledAutoLockSec = 30UL;
    backlightSec           = 0;     // DEFAULT: 0 = ALWAYS ON
    motorSleepMin          = 0UL;   // DEFAULT: 0 = OFF

    tempDriverRes          = driverResolution;
    tempRollerDia          = rollerDia;
    tempMaxRPM             = maxRPMSetting;
    tempFeedAngle          = feedAngleDeg;
    tempSafetyMargin       = safetyMarginPercent;
    tempMotorDir           = motorDirection;
    tempKeypad6Btn         = keypad6ButtonMode;
    tempAutoLockSec        = autoLockSec;
    tempBacklightSec       = backlightSec;
    tempMotorSleepMin      = motorSleepMin;

    isUiLocked             = false;
    isEditingMainDecimal   = false;
    isEditingSetting       = false;
    blinkTarget            = BLINK_NONE;
    applyMotorDirection();
    recalculatePitchProfiles();
    p5_fixed               = 70000000ULL;
    p8_fixed               = 80000000ULL;
    p10_fixed              = 100000000ULL;
    currentPulsesFixed     = p8_fixed;
    calculateAllPulseWidths();
    syncStoredBaselinesWithRam();
    pulseModifiedByUser    = false;
    hasStagedChanges       = false;
}

void loadFromEEPROM() {
    MachineConfigRecord rec0, rec1;
    EEPROM.get(0, rec0);
    EEPROM.get(128, rec1);

    bool v0 = PulseStepPersistenceManager::validateRecord(rec0);
    bool v1 = PulseStepPersistenceManager::validateRecord(rec1);

    MachineConfigRecord *chosen = nullptr;
    uint32_t chosenSlot = 0;

    if (v0 && v1) {
        if (rec0.seq >= rec1.seq) {
            chosen = &rec0;
            chosenSlot = 0;
        } else {
            chosen = &rec1;
            chosenSlot = 1;
        }
    } else if (v0) {
        chosen = &rec0;
        chosenSlot = 0;
    } else if (v1) {
        chosen = &rec1;
        chosenSlot = 1;
    }

    if (chosen != nullptr) {
        activeEEPROMSlot      = chosenSlot;
        eepromSeqNumber       = chosen->seq;
        eepromSlotInitialized = true;

        p5_fixed            = chosen->payload.p5_fixed;
        p8_fixed            = chosen->payload.p8_fixed;
        p10_fixed           = chosen->payload.p10_fixed;
        driverResolution    = chosen->payload.driverResolution;
        rollerDia           = chosen->payload.rollerDia;
        if (rollerDia < 10.0f || rollerDia > 100.0f) rollerDia = 45.0f;
        maxRPMSetting       = chosen->payload.maxRPMSetting;
        if (maxRPMSetting < 100 || maxRPMSetting > 4000) maxRPMSetting = 3000;
        feedAngleDeg        = chosen->payload.feedAngleDeg;
        if (feedAngleDeg < 30 || feedAngleDeg > 270) feedAngleDeg = 90;
        safetyMarginPercent = chosen->payload.safetyMarginPercent;
        if (safetyMarginPercent < 0 || safetyMarginPercent > 29) safetyMarginPercent = 15;
        currentSize         = chosen->payload.currentSize;
        if (currentSize < 1 || currentSize > 3) currentSize = 2;
        keypad6ButtonMode   = (chosen->payload.sensorGuardActive == 1UL);
        motorDirection      = (chosen->payload.motorDirection == 1UL);

        autoLockSec = chosen->payload.autoLockSec;
        if (autoLockSec > 0UL && autoLockSec < 10UL) autoLockSec = 10UL;
        if (autoLockSec > 300UL) autoLockSec = 30UL;
        lastEnabledAutoLockSec = (autoLockSec >= 10UL && autoLockSec <= 300UL) ? autoLockSec : 30UL;

        backlightSec = chosen->payload.backlightSec;
        if (backlightSec < 0 || (backlightSec > 0 && backlightSec < 10)) backlightSec = 0;
        if (backlightSec > 300 && backlightSec != 999) backlightSec = 0;

        motorSleepMin = chosen->payload.motorSleepMin;
        if (motorSleepMin > 0UL && motorSleepMin < 30UL) motorSleepMin = 0UL;
        if (motorSleepMin > 300UL) motorSleepMin = 0UL;

        tempDriverRes     = driverResolution;
        tempRollerDia     = rollerDia;
        tempMaxRPM        = maxRPMSetting;
        tempFeedAngle     = feedAngleDeg;
        tempSafetyMargin  = safetyMarginPercent;
        tempMotorDir      = motorDirection;
        tempKeypad6Btn    = keypad6ButtonMode;
        tempAutoLockSec   = autoLockSec;
        tempBacklightSec  = backlightSec;
        tempMotorSleepMin = motorSleepMin;
        isUiLocked        = false;

        applyMotorDirection();
        if (p5_fixed < PULSE_STEP_MIN_FIXED || p5_fixed > PULSE_STEP_MAX_FIXED ||
            p8_fixed < PULSE_STEP_MIN_FIXED || p8_fixed > PULSE_STEP_MAX_FIXED ||
            p10_fixed < PULSE_STEP_MIN_FIXED || p10_fixed > PULSE_STEP_MAX_FIXED) {
            recalculatePitchProfiles();
        }
        calculateAllPulseWidths();

        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        if (currentSize == 1) currentPulsesFixed = p5_fixed;
        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
        else currentPulsesFixed = p10_fixed;
        __set_PRIMASK(primask);
        updateActivePulseWidth();

        syncStoredBaselinesWithRam();
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
    } else {
        loadFactoryDefaults();
    }
}

// PRIMARY MOTION PATH: PA0 falling-edge trigger -> this ISR -> one synchronized PA8 STEP burst.
// Auxiliary sensors/relay logic must never preempt, abort, or replace this path.
// Reset only the RPM display estimator; raw timing/safety state remains separate.
static inline void resetRpmIntervalHistory() {
    rpmIntervalHistoryUs[0] = 0UL;
    rpmIntervalHistoryUs[1] = 0UL;
    rpmIntervalHistoryUs[2] = 0UL;
    rpmIntervalHistoryCount = 0U;
    rpmIntervalHistoryIndex = 0U;
}

static inline uint32_t median3u32(uint32_t a, uint32_t b, uint32_t c) {
    if (a > b) { uint32_t t = a; a = b; b = t; }
    if (b > c) { uint32_t t = b; b = c; c = t; }
    if (a > b) { uint32_t t = a; a = b; b = t; }
    return b;
}

// Process one PA0 falling edge using its TIM2 hardware-captured timestamp.
// Process one accepted PA0 edge. This function receives the monotonic TIM4 timestamp from sensorISR.
void processSensorTrigger(uint32_t capturedTimestampUs) {
    const uint32_t nowUs = capturedTimestampUs;
    unsigned long diff = 0;

    if (lastTriggerMicros == 0UL) {
        lastMeasuredIntervalUs = 0UL;
        currentRPM = 0UL;
        resetRpmIntervalHistory();
        acceptedTriggerPulses++;
        validTriggerCount = 1U;
        motionWatchdogArmed = false;
    } else {
        // Both values are extended TIM2 capture timestamps (1 tick = 1 us).
        // Unsigned subtraction is wrap-safe across the 32-bit timestamp rollover.
        diff = (uint32_t)(nowUs - (uint32_t)lastTriggerMicros);

        if (diff > 2000000UL) {
            // Standstill: the next edge is a new first edge. Do not watchdog it.
            lastMeasuredIntervalUs = 0UL;
            currentRPM = 0UL;
            resetRpmIntervalHistory();
            acceptedTriggerPulses++;
            validTriggerCount = 1U;
            motionWatchdogArmed = false;
            diff = 0UL; // This edge re-baselines motion; do not turn standstill time into STEP period.
            isCaptureStreamDiscontinuous = false;
        } else if (isCaptureStreamDiscontinuous) {
            // Overcapture recovery: CCR1 was overwritten before service, so diff spans 2+ physical cycles.
            // Do NOT let this 2x artifact drop the displayed RPM or stretch the STEP burst!
            isCaptureStreamDiscontinuous = false;
            tim2CaptureResyncEvents++;
            // Resynchronize to the continuous operating interval so RPM and STEP timing remain stable
            if (lastMeasuredIntervalUs > 0UL) {
                diff = lastMeasuredIntervalUs;
            } else if (diff > 0UL) {
                diff = diff / 2UL; // Estimate single-revolution period if overcapture occurred on startup
                lastMeasuredIntervalUs = diff;
            }
            acceptedTriggerPulses++;
            validTriggerCount++;
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
            }
        } else {
            // Speed-adaptive software blanking: 1.5ms minimum and 4.5ms maximum.
            unsigned long activeBlankingUs = 1000UL;
            if (lastMeasuredIntervalUs > 0UL) {
                activeBlankingUs = lastMeasuredIntervalUs / 4UL; // 25% of previous revolution
                if (activeBlankingUs < 1000UL) activeBlankingUs = 1000UL;
                if (activeBlankingUs > 4000UL) activeBlankingUs = 4000UL;
            }

            // Speed-adaptive software blanking: 1.0ms minimum and 4.0ms maximum.
            // CRITICAL NEEDLE SAFETY INVARIANT: Every needle cycle MUST produce a STEP burst!
            // If a pulse is dropped or rejected, the zipper tape remains stationary while the needle
            // plunges into the coil, jamming or breaking the needle.
            // We reject ONLY sub-millisecond switch contact chatter (< activeBlankingUs).
            // Never drop a cycle due to machine speed exceeding maxRPMSetting.
            if (diff < activeBlankingUs) {
                rejectedTriggerCount++;
                return; // Pure sub-millisecond optocoupler contact chatter rejected
            }

            // Servo plausibility guard: at configured max RPM, one revolution has
            // 60,000,000/maxRPMSetting us. Allow 25% speed headroom (period >= 75% of
            // that value), which rejects 4.5-9ms false edges while allowing a 3000 RPM
            // machine (20ms/rev) and brief speed transients up to ~4000 RPM.
            uint32_t configuredMaxRPM = (maxRPMSetting >= 100 && maxRPMSetting <= 4000)
                ? (uint32_t)maxRPMSetting : 3000UL;
            uint32_t minimumPlausibleIntervalUs = (60000000UL / configuredMaxRPM) * 3UL / 4UL;
            if (diff < minimumPlausibleIntervalUs) {
                rejectedTriggerCount++;
                return; // Implausibly fast edge: keep lastTriggerMicros unchanged.
            }

            lastMeasuredIntervalUs = diff;
            acceptedTriggerPulses++;
            validTriggerCount++;
            // A real interval now exists: this is the first point at which
            // motion-loss monitoring is allowed to arm.
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
            }

        }
    }

    // 2. DIRECT REAL-TIME INTERVAL RESOLUTION (100% Raw Physical Revolution `diff` for StepPulse!)
    // median3u32() is NEVER used for StepPulse generation so both acceleration and deceleration
    // track the exact physical needle revolution interval (`diff`) with zero 3-stitch history lag!
    const uint32_t stepTimingIntervalUs = (uint32_t)diff;
    const uint32_t prevTriggerMicros = lastTriggerMicros;
    lastTriggerMicros = nowUs;

    // 3. ZERO-LATENCY STEPPER BURST TRIGGERING (Fires TIM1 in Silicon BEFORE any secondary UI work!)
    if (!pulseTimingInvalid && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        PulseParameters snap;
        snap.integerPart    = activePulseParams.integerPart;
        snap.fractionalPart = activePulseParams.fractionalPart;
        snap.generation     = activePulseParams.generation;
#if DEBUG_TEST_MODE
        paramGenerationUsed = snap.generation;
        acceptedTriggerCount++;
        requestedPulseCount += snap.integerPart;
#endif
        int newSteps = (int)snap.integerPart;
        pulseFracAccumulator += snap.fractionalPart;
        if (pulseFracAccumulator >= 1000000UL) {
            newSteps++;
            pulseFracAccumulator -= 1000000UL;
#if DEBUG_TEST_MODE
            requestedPulseCount++;
#endif
        }

        uint32_t burstPeriodQ16;
        if (stepTimingIntervalUs > 0UL) {
            // Single-pass Q16.16 period calculation & phase-lock update from raw physical revolution `diff`
            updateStepPeriodFromServoInterval(stepTimingIntervalUs, (uint32_t)newSteps);
            burstPeriodQ16 = servoPeriodQ16;
        } else {
            uint32_t configuredRPM = (maxRPMSetting >= 100 && maxRPMSetting <= 4000)
                ? (uint32_t)maxRPMSetting : 3000UL;
            uint32_t startupRevUs = 60000000UL / configuredRPM;
            burstPeriodQ16 = calculateAdaptiveStepPeriodQ16(startupRevUs, (uint32_t)newSteps);
        }
        uint16_t burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        if (burstPeriodUs < SERVO_PERIOD_MIN_US) burstPeriodUs = SERVO_PERIOD_MIN_US;
        if (burstPeriodUs > SERVO_PERIOD_MAX_US) burstPeriodUs = SERVO_PERIOD_MAX_US;

        if (newSteps > 0) {
            // TRIGGER IS KING: If a standstill save lock was active, abort save immediately
            // and fire the real-time TIM1 burst with 0.00 us deferral delay!
            if (flashSaveTx.isSaveLockActive()) {
                flashSaveTx.abortLock();
            }
            startHardwareTimerBurst(newSteps, burstPeriodUs, burstPeriodQ16);
        }
    }

    // 4. POST-BURST SECONDARY HOUSEKEEPING (Executes ONLY AFTER TIM1 is already running on PA8!)
    // median3u32() is used STRICTLY for LCD Display RPM smoothing (currentRPM), NEVER for StepPulse!
    STATUS_LED_ON();
    if (prevTriggerMicros != 0UL && diff > 0UL && diff <= 2000000UL) {
        rpmIntervalHistoryUs[rpmIntervalHistoryIndex] = (uint32_t)diff;
        rpmIntervalHistoryIndex = (uint8_t)((rpmIntervalHistoryIndex + 1U) % 3U);
        if (rpmIntervalHistoryCount < 3U) rpmIntervalHistoryCount++;
        uint32_t rpmIntervalForDisplay = (uint32_t)diff;
        if (rpmIntervalHistoryCount >= 3U) {
            rpmIntervalForDisplay = median3u32(rpmIntervalHistoryUs[0],
                                               rpmIntervalHistoryUs[1],
                                               rpmIntervalHistoryUs[2]);
        }
        if (rpmIntervalForDisplay > 0UL) {
            const unsigned long instantRPM = 60000000UL / rpmIntervalForDisplay;
            if (instantRPM > 0UL && instantRPM <= 40000UL) {
                if (currentRPM == 0UL) currentRPM = instantRPM;
                else currentRPM = (unsigned long)((3UL * instantRPM + 5UL * currentRPM) / 8UL);
            }
        }
    } else if (diff > 2000000UL) {
        currentRPM = 0UL;
        resetRpmIntervalHistory();
    }
    if (motorSleepMin >= 30UL) {
        lastMotionOrButtonTime = millis();
    }
    if (isEditingMainDecimal || blinkTarget != BLINK_NONE) {
        isEditingMainDecimal = false;
        blinkTarget = BLINK_NONE;
    }
    if (menuState != 0 && menuState != 9) {
        pendingMenuExit = true;
    }
}

void setup() {
    // 1. Lock all stepper & sensor pins into safe deterministic idle states at t = 0ms
    pinMode(stepPin, OUTPUT);
    STEP_HIGH_IDLE();
    pinMode(dirPin, OUTPUT);
    pinMode(motorEnaPin, OUTPUT);
    digitalWrite(motorEnaPin, LOW); // Stepper driver enabled by default

    pinMode(proxSensorPin, INPUT_PULLUP);

    // Initialize 3 primary buttons + 3 extended 6-button navigation pins with internal pull-up
    pinMode(btnUp, INPUT_PULLUP);
    pinMode(btnDown, INPUT_PULLUP);
    pinMode(btnMode, INPUT_PULLUP);
    pinMode(btnBack, INPUT_PULLUP);
    pinMode(btnLeft, INPUT_PULLUP);
    pinMode(btnRight, INPUT_PULLUP);

    pinMode(statusLedPin, OUTPUT);
    STATUS_LED_OFF();

#if defined(CoreDebug) && defined(DWT)
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
#endif

    // 2. Determine Cold Power-On vs Mid-Run Watchdog Reset BEFORE clearing reset flags:
    // On STM32F103, PORRSTF (bit 27) is set on every physical Power-On Reset.
    // Checking (PORRSTF == 0) guarantees a sticky IWDGRSTF flag never skips the power-on splash!
    #ifndef RCC_CSR_PORRSTF
    #define RCC_CSR_PORRSTF  (1U << 27)
    #endif
    #ifndef RCC_CSR_IWDGRSTF
    #define RCC_CSR_IWDGRSTF (1U << 29)
    #endif
    #ifndef RCC_CSR_RMVF
    #define RCC_CSR_RMVF     (1U << 24)
    #endif

    const uint32_t resetFlags = RCC->CSR;
    const bool isWatchdogReset = ((resetFlags & RCC_CSR_IWDGRSTF) != 0U) &&
                                 ((resetFlags & RCC_CSR_PORRSTF) == 0U);
    RCC->CSR |= RCC_CSR_RMVF;

    // 3. ZERO-BLINK, ZERO-BLANK-DELAY INSTANT BOOT DISPLAY (~60ms from Power-On!):
    // FastLiquidCrystal_I2C eliminates LiquidCrystal_I2C's 1000ms blank delay and keeps
    // Backlight bit (0x08) HIGH from t = 0ms so DEV: RAJESH SHAH / NIPON ZIPPER IND
    // appears immediately (~0.06s) on switch ON with zero blank screen and zero blink.
    Wire.begin();
    Wire.setClock(100000); // 100 kHz standard mode for rock-solid 5V PCF8574 communication
#if defined(WIRE_HAS_TIMEOUT) || defined(ARDUINO_ARCH_STM32)
    Wire.setTimeout(25000);
#endif
    lcd.backlight();
    lcd.init();
    lcd.backlight();
    isBacklightCurrentlyOn = true;
    lcd.setCursor(0, 0);
    lcd.print("DEV: RAJESH SHAH");
    lcd.setCursor(0, 1);
    lcd.print("NIPON ZIPPER IND");

    loadFromEEPROM();
    applyMotorDirection();
    STEP_HIGH_IDLE();

#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
    initFreeRunningTimer4();
#endif
    initHardwareTimer2(); // PA0 TIM2_CH1 hardware capture + PA8 TIM1_CH1 STEP engine
    validTriggerCount = 0UL;

    // Strict NVIC Priority Hierarchy:
    // Priority 0: TIM1_UP (PA8 STEP pulse generator - highest possible priority, zero pulse jitter)
    // Priority 1: TIM2_IRQn (PA0 Cam Proximity trigger - immediate hardware preemption)
    // Priority 3: SysTick_IRQn (Background Arduino timebase)
    NVIC_SetPriority(TIM1_UP_IRQn, 0);
    NVIC_SetPriority(SysTick_IRQn, 3);
    IWDG_INIT();

    if (!isWatchdogReset) {
        // Cold Power-On Boot: Hold Splash Screen for exact 2.0 seconds (20 x 100ms) while TIM4/TIM2 warm up.
        // At 100ms and 300ms, silently re-sync 4-bit mode & text without clearing DDRAM
        // in case a slow external 5V capacitor bank took 100-250ms to reach 4.5V.
        for (int i = 0; i < 20; i++) {
            if (i == 1 || i == 3) {
#ifndef HOST_SIMULATION_TEST
                lcd.sync4BitModeNoClear();
#endif
                lcd.backlight();
                lcd.setCursor(0, 0);
                lcd.print("DEV: RAJESH SHAH");
                lcd.setCursor(0, 1);
                lcd.print("NIPON ZIPPER IND");
            }
            IWDG_FEED();
            delay(100);
        }
    } else {
        lcd.setCursor(0, 0);
        lcd.print("FAST-BOOT READY ");
        lcd.setCursor(0, 1);
        lcd.print("IWDG RECOVERED  ");
        delay(100);
    }

    // Switch I2C bus back to 400 kHz Fast-Mode for ultra-fast runtime display updates in loop()
    Wire.setClock(400000);

    // Clear any power-on settling spike or boot noise after the 2.0s splash so loop() starts 100% clean
    stopHardwareTimerImmediately();
    movementState          = STATE_IDLE;
    lastTriggerMicros      = 0UL;
    lastMeasuredIntervalUs = 0UL;
    currentRPM             = 0UL;
    validTriggerCount      = 0UL;
    acceptedTriggerPulses  = 0UL;
    rejectedTriggerCount   = 0UL;
    motionWatchdogArmed    = false;
    isMotionSyncLost       = false;
    isTimingOverrun        = false;
    isTimingWarningActive  = false;
    resetRpmIntervalHistory();

    invalidateLcdShadow();
    oldMenuState           = -1;
    lastDisplayUpdate      = 0UL;
    lastUnlockActivity     = millis();
    lastButtonPressTime    = millis();
    lastMotionOrButtonTime = millis();
    isUiLocked             = false;
}

static inline bool computeHasStagedChanges() {
    return (tempDriverRes != driverResolution) ||
           (fabsf(tempRollerDia - rollerDia) > 0.001f) ||
           (tempMaxRPM != maxRPMSetting) ||
           (tempFeedAngle != feedAngleDeg) ||
           (tempSafetyMargin != safetyMarginPercent) ||
           (tempMotorDir != motorDirection) ||
           (tempKeypad6Btn != keypad6ButtonMode) ||
           (tempAutoLockSec != autoLockSec) ||
           (tempBacklightSec != backlightSec) ||
           (tempMotorSleepMin != motorSleepMin);
}

static inline void clampConfirmedSettingValue(int opt) {
    if (opt == 2) {
        if (tempRollerDia < 10.0f)  tempRollerDia = 10.0f;
        if (tempRollerDia > 100.0f) tempRollerDia = 100.0f;
    } else if (opt == 3) {
        if (tempMaxRPM < 100)  tempMaxRPM = 100;
        if (tempMaxRPM > 4000) tempMaxRPM = 4000;
    } else if (opt == 4) {
        if (tempFeedAngle < 30)  tempFeedAngle = 30;
        if (tempFeedAngle > 270) tempFeedAngle = 270;
    } else if (opt == 5) {
        if (tempSafetyMargin < 0)  tempSafetyMargin = 0;
        if (tempSafetyMargin > 29) tempSafetyMargin = 29;
    } else if (opt == 8) {
        if (tempAutoLockSec > 0UL && tempAutoLockSec < 10UL) tempAutoLockSec = 10UL;
        if (tempAutoLockSec > 300UL) tempAutoLockSec = 300UL;
        if (tempAutoLockSec >= 10UL) lastEnabledAutoLockSec = tempAutoLockSec;
    } else if (opt == 9) {
        if (tempBacklightSec > 0 && tempBacklightSec < 10) tempBacklightSec = 10;
        if (tempBacklightSec > 300) tempBacklightSec = 300;
    } else if (opt == 10) {
        if (tempMotorSleepMin > 0UL && tempMotorSleepMin < 30UL) tempMotorSleepMin = 30UL;
        if (tempMotorSleepMin > 300UL) tempMotorSleepMin = 300UL;
    }
    hasStagedChanges = computeHasStagedChanges();
}

void loop() {
    IWDG_FEED();

    // =========================================================================
    // INTERACTIVE STEPPER JOG BENCH TEST (Diagnostics Page 1)
    // =========================================================================
    if (menuState == 9 && infoIndex == 1 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        static uint32_t lastJogUs = 0;
        uint32_t nowJog = micros();
        if (digitalRead(btnUp) == LOW) {
            DIR_NORMAL();
            if ((uint32_t)(nowJog - lastJogUs) >= 800) {
                lastJogUs = nowJog;
                STEP_LOW_ACTIVE();
                delayMicroseconds(5);
                STEP_HIGH_IDLE();
            }
        } else if (digitalRead(btnDown) == LOW) {
            DIR_REVERSE();
            if ((uint32_t)(nowJog - lastJogUs) >= 800) {
                lastJogUs = nowJog;
                STEP_LOW_ACTIVE();
                delayMicroseconds(5);
                STEP_HIGH_IDLE();
            }
        } else {
            applyMotorDirection();
        }
    }

    // =========================================================================
    // INTERACTIVE OPTOCOUPLER SINKING BENCH TEST (Diagnostics Page 2)
    // =========================================================================
    if (menuState == 9 && infoIndex == 2 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        if (digitalRead(btnUp) == LOW) {
            STEP_LOW_ACTIVE();
            stepPinState = LOW;
        } else {
            STEP_HIGH_IDLE();
            stepPinState = HIGH;
        }
    }

    // Safely return to IDLE when any previous burst has finished
    if (!hwBurstActive && stepsRemaining == 0) {
        if (movementState == STATE_COMPLETE || movementState == STATE_ABORTED) {
            movementState = STATE_IDLE;
        }
    }

    // Onboard PC13 LED at standstill
    const bool isMachineRunning = (currentRPM > 0UL) || hwBurstActive ||
                                  (lastTriggerMicros != 0UL && ((uint32_t)(get_hardware_timestamp_us() - (uint32_t)lastTriggerMicros) < 2000000UL));
    if (!isMachineRunning) {
        if (digitalRead(proxSensorPin) == LOW) {
            STATUS_LED_ON();
        } else {
            STATUS_LED_OFF();
        }
    }

    // RPM Zeroing timeout if machine stops > 2.0s
    static uint32_t lastSeenAcceptedTriggerCount = 0;
    static uint32_t lastTriggerActivityMs = 0;
    const uint32_t currentAcceptedTriggers = acceptedTriggerPulses;
    if (currentAcceptedTriggers != lastSeenAcceptedTriggerCount) {
        lastSeenAcceptedTriggerCount = currentAcceptedTriggers;
        lastTriggerActivityMs = millis();
    }
    if (millis() - lastTriggerActivityMs > 2000UL) {
        if (currentRPM > 0UL) {
            currentRPM = 0UL;
            lastMeasuredIntervalUs = 0UL;
            motionWatchdogArmed = false;
            isMotionSyncLost = false;
        }
        if (hwBurstActive && (TIM1->CR1 & TIM_CR1_CEN) == 0U) {
            hwBurstActive = false;
            stepsRemaining = 0;
            movementState = STATE_IDLE;
        }
    }

    // =========================================================================
    // 2-MINUTE COOLDOWN STANDSTILL AUTO-SAVE ENGINE (Strictly Main Screen Pulses)
    // =========================================================================
    const bool isAnyDirty = (p5_fixed != pulseStepStored_p5) ||
                            (p8_fixed != pulseStepStored_p8) ||
                            (p10_fixed != pulseStepStored_p10);
    pulseModifiedByUser = isAnyDirty;
    const bool isRpmFresh = (lastTriggerActivityMs != 0UL) && ((currentRPM > 0UL) || (millis() - lastTriggerActivityMs < 2000UL));
    autoSaveEngine.update(currentRPM, 300UL, isRpmFresh, false, false, (currentRPM == 0UL), isAnyDirty, millis());
    autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

    if (currentRPM == 0UL && menuState == 0) {
        if (autoSaveEngine.autoSavePendingStandstill && isMachineSafelyIdle()) {
            if (isAnyDirty) {
                bool saveOk = saveToEEPROM();
                if (saveOk) {
                    uiBannerLine1 = "AUTO-SAVED OK!  ";
                    uiBannerLine2 = "SETTINGS SAVED  ";
                    autoSaveEngine.clearPendingSave();
                    autoSavePendingStandstill = false;
                } else {
                    uiBannerLine1 = "SAVE FAILED!    ";
                    uiBannerLine2 = "RETRY AT IDLE   ";
                }
                uiMessageTimer = millis() + 1500UL;
                oldMenuState = -1;
            } else {
                autoSaveEngine.clearPendingSave();
                autoSavePendingStandstill = false;
            }
        }
    }

    // Real Motion Sync Watchdog: Detect missing cam pulses while needle is in motion
    if (motionWatchdogArmed && currentRPM >= 100UL && lastMeasuredIntervalUs > 0UL) {
        uint32_t nowUs = get_hardware_timestamp_us();
        uint32_t elapsedUs = (uint32_t)(nowUs - (uint32_t)lastTriggerMicros);
        uint32_t timeoutLimitUs = ((uint32_t)lastMeasuredIntervalUs * 5UL) / 2UL; // 2.5x expected interval
        if (timeoutLimitUs < 50000UL) timeoutLimitUs = 50000UL; // 50ms floor
        if (elapsedUs > timeoutLimitUs && elapsedUs <= 2000000UL) {
            if (!isMotionSyncLost) {
                isMotionSyncLost = true;
                faultType = 3; // Trigger Sync Lost
            }
        }
    }

    // Active Burst Timing Overrun Notification
    if (isTimingOverrun) {
        isTimingOverrun = false;
        uiBannerLine1 = "ERR: TIMING OVRN";
        uiBannerLine2 = "BURST OVERRUN!  ";
        uiMessageTimer = millis() + 1500UL;
        oldMenuState = -1;
    }

    // Safety Auto-Abort: Return to Main Screen if machine starts running while in any menu
    if (pendingMenuExit) {
        pendingMenuExit = false;
        isEditingSetting = false;
        menuState = 0;
        oldMenuState = -1;
        hasStagedChanges = false;
    }

    // Auto-Relock Timeout based on user-configured autoLockSec (default 30s; 0 = OFF)
    if (autoLockSec == 0UL) {
        isUiLocked = false;
    } else if (!isUiLocked && menuState == 0) {
        if (millis() - lastUnlockActivity > (autoLockSec * 1000UL)) {
            isUiLocked = true;
            isEditingMainDecimal = false;
            blinkTarget = BLINK_NONE;
            oldMenuState = -1;
        }
    }

    // Safety Inactivity Auto-Exit after 2 minutes (120s) without button presses in Settings
    if (menuState != 0) {
        if (millis() - lastUnlockActivity > 120000UL) {
            hasStagedChanges = false;
            isEditingSetting = false;
            menuState = 0;
            oldMenuState = -1;
            lastUnlockActivity = millis();
            isUiLocked = false; // Never lock immediately on exit!
        }
    }

    // Backlight Power Management: Direct Fast Bypass when ALWAYS ON (backlightSec == 0)
    if (backlightSec > 0) {
        bool wantBacklight = (backlightSec <= 300) &&
                             (millis() - lastButtonPressTime < ((unsigned long)backlightSec * 1000UL));
        if (wantBacklight != isBacklightCurrentlyOn && !hwBurstActive) {
            isBacklightCurrentlyOn = wantBacklight;
            if (wantBacklight) lcd.backlight();
            else               lcd.noBacklight();
        }
    } else if (!isBacklightCurrentlyOn && !hwBurstActive) {
        isBacklightCurrentlyOn = true;
        lcd.backlight();
    }

    // Stepper Motor Sleep: Direct Fast Bypass when OFF (motorSleepMin == 0UL)
    if (motorSleepMin >= 30UL) {
        bool wantMotorSleep = (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive &&
                               (millis() - lastMotionOrButtonTime >= (motorSleepMin * 60000UL)));
        if (wantMotorSleep != isMotorCurrentlyAsleep) {
            isMotorCurrentlyAsleep = wantMotorSleep;
            if (wantMotorSleep) {
                MOTOR_ENA_SLEEP();
                captureTimer->attachInterrupt(1, tim2WakeOnceCallback);
            } else {
                MOTOR_ENA_ACTIVE();
                captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback);
            }
        }
    } else if (isMotorCurrentlyAsleep) {
        isMotorCurrentlyAsleep = false;
        MOTOR_ENA_ACTIVE();
        captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback);
    }

    // Industrial Edge-Triggered Button States with Hold Auto-Repeat
    static bool upPressedState = false;
    static unsigned long upFirstPressTime = 0UL;
    static unsigned long lastUpRepeatTime = 0UL;

    static bool downPressedState = false;
    static unsigned long downFirstPressTime = 0UL;
    static unsigned long lastDownRepeatTime = 0UL;

    static bool leftPressedState = false;
    static bool rightPressedState = false;
    static bool backPressedState = false;

    // Button Debouncing and Event Processing (3-BTN & 6-BTN Compatible)
    if (millis() - lastButtonCheck > 20UL) {
        lastButtonCheck = millis();
        const bool extraBtnsActive = keypad6ButtonMode;
        const bool leftLow  = extraBtnsActive && (digitalRead(btnLeft) == LOW);
        const bool rightLow = extraBtnsActive && (digitalRead(btnRight) == LOW);
        const bool backLow  = extraBtnsActive && (digitalRead(btnBack) == LOW);

        if (digitalRead(btnUp) == LOW || digitalRead(btnDown) == LOW || digitalRead(btnMode) == LOW ||
            leftLow || rightLow || backLow) {
            lastUnlockActivity = millis();
            lastButtonPressTime = millis();
            lastMotionOrButtonTime = millis();
            if (isMotorCurrentlyAsleep) {
                MOTOR_ENA_ACTIVE();
                isMotorCurrentlyAsleep = false;
                captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback);
            }
            if (!isBacklightCurrentlyOn && backlightSec != 999 && !hwBurstActive) {
                lcd.backlight();
                isBacklightCurrentlyOn = true;
            }
        }

        // Single Click MODE/SELECT handling on Main Screen:
        // Toggles Digital Watch .10 Decimal Inline Edit Mode (Never wipes decimal to .00!)
        if (pendingSingleClick && (millis() - lastModeClickTime > 350UL)) {
            pendingSingleClick = false;
            if (isUiLocked && menuState == 0) {
                unlockPendingDown = true;
                unlockPromptUntil = millis() + 3000UL;
                uiBannerLine1 = "UNLOCK KEYPAD:  ";
                uiBannerLine2 = "PRESS [DOWN] NOW";
                uiMessageTimer = millis() + 3000UL;
                oldMenuState = -1;
            } else if (!isUiLocked && menuState == 0) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (!isEditingMainDecimal) {
                        // Enter Main Screen Digital Watch Inline Editor starting at .10 decimal (10s timeout)
                        setMainEditCursorAndBlink(0);
                    } else {
                        // Second press of MODE acts as OK -> confirms value and stops blinking immediately!
                        isEditingMainDecimal = false;
                        blinkTarget          = BLINK_NONE;
                    }
                    lastUnlockActivity = millis();
                    oldMenuState = -1;
                }
            }
        }

        // Single Click MODE/SELECT handling in Settings Menu (menuState == 1):
        // Enters Digital Watch Inline Edit Mode (1..10) or opens Info Diag (11) / Save & Exit (12)
        if (pendingMenuSingleClick && (millis() - lastMenuModeClickTime > 350UL)) {
            pendingMenuSingleClick = false;
            if (menuState == 1 && !isEditingSetting) {
                if (hiddenOption >= 1 && hiddenOption <= 10) {
                    isEditingSetting = true;
                    settingDigitCursor = 0;
                    lastUnlockActivity = millis();
                } else if (hiddenOption == 11) {
                    evaluateDiagnostics();
                    infoIndex = 1;
                    menuState = 9;  // 11. Info Diag
                    oldMenuState = -1;
                } else if (hiddenOption == 12) {
                    saveExitChoice = true;
                    menuState = 13; // 12. Save & Exit Dialog
                    oldMenuState = -1;
                }
            }
        }

        // Dual Button Press: Emergency Factory Reset (>10s)
        if (digitalRead(btnUp) == LOW && digitalRead(btnDown) == LOW) {
            if (!upDownPressed) dualPressTime = millis();
            upDownPressed = true;
            if (millis() - dualPressTime > 10000UL && menuState != 3) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    menuState = 3;
                    resetChoice = false;
                    oldMenuState = -1;
                }
            }
        } else {
            upDownPressed = false;
        }

        // =====================================================================
        // 6-BUTTON NAVIGATION: [LEFT], [RIGHT], [BACK] EDGE HANDLERS
        // Active only when keypad6ButtonMode == true (6-BTN Mode)
        // =====================================================================
        bool triggerLeft = false;
        if (leftLow) {
            if (!leftPressedState) {
                leftPressedState = true;
                triggerLeft = true;
            }
        } else {
            leftPressedState = false;
        }

        bool triggerRight = false;
        if (rightLow) {
            if (!rightPressedState) {
                rightPressedState = true;
                triggerRight = true;
            }
        } else {
            rightPressedState = false;
        }

        bool triggerBack = false;
        if (backLow) {
            if (!backPressedState) {
                backPressedState = true;
                triggerBack = true;
            }
        } else {
            backPressedState = false;
        }

        if (triggerLeft) {
            if (menuState == 0) {
                if (isUiLocked) {
                    unlockPendingDown = false;
                    uiBannerLine1 = "** KEYPAD LOCKED **";
                    uiBannerLine2 = "PRESS MODE+DOWN ";
                    uiMessageTimer = millis() + 1500UL;
                    oldMenuState = -1;
                } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    // 6-Button Main Screen [LEFT]: shift Digital Watch cursor one digit LEFT (.10 -> Units -> Tens -> Hundreds -> .10)
                    if (!isEditingMainDecimal) {
                        setMainEditCursorAndBlink(1U); // Start at Units digit (immediately left of .10)
                    } else {
                        setMainEditCursorAndBlink((uint8_t)((mainEditCursor + 1U) % 4U));
                    }
                }
            } else if (menuState == 1) {
                if (isEditingSetting) {
                    if (hiddenOption == 1) {
                        int idx = getDriverResIndex(tempDriverRes);
                        if (idx > 0) idx--;
                        else idx = (int)DRIVER_RES_TABLE_SIZE - 1;
                        tempDriverRes = DRIVER_RES_TABLE[idx];
                        hasStagedChanges = computeHasStagedChanges();
                    } else if (hiddenOption == 2) {
                        // Roller Dia (cursor 0=.0 rightmost -> 1=Units -> 2=Tens -> 3=Hundreds leftmost): [LEFT] shifts left!
                        settingDigitCursor = (settingDigitCursor + 1) % 4;
                    } else if (hiddenOption == 3) {
                        settingDigitCursor = (settingDigitCursor == 0) ? 3 : (settingDigitCursor - 1);
                    } else if (hiddenOption == 5) {
                        settingDigitCursor = (settingDigitCursor == 0) ? 1 : 0;
                    } else if (hiddenOption == 8) {
                        if (tempAutoLockSec == 0UL) {
                            tempAutoLockSec = (lastEnabledAutoLockSec >= 10UL && lastEnabledAutoLockSec <= 300UL) ? lastEnabledAutoLockSec : 30UL;
                            settingDigitCursor = 3;
                        } else {
                            settingDigitCursor = (settingDigitCursor == 0) ? 3 : (settingDigitCursor - 1);
                        }
                        hasStagedChanges = computeHasStagedChanges();
                    } else if (hiddenOption == 4 || hiddenOption == 9 || hiddenOption == 10) {
                        settingDigitCursor = (settingDigitCursor == 0) ? 2 : (settingDigitCursor - 1);
                    } else if (hiddenOption == 6) {
                        tempMotorDir = false; // NORMAL [FW]
                        hasStagedChanges = computeHasStagedChanges();
                    } else if (hiddenOption == 7) {
                        tempKeypad6Btn = false; // 3-BTN
                        hasStagedChanges = computeHasStagedChanges();
                    }
                    lastEditKeyPressMs = millis();
                } else {
                    hiddenOption--;
                    if (hiddenOption < 1) hiddenOption = 12;
                }
            } else if (menuState == 13) {
                saveExitChoice = true; // [LEFT] -> >YES
            } else if (menuState == 3) {
                resetChoice = true;    // [LEFT] -> >YES
            } else if (menuState == 9) {
                infoIndex--;
                if (infoIndex < 1) infoIndex = 9;
            } else if (menuState == 21) {
                helpIndex--;
                if (helpIndex < 1) helpIndex = 5;
            }
        }

        if (triggerRight) {
            if (menuState == 0) {
                if (isUiLocked) {
                    unlockPendingDown = false;
                    uiBannerLine1 = "** KEYPAD LOCKED **";
                    uiBannerLine2 = "PRESS MODE+DOWN ";
                    uiMessageTimer = millis() + 1500UL;
                    oldMenuState = -1;
                } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    // 6-Button Main Screen [RIGHT]: shift Digital Watch cursor one digit RIGHT (Hundreds -> Tens -> Units -> .10 -> Hundreds)
                    if (!isEditingMainDecimal) {
                        setMainEditCursorAndBlink(0U); // Start at .10 decimal digit
                    } else {
                        setMainEditCursorAndBlink((mainEditCursor == 0U) ? 3U : (uint8_t)(mainEditCursor - 1U));
                    }
                }
            } else if (menuState == 1) {
                if (isEditingSetting) {
                    if (hiddenOption == 1) {
                        int idx = getDriverResIndex(tempDriverRes);
                        if (idx < (int)DRIVER_RES_TABLE_SIZE - 1) idx++;
                        else idx = 0;
                        tempDriverRes = DRIVER_RES_TABLE[idx];
                        hasStagedChanges = computeHasStagedChanges();
                    } else if (hiddenOption == 2) {
                        // Roller Dia (cursor 3=Hundreds leftmost -> 2=Tens -> 1=Units -> 0=.0 rightmost): [RIGHT] shifts right!
                        settingDigitCursor = (settingDigitCursor == 0) ? 3 : (settingDigitCursor - 1);
                    } else if (hiddenOption == 3) {
                        settingDigitCursor = (settingDigitCursor + 1) % 4;
                    } else if (hiddenOption == 5) {
                        settingDigitCursor = (settingDigitCursor == 0) ? 1 : 0;
                    } else if (hiddenOption == 8) {
                        if (tempAutoLockSec == 0UL) {
                            tempAutoLockSec = (lastEnabledAutoLockSec >= 10UL && lastEnabledAutoLockSec <= 300UL) ? lastEnabledAutoLockSec : 30UL;
                            settingDigitCursor = 1;
                        } else {
                            settingDigitCursor = (settingDigitCursor + 1) % 4;
                        }
                        hasStagedChanges = computeHasStagedChanges();
                    } else if (hiddenOption == 4 || hiddenOption == 9 || hiddenOption == 10) {
                        settingDigitCursor = (settingDigitCursor + 1) % 3;
                    } else if (hiddenOption == 6) {
                        tempMotorDir = true; // REVERSE [RV]
                        hasStagedChanges = computeHasStagedChanges();
                    } else if (hiddenOption == 7) {
                        tempKeypad6Btn = true; // 6-BTN
                        hasStagedChanges = computeHasStagedChanges();
                    }
                    lastEditKeyPressMs = millis();
                } else {
                    hiddenOption++;
                    if (hiddenOption > 12) hiddenOption = 1;
                }
            } else if (menuState == 13) {
                saveExitChoice = false; // [RIGHT] -> >NO
            } else if (menuState == 3) {
                resetChoice = false;    // [RIGHT] -> >NO
            } else if (menuState == 9) {
                infoIndex++;
                if (infoIndex > 9) infoIndex = 1;
            } else if (menuState == 21) {
                helpIndex++;
                if (helpIndex > 5) helpIndex = 1;
            }
        }

        if (triggerBack) {
            if (menuState == 0) {
                uiBannerLine1        = nullptr;
                uiBannerLine2        = nullptr;
                isEditingMainDecimal = false;
                blinkTarget          = BLINK_NONE;
            } else if (menuState == 1) {
                if (isEditingSetting) {
                    clampConfirmedSettingValue(hiddenOption);
                    isEditingSetting = false;
                } else if (hasStagedChanges) {
                    // Smart [BACK] Confirmation: parameter was changed -> open SAVE CHANGES? (>YES / NO)
                    saveExitChoice = true;
                    menuState = 13;
                    oldMenuState = -1;
                } else {
                    // Nothing changed -> exit directly to Main Screen (reset timer, do not lock immediately)
                    menuState = 0;
                    oldMenuState = -1;
                    lastUnlockActivity = millis();
                    isUiLocked = false;
                }

            } else if (menuState == 9) {
                menuState = 1;
                oldMenuState = -1;
            } else if (menuState == 21) {
                menuState = 9;
                infoIndex = 8;
                oldMenuState = -1;
            } else if (menuState == 13) {
                // [BACK] inside SAVE CHANGES? dialog returns to Settings Menu list to continue editing
                menuState = 1;
                oldMenuState = -1;
            } else if (menuState == 3) {
                menuState = 0;
                oldMenuState = -1;
            }
        }

        // MODE / SELECT Button State Machine (with Long-Press Settings Menu Launch)
        static bool modeHoldSettingsTriggered = false;
        if (digitalRead(btnMode) == LOW) {
            if (!modePressed) {
                modePressTime = millis();
                modeHoldSettingsTriggered = false;
                // Instant unlock arming when screen is locked (no 350ms wait!)
                if (isUiLocked && menuState == 0) {
                    unlockPendingDown = true;
                    unlockPromptUntil = millis() + 3000UL;
                    uiBannerLine1 = "UNLOCK KEYPAD:  ";
                    uiBannerLine2 = "PRESS [DOWN] NOW";
                    uiMessageTimer = millis() + 3000UL;
                    oldMenuState = -1;
                }
            }
            modePressed = true;

            // MODE Long-Press on Main Screen (1s -> 5s Countdown -> Open Settings Menu)
            unsigned long modeHoldMs = millis() - modePressTime;
            if (!isUiLocked && menuState == 0 && currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                if (modeHoldMs >= 1000UL && modeHoldMs < 5000UL) {
                    pendingSingleClick = false;
                    isEditingMainDecimal = false;
                    blinkTarget = BLINK_NONE;
                    int secLeft = (int)((5000UL - modeHoldMs + 999UL) / 1000UL);
                    static char modeHoldCount[24];
                    snprintf(modeHoldCount, sizeof(modeHoldCount), "IN %d SEC...      ", secLeft);
                    uiBannerLine1 = "ENTER SETTINGS: ";
                    uiBannerLine2 = modeHoldCount;
                    uiMessageTimer = millis() + 250UL;
                } else if (modeHoldMs >= 5000UL && !modeHoldSettingsTriggered) {
                    modeHoldSettingsTriggered = true;
                    pendingSingleClick  = false;
                    pendingMenuSingleClick = false;
                    isEditingMainDecimal = false;
                    blinkTarget         = BLINK_NONE;
                    uiBannerLine1       = nullptr;
                    uiBannerLine2       = nullptr;
                    tempDriverRes       = driverResolution;
                    tempRollerDia       = rollerDia;
                    tempMaxRPM          = maxRPMSetting;
                    tempFeedAngle       = feedAngleDeg;
                    tempSafetyMargin    = safetyMarginPercent;
                    tempMotorDir        = motorDirection;
                    tempKeypad6Btn      = keypad6ButtonMode;
                    tempAutoLockSec     = autoLockSec;
                    tempBacklightSec    = backlightSec;
                    tempMotorSleepMin   = motorSleepMin;
                    hasStagedChanges    = false;
                    isEditingSetting    = false;
                    menuState           = 1;
                    hiddenOption        = 1;
                    oldMenuState        = -1;
                    lastUnlockActivity  = millis();
                    isUiLocked          = false;
                }
            }
        } else if (modePressed) {
            unsigned long holdTime = millis() - modePressTime;
            modePressed = false;

            if (modeHoldSettingsTriggered) {
                // Ignore button release right after MODE long-press opened Settings Menu
                modeHoldSettingsTriggered = false;
            } else if (menuState == 0) {
                if (uiBannerLine1 != nullptr && strncmp(uiBannerLine1, "ENTER SETTINGS", 14) == 0) {
                    uiBannerLine1 = nullptr;
                    uiBannerLine2 = nullptr;
                    oldMenuState = -1;
                }
                if (isUiLocked) {
                    // Already armed unlockPendingDown on press; keep prompt active for 3 seconds
                    unlockPendingDown = true;
                    unlockPromptUntil = millis() + 3000UL;
                    pendingSingleClick = false;
                } else if (holdTime < 350UL) {
                    if (pendingSingleClick && (millis() - lastModeClickTime < 350UL)) {
                        // Double Click MODE on Main Screen: Switch Zipper Size (#5 -> #8 -> #10 -> #5)
                        pendingSingleClick = false;
                        lastModeClickTime = 0UL;
                        if (!isUiLocked && currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                            isEditingMainDecimal = false;
                            currentSize++;
                            if (currentSize > 3) currentSize = 1;
                            uint32_t primask = __get_PRIMASK();
                            __disable_irq();
                            if (currentSize == 1) currentPulsesFixed = p5_fixed;
                            else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                            else currentPulsesFixed = p10_fixed;
                            __set_PRIMASK(primask);
                            updateActivePulseWidth();
                            bool saveOk = saveToEEPROM();
                            if (!saveOk) {
                                autoSavePendingStandstill = true;
                            }
                            lastUnlockActivity = millis();
                            blinkTarget  = BLINK_MAIN_SIZE;
                            blinkUntilMs = millis() + 2000UL;
                            oldMenuState = -1;
                        }
                    } else {
                        lastModeClickTime = millis();
                        if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                            pendingSingleClick = true;
                        } else {
                            pendingSingleClick = false;
                        }
                    }
                }
            } else if (menuState == 1) {
                
                if (isEditingSetting) {
                    clampConfirmedSettingValue(hiddenOption);
                    isEditingSetting = false;
                    lastUnlockActivity = millis();
                } else {
                    if (holdTime < 350UL) {
                        if (pendingMenuSingleClick && (millis() - lastMenuModeClickTime < 350UL)) {
                            // MODE Double Click: Back to Main Screen (with Smart Save Confirmation if modified)
                            pendingMenuSingleClick = false;
                            lastMenuModeClickTime = 0UL;
                            if (hasStagedChanges) {
                                saveExitChoice = true;
                                menuState = 13; // Confirmation Dialog
                                oldMenuState = -1;
                            } else {
                                menuState = 0;
                                oldMenuState = -1;
                                lastUnlockActivity = millis();
                                isUiLocked = false; // Never lock immediately on exit!
                            }
                            return;
                        } else {
                            lastMenuModeClickTime = millis();
                            pendingMenuSingleClick = true;
                        }
                    }
                }
            } else if (menuState == 9) {
                if (holdTime >= 800UL) {
                    // Hold MODE (>= 800ms) on any Diagnostics page returns to Settings List
                    menuState = 1;
                    oldMenuState = -1;
                } else if (infoIndex == 1) {
                    // On Page 1 (STEPPER JOG TST), UP/DOWN jog the motor; short-click MODE advances to Page 2!
                    infoIndex = 2;
                } else if (infoIndex == 8) {
                    helpIndex = 1;
                    menuState = 21; // Open HELP Sub-Branch
                    oldMenuState = -1;
                } else {
                    menuState = 1;  // Return to Settings List
                    oldMenuState = -1;
                }
            } else if (menuState == 21) {
                menuState = 9;
                infoIndex = 8;
                oldMenuState = -1;
            } else if (menuState == 13) {
                // Execute Save & Exit Dialog decision
                if (saveExitChoice) {
                    if (!stagedTimingConfigurationFeasible()) {
                        uiBannerLine1 = "TIMING INVALID! ";
                        uiBannerLine2 = "LOWER RPM/RES  ";
                        uiMessageTimer = millis() + 1600UL;
                        menuState = 1;
                        oldMenuState = -1;
                    } else {
                        for (int opt = 1; opt <= 10; opt++) clampConfirmedSettingValue(opt);
                        const bool geometryChanged = (driverResolution != tempDriverRes) ||
                                                     (fabsf(rollerDia - tempRollerDia) > 0.001f);
                        const bool dirChanged      = (motorDirection != tempMotorDir);
                        if (driverResolution != tempDriverRes)       driverResolution    = tempDriverRes;
                        if (fabsf(rollerDia - tempRollerDia) > 0.001f) rollerDia         = tempRollerDia;
                        if (maxRPMSetting != tempMaxRPM)             maxRPMSetting       = tempMaxRPM;
                        if (feedAngleDeg != tempFeedAngle)           feedAngleDeg        = tempFeedAngle;
                        if (safetyMarginPercent != tempSafetyMargin) safetyMarginPercent = tempSafetyMargin;
                        if (motorDirection != tempMotorDir)          motorDirection      = tempMotorDir;
                        if (keypad6ButtonMode != tempKeypad6Btn)     keypad6ButtonMode   = tempKeypad6Btn;
                        if (autoLockSec != tempAutoLockSec)          autoLockSec         = tempAutoLockSec;
                        if (backlightSec != tempBacklightSec)        backlightSec        = tempBacklightSec;
                        if (motorSleepMin != tempMotorSleepMin)      motorSleepMin       = tempMotorSleepMin;
                        if (dirChanged) applyMotorDirection();
                        if (geometryChanged) {
                            recalculatePitchProfiles();
                            uint32_t primask = __get_PRIMASK();
                            __disable_irq();
                            if (currentSize == 1) currentPulsesFixed = p5_fixed;
                            else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                            else currentPulsesFixed = p10_fixed;
                            __set_PRIMASK(primask);
                        }
                        calculateAllPulseWidths();
                        refreshPulseTimingValidity();
                        hasStagedChanges = false;
                        isEditingSetting = false;
                        menuState = 0;
                        oldMenuState = -1;
                        lastUnlockActivity = millis();
                        isUiLocked = false;
                        if (isMachineSafelyIdle() && currentRPM == 0UL) {
                            bool saveOk = saveToEEPROM();
                            if (saveOk) {
                                autoSavePendingStandstill = false;
                                autoSaveEngine.clearPendingSave();
                                pulseModifiedByUser = false;
                                hasStagedChanges = false;
                                uiBannerLine1 = "SETTINGS SAVED  ";
                                uiBannerLine2 = "DIRECT SAVE OK  ";
                            } else {
                                uiBannerLine1 = "SAVE FAILED!    ";
                                uiBannerLine2 = "RETRY AT 0 RPM  ";
                            }
                        } else {
                            uiBannerLine1 = "SAVE BLOCKED!   ";
                            uiBannerLine2 = "STOP MACHINE 1ST";
                        }
                        uiMessageTimer = millis() + 1500UL;
                    }
                } else {
                    // NO: Discard Changes & Exit (restore all staged variables to active values)
                    tempDriverRes     = driverResolution;
                    tempRollerDia     = rollerDia;
                    tempMaxRPM        = maxRPMSetting;
                    tempFeedAngle     = feedAngleDeg;
                    tempSafetyMargin  = safetyMarginPercent;
                    tempMotorDir      = motorDirection;
                    tempKeypad6Btn    = keypad6ButtonMode;
                    tempAutoLockSec   = autoLockSec;
                    tempBacklightSec  = backlightSec;
                    tempMotorSleepMin = motorSleepMin;
                    hasStagedChanges  = false;
                    isEditingSetting = false;
                    menuState = 0;
                    oldMenuState = -1;
                    lastUnlockActivity = millis();
                    isUiLocked = false;
                }
            } else if (menuState == 3) {
                if (resetChoice) {
                    loadFactoryDefaults();
                    saveToEEPROM();
                    uiBannerLine1 = "FACTORY RESET OK";
                    uiBannerLine2 = "DEFAULTS LOADED ";
                    uiMessageTimer = millis() + 1500UL;
                }
                menuState = 0;
                oldMenuState = -1;
            }
        }

        // UP Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool upRaw = (digitalRead(btnUp) == LOW);
        bool triggerUpStep = false;
        if (upRaw && !upDownPressed) {
            if (!upPressedState) {
                upPressedState = true;
                upFirstPressTime = millis();
                lastUpRepeatTime = millis();
                triggerUpStep = true;
            } else if (millis() - upFirstPressTime >= 600UL) {
                if (millis() - lastUpRepeatTime >= 200UL) {
                    lastUpRepeatTime = millis();
                    triggerUpStep = true;
                }
            }
        } else {
            upPressedState = false;
        }

        if (triggerUpStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        unlockPendingDown = false;
                        uiBannerLine1 = "** KEYPAD LOCKED **";
                        uiBannerLine2 = "PRESS MODE+DOWN ";
                        uiMessageTimer = millis() + 1500UL;
                        oldMenuState = -1;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint64_t proposedPulses = currentPulsesFixed;
                        if (!isEditingMainDecimal) {
                            // Direct UP on Main Screen: +1.0 whole pulse (preserving .10 decimal) + blink integer part
                            proposedPulses = currentPulsesFixed + 1000000ULL;
                            if (proposedPulses > PULSE_STEP_MAX_FIXED) proposedPulses = PULSE_STEP_MAX_FIXED;
                            blinkTarget = BLINK_MAIN_GEAR_INT;
                        } else {
                            // Pure Digital Watch Single-Digit UP (0=.10, 1=Units, 2=Tens, 3=Hundreds)
                            int pInt  = (int)(currentPulsesFixed / 1000000ULL);
                            int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                            int h = (pInt / 100) % 10;
                            int t = (pInt / 10) % 10;
                            int u = pInt % 10;
                            if (mainEditCursor == 0) {
                                pFrac = (pFrac + 1) % 10;
                                blinkTarget = BLINK_MAIN_GEAR_DEC;
                            } else if (mainEditCursor == 1) {
                                u = (u + 1) % 10;
                                blinkTarget = BLINK_MAIN_UNITS;
                            } else if (mainEditCursor == 2) {
                                t = (t + 1) % 10;
                                blinkTarget = BLINK_MAIN_TENS;
                            } else {
                                h = (h >= 5) ? 0 : (h + 1);
                                blinkTarget = BLINK_MAIN_HUNDREDS;
                            }
                            int newInt = h * 100 + t * 10 + u;
                            if (newInt < 1) newInt = 1;
                            proposedPulses = (uint64_t)newInt * 1000000ULL + (uint64_t)pFrac * 100000ULL;
                            if (proposedPulses > PULSE_STEP_MAX_FIXED) proposedPulses = PULSE_STEP_MAX_FIXED;
                            lastEditKeyPressMs = millis();
                        }

                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        currentPulsesFixed = proposedPulses;
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                              (p8_fixed != pulseStepStored_p8) ||
                                              (p10_fixed != pulseStepStored_p10);
                        if (pulseModifiedByUser) {
                            autoSaveEngine.notifyModification(millis());
                        } else {
                            autoSaveEngine.clearPendingSave();
                        }
                        autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

                        blinkUntilMs = millis() + (isEditingMainDecimal ? MAIN_INLINE_EDIT_TIMEOUT_MS : 2000UL);
                        lastUnlockActivity = millis();
                    }
                    break;

                case 1:
                    if (!isEditingSetting) {
                        hiddenOption--;
                        if (hiddenOption < 1) hiddenOption = 12;
                    } else {
                        if (hiddenOption == 1) {
                            int idx = getDriverResIndex(tempDriverRes);
                            if (idx < (int)DRIVER_RES_TABLE_SIZE - 1) idx++;
                            else idx = 0; // Wrap to first
                            tempDriverRes = DRIVER_RES_TABLE[idx];
                        } else if (hiddenOption == 2) {
                            // Roller Dia (010.0 to 100.0 mm): Pure Single-Digit Watch Edit (0=.0, 1=Units, 2=Tens, 3=Hundreds)
                            int dTenths = (int)(tempRollerDia * 10.0f + 0.5f);
                            int h = (dTenths / 1000) % 10;
                            int t = (dTenths / 100) % 10;
                            int u = (dTenths / 10) % 10;
                            int d = dTenths % 10;
                            if (settingDigitCursor == 0)      d = (d + 1) % 10;
                            else if (settingDigitCursor == 1) u = (u + 1) % 10;
                            else if (settingDigitCursor == 2) t = (t + 1) % 10;
                            else                              h = (h >= 1) ? 0 : 1;
                            int newTenths = h * 1000 + t * 100 + u * 10 + d;
                            if (newTenths > 1000) newTenths = 1000;
                            tempRollerDia = (float)newTenths / 10.0f;
                        } else if (hiddenOption == 3) {
                            // Max RPM (0100 to 4000 RPM): Pure 4-Digit Single-Digit Watch Edit (0=Thousands, 1=Hundreds, 2=Tens, 3=Units)
                            int th = (tempMaxRPM / 1000) % 10;
                            int hd = (tempMaxRPM / 100) % 10;
                            int tn = (tempMaxRPM / 10) % 10;
                            int un = tempMaxRPM % 10;
                            if (settingDigitCursor == 0)      th = (th >= 4) ? 0 : (th + 1);
                            else if (settingDigitCursor == 1) hd = (hd + 1) % 10;
                            else if (settingDigitCursor == 2) tn = (tn + 1) % 10;
                            else                              un = (un + 1) % 10;
                            tempMaxRPM = th * 1000 + hd * 100 + tn * 10 + un;
                            if (tempMaxRPM > 4000) tempMaxRPM = 4000;
                        } else if (hiddenOption == 4) {
                            // Feed Angle (030 to 270 deg): Pure 3-Digit Single-Digit Watch Edit (0=Hundreds, 1=Tens, 2=Units)
                            int h = (tempFeedAngle / 100) % 10;
                            int t = (tempFeedAngle / 10) % 10;
                            int u = tempFeedAngle % 10;
                            if (settingDigitCursor == 0)      h = (h >= 2) ? 0 : (h + 1);
                            else if (settingDigitCursor == 1) t = (t + 1) % 10;
                            else                              u = (u + 1) % 10;
                            tempFeedAngle = h * 100 + t * 10 + u;
                            if (tempFeedAngle > 270) tempFeedAngle = 270;
                        } else if (hiddenOption == 5) {
                            // Safety Margin (00 to 29 %): Pure 2-Digit Single-Digit Watch Edit (0=Tens, 1=Units)
                            int t = (tempSafetyMargin / 10) % 10;
                            int u = tempSafetyMargin % 10;
                            if (settingDigitCursor == 0) t = (t >= 2) ? 0 : (t + 1);
                            else                         u = (u + 1) % 10;
                            tempSafetyMargin = t * 10 + u;
                            if (tempSafetyMargin > 29) tempSafetyMargin = 29;
                        } else if (hiddenOption == 6) {
                            tempMotorDir = !tempMotorDir;
                        } else if (hiddenOption == 7) {
                            tempKeypad6Btn = !tempKeypad6Btn;
                        } else if (hiddenOption == 8) {
                            // Auto Lock: cursor 0 = Explicit [ON]/[OFF] Toggle; cursor 1..3 = 3-Digit Seconds (Hundreds, Tens, Units)
                            if (settingDigitCursor == 0) {
                                if (tempAutoLockSec > 0UL) {
                                    if (tempAutoLockSec >= 10UL && tempAutoLockSec <= 300UL) {
                                        lastEnabledAutoLockSec = tempAutoLockSec;
                                    }
                                    tempAutoLockSec = 0UL; // Turn Auto-Lock OFF
                                } else {
                                    tempAutoLockSec = (lastEnabledAutoLockSec >= 10UL && lastEnabledAutoLockSec <= 300UL)
                                                      ? lastEnabledAutoLockSec : 30UL; // Turn Auto-Lock ON
                                }
                            } else {
                                int h = (int)(tempAutoLockSec / 100UL) % 10;
                                int t = (int)(tempAutoLockSec / 10UL) % 10;
                                int u = (int)(tempAutoLockSec % 10UL);
                                if (settingDigitCursor == 1)      h = (h >= 3) ? 0 : (h + 1);
                                else if (settingDigitCursor == 2) t = (t + 1) % 10;
                                else                              u = (u + 1) % 10;
                                tempAutoLockSec = (uint32_t)(h * 100 + t * 10 + u);
                                if (tempAutoLockSec > 300UL) tempAutoLockSec = 300UL;
                                if (tempAutoLockSec >= 10UL) lastEnabledAutoLockSec = tempAutoLockSec;
                            }
                        } else if (hiddenOption == 9) {
                            // Backlight (000 to 300 sec): Pure 3-Digit Single-Digit Watch Edit (0=Hundreds, 1=Tens, 2=Units)
                            int h = (tempBacklightSec / 100) % 10;
                            int t = (tempBacklightSec / 10) % 10;
                            int u = tempBacklightSec % 10;
                            if (settingDigitCursor == 0)      h = (h >= 3) ? 0 : (h + 1);
                            else if (settingDigitCursor == 1) t = (t + 1) % 10;
                            else                              u = (u + 1) % 10;
                            tempBacklightSec = h * 100 + t * 10 + u;
                            if (tempBacklightSec > 300) tempBacklightSec = 300;
                        } else if (hiddenOption == 10) {
                            // Motor Sleep (000 to 300 min): Pure 3-Digit Single-Digit Watch Edit (0=Hundreds, 1=Tens, 2=Units)
                            int h = (int)(tempMotorSleepMin / 100UL) % 10;
                            int t = (int)(tempMotorSleepMin / 10UL) % 10;
                            int u = (int)(tempMotorSleepMin % 10UL);
                            if (settingDigitCursor == 0)      h = (h >= 3) ? 0 : (h + 1);
                            else if (settingDigitCursor == 1) t = (t + 1) % 10;
                            else                              u = (u + 1) % 10;
                            tempMotorSleepMin = (uint32_t)(h * 100 + t * 10 + u);
                            if (tempMotorSleepMin > 300UL) tempMotorSleepMin = 300UL;
                        }
                        hasStagedChanges = computeHasStagedChanges();
                        lastEditKeyPressMs = millis();
                    }
                    break;

                case 3:  resetChoice = !resetChoice; break;
                case 13: saveExitChoice = !saveExitChoice; break;
                case 21:
                    helpIndex--;
                    if (helpIndex < 1) helpIndex = 5;
                    break;
                case 9:
                    if (infoIndex != 1 && infoIndex != 2) {
                        infoIndex--;
                        if (infoIndex < 1) infoIndex = 9;
                    }
                    break;
            }
        }

        // DOWN Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat, symmetric with UP)
        bool downRaw = (digitalRead(btnDown) == LOW);
        bool triggerDownStep = false;
        if (downRaw && !upDownPressed) {
            if (!downPressedState) {
                downPressedState = true;
                downFirstPressTime = millis();
                lastDownRepeatTime = millis();
                triggerDownStep = true;
            } else if (millis() - downFirstPressTime >= 600UL) {
                if (millis() - lastDownRepeatTime >= 200UL) {
                    lastDownRepeatTime = millis();
                    triggerDownStep = true;
                }
            }
        } else {
            downPressedState = false;
        }

        if (triggerDownStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        if (unlockPendingDown && millis() <= unlockPromptUntil) {
                            isUiLocked = false;
                            unlockPendingDown = false;
                            lastUnlockActivity = millis();
                            uiBannerLine1 = "** UNLOCKED **  ";
                            uiBannerLine2 = "READY TO OPERATE";
                            uiMessageTimer = millis() + 1200UL;
                            oldMenuState = -1;
                        } else {
                            unlockPendingDown = false;
                            uiBannerLine1 = "** KEYPAD LOCKED **";
                            uiBannerLine2 = "PRESS MODE+DOWN ";
                            uiMessageTimer = millis() + 1500UL;
                            oldMenuState = -1;
                        }
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        if (isEditingMainDecimal) {
                            if (!keypad6ButtonMode) {
                                // 3-BTN Mode: DOWN shifts single digit (.10 -> Units -> Tens -> Hundreds -> .10)
                                setMainEditCursorAndBlink((uint8_t)((mainEditCursor + 1U) % 4U));
                            } else {
                                // 6-BTN Mode (has dedicated LEFT/RIGHT): DOWN decrements active blinking digit (-1)
                                int pInt  = (int)(currentPulsesFixed / 1000000ULL);
                                int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                                int h = (pInt / 100) % 10;
                                int t = (pInt / 10) % 10;
                                int u = pInt % 10;
                                if (mainEditCursor == 0) {
                                    pFrac = (pFrac == 0) ? 9 : (pFrac - 1);
                                    blinkTarget = BLINK_MAIN_GEAR_DEC;
                                } else if (mainEditCursor == 1) {
                                    u = (u == 0) ? 9 : (u - 1);
                                    blinkTarget = BLINK_MAIN_UNITS;
                                } else if (mainEditCursor == 2) {
                                    t = (t == 0) ? 9 : (t - 1);
                                    blinkTarget = BLINK_MAIN_TENS;
                                } else {
                                    h = (h == 0) ? 5 : (h - 1);
                                    blinkTarget = BLINK_MAIN_HUNDREDS;
                                }
                                int newInt = h * 100 + t * 10 + u;
                                if (newInt < 1) newInt = 1;
                                uint64_t proposedPulses = (uint64_t)newInt * 1000000ULL + (uint64_t)pFrac * 100000ULL;
                                if (proposedPulses > PULSE_STEP_MAX_FIXED) proposedPulses = PULSE_STEP_MAX_FIXED;
                                uint32_t primask = __get_PRIMASK();
                                __disable_irq();
                                currentPulsesFixed = proposedPulses;
                                if (currentSize == 1) p5_fixed = currentPulsesFixed;
                                else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                                else p10_fixed = currentPulsesFixed;
                                __set_PRIMASK(primask);
                                updateActivePulseWidth();
                                pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                                      (p8_fixed != pulseStepStored_p8) ||
                                                      (p10_fixed != pulseStepStored_p10);
                                if (pulseModifiedByUser) autoSaveEngine.notifyModification(millis());
                                else                     autoSaveEngine.clearPendingSave();
                                autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;
                                blinkUntilMs = millis() + MAIN_INLINE_EDIT_TIMEOUT_MS;
                                lastEditKeyPressMs = millis();
                            }
                            lastUnlockActivity = millis();
                        } else {
                            // Direct DOWN on Main Screen: -1.0 whole pulse (preserving .10 decimal) + blink integer part
                            uint32_t primask = __get_PRIMASK();
                            __disable_irq();
                            if (currentPulsesFixed >= 1000000ULL + PULSE_STEP_MIN_FIXED) {
                                currentPulsesFixed -= 1000000ULL;
                            } else {
                                currentPulsesFixed = PULSE_STEP_MIN_FIXED + (currentPulsesFixed % 1000000ULL);
                            }
                            if (currentSize == 1) p5_fixed = currentPulsesFixed;
                            else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                            else p10_fixed = currentPulsesFixed;
                            __set_PRIMASK(primask);

                            updateActivePulseWidth();
                            pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                                  (p8_fixed != pulseStepStored_p8) ||
                                                  (p10_fixed != pulseStepStored_p10);
                                if (pulseModifiedByUser) {
                                autoSaveEngine.notifyModification(millis());
                            } else {
                                autoSaveEngine.clearPendingSave();
                            }
                            autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

                            blinkTarget  = BLINK_MAIN_GEAR_INT;
                            blinkUntilMs = millis() + 2000UL;
                            lastUnlockActivity = millis();
                        }
                    }
                    break;

                case 1:
                    if (!isEditingSetting) {
                        hiddenOption++;
                        if (hiddenOption > 12) hiddenOption = 1;
                    } else {
                        // Digital Watch Inline Editor: DOWN shifts cursor to next decimal/digit position!
                        if (hiddenOption == 1) {
                            int idx = getDriverResIndex(tempDriverRes);
                            if (idx > 0) idx--;
                            else idx = (int)DRIVER_RES_TABLE_SIZE - 1; // Wrap to last
                            tempDriverRes = DRIVER_RES_TABLE[idx];
                            hasStagedChanges = computeHasStagedChanges();
                        } else if (hiddenOption == 2 || hiddenOption == 3) {
                            // 4-Digit Single-Digit Shift (0 -> 1 -> 2 -> 3 -> 0)
                            settingDigitCursor = (settingDigitCursor + 1) % 4;
                        } else if (hiddenOption == 4) {
                            // 3-Digit Single-Digit Shift (0 -> 1 -> 2 -> 0)
                            settingDigitCursor = (settingDigitCursor + 1) % 3;
                        } else if (hiddenOption == 5) {
                            // 2-Digit Single-Digit Shift (0 <-> 1)
                            settingDigitCursor = (settingDigitCursor == 0) ? 1 : 0;
                        } else if (hiddenOption == 6) {
                            tempMotorDir = !tempMotorDir;
                            hasStagedChanges = computeHasStagedChanges();
                        } else if (hiddenOption == 7) {
                            tempKeypad6Btn = !tempKeypad6Btn;
                            hasStagedChanges = computeHasStagedChanges();
                        } else if (hiddenOption == 8) {
                            // Auto Lock: cursor 0 ([ON]/[OFF]) -> 1 (Hundreds) -> 2 (Tens) -> 3 (Units) -> 0
                            if (tempAutoLockSec == 0UL) {
                                tempAutoLockSec = (lastEnabledAutoLockSec >= 10UL && lastEnabledAutoLockSec <= 300UL)
                                                  ? lastEnabledAutoLockSec : 30UL;
                                settingDigitCursor = 1;
                                hasStagedChanges = computeHasStagedChanges();
                            } else {
                                settingDigitCursor = (settingDigitCursor + 1) % 4;
                            }
                        } else if (hiddenOption == 9) {
                            // Backlight: 3-Digit Single-Digit Shift (0 -> 1 -> 2 -> 0)
                            settingDigitCursor = (settingDigitCursor + 1) % 3;
                        } else if (hiddenOption == 10) {
                            // Motor Sleep: 3-Digit Single-Digit Shift (0 -> 1 -> 2 -> 0)
                            settingDigitCursor = (settingDigitCursor + 1) % 3;
                        }
                        lastEditKeyPressMs = millis();
                    }
                    break;

                case 3:  resetChoice = !resetChoice; break;
                case 13: saveExitChoice = !saveExitChoice; break;
                case 21:
                    helpIndex++;
                    if (helpIndex > 5) helpIndex = 1;
                    break;
                case 9:
                    if (infoIndex != 1) {
                        infoIndex++;
                        if (infoIndex > 9) infoIndex = 1;
                    }
                    break;
            }
        }

        if (digitalRead(btnUp) == HIGH && digitalRead(btnDown) == HIGH) {
            upDownPressed = false;
        }
    }

    // 16x2 Character LCD Screen Renderer (Selective Character-Diff via lcdPrint16)
    if (uiBannerLine1 != nullptr) {
        if (millis() < uiMessageTimer) {
            char b1[17], b2[17];
            snprintf(b1, sizeof(b1), "%-16.16s", uiBannerLine1);
            snprintf(b2, sizeof(b2), "%-16.16s", uiBannerLine2 ? uiBannerLine2 : "");
            lcdPrint16(0, b1);
            lcdPrint16(1, b2);
            oldMenuState = -2;
            return;
        } else {
            uiBannerLine1 = nullptr;
            uiBannerLine2 = nullptr;
            oldMenuState = -1;
            lcd.clear();
            invalidateLcdShadow();
        }
    }

    // Running-state RPM refresh (gated by !hwBurstActive & shadow diff so I2C writes only when RPM changes)
    if (menuState == 0 && oldMenuState == menuState && !hwBurstActive) {
        if (millis() - lastRpmDisplayUpdate > 250UL) {
            lastRpmDisplayUpdate = millis();
            char rpmBuf[8];
            unsigned int dispRpm = (currentRPM > 9999UL) ? 9999U : (unsigned int)currentRPM;
            snprintf(rpmBuf, sizeof(rpmBuf), "%04u", dispRpm);
            if (!s_lcdShadowValid[0] || memcmp(&s_lcdShadow[0][5], rpmBuf, 4) != 0) {
                lcd.setCursor(5, 0);
                lcd.print(rpmBuf);
                if (s_lcdShadowValid[0]) {
                    memcpy(&s_lcdShadow[0][5], rpmBuf, 4);
                }
            }
        }
    }

    if (millis() >= blinkUntilMs && (blinkTarget != BLINK_NONE || isEditingMainDecimal)) {
        blinkTarget = BLINK_NONE;
        isEditingMainDecimal = false; // Automatically exit .10 inline editor after 2 seconds of idle!
    }
    // Calm Eye-Friendly Watch Blink: 500ms Visible (ON) / 250ms Hide (OFF), forced SOLID for 400ms on key press!
    const bool blinkHide = ((millis() - lastEditKeyPressMs) >= 400UL) && ((millis() % 750UL) >= 500UL);

    if ((currentRPM == 0UL || menuState != oldMenuState || menuState == 9) && millis() - lastDisplayUpdate > 125UL) {
        if (menuState != oldMenuState) {
            lcd.clear();
            invalidateLcdShadow();
            oldMenuState = menuState;
        }

        char l1[48] = "                ";
        char l2[48] = "                ";
        switch (menuState) {
            case 0: // Normal Operational Screen with In-Place Blinking
            {
                int szNum = (currentSize == 1) ? 5 : ((currentSize == 2) ? 8 : 10);
                const double feedMm = ((double)currentPulsesFixed / 1000000.0) *
                    (3.14159265358979323846 * (double)rollerDia) / (double)driverResolution;
                unsigned long feedHundredths = (feedMm > 0.0) ? (unsigned long)(feedMm * 100.0 + 0.5) : 0UL;
                if (feedHundredths > 9999UL) feedHundredths = 9999UL;
                const int actInt = (int)(feedHundredths / 100UL);
                const int actFrac = (int)(feedHundredths % 100UL);
                char feedStr[8];
                snprintf(feedStr, sizeof(feedStr), "%d.%02d", actInt, actFrac);
                unsigned int dispRpm = constrain((unsigned int)currentRPM, 0U, 9999U);

                if (blinkTarget == BLINK_MAIN_SIZE && blinkHide) {
                    snprintf(l1, sizeof(l1), "S:   %04u F:%s", dispRpm, feedStr);
                } else {
                    snprintf(l1, sizeof(l1), "S:%-2d %04u F:%s", szNum, dispRpm, feedStr);
                }

                char cue = (activePulseWidth <= 2) ? '*' : ((activePulseWidth < 6) ? '#' : 'H');
                int pInt = (int)(currentPulsesFixed / 1000000ULL);
                int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                const char* lockStr = (blinkTarget == BLINK_MAIN_LOCK && blinkHide)
                    ? "   " : (isUiLocked ? "[L]" : "[U]");

                char pulseField[16];
                if (pInt < 0) pInt = 0;
                const bool show3IntDigits = isEditingMainDecimal || (pInt >= 100);
                if (blinkTarget == BLINK_MAIN_PULSE && blinkHide) {
                    snprintf(pulseField, sizeof(pulseField), show3IntDigits ? "     " : "    ");
                } else if (blinkTarget == BLINK_MAIN_GEAR_INT && blinkHide) {
                    snprintf(pulseField, sizeof(pulseField), show3IntDigits ? "   .%01d" : "  .%01d", pFrac);
                } else if (blinkTarget == BLINK_MAIN_GEAR_DEC && blinkHide) {
                    if (show3IntDigits) snprintf(pulseField, sizeof(pulseField), "%03d. ", pInt % 1000);
                    else                snprintf(pulseField, sizeof(pulseField), "%d. ", pInt);
                } else if (blinkTarget == BLINK_MAIN_UNITS && blinkHide) {
                    if (show3IntDigits) snprintf(pulseField, sizeof(pulseField), "%02d .%01d", (pInt / 10) % 100, pFrac % 10);
                    else                snprintf(pulseField, sizeof(pulseField), "%d .%01d", (pInt / 10) % 10, pFrac);
                } else if (blinkTarget == BLINK_MAIN_TENS && blinkHide) {
                    if (show3IntDigits) snprintf(pulseField, sizeof(pulseField), "%d %d.%01d", (pInt / 100) % 10, pInt % 10, pFrac % 10);
                    else                snprintf(pulseField, sizeof(pulseField), " %d.%01d", pInt % 10, pFrac);
                } else if (blinkTarget == BLINK_MAIN_HUNDREDS && blinkHide) {
                    snprintf(pulseField, sizeof(pulseField), " %02d.%01d", pInt % 100, pFrac % 10);
                } else {
                    if (show3IntDigits) snprintf(pulseField, sizeof(pulseField), "%03d.%01d", pInt % 1000, pFrac % 10);
                    else                snprintf(pulseField, sizeof(pulseField), "%d.%01d", pInt, pFrac);
                }

                if (!show3IntDigits && activePulseWidth < 100) {
                    snprintf(l2, sizeof(l2), "P:%s W:%d %c%s",
                             pulseField, activePulseWidth, cue, lockStr);
                } else {
                    snprintf(l2, sizeof(l2), "P:%s W:%d%c%s",
                             pulseField, activePulseWidth, cue, lockStr);
                }
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
            }
            break;

            case 1: // Clean 12-Option Settings Menu with Digital Watch Single-Decimal Blinking
            {
                if (hiddenOption == 1)       snprintf(l1, sizeof(l1), "1. Driver Res   ");
                else if (hiddenOption == 2)  snprintf(l1, sizeof(l1), "2. Roller Dia   ");
                else if (hiddenOption == 3)  snprintf(l1, sizeof(l1), "3. Max RPM      ");
                else if (hiddenOption == 4)  snprintf(l1, sizeof(l1), "4. Feed Angle   ");
                else if (hiddenOption == 5)  snprintf(l1, sizeof(l1), "5. Safety Margin");
                else if (hiddenOption == 6)  snprintf(l1, sizeof(l1), "6. Motor Dir    ");
                else if (hiddenOption == 7)  snprintf(l1, sizeof(l1), "7. Keypad Mode  ");
                else if (hiddenOption == 8)  snprintf(l1, sizeof(l1), "8. Auto Lock    ");
                else if (hiddenOption == 9)  snprintf(l1, sizeof(l1), "9. Backlight    ");
                else if (hiddenOption == 10) snprintf(l1, sizeof(l1), "10. Motor Sleep ");
                else if (hiddenOption == 11) snprintf(l1, sizeof(l1), "11. Info Diag   ");
                else if (hiddenOption == 12) snprintf(l1, sizeof(l1), "12. Save & Exit ");

                const bool hideVal = isEditingSetting && blinkHide;

                if (hiddenOption == 1) {
                    if (isEditingSetting) {
                        if (hideVal) snprintf(l2, sizeof(l2), "Val:       steps");
                        else         snprintf(l2, sizeof(l2), "Val: %-5d steps", (int)tempDriverRes);
                    } else {
                        snprintf(l2, sizeof(l2), "Val: %-5d steps", (int)tempDriverRes);
                    }
                } else if (hiddenOption == 2) {
                    int dTenths = (int)(tempRollerDia * 10.0f + 0.5f);
                    int h = (dTenths / 1000) % 10;
                    int t = (dTenths / 100) % 10;
                    int u = (dTenths / 10) % 10;
                    int d = dTenths % 10;
                    if (isEditingSetting && blinkHide) {
                        if (settingDigitCursor == 0)      snprintf(l2, sizeof(l2), "Val: %d%d%d.  mm  ", h, t, u);
                        else if (settingDigitCursor == 1) snprintf(l2, sizeof(l2), "Val: %d%d .%d mm  ", h, t, d);
                        else if (settingDigitCursor == 2) snprintf(l2, sizeof(l2), "Val: %d %d.%d mm  ", h, u, d);
                        else                              snprintf(l2, sizeof(l2), "Val:  %d%d.%d mm  ", t, u, d);
                    } else {
                        snprintf(l2, sizeof(l2), "Val: %d%d%d.%d mm  ", h, t, u, d);
                    }
                } else if (hiddenOption == 3) {
                    int th = (tempMaxRPM / 1000) % 10;
                    int hd = (tempMaxRPM / 100) % 10;
                    int tn = (tempMaxRPM / 10) % 10;
                    int un = tempMaxRPM % 10;
                    if (isEditingSetting && blinkHide) {
                        if (settingDigitCursor == 0)      snprintf(l2, sizeof(l2), "Val:  %d%d%d RPM  ", hd, tn, un);
                        else if (settingDigitCursor == 1) snprintf(l2, sizeof(l2), "Val: %d %d%d RPM  ", th, tn, un);
                        else if (settingDigitCursor == 2) snprintf(l2, sizeof(l2), "Val: %d%d %d RPM  ", th, hd, un);
                        else                              snprintf(l2, sizeof(l2), "Val: %d%d%d  RPM  ", th, hd, tn);
                    } else {
                        snprintf(l2, sizeof(l2), "Val: %d%d%d%d RPM  ", th, hd, tn, un);
                    }
                } else if (hiddenOption == 4) {
                    int h = (tempFeedAngle / 100) % 10;
                    int t = (tempFeedAngle / 10) % 10;
                    int u = tempFeedAngle % 10;
                    if (isEditingSetting && blinkHide) {
                        if (settingDigitCursor == 0)      snprintf(l2, sizeof(l2), "Val:  %d%d deg   ", t, u);
                        else if (settingDigitCursor == 1) snprintf(l2, sizeof(l2), "Val: %d %d deg   ", h, u);
                        else                              snprintf(l2, sizeof(l2), "Val: %d%d  deg   ", h, t);
                    } else {
                        snprintf(l2, sizeof(l2), "Val: %d%d%d deg   ", h, t, u);
                    }
                } else if (hiddenOption == 5) {
                    int t = (tempSafetyMargin / 10) % 10;
                    int u = tempSafetyMargin % 10;
                    if (isEditingSetting && blinkHide) {
                        if (settingDigitCursor == 0) snprintf(l2, sizeof(l2), "Val:  %d %%    ", u);
                        else                         snprintf(l2, sizeof(l2), "Val: %d  %%    ", t);
                    } else {
                        snprintf(l2, sizeof(l2), "Val: %d%d %%    ", t, u);
                    }
                } else if (hiddenOption == 6) {
                    if (hideVal) snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: REVERSE    " : "Dir: NORMAL     ");
                    else         snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: REVERSE[RV]" : "Dir: NORMAL [FW]");
                } else if (hiddenOption == 7) {
                    if (hideVal) snprintf(l2, sizeof(l2), tempKeypad6Btn ? "Mode: 6-BTN     " : "Mode: 3-BTN     ");
                    else         snprintf(l2, sizeof(l2), tempKeypad6Btn ? "Mode: 6-BTN [6K]" : "Mode: 3-BTN [3K]");
                } else if (hiddenOption == 8) {
                    if (tempAutoLockSec == 0UL) {
                        if (isEditingSetting && blinkHide) {
                            snprintf(l2, sizeof(l2), "Lock: OFF       ");
                        } else {
                            snprintf(l2, sizeof(l2), "Lock: OFF  [OFF]");
                        }
                    } else {
                        int h = (int)(tempAutoLockSec / 100UL) % 10;
                        int t = (int)(tempAutoLockSec / 10UL) % 10;
                        int u = (int)(tempAutoLockSec % 10UL);
                        if (isEditingSetting && blinkHide) {
                            if (settingDigitCursor == 0)      snprintf(l2, sizeof(l2), "Lock: %d%d%ds      ", h, t, u);
                            else if (settingDigitCursor == 1) snprintf(l2, sizeof(l2), "Lock:  %d%ds [ON] ", t, u);
                            else if (settingDigitCursor == 2) snprintf(l2, sizeof(l2), "Lock: %d %ds [ON] ", h, u);
                            else                              snprintf(l2, sizeof(l2), "Lock: %d%d s [ON] ", h, t);
                        } else {
                            snprintf(l2, sizeof(l2), "Lock: %d%d%ds [ON] ", h, t, u);
                        }
                    }
                } else if (hiddenOption == 9) {
                    if (tempBacklightSec == 0 && !isEditingSetting) {
                        snprintf(l2, sizeof(l2), "Light: ALWAYS ON");
                    } else {
                        int h = (tempBacklightSec / 100) % 10;
                        int t = (tempBacklightSec / 10) % 10;
                        int u = tempBacklightSec % 10;
                        if (isEditingSetting && blinkHide) {
                            if (settingDigitCursor == 0)      snprintf(l2, sizeof(l2), "Light:  %d%d s   ", t, u);
                            else if (settingDigitCursor == 1) snprintf(l2, sizeof(l2), "Light: %d %d s   ", h, u);
                            else                              snprintf(l2, sizeof(l2), "Light: %d%d  s   ", h, t);
                        } else {
                            snprintf(l2, sizeof(l2), "Light: %d%d%d s   ", h, t, u);
                        }
                    }
                } else if (hiddenOption == 10) {
                    if (tempMotorSleepMin == 0UL && !isEditingSetting) {
                        snprintf(l2, sizeof(l2), "Sleep: OFF      ");
                    } else {
                        int h = (int)(tempMotorSleepMin / 100UL) % 10;
                        int t = (int)(tempMotorSleepMin / 10UL) % 10;
                        int u = (int)(tempMotorSleepMin % 10UL);
                        if (isEditingSetting && blinkHide) {
                            if (settingDigitCursor == 0)      snprintf(l2, sizeof(l2), "Sleep:  %d%d min ", t, u);
                            else if (settingDigitCursor == 1) snprintf(l2, sizeof(l2), "Sleep: %d %d min ", h, u);
                            else                              snprintf(l2, sizeof(l2), "Sleep: %d%d  min ", h, t);
                        } else {
                            snprintf(l2, sizeof(l2), "Sleep: %d%d%d min ", h, t, u);
                        }
                    }
                } else if (hiddenOption == 11) {
                    snprintf(l2, sizeof(l2), "Open Diagnostics");
                } else if (hiddenOption == 12) {
                    snprintf(l2, sizeof(l2), "Select Save/Exit");
                }

                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
            }
            break;

            case 13: // Save & Exit Confirmation Dialog with In-Place Blinking
                snprintf(l1, sizeof(l1), "SAVE CHANGES?   ");
                if (saveExitChoice) {
                    snprintf(l2, sizeof(l2), blinkHide ? "       NO       " : ">YES   NO       ");
                } else {
                    snprintf(l2, sizeof(l2), blinkHide ? " YES            " : " YES  >NO       ");
                }
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 3: // Emergency Factory Reset with In-Place Blinking
                lcdPrint16(0, "Factory Reset?  ");
                if (resetChoice) {
                    lcdPrint16(1, blinkHide ? "      NO        " : ">YES  NO        ");
                } else {
                    lcdPrint16(1, blinkHide ? " YES            " : " YES >NO        ");
                }
                break;

            case 9: // Info / Diag: 9 Pages
            {
                int cycle = (millis() / 1500UL) % 2;
                char dl1[24] = "                ";
                char dl2[24] = "                ";
                switch (infoIndex) {
                    case 1:
                        snprintf(dl1, sizeof(dl1), "STEPPER JOG TST ");
                        if (currentRPM != 0UL || hwBurstActive || stepsRemaining != 0) {
                            snprintf(dl2, sizeof(dl2), "BLOCKED: RUNNING");
                        } else {
                            if (digitalRead(btnUp) == LOW) snprintf(dl2, sizeof(dl2), "JOG FWD >>> [UP]");
                            else if (digitalRead(btnDown) == LOW) snprintf(dl2, sizeof(dl2), "JOG REV <<< [DN]");
                            else snprintf(dl2, sizeof(dl2), "UP:FWD   DN:REV ");
                        }
                        break;
                    case 2:
                        snprintf(dl1, sizeof(dl1), "OPTO SINK TST   ");
                        if (currentRPM != 0UL || hwBurstActive || stepsRemaining != 0) {
                            snprintf(dl2, sizeof(dl2), "BLOCKED: RUNNING");
                        } else {
                            snprintf(dl2, sizeof(dl2), digitalRead(btnUp) == LOW ? "V<=0.5V SINK ON " : "HOLD [UP] TEST  ");
                        }
                        break;
                    case 3:
                        snprintf(dl1, sizeof(dl1), "PROX HEALTH     ");
                        if (lastMeasuredIntervalUs > 0UL) {
                            unsigned long dispRpm = (currentRPM <= 9999UL) ? currentRPM : 9999UL;
                            snprintf(dl2, sizeof(dl2), "P:%-6lu R:%-4lu", (unsigned long)lastMeasuredIntervalUs, dispRpm);
                        } else {
                            snprintf(dl2, sizeof(dl2), "P:WAIT  RPM: 0  ");
                        }
                        break;
                    case 4:
                        snprintf(dl1, sizeof(dl1), "SYNC HEALTH     ");
                        if (isMotionSyncLost) {
                            snprintf(dl2, sizeof(dl2), "FAULT:SYNC LOST!");
                        } else if (servoPhaseLocked) {
                            snprintf(dl2, sizeof(dl2), "LOCK J:%-6luus", (unsigned long)servoMaxJitterUs);
                        } else {
                            snprintf(dl2, sizeof(dl2), "ACQUIRING...    ");
                        }
                        break;
                    case 5:
                        snprintf(dl1, sizeof(dl1), "STEP TIMING FILT");
                        snprintf(dl2, sizeof(dl2), "T:%-5lu O:%-2lu R:%-2lu", (unsigned long)(validTriggerCount % 100000UL), (unsigned long)(tim2CaptureOverrunCount % 100UL), (unsigned long)(rejectedTriggerCount % 100UL));
                        break;
                    case 6:
                        snprintf(dl1, sizeof(dl1), "STEP ENGINE STAT");
                        snprintf(dl2, sizeof(dl2), "TIM1:%s KEY:%s", hwBurstActive ? "RUN " : "IDLE", keypad6ButtonMode ? "6B" : "3B");
                        break;
                    case 7:
                        evaluateDiagnostics();
                        snprintf(dl1, sizeof(dl1), "%-16s", diagFixLine1 ? diagFixLine1 : "TIMING HEALTH:  ");
                        snprintf(dl2, sizeof(dl2), "%-16s", diagFixLine2 ? diagFixLine2 : "SYSTEM OPTIMAL  ");
                        break;
                    case 8:
                        snprintf(dl1, sizeof(dl1), "HELP & TROUBLE? ");
                        snprintf(dl2, sizeof(dl2), "[MODE] OPEN HELP");
                        break;
                    case 9:
                        snprintf(dl1, sizeof(dl1), "V17.0.0 (NIPON) ");
                        if (cycle == 0) snprintf(dl2, sizeof(dl2), "DEV: RAJESH SHAH");
                        else snprintf(dl2, sizeof(dl2), "BLD: %-11s", FW_BUILD_DATE_STR);
                        break;
                    default:
                        infoIndex = 1;
                        break;
                }
                lcdPrint16(0, dl1);
                lcdPrint16(1, dl2);
            }
            break;

            case 21: // HELP Sub-Branch (5 Diagnostic Troubleshooting Guides)
            {
                int cycle = (millis() / 1500UL) % 2;
                char hl1[17] = "                ";
                char hl2[17] = "                ";
                switch (helpIndex) {
                    case 1:
                        snprintf(hl1, sizeof(hl1), "1. MOTOR STALL? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: INC ANGLE  " : "OR DEC RES/RPM  ");
                        break;
                    case 2:
                        snprintf(hl1, sizeof(hl1), "2. PITCH ERROR? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: TUNE DIA MM" : "OR GEAR +/- PUL ");
                        break;
                    case 3:
                        snprintf(hl1, sizeof(hl1), "3. SENSOR NOISE?");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: CLEAN CAM  " : "CHECK PC817 GND ");
                        break;
                    case 4:
                        snprintf(hl1, sizeof(hl1), "4. MOTOR HOT?   ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: SW4=HALF   " : "CURR 2.8A-3.0A  ");
                        break;
                    case 5:
                        snprintf(hl1, sizeof(hl1), "5. TEETH DRIFT? ");
                        snprintf(hl2, sizeof(hl2), cycle == 0 ? "FIX: TIGHT TAPE " : "CHK ROLLER GRIP ");
                        break;
                    default:
                        helpIndex = 1;
                        break;
                }
                lcdPrint16(0, hl1);
                lcdPrint16(1, hl2);
            }
            break;
        }
        lastDisplayUpdate = millis();
    }
}
