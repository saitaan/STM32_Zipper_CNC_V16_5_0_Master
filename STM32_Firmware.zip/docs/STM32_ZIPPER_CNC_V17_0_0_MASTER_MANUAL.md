# STM32 ZIPPER CNC FEEDER — MASTER TECHNICAL MANUAL & SYSTEM GUIDE

**Firmware Version:** V17.0.0 (Production Release — `V17.0.0-PA0-TIM2-CAPTURE-PA8-TIM1`)  
**Target Hardware:** STM32F103C8T6 (ARM Cortex-M3 @ 72 MHz, "Blue Pill")  
**Application:** High-Speed Zipper Stitching CNC Feeder (Zero-Latency Needle Synchronization Engine)  
**Factory Installation:** Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC / Surat, Gujarat  
**Lead Embedded Systems Architect:** Rajesh Shah  
**Release Date:** October 2026  

---

## 1. SYSTEM OVERVIEW & SPECIFICATIONS

### 1.1 Machine Mission & Operating Principles
The STM32 Zipper CNC Feeder is an ultra-precise, real-time slave-following CNC feeding mechanism mounted on heavy-duty industrial zipper sewing machines. At line speeds of up to **3000 RPM (20,000 µs per complete stitch cycle)**, the feeder advances zipper tape by the exact tooth pitch of the zipper coil (Size #5, Size #8, or Size #10) strictly within the needle-retracted clearance angle (Feed Window), stopping completely with full holding torque before the sewing needle descends to pierce the zipper tape.

```text
       3000 RPM Full Spindle Cycle (20,000 µs Total)
┌──────────────────────────────────────┬──────────────────────────────────────┐
│  Needle Clear Zone: 90° Feed Window  │ Needle Penetration Zone: 270° Locked │
│ Gross Time: 5,000 µs                 │ Spindle & Tape Locked Stiff          │
│ Effective Burst: 4,250 µs            │ Zero Stepper Motion                  │
│ Cushion: 750 µs (15% Safety Margin)  │ Zero Needle Collisions               │
└──────────────────────────────────────┴──────────────────────────────────────┘
```

### 1.2 Master Performance Specifications
| Specification | Parameter Value | Engineering Rationale |
| :--- | :--- | :--- |
| **Max Sewing Spindle Speed** | **3000 RPM Default (100–4000 RPM)** | Nominal 20,000 µs cycle period at 3000 RPM |
| **Gross Feed Angle** | **90° Default (30°–270°)** | Mechanical cam window where needle is outside fabric/tape |
| **Safety Margin Cushion** | **15% Default (0%–29%)** | Eliminates needle deflection & collision risk (750 µs cushion at 3000 RPM) |
| **Effective Feed Window** | **4,250 µs (at 3000 RPM / 90° / 15%)** | Strict time budget for stepper motor burst completion |
| **Authoritative Input Trigger** | **`PA0` (`TIM2_CH1` Input Capture)** | 1 MHz hardware capture, falling-edge latched in silicon (`NVIC Priority 1`, `IC1F=0x3` 8-cycle filter) |
| **Authoritative Output Step** | **`PA8` (`TIM1_CH1` Hardware PWM)** | 1 MHz autonomous hardware PWM Mode 2 burst engine (`5.0 µs` Active-LOW pulse, `NVIC Priority 0`) |
| **Direction Output** | **`PA2` (`dirPin`)** | `HIGH` = Normal Forward (`[FW]`), `LOW` = Reverse (`[RV]`), `20 µs` hardware setup/hold guard |
| **Driver Enable / Sleep Output** | **`PB1` (`motorEnaPin`)** | `LOW` = Driver Active, `HIGH` = Standstill Sleep with 1-cycle (`13.8 ns`) hardware wake ISR |
| **Microstep Resolution** | **6400 steps/rev Default** | Discrete DM542 DIP table: `400` to `51200` steps/rev |
| **Feed Roller Diameter** | **45.0 mm Default (10.0–100.0 mm)** | Circumference = 141.37 mm; 45.27 pulses per mm at 6400 steps/rev |
| **Default Active Size** | **Size #8 (`currentSize = 2`)** | Machine defaults to Size #8 on factory reset |
| **Default Pulse Baselines** | **#5: `70.0` \| #8: `80.0` \| #10: `100.0`** | Stored in 64-bit `1,000,000x` fixed-point micro-units (`001.0` to `500.0` pulses) |
| **LCD Display Driver** | **`FastLiquidCrystal_I2C` (`0x27`)** | Zero-blink, zero-blank-delay power-on splash (`DEV: RAJESH SHAH` / `NIPON ZIPPER IND` for `2.0s` at `100 kHz`, runtime `400 kHz` Fast-Mode) |
| **Flash Memory Persistence** | **True Dual-Slot Ping-Pong EEPROM** | Alternates `Slot 0` (offset 0) $\leftrightarrow$ `Slot 1` (offset 128), selective `offsetof` field writes, CRC32 validated, instant abort on `PA0` trigger |

---

## 2. USER MANUAL: COMPLETE OPERATION, ALL 12 SETTINGS & DIAGNOSTICS GUIDE

### 2.1 Power-On Boot & 16x2 LCD Main Screen Display Layout
When the power switch is turned ON:
1. **Zero-Blink Instant Splash (`0.06s` to `2.06s`):** The LCD backlight stays continuously ON without blinking or blanking, displaying:
   ```text
   Row 1: DEV: RAJESH SHAH
   Row 2: NIPON ZIPPER IND
   ```
2. **Main Operational Screen (`menuState == 0`):**
   ```text
   Row 1: S: 8 3000 F:1.77
   Row 2: P:80.0 W:53 * [U]
   ```
   - **`S: 8`** $\rightarrow$ Active Zipper Size (`S: 5`, `S: 8`, or `S:10`).
   - **`3000`** $\rightarrow$ Live 4-digit Spindle Speed (RPM), refreshed every `250 ms` via shadow-diff I2C only when `!hwBurstActive`.
   - **`F:1.77`** $\rightarrow$ Calculated Feed Length in `mm` per trigger.
   - **`P:80.0`** (or `P:080.0` in inline edit mode) $\rightarrow$ Active Step Pulse Count (`001.0` to `500.0`).
   - **`W:53 *`** $\rightarrow$ Nominal Step Period in `µs` and hardware timing cue (`*`, `#`, `H`).
   - **`[U]` / `[L]`** $\rightarrow$ Keypad Unlocked (`[U]`) or Locked (`[L]`).

---

### 2.2 Dual-Mode Keypad Controls (3-Button Default & 6-Button Extended Mode)

```text
3-BUTTON MODE (Default: keypad6ButtonMode = false):
       ┌──────────┐     ┌──────────┐     ┌──────────┐
       │   [UP]   │     │  [DOWN]  │     │  [MODE]  │
       │  PB13    │     │  PB12    │     │  PB14    │
       └──────────┘     └──────────┘     └──────────┘

6-BUTTON MODE (Extended: keypad6ButtonMode = true, Settings Option 7):
       ┌──────────┐     ┌──────────┐     ┌──────────┐
       │  [LEFT]  │     │ [RIGHT]  │     │  [BACK]  │
       │  PB11    │     │  PB10    │     │  PB15    │
       └──────────┘     └──────────┘     └──────────┘
```

| Action / Gesture on Main Screen (`menuState == 0`) | 3-Button Mode (`[UP]`, `[DOWN]`, `[MODE]`) | 6-Button Mode (`+ [LEFT]`, `[RIGHT]`, `[BACK]`) |
| :--- | :--- | :--- |
| **Adjust Whole Pulses (`+1.0` / `-1.0`)** | Tap `[UP]` / `[DOWN]` (`600 ms` hold = `200 ms` auto-repeat; `.10` decimal preserved) | Same (`[UP]` / `[DOWN]` tap or hold auto-repeat) |
| **Enter 4-Digit Watch Inline Editor (`001.0..500.0`)** | **Single-Click `[MODE]`** (starts at `.10` decimal, 10s idle timeout) | **Single-Click `[MODE]`** or press **`[LEFT]` / `[RIGHT]`** directly |
| **Shift Digit in Main Inline Editor** | Press **`[DOWN]`** (`.10` $\rightarrow$ `Units` $\rightarrow$ `Tens` $\rightarrow$ `Hundreds`) | Press **`[LEFT]`** (move cursor left) or **`[RIGHT]`** (move cursor right) |
| **Change Digit in Main Inline Editor** | Press **`[UP]`** (cycles digit `0..9`; Hundreds `0..5`) | Press **`[UP]`** (`+1` digit) or **`[DOWN]`** (`-1` digit) |
| **Confirm / Exit Main Inline Editor** | **Single-Click `[MODE]`** (`OK`) or wait `10s` idle | **Single-Click `[MODE]`**, press **`[BACK]`**, or wait `10s` idle |
| **Switch Zipper Size (`#5 -> #8 -> #10 -> #5`)** | **Double-Click `[MODE]`** at `0 RPM` standstill | **Double-Click `[MODE]`** at `0 RPM` standstill |
| **Open 12-Option Settings Menu (`menuState = 1`)** | **Hold `[MODE]` for 5 seconds** (`ENTER SETTINGS: IN 4..1 SEC`) | **Hold `[MODE]` for 5 seconds** at `0 RPM` standstill |
| **Unlock Keypad (`[L]` $\rightarrow$ `[U]`)** | Press **`[MODE]`** (`PRESS [DOWN] NOW`), then press **`[DOWN]`** within 3s | Same (`[MODE]` then `[DOWN]` within 3s) |
| **Emergency Factory Reset (`menuState = 3`)** | Hold **`[UP] + [DOWN]`** together for **`> 10 seconds`** at `0 RPM` | Hold **`[UP] + [DOWN]`** together for **`> 10 seconds`** at `0 RPM` |

---

### 2.3 All 12 Settings Menu Options (`menuState == 1`) — Complete Reference

To enter the Settings Menu: Ensure the machine is stopped (`0 RPM`) and unlocked (`[U]`), then **hold `[MODE]` for 5 seconds**.
- **Browse Options (`1..12`):** Press `[DOWN]` (next option `1 -> 12`) or `[UP]` (previous option `12 -> 1`). In 6-BTN Mode, `[LEFT]` / `[RIGHT]` also scroll when not editing.
- **Edit an Option (`1..10`):** **Single-Click `[MODE]`** to enter in-place blinking edit mode (`isEditingSetting = true`). **Single-Click `[MODE]`** again (or press `[BACK]` in 6-BTN Mode) to confirm the value.
- **Exit Settings Menu:** Select `12. Save & Exit`, or **Double-Click `[MODE]`** (when not editing), or press **`[BACK]`** (6-BTN Mode). If any setting was modified (`hasStagedChanges == true`), the firmware automatically prompts `SAVE CHANGES? >YES  NO` before exiting.

#### Option 1: `1. Driver Res` (Stepper Driver Microstep Resolution)
```text
Line 1: 1. Driver Res   
Line 2: Val: 6400  steps
```
* **Default:** `6400 steps`
* **Discrete DIP Table Values:** `400`, `800`, `1000`, `1600`, `2000`, `3200`, `4000`, `5000`, `6400`, `8000`, `10000`, `12800`, `20000`, `25600`, `40000`, `51200`.
* **How to Edit:** Single-click `[MODE]` (value blinks). Press `[UP]` (or `[RIGHT]`) for next DIP resolution; press `[DOWN]` (or `[LEFT]`) for previous DIP resolution. Single-click `[MODE]` to confirm.

#### Option 2: `2. Roller Dia` (Feed Roller Diameter — 4-Digit Watch Editor)
```text
Line 1: 2. Roller Dia   
Line 2: Val: 045.0 mm   
```
* **Default:** `045.0 mm` | **Allowed Range:** `010.0 mm` to `100.0 mm` (clamped automatically on confirm).
* **How to Edit:** Single-click `[MODE]`. Cursor starts at `.0` decimal (`cursor 0 = .0`, `1 = Units`, `2 = Tens`, `3 = Hundreds`).
  - **3-BTN Mode:** `[UP]` increments active digit (`0..9`, Hundreds `0..1`), `[DOWN]` shifts to next digit, `[MODE]` confirms.
  - **6-BTN Mode:** `[LEFT]` shifts cursor left (`.0 -> Units -> Tens -> Hundreds`), `[RIGHT]` shifts cursor right, `[UP]`/`[DOWN]` increment/decrement digit, `[MODE]`/`[BACK]` confirms.

#### Option 3: `3. Max RPM` (Maximum Machine Speed — 4-Digit Watch Editor)
```text
Line 1: 3. Max RPM      
Line 2: Val: 3000 RPM   
```
* **Default:** `3000 RPM` | **Allowed Range:** `0100 RPM` to `4000 RPM`.
* **How to Edit:** Single-click `[MODE]`. Cursor order: `0 = Thousands (0..4)`, `1 = Hundreds (0..9)`, `2 = Tens (0..9)`, `3 = Units (0..9)`. Use `[UP]` to increment digit, `[DOWN]` (or `[LEFT]`/`[RIGHT]` in 6-BTN) to shift digit, and `[MODE]` to confirm.

#### Option 4: `4. Feed Angle` (Mechanical Cam Feed Window — 3-Digit Watch Editor)
```text
Line 1: 4. Feed Angle   
Line 2: Val: 090 deg    
```
* **Default:** `090 deg` | **Allowed Range:** `030 deg` to `270 deg`.
* **How to Edit:** Single-click `[MODE]`. Cursor order: `0 = Hundreds (0..2)`, `1 = Tens (0..9)`, `2 = Units (0..9)`. Confirm with `[MODE]`.

#### Option 5: `5. Safety Margin` (Needle Clearance Margin — 2-Digit Watch Editor)
```text
Line 1: 5. Safety Margin
Line 2: Val: 15 %       
```
* **Default:** `15 %` | **Allowed Range:** `00 %` to `29 %`.
* **How to Edit:** Single-click `[MODE]`. Cursor `0 = Tens (0..2)`, `1 = Units (0..9)`. Confirm with `[MODE]`.

#### Option 6: `6. Motor Dir` (Stepper Rotation Direction)
```text
Line 1: 6. Motor Dir    
Line 2: Dir: NORMAL [FW]   (or Dir: REVERSE[RV])
```
* **Default:** `NORMAL [FW]` (`PA2 = HIGH`).
* **How to Edit:** Single-click `[MODE]`. Press `[UP]` or `[DOWN]` to toggle `NORMAL [FW]` $\leftrightarrow$ `REVERSE[RV]` (in 6-BTN Mode: `[LEFT]` = `NORMAL [FW]`, `[RIGHT]` = `REVERSE[RV]`). Confirm with `[MODE]`.

#### Option 7: `7. Keypad Mode` (3-Button vs 6-Button Hardware Selection)
```text
Line 1: 7. Keypad Mode  
Line 2: Mode: 3-BTN [3K]   (or Mode: 6-BTN [6K])
```
* **Default:** `3-BTN [3K]` (persisted in EEPROM `sensorGuardActive` field: `0` = 3-BTN, `1` = 6-BTN).
* **How to Edit:** Single-click `[MODE]`. Press `[UP]` or `[DOWN]` to toggle `3-BTN [3K]` $\leftrightarrow$ `6-BTN [6K]`. Confirm with `[MODE]`.

#### Option 8: `8. Auto Lock` (Keypad Inactivity Auto-Lock with Explicit `[ON]`/`[OFF]` Switch)
```text
Line 1: 8. Auto Lock    
Line 2: Lock: 030s [ON]    (or Lock: OFF  [OFF])
```
* **Default:** `030s [ON]` | **Allowed Range:** `OFF` (`0s`) or `010s` to `300s`.
* **How to Edit:** Single-click `[MODE]`.
  - **Cursor 0 (`[ON]` / `[OFF]` Switch):** Pressing `[UP]` toggles Auto-Lock between `[ON]` (restoring your last active seconds, e.g. `030s`) and `Lock: OFF  [OFF]` (completely disabling auto-lock).
  - **Cursors 1..3 (Hundreds, Tens, Units Seconds):** Press `[DOWN]` (or `[LEFT]`/`[RIGHT]`) to move onto the 3 digits (`010s` to `300s`) and adjust each digit with `[UP]`. Confirm with `[MODE]`.

#### Option 9: `9. Backlight` (LCD Backlight Auto-Off Timer — 3-Digit Watch Editor)
```text
Line 1: 9. Backlight    
Line 2: Light: ALWAYS ON   (or Light: 060 s)
```
* **Default:** `ALWAYS ON` (`000 s`) | **Allowed Range:** `000 s` (`ALWAYS ON`) or `010 s` to `300 s`.
* **How to Edit:** Single-click `[MODE]`. Edit Hundreds (`0..3`), Tens (`0..9`), and Units (`0..9`). Setting `000 s` keeps the LCD backlight permanently ON. Confirm with `[MODE]`.

#### Option 10: `10. Motor Sleep` (Standstill Stepper Driver Sleep Timer — 3-Digit Watch Editor)
```text
Line 1: 10. Motor Sleep 
Line 2: Sleep: OFF         (or Sleep: 030 min)
```
* **Default:** `OFF` (`000 min`) | **Allowed Range:** `000 min` (`OFF`) or `030 min` to `300 min`.
* **How to Edit:** Single-click `[MODE]`. Edit Hundreds (`0..3`), Tens (`0..9`), and Units (`0..9`). When enabled (`30..300 min`), if the machine sits idle at `0 RPM` with no triggers or button presses for that duration, `PB1` (`motorEnaPin`) goes `HIGH` to put the DM542 driver to sleep and attaches `tim2WakeOnceCallback`—the very first `PA0` cam trigger wakes `PB1` (`LOW`) in **1 CPU cycle (`13.8 ns`)** and fires the step burst with zero latency!

#### Option 11: `11. Info Diag` (Open 9-Page Diagnostics & Hardware Bench Test Suite)
```text
Line 1: 11. Info Diag   
Line 2: Open Diagnostics
```
* **How to Open:** Single-click `[MODE]` on Option 11 to enter `menuState = 9` (Page 1: `STEPPER JOG TST`).

#### Option 12: `12. Save & Exit` (Unified Save / Discard Confirmation Dialog)
```text
Line 1: SAVE CHANGES?   
Line 2: >YES   NO       
```
* **How to Use:** Single-click `[MODE]` on Option 12.
  - Select **`>YES`** (`[UP]` / `[LEFT]`) and press `[MODE]` to validate timing feasibility, apply changes to RAM, and commit selectively to the alternate Ping-Pong EEPROM slot (`SETTINGS SAVED / DIRECT SAVE OK`).
  - Select **`>NO`** (`[DOWN]` / `[RIGHT]`) and press `[MODE]` to discard all staged changes and restore the original settings.

---

### 2.4 Complete 9-Page Diagnostics Suite (`menuState == 9`) & 5-Page Help (`menuState == 21`)

| Page # | LCD Line 1 Title | LCD Line 2 Telemetry / Action | Navigation & Operation |
| :---: | :--- | :--- | :--- |
| **Page 1** | `STEPPER JOG TST ` | `UP:FWD   DN:REV ` | Hold **`[UP]`** = Jog Forward (`1.2 kHz`); Hold **`[DOWN]`** = Jog Reverse (`1.2 kHz`). **Click `[MODE]`** (or `[RIGHT]`) to advance to **Page 2**; **Hold `[MODE]` (`>= 800 ms`)** or press **`[BACK]`** to exit to Settings. |
| **Page 2** | `OPTO SINK TST   ` | `HOLD [UP] TEST  ` | Hold **`[UP]`** to pull `PA8` (`PUL-`) LOW (`V<=0.5V SINK ON`) for multimeter testing. Press **`[DOWN]`** (or `[RIGHT]`) to advance to **Page 3**; click **`[MODE]`** or **`[BACK]`** to exit. |
| **Page 3** | `PROX HEALTH     ` | `P:20000  R:3000 ` | Live `PA0` trigger period in `µs` (`P:`) and calculated RPM (`R:`). `[UP]`/`[DOWN]` browse pages. |
| **Page 4** | `SYNC HEALTH     ` | `LOCK J:12    us ` | Phase lock status (`ACQUIRING...`, `LOCK J:...us`, or `FAULT:SYNC LOST!` if trigger exceeds `2.5x` expected interval). Purely diagnostic—never stops motor in software. |
| **Page 5** | `STEP TIMING FILT` | `T:14520 O:0  R:0` | `T:` Valid Triggers, `O:` `TIM2` Hardware Overcaptures (`CC1OF`), `R:` Rejected Noise / Overrun Triggers. |
| **Page 6** | `STEP ENGINE STAT` | `TIM1:IDLE KEY:3B` | Shows `TIM1` hardware PWM state (`RUN` / `IDLE`) and active keypad mode (`3B` / `6B`). |
| **Page 7** | `TIMING HEALTH:  ` | `SYSTEM OPTIMAL  ` | Live mathematical feasibility check (`SYSTEM OPTIMAL`, `SET RES <= 12800`, or `INC ANGLE >= 120`). |
| **Page 8** | `HELP & TROUBLE? ` | `[MODE] OPEN HELP` | **Single-Click `[MODE]`** opens the **5-Page Field Troubleshooting Help Guide (`menuState = 21`)**: `1. MOTOR STALL?`, `2. PITCH ERROR?`, `3. SENSOR NOISE?`, `4. MOTOR HOT?`, `5. TEETH DRIFT?` (`[UP]`/`[DOWN]` browse `1..5`, `[MODE]`/`[BACK]` returns to Page 8). |
| **Page 9** | `V17.0.0 (NIPON) ` | `DEV: RAJESH SHAH` | Alternates `DEV: RAJESH SHAH` and `BLD: OCT 2026` every `1.5s`. Click `[MODE]` or `[BACK]` to return to Settings. |

---

## 3. HARDWARE WIRING & SCHEMATIC CONNECTION GUIDE

### 3.1 Authoritative STM32F103C8T6 Pinout Allocation Table (100% Matched to Firmware)

| STM32 Pin | Firmware Symbol | Direction / Peripheral | Electrical Standard | External Hardware Connection |
| :--- | :--- | :--- | :--- | :--- |
| **`PA0`** | `proxSensorPin` | Input (`TIM2_CH1`) | `INPUT_PULLUP` + `IC1F=0x3` Filter | `PC817` Optocoupler Collector ( Pin 4) from 24V NPN Proximity Sensor (`LJ12A3-4-Z/BX`) |
| **`PA8`** | `stepPin` | Output (`TIM1_CH1`) | 3.3V Push-Pull / AF PWM Mode 2 | Logic Level Converter `LV1` $\rightarrow$ `HV1` $\rightarrow$ DM542 `PUL-` (Active-LOW `5.0 µs` pulse) |
| **`PA2`** | `dirPin` | Output (GPIO) | 3.3V Push-Pull | Logic Level Converter `LV2` $\rightarrow$ `HV2` $\rightarrow$ DM542 `DIR-` (`HIGH`=Normal, `LOW`=Reverse) |
| **`PB1`** | `motorEnaPin` | Output (GPIO) | 3.3V Push-Pull | Logic Level Converter `LV3` $\rightarrow$ `HV3` $\rightarrow$ DM542 `ENA-` (`LOW`=Enabled/Run, `HIGH`=Sleep) |
| **`PB6`** | `I2C1_SCL` | I2C Clock | 5V-Tolerant Open-Drain (`100/400 kHz`) | 16x2 I2C LCD (`0x27` PCF8574) `SCL` Pin (with `4.7 kΩ` Pull-Up to `+5V`) |
| **`PB7`** | `I2C1_SDA` | I2C Data | 5V-Tolerant Open-Drain (`100/400 kHz`) | 16x2 I2C LCD (`0x27` PCF8574) `SDA` Pin (with `4.7 kΩ` Pull-Up to `+5V`) |
| **`PB13`** | `btnUp` | Input (GPIO) | `INPUT_PULLUP` (Active-LOW) | **`[UP]`** Pushbutton to clean MCU `GND` |
| **`PB12`** | `btnDown` | Input (GPIO) | `INPUT_PULLUP` (Active-LOW) | **`[DOWN]`** Pushbutton to clean MCU `GND` |
| **`PB14`** | `btnMode` | Input (GPIO) | `INPUT_PULLUP` (Active-LOW) | **`[MODE / SELECT]`** Pushbutton to clean MCU `GND` |
| **`PB15`** | `btnBack` | Input (GPIO) | `INPUT_PULLUP` (Active-LOW) | **`[BACK]`** Pushbutton to clean MCU `GND` (Active when `7. Keypad Mode = 6-BTN`) |
| **`PB11`** | `btnLeft` | Input (GPIO) | `INPUT_PULLUP` (Active-LOW) | **`[LEFT]`** Pushbutton to clean MCU `GND` (Active when `7. Keypad Mode = 6-BTN`) |
| **`PB10`** | `btnRight` | Input (GPIO) | `INPUT_PULLUP` (Active-LOW) | **`[RIGHT]`** Pushbutton to clean MCU `GND` (Active when `7. Keypad Mode = 6-BTN`) |
| **`PC13`** | `statusLedPin` | Output (GPIO) | Active-LOW Onboard LED | Onboard Trigger & Burst Activity Indicator |
| **`5V`** | `VCC_5V` | Power Input | Regulated `5.0V DC` ($\ge 1\text{A}$) | Powers STM32 `5V` pin, 16x2 I2C LCD `VCC`, Level Converter `HV`, and DM542 `+5V` Anodes |
| **`GND`** | `GND` | Common Reference | `0V` Star Ground | Common ground across STM32, Level Converter, and LCD |

---

### 3.2 Stepper Driver (`DM542`) & Logic Level Converter (`PA8`, `PA2`, `PB1`) Schematic

```text
STM32 Board (3.3V Side)        LOGIC LEVEL CONVERTER (LLC)        DM542 Stepper Driver (5V Side)
[ 3.3V Pin ] ───────────────── LV  (Low-Voltage 3.3V Ref)
[ GND Pin  ] ───────────────── GND (Common Star Ground)
[ +5V Rail ] ───────────────── HV  (High-Voltage 5.0V Ref) ──┬── PUL+ (Terminal 1)
                                                             ├── DIR+ (Terminal 3)
                                                             ├── ENA+ (Terminal 5)
                                                             └── [ R0: 1.0 kΩ Pull-Up to PUL- ]

PA8 (TIM1_CH1 STEP) ────────── LV1 ───[ BSS138 CH1 ]─── HV1 ────┴── PUL- (Terminal 2)
PA2 (GPIO DIR)      ────────── LV2 ───[ BSS138 CH2 ]─── HV2 ─────── DIR- (Terminal 4)
PB1 (GPIO ENA/SLP)  ────────── LV3 ───[ BSS138 CH3 ]─── HV3 ─────── ENA- (Terminal 6, Optional Sleep)
```

---

### 3.3 Proximity Sensor Isolated Optocoupler Circuit (`PA0 -> TIM2_CH1`)

```text
+24V DC Rail ────[ LJ12A3-4-Z/BX NPN NO Proximity Sensor ]
                        │
                  (Black Signal Wire)
                        │
                [ R1: 2.2 kΩ, 0.5W ]  (Limits 24V signal to ~10 mA for PC817 LED)
                        │
                 ┌──────┴───────┐
                 │  PC817 Opto  │  Pin 1 (Anode) / Pin 2 (Cathode -> 24V GND)
                 └──────┬───────┘
                 ───────┼───────  (5000V Galvanic Isolation Barrier)
STM32 +3.3V ─────┬─[ R2: 4.7 kΩ Pull-Up ]
                 ├─── PC817 Pin 4 (Collector)
STM32 PA0 Pin ───┼─── [TIM2_CH1 Falling-Edge Input Capture + IC1F Hardware Filter]
                 ├─── [ C3: 10 nF Ceramic Filter Cap to MCU GND ]
STM32 GND ───────┴─── PC817 Pin 3 (Emitter) & MCU Star GND
```

---

### 3.4 3-Button / 6-Button Keypad & 16x2 I2C LCD Wiring

```text
16x2 I2C LCD (0x27 PCF8574):
  STM32 +5V ────┬──── [ R4: 4.7 kΩ ] ────┬──── STM32 PB6 (I2C1_SCL) ────► LCD SCL
                ├──── [ R5: 4.7 kΩ ] ────┼──── STM32 PB7 (I2C1_SDA) ────► LCD SDA
                └────────────────────────┼──────────────────────────────► LCD VCC (+5V)
  STM32 GND ─────────────────────────────┴──────────────────────────────► LCD GND

3-Button Primary Keypad (Default 3-BTN Mode):
  STM32 PB13 ───┬─── [ 10 kΩ to +3.3V ] ─── [ [UP] Button ] ─────────┐
  STM32 PB12 ───┼─── [ 10 kΩ to +3.3V ] ─── [ [DOWN] Button ] ───────┼───► STM32 GND
  STM32 PB14 ───┴─── [ 10 kΩ to +3.3V ] ─── [ [MODE] Button ] ───────┤
                                                                     │
6-Button Extended Keypad Add-On (Optional 6-BTN Mode):               │
  STM32 PB15 ───┬─── [ 10 kΩ to +3.3V ] ─── [ [BACK] Button ] ───────┤
  STM32 PB11 ───┼─── [ 10 kΩ to +3.3V ] ─── [ [LEFT] Button ] ───────┤
  STM32 PB10 ───┴─── [ 10 kΩ to +3.3V ] ─── [ [RIGHT] Button ] ──────┘
```

---

## 4. COMPLETE COMPONENT BILL OF MATERIALS (BOM)

| Ref | Component Value | Rating / Package | Connected Pin / Net | Function in V17.0.0 Circuit |
| :--- | :--- | :--- | :--- | :--- |
| **R0** | **1.0 kΩ** | 0.25W Metal Film | `+5V` (`HV`) to `HV1` (`PUL-`) | High-speed pull-up on 5V side of Level Converter for crisp rising edges |
| **R1** | **2.2 kΩ** | 0.5W Metal Film | 24V Sensor Output to `PC817` Pin 1 | Current limiter (~10 mA) for 24V proximity sensor into `PC817` optocoupler |
| **R2** | **4.7 kΩ** | 0.25W Metal Film | `+3.3V` to `PA0` (`PC817` Pin 4) | Pull-up resistor for `PA0` (`TIM2_CH1` capture input) |
| **R4, R5** | **4.7 kΩ** | 0.25W Metal Film | `+5V` to `PB6` (`SCL`) & `PB7` (`SDA`) | I2C bus pull-up resistors for 16x2 LCD (`0x27`) |
| **R7–R12** | **10 kΩ** | 0.25W Metal Film | `+3.3V` to `PB10..PB15` | External EMI-hardened pull-ups for 3-button / 6-button operator keypad |
| **C1, C2** | **100 nF (0.1 µF)** | 50V Ceramic | STM32 `5V`/`3.3V` to `GND` | High-frequency decoupling capacitors close to MCU power pins |
| **C3** | **10 nF (0.01 µF)** | 50V Ceramic | `PA0` to `GND` | Hardware RC low-pass filter (`τ = 47 µs` with `R2`) + `TIM2` `IC1F` digital filter |
| **C4** | **1000 µF / 50V** | Electrolytic | Stepper Driver `+24V/+36V` to `GND` | Bulk DC bus reservoir capacitor to absorb stepper deceleration back-EMF |
| **U1** | **PC817 / EL817** | DIP-4 Optocoupler | Between 24V Sensor & `PA0` | 5000V RMS optical isolation between sewing machine 24V rail and 3.3V MCU |
| **U2** | **4-Ch BSS138 LLC** | Bi-Directional Module | `PA8`/`PA2`/`PB1` (`3.3V` $\rightarrow$ `5V`) | Shifts 3.3V MCU outputs (`LV1..LV3`) to 5V (`HV1..HV3`) for DM542 driver |

---

## 5. FACTORY PRE-FLIGHT VERIFICATION CHECKLIST (SURAT SHOP FLOOR)

1. **Power-On Splash Check:** Flip main power switch ON. Verify the 16x2 LCD immediately displays `DEV: RAJESH SHAH` / `NIPON ZIPPER IND` for `2.0 seconds` without blinking off or showing a 1-second blank screen.
2. **DIP Switch Confirmation:** Confirm DM542 switches match Option 1 (`1. Driver Res = 6400 steps`, SW5=ON, SW6=OFF, SW7=ON, SW8=OFF).
3. **Sensor Air Gap:** Verify inductive proximity sensor gap to cam tooth is **1.0 mm to 1.5 mm**. At standstill (`0 RPM`), rotating the handwheel onto the cam tooth must light the onboard `PC13` LED.
4. **Bench Stepper Jog Test (`11. Info Diag` -> Page 1):** Hold `[MODE]` for 5s to open Settings, go to `11. Info Diag`, press `[MODE]` to open Page 1 (`STEPPER JOG TST`), hold `[UP]` to confirm Forward feeding, and hold `[DOWN]` to confirm Reverse feeding.
5. **Optocoupler Sinking Test (`11. Info Diag` -> Page 2):** From Page 1, click `[MODE]` to advance to Page 2 (`OPTO SINK TST`). Hold `[UP]` and verify with a multimeter that `PUL-` drops to $\le 0.5\text{V}$.
6. **Timing Health Check (`11. Info Diag` -> Page 7):** Press `[DOWN]` to reach Page 7 and confirm `TIMING HEALTH: / SYSTEM OPTIMAL`.

---
*Manual compiled and verified against authoritative V17.0.0 source code for Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC / Surat, Gujarat.*
