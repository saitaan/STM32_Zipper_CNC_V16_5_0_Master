# STM32 ZIPPER CNC FEEDER — MASTER TECHNICAL MANUAL & SYSTEM GUIDE

**Firmware Version:** V17.0.0 (Production Release)  
**Target Hardware:** STM32F103C8T6 (ARM Cortex-M3 @ 72 MHz, "Blue Pill")  
**Application:** High-Speed Zipper Stitching CNC Feeder (Needle Synchronization Engine)  
**Factory Installation:** Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC / Surat, Gujarat  
**Lead Embedded Systems Architect:** Rajesh Shah  
**Release Date:** October 2026  

---

## 1. SYSTEM OVERVIEW & SPECIFICATIONS

### 1.1 Machine Mission & Operating Principles
The STM32 Zipper CNC Feeder is an ultra-precise, real-time slave-following CNC feeding mechanism mounted on heavy-duty industrial zipper sewing machines. At maximum line speeds of up to **3000 RPM (20 ms per complete stitch cycle)**, the feeder must advance zipper tape by the exact tooth pitch of the zipper coil (Size #5, Size #8, or Size #10) strictly within the needle-retracted clearance angle (Feed Window), stopping completely with maximum holding torque before the sewing needle descends to pierce the zipper tape.

```
       3000 RPM Full Spindle Cycle (20,000 µs Total)
┌──────────────────────────────────────┬──────────────────────────────────────┐
│  Needle Clear Zone: 90° Feed Window  │ Needle Penetration Zone: 270° Locked │
│ Gross Time: 5,000 µs                 │ Spindle & Tape Locked Stiff          │
│ Effective Burst: 4,250 µs            │ Zero Stepper Motion                  │
│ Cushion: 750 µs (>15% Safety Margin) │ Zero Needle Collisions               │
└──────────────────────────────────────┴──────────────────────────────────────┘
```

### 1.2 Master Performance Specifications
| Specification | Parameter Value | Engineering Rationale |
| :--- | :--- | :--- |
| **Max Sewing Spindle Speed** | **3000 RPM (50.0 Hz)** | Nominal 20,000 µs cycle period |
| **Gross Feed Angle** | **90.0°** | Mechanical cam window where needle is outside fabric/tape |
| **Safety Margin Cushion** | **15.0% (750 µs)** | Eliminates needle deflection & collision risk |
| **Effective Feed Window** | **4,250 µs** | Strict time budget for stepper motor burst completion |
| **Authoritative Input Trigger** | **PA0 (TIM2_CH1)** | 1 MHz hardware capture, falling-edge latched in silicon (0 ns jitter) |
| **Authoritative Output Step** | **PA8 (TIM1_CH1)** | 1 MHz autonomous hardware PWM Mode 2 burst engine |
| **Microstep Resolution** | **6400 steps/rev** | DM542/DM556 driver setting (SW5=ON, SW6=OFF, SW7=ON, SW8=OFF) |
| **Feed Roller Diameter** | **45.0 mm** | Circumference = 141.37 mm; 45.27 pulses per mm |
| **Default Active Size** | **Size #8 (Mode 2)** | Machine defaults to Size #8 on boot/reset |
| **Size #8 Default Pulses** | **80.00 pulses** | Step Interval = 53.13 µs; Frequency = 18.82 kHz; Pitch = 1.77 mm |
| **Size #5 Default Pulses** | **70.00 pulses** | Step Interval = 60.71 µs; Frequency = 16.47 kHz; Pitch = 1.55 mm |
| **Size #10 Default Pulses** | **100.00 pulses** | Step Interval = 42.50 µs; Frequency = 23.53 kHz; Pitch = 2.21 mm |
| **Driver Step Limit Safety** | **> 5.3x Margin** | Fastest step is 42.5 µs vs driver 8.0 µs minimum floor (125 kHz max) |
| **Flash Memory Persistence** | **Dual-Slot Ping-Pong** | CRC32 validated, 0 RPM standstill commit, zero motion stalls |

---

## 2. USER MANUAL: COMPLETE OPERATION, ALL SETTINGS & DIAGNOSTICS GUIDE

This section contains the complete operational instructions for shop-floor operators and maintenance engineers at Nipon Zipper Industries.

### 2.1 16x2 LCD Main Screen Display Layout
During normal operation (`menuState == 0`), the 16x2 I2C LCD screen displays real-time machine telemetry:

```text
Row 1: S: 8  3000 F:1.77
Row 2: P: 80.0 W:2* [L]
```

* **`S: 8`** $\rightarrow$ **Active Zipper Size:** Shows Size #5 (`S: 5`), Size #8 (`S: 8`), or Size #10 (`S:10`).
* **`3000`** $\rightarrow$ **Live Spindle Speed (RPM):** Measured in real time. Monitored passively in `loop()` so RPM never flashes 0000 while running.
* **`F:1.77`** $\rightarrow$ **Calculated Stitch Length / Feed (mm):** Derived from pulses, roller diameter, and resolution (e.g. $80 \div 45.27 = 1.77\text{ mm}$).
* **`P: 80.0`** $\rightarrow$ **Active Step Pulse Count:** Whole steps and tenths of a step.
* **`W:2*`** $\rightarrow$ **Hardware Pulse Width & Mode Cue:**
  - `2`: Step pulse width in microseconds (2 µs).
  - `*`: Active ultra-fast hardware timer engine indicator.
* **`[L]` / `[U]`** $\rightarrow$ **Keypad Lock Status:**
  - `[L]`: Keypad is LOCKED (prevents accidental parameter modifications during production).
  - `[U]`: Keypad is UNLOCKED (operator can tune pulses and change gears).

---

### 2.2 Button Controls & Gestures Cheat-Sheet

```
       ┌──────────┐     ┌──────────┐     ┌──────────┐
       │   [UP]   │     │  [DOWN]  │     │  [MODE]  │
       │  PB13    │     │  PB12    │     │  PB14    │
       └──────────┘     └──────────┘     └──────────┘
```

| Button / Gesture | Standstill Condition (0 RPM) | Running Condition (> 0 RPM) |
| :--- | :--- | :--- |
| **Double-Click `[MODE]`** | **Toggle Lock / Unlock (`[L]` $\leftrightarrow$ `[U]`)** | **Toggle Lock / Unlock (`[L]` $\leftrightarrow$ `[U]`)** |
| **Single-Click `[MODE]`** | **Toggle Tuning Gear** (`0.10` $\leftrightarrow$ `1.00`). Decimal snaps to `.00` on gear up! | **BLOCKED** (`GEAR CHG BLOCKED`) |
| **Hold `[MODE]` (1.5s to 5.0s)** | **Cycle Zipper Size** (`#5 -> #8 -> #10 -> #5`) | **BLOCKED** (`SIZE CHG BLOCKED`) |
| **Hold `[MODE]` (> 5.0s)** | **Enter Settings Menu** (`menuState = 1`) with live countdown | **BLOCKED** (`MENU LOCKED [L]`) |
| **Press `[UP]`** | **Increment Pulses by Active Gear** (RAM only) | **BLOCKED** (`PULSE TUNE LOCK`) |
| **Press `[DOWN]`** | **Decrement Pulses by Active Gear** (RAM only) | **BLOCKED** (`PULSE TUNE LOCK`) |
| **Dual Hold `[UP] + [DOWN]` (> 10s)** | **Open Factory Reset Dialog** (`>YES  NO`) | **BLOCKED** (`RESET BLOCKED!`) |

---

### 2.3 Step-by-Step Operator Procedures (Kaise Operate Karein)

#### 1. Keypad Ko Unlock Kaise Karein:
1. Main Screen par dekhein, kone me **`[L]`** dikhega (Locked).
2. `[MODE]` button ko **fatafat do baar dabayein (Double-Click)**.
3. Screen par aayega: `KEYPAD UNLOCKED / *[U] ACTIVE`. Kone me **`[U]`** likh jayega.
4. **Auto-Lock:** Agar 1 minute (60s) tak koi button nahi dabaya jayega, toh keypad automatically wapas `[L]` ho jayega.

#### 2. Zipper Size (#5, #8, #10) Kaise Badlein:
1. Keypad unlock karein (`[U]`). Machine 0 RPM par ruki honi chahiye.
2. `[MODE]` button ko **2 second tak daba kar rakhein (Hold)**.
3. Screen par naya size flash hoga (jaise `SIZE: #8 (3.0mm)` ya `SIZE: #10 (4.0mm)`).
4. Us size ke saved pulses (Size #5 = 70.0, Size #8 = 80.0, Size #10 = 100.0) automatically active ho jayenge.

#### 3. Stitch Length / Pulses Ko Fine-Tune Kaise Karein:
1. Keypad unlock karein (`[U]`).
2. **Gear Select Karein:** `[MODE]` ko single-click dabayein:
   - `GEAR: 0.10 PULSE` (Fine tuning: 0.10 pulse per click)
   - `GEAR: 1.00 PULSE` (Normal tuning: 1.00 pulse per click)
   - *(10.0 gear needle protection ke liye hata diya gaya hai; ab gear strictly 0.10 aur 1.00 ke beech toggle hota hai).*
   - *Gear badal kar 1.00 karne par decimal fraction automatically `.00` par snap ho jayega.*
3. **Pulse Badhana / Ghatana:**
   - **`[UP]` dabayein:** Pulses badhengi (stitch length lamba hoga).
   - **`[DOWN]` dabayein:** Pulses ghatengi (stitch length chhota hoga).
4. **Auto-Save:** Nayi value RAM me turant active ho jayegi. 2 minute ke settling time ke baad jab machine 0 RPM standstill par aayegi, setting automatically permanently Flash me save ho jayegi (`AUTO-SAVED OK! / SETTINGS SAVED`), aur gear automatically wapas 1.00 par reset ho jayega.

---

### 2.4 All 10 Settings: Full Details & Step-by-Step "Kaise Change Karein"

Settings Menu me jaane ke liye:
- Keypad unlock karein (`[U]`).
- Machine 0 RPM standstill par ho.
- `[MODE]` button ko **5 second tak daba kar rakhein** (`HOLD MENU: 5s... 4s... 3s...`).
- Settings Menu list open ho jayegi.

```text
Navigation in Settings List:
[DOWN] ──► Agla Option (1 -> 2 -> ... -> 10 -> 1)
[UP]   ──► Pichhla Option (10 -> 9 -> ... -> 1)
[MODE] ──► Option me dakhil hona (ENTER / EDIT)
Hold [MODE] (1.5s) ──► Kisi bhi option se seedha MAIN SCREEN par Quick Back!
Inactivity Timeout ──► Agar 2 minute (120s) tak koi button na dabayein, toh staged changes auto-cancel hokar Main Screen par auto-lock ho jata hai!
```

---

#### Option 1: `1. Driver Res` (Driver Microstep Resolution)
* **Description:** Stepper driver (DM542/DM556) par DIP switch se set kiya gaya microstep resolution (steps per revolution).
* **Factory Default:** **6400 steps/rev**
* **Allowed Range:** 200 steps se 51,200 steps.
* **Kaise Change Karein:**
  1. Option 1 par jakar `[MODE]` dabayein. Screen khulegi:
     ```text
     Res: 6400 stp
     S:100 [MD] HLD:EX
     ```
  2. `[UP]` dabane par resolution badhega; `[DOWN]` dabane par ghatega.
  3. Step multiplier change karne ke liye `[MODE]` single-click dabayein (100 -> 200 -> 500 -> 1000).
  4. Setting poori hone par **`[MODE]` ko 800ms hold karein** (`HLD:EX`). Screen par `EXITING SUB-MENU` aayega aur aap settings list me wapas aa jayenge.

---

#### Option 2: `2. Roller Dia` (Feed Roller Diameter)
* **Description:** Zipper tape ko kheenchne wale mechanical rubber/knurled feed roller ka exact diameter millimeters me.
* **Factory Default:** **45.0 mm**
* **Allowed Range:** 15.0 mm se 100.0 mm (0.1 mm precision).
* **Kaise Change Karein:**
  1. Option 2 par `[MODE]` dabayein:
     ```text
     Dia: 45.0 mm  
     S:0.1 [MD] HLD:EX
     ```
  2. Vernier caliper se roller naapein. Agar roller ghis kar 44.8 mm ho gaya hai, toh `[DOWN]` dabakar `44.8 mm` set karein.
  3. `[MODE]` click se gear badalta hai (strictly `0.1` $\leftrightarrow$ `1.0 mm`; 0.5mm hata diya gaya hai).
  4. **`[MODE]` ko 800ms hold karke** Settings list me back aa jayein.

---

#### Option 3: `3. Max RPM` (Maximum Machine Speed Limit)
* **Description:** Sewing machine ki maximum operational speed limit. Timing feasibility engine is speed par feed window check karta hai.
* **Factory Default:** **3000 RPM**
* **Allowed Range:** 100 RPM se 4000 RPM.
* **Kaise Change Karein:**
  1. Option 3 par `[MODE]` dabayein:
     ```text
     RPM: 3000     
     S:100 [MD] HLD:EX
     ```
  2. `[UP]` / `[DOWN]` se RPM adjust karein (gear fixed: **50 RPM** per click; hold karke rapid scroll karein).
  3. **`[MODE]` single-click dabayein:** Naya RPM turant confirm hokar Settings list me wapas Back aa jayenge (Hold karne ki zaroorat nahi)!

---

#### Option 4: `4. Feed Angle` (Mechanical Feed Window Angle)
* **Description:** Machine ke 360° spindle rotation me se kitne degrees tak needle fabric/zipper se poori tarah baahar rehti hai.
* **Factory Default:** **90 deg** (5,000 µs window at 3000 RPM).
* **Allowed Range:** 30 deg se 270 deg.
* **Kaise Change Karein:**
  1. Option 4 par `[MODE]` dabayein:
     ```text
     Angle:  90 deg
     S:1   [MD] BACK 
     ```
  2. `[UP]` / `[DOWN]` se angle adjust karein (fixed gear: **1 deg** per click).
  3. **`[MODE]` single-click dabayein:** Confirm hokar wapas list me Back aa jayein.
  *(Note: Pehle ka Option 4 Start Spd needle safety ke liye hata diya gaya hai. Stitch #1 hamesha 100% full speed par chalta hai).*

---

#### Option 5: `5. Safety Margin` (Needle Clearance Cushion)
* **Description:** Feed window ke aakhiri hisse me needle collision se bachne ke liye safe clearance margin percentage.
* **Factory Default:** **15%** (750 µs clean holding cushion).
* **Allowed Range:** 0% se 25%.
* **Kaise Change Karein:**
  1. Option 5 par `[MODE]` dabayein:
     ```text
     Margin: 15%   
     S:1%  [MD] BACK 
     ```
  2. `[UP]` / `[DOWN]` se margin adjust karein (fixed gear: **1%** per click).
  3. **`[MODE]` single-click dabayein:** Confirm hokar wapas list me Back aa jayein.

---

#### Option 6: `6. Motor Dir` (Stepper Rotation Direction)
* **Description:** Motor ki rotation direction ko invert karta hai agar roller tape ko aage kheenchne ke bajaye peeche fek raha ho.
* **Factory Default:** **NORMAL [FW]**
* **Kaise Change Karein:**
  1. Option 6 par `[MODE]` dabayein.
  2. `[UP]` se `Dir: NORMAL [FW]`, `[DOWN]` se `Dir: REVERSE[RV]`.
  3. **`[MODE]` single-click dabayein:** Confirm hokar wapas list me Back aa jayein (20 µs hardware delay auto-applied).

---

#### Option 7: `7. STEP Engine` (Motion Generator Architecture)
* **Description:** Production Hardware TIM1 PWM Engine aur Diagnostic DDA Engine ke beech toggle.
* **Factory Default:** **TIM1: HW PRIMARY** (Production Standard)
* **Kaise Change Karein:**
  1. Option 7 par `[MODE]` dabayein.
  2. `[UP]` se `TIM1: HW PRIMARY`, `[DOWN]` se `DDA: DIAG TEMP`.
  3. **`[MODE]` single-click dabayein:** Confirm hokar wapas list me Back aa jayein.

---

#### Option 8: `8. Sensors` (Auxiliary Safety Sensors Sub-Branch)
* **Description:** Charo auxiliary safety features ko ek dedicated consolidated sub-menu me manage karta hai.
* **Sub-Items:**
  - **S1: Tape Guard** (PA3 Optical Tape Break Sensor)
  - **S2: Coil Guard** (PB0 Thread / Coil Break Sensor)
  - **S3: Safety Guard** (PB3 Machine Cover Limit Switch)
  - **S4: Motion Relay** (PB1 Main Motor Emergency Stop Relay)
* **Kaise Change Karein:**
  1. Option 8 par `[MODE]` dabayein. Sensors Sub-Menu open hoga:
     ```text
     S1: Tape Guard   
     PA3: >OFF [MD:ED]
     ```
  2. `[UP]` aur `[DOWN]` se S1, S2, S3, S4 ke beech browse karein.
  3. Kisi bhi sensor ko edit karne ke liye `[MODE]` dabayein:
     - `[UP]` dabane par `>ON` ho jayega.
     - `[DOWN]` dabane par `>OFF` ho jayega.
     - `[MODE]` dabate hi state confirm hokar Sensors menu me Back aa jayega.
  4. Sensors menu se Settings list me wapas aane ke liye **`[MODE]` ko 800ms hold karein**.

---

#### Option 9: `9. Info Diag` (Open Diagnostics System)
* **Description:** Complete 9-Page Diagnostics, live health monitors, troubleshooter HELP sub-branch, aur bench test engine kholta hai.
* **Kaise Kholein:**
  1. Option 9 par cursor layein (`9. Info Diag / Open Diagnostics`).
  2. `[MODE]` dabayein. Diagnostics Page 1 (`STEPPER JOG TST`) open ho jayega.

---

#### Option 10: `10. Save & Exit` (Unified Save / Discard Confirmation Dialog)
* **Description:** Staged settings ko review karke permanently EEPROM me save karne ya cancel karne ka single unified dialog.
* **Kaise Use Karein:**
  1. Option 10 par `[MODE]` dabayein. Screen par confirmation dialog aayega:
     ```text
     Line 1: SAVE CHANGES?   
     Line 2: >YES   NO       
     ```
  2. **Agar Save Karna Hai:**
     - `[UP]` dabayein: cursor **`>YES`** par jayega.
     - `[MODE]` dabayein: Settings EEPROM me Flash hongi, CRC32 verify hoga, screen par aayega:
       ```text
       SETTINGS SAVED  
       DIRECT SAVE OK  
       ```
     - Aur system Main Screen par exit ho jayega.
  3. **Agar Save Nahi Karna (Cancel):**
     - `[DOWN]` dabayein: cursor **`>NO`** par jayega (` YES  >NO `).
     - `[MODE]` dabayein: Staged changes discard ho jayenge:
       ```text
       CHANGES CANCELED
       ORIGINAL KEPT   
       ```
     - Aur system purani settings ke sath Main Screen par exit ho jayega.

---

### 2.5 Complete 9-Page Diagnostics Manual (Kaise Use Karein & Full Detail)

Settings Menu ke Option 10 me jakar `[MODE]` dabane par Diagnostics Screen khulti hai.  
Pages browse karne ke liye:
- **`[UP]`** $\rightarrow$ Agla Page (Page 1 se Page 9).
- **`[DOWN]`** $\rightarrow$ Pichhla Page (Page 9 se Page 1).
- **`[MODE]`** $\rightarrow$ Settings list me wapas Back aana (Page 8 par HELP sub-branch kholta hai).

```text
       ┌────────────────────────────────────────────────────────┐
       │               DIAGNOSTICS PAGE DIRECTORY (9 PAGES)     │
       ├────────┬──────────────────────┬────────────────────────┤
       │ Page 1 │ STEPPER JOG TST      │ Manual FWD/REV Motor   │
       │ Page 2 │ OPTO SINK TST        │ Multimeter Bench Test  │
       │ Page 3 │ PROX HEALTH          │ Sensor Live Period/RPM │
       │ Page 4 │ SYNC HEALTH          │ Phase Jitter & Lock    │
       │ Page 5 │ STEP TIMING FILT     │ Triggers & Overrun     │
       │ Page 6 │ STEP / GUARD         │ Live Pulse & Guards    │
       │ Page 7 │ TIMING HEALTH        │ Speed Window Feasible  │
       │ Page 8 │ HELP & TROUBLE?      │ Field Troubleshooter   │
       │ Page 9 │ V17.0.0 (NIPON)      │ System & Developer ID  │
       └────────┴──────────────────────┴────────────────────────┘
```

---

#### Page 1: Stepper Jog Test (`STEPPER JOG TST` — Sensorless Motor Check)
```text
Line 1: STEPPER JOG TST 
Line 2: UP:FWD   DN:REV 
```
* **Kya Kaam Karta Hai:** Bina sewing handwheel ghumaye aur bina proximity trigger ke stepper motor aur driver ko direct chala kar check karne ka feature.
* **Kaise Operate Karein:**
  1. Machine ruki honi chahiye (0 RPM).
  2. **`[UP]` button ko daba kar rakhein:**
     - Screen par aayega: `JOG FWD >>> [UP]`
     - Stepper motor smooth 1.2 kHz speed par **Forward (Aage)** ghoomne lagegi.
  3. **`[DOWN]` button ko daba kar rakhein:**
     - Screen par aayega: `JOG REV <<< [DN]`
     - Stepper motor smooth 1.2 kHz speed par **Reverse (Peeche)** ghoomne lagegi.
  4. **Button chhodte hi:** Motor turant usi microsecond me ruk jayegi (Dead-Man safety switch).
* **Safety Lock:** Agar machine ka spindle chal raha hoga (RPM > 0), toh needle protection ke liye screen par aayega: `BLOCKED: RUNNING` aur motor nahi ghoomegi.
* **Fault Diagnosis:**
  - Agar `[UP]` aur `[DOWN]` dabane par motor ghoomti hai $\implies$ Driver, 24V Power, Stepper Motor, aur Wiring **100% OK** hain!
  - Agar yahan motor nahi ghoomti $\implies$ Fault driver power, wiring ya motor coil me hai.

---

#### Page 2: Optocoupler Multimeter Test (`OPTO SINK TST` — Bench Testing Without Oscilloscope)
```text
Line 1: OPTO SINK TST   
Line 2: HOLD [UP] TEST  
```
* **Kya Kaam Karta Hai:** Standard ₹200 ke Digital Multimeter se DM542 driver ke input optocoupler aur STM32 PA8 step pin ki physical wiring test karna.
* **Kaise Test Karein:**
  1. Machine 0 RPM par ruki ho.
  2. Multimeter ko DC 20V range par set karein.
  3. Red probe ko Driver `PUL+` (+5V) par aur Black probe ko Driver `PUL-` (PA8) par lagayein.
  4. **Idle Condition:** Multimeter par **4.8V se 5.0V** aana chahiye (Internal LED OFF).
  5. **`[UP]` Button Daba Kar Rakhein:**
     - Screen par aayega: `V<=0.5V SINK ON `
     - STM32 PA8 ko GND par sink kar dega.
     - Multimeter voltage turant gir kar **0.1V se 0.5V** ho jana chahiye!
  6. **Diagnosis:**
     - Agar voltage 4.8V se 0.3V girta hai $\implies$ Logic level converter aur optocoupler **100% swasth (healthy)** hain!
     - Agar voltage 4.8V par hi rehta hai $\implies$ Level converter MOSFET ya PA8 output kharab hai.
     - Agar idle me 0V rehta hai $\implies$ R0 (1.0kΩ) pull-up resistor disconnected hai.

---

#### Page 3: Proximity Sensor Health (`PROX HEALTH`)
```text
Line 1: PROX HEALTH     
Line 2: P: 20000 R:3000 
```
* **`P:[us]`:** Inductive proximity sensor ke consecutive falling edges ke beech ka live time microseconds me (3000 RPM par exact 20,000 µs).
* **`R:[RPM]`:** Live calculate hui mechanical sewing speed.
* **Diagnosis:** Agar handwheel ghumane par `P:WAIT` bana rehta hai, toh sensor air gap (1.0–1.5mm) ya PC817 optocoupler check karein.

---

#### Page 4: Phase Synchronization Health (`SYNC HEALTH`)
```text
Line 1: SYNC HEALTH     
Line 2: LOCK J:   12us  
```
* **`LOCK J:[us]`:** Hardware capture aur theoretical spindle speed ke beech phase jitter microseconds me. Normal range: $< 35\ \mu\text{s}$.
* **`FAULT:SYNC LOST`:** Agar spindle clutch slip ya belt break se phase sync loose hota hai, toh yeh warning aayegi aur PB1 relay motor ko turant rokk dega.

---

#### Page 5: Step Timing Filter & Diagnostics (`STEP TIMING FILT`)
```text
Line 1: STEP TIMING FILT
Line 2: T:14520 O: 0 R: 2
```
* **`T:[Count]`:** Accepted valid needle triggers.
* **`O:[Overrun]`:** Silicon hardware TIM2 CC1OF capture overrun events count. Clean production me **0** hona chahiye.
* **`R:[Rejection]`:** Sub-millisecond mechanical contactor electrical noise spikes jinhe digital filter ne reject kiya.

---

#### Page 6: Step Engine & Optical Guard Live State (`STEP / GUARD`)
```text
Line 1: STEP / GUARD    
Line 2: STEP:IDLE TAPE:OK
```
* **`STEP`:** `RUN` (active pulse burst generation) ya `IDLE` (needle penetration zone me stiff holding torque).
* **`GUARD`:** `TAPE:OK` (tape present), `TAPE-END` (tape finished/broken, feeding stopped), ya `G:OFF` (guard disabled).

---

#### Page 7: Live Timing Health Evaluator (`TIMING HEALTH`)
```text
Line 1: TIMING HEALTH:  
Line 2: SYSTEM OPTIMAL  
```
* **System Optimal:** Mathematical feasibility engine verify karta hai ki configured resolution aur roller diameter 3000 RPM par feed window ke andar safely fit ho rahe hain (Step pulse interval $\ge 8.0\ \mu\text{s}$).
* **Unfeasible Warning:** Agar user ne extreme resolution daal di jo 3000 RPM par physical limits cross kar rahi hai, toh screen live suggestion deti hai: `SET RES <= 12800` ya `INC ANGLE >= 120`.

---

#### Page 8: Field Troubleshooter HELP Sub-Branch (`HELP & TROUBLE?`)
```text
Line 1: HELP & TROUBLE? 
Line 2: [MODE] OPEN HELP
```
* **Kaise Use Karein:** Page 8 par jakar `[MODE]` single-click dabayein. Dedicated 5-Screen Troubleshooter khulega (`menuState = 21`):
  - **H1 (1. Motor Stall?):** Screen alternates: `FIX: INC ANGLE  ` $\longleftrightarrow$ `OR DEC RES/RPM  `.
  - **H2 (2. Pitch Error?):** Screen alternates: `FIX: TUNE DIA MM` $\longleftrightarrow$ `OR GEAR +/- PUL `.
  - **H3 (3. Sensor Noise?):** Screen alternates: `FIX: CLEAN CAM  ` $\longleftrightarrow$ `CHECK PC817 GND `.
  - **H4 (4. Motor Hot?):** Screen alternates: `FIX: SW4=HALF   ` $\longleftrightarrow$ `CURR 2.8A-3.0A  `.
  - **H5 (5. Teeth Drift?):** Screen alternates: `FIX: TIGHT TAPE ` $\longleftrightarrow$ `CHK ROLLER GRIP `.
  - `[UP]` aur `[DOWN]` se H1..H5 browse karein.
  - `[MODE]` single-click dabane par wapas Diagnostics Page 8 par return ho jate hain!

---

#### Page 9: System Info & Build Details (Moved to End Page)
```text
Line 1: V17.0.0 (NIPON) 
Line 2: DEV: RAJESH SHAH / BLD: 10-OCT-2026
```
* **Kya Dikhata Hai:** Firmware Version `V17.0.0`, Nipon Zipper factory installation tag, Developer Rajesh Shah, aur exact firmware compilation date. Line 2 har 1.5 second me developer name aur build date swap karti hai.

---

## 3. HARDWARE WIRING & SCHEMATIC CONNECTION GUIDE

```
                    ┌──────────────────────────────┐
                    │    STM32F103C8T6 BLUE PILL   │
                    │         (72 MHz ARM)         │
                    └──────────────┬───────────────┘
                                   │
      ┌────────────────────────────┼────────────────────────────┐
      │                            │                            │
      ▼                            ▼                            ▼
┌───────────┐                ┌───────────┐                ┌───────────┐
│ PROX SENSOR│               │  LOGIC    │                │  16x2 I2C │
│ (PA0 TIM2)│                │ CONVERTER │                │    LCD    │
│  IND. NPN │                │  (LV/HV)  │                │ (PB6/PB7) │
└───────────┘                └─────┬─────┘                └───────────┘
                                   │
                                   ▼
                             ┌───────────┐
                             │   DM542   │
                             │  STEPPER  │
                             │  DRIVER   │
                             └───────────┘
```

### 3.1 STM32 Pinout Allocation Table

| STM32 Pin | Signal Name | Type | Electrical Standard | External Connection |
| :--- | :--- | :--- | :--- | :--- |
| **PA0** | `proxSensorPin` | Input (TIM2_CH1) | 5V-Tolerant, Internal Pull-Up | NPN NO Proximity Sensor (Cam Edge) via PC817 Opto |
| **PA8** | `stepPin` | Output (TIM1_CH1) | 3.3V Logic Output | Level Converter `LV1` $\rightarrow$ `HV1` $\rightarrow$ DM542 `PUL-` |
| **PA2** | `dirPin` | Output (GPIO) | 3.3V Logic Output | Level Converter `LV2` $\rightarrow$ `HV2` $\rightarrow$ DM542 `DIR-` |
| **PB6** | `I2C1_SCL` | Bidirectional | 5V-Tolerant, I2C SCL (400 kHz) | I2C LCD Backpack SCL Pin (with 4.7kΩ Pull-Up) |
| **PB7** | `I2C1_SDA` | Bidirectional | 5V-Tolerant, I2C SDA (400 kHz) | I2C LCD Backpack SDA Pin (with 4.7kΩ Pull-Up) |
| **PA3** | `tapeSensorPin` | Input (GPIO) | 5V-Tolerant, Pull-Up | Optical Tape-Break Sensor Output (with 1kΩ Limiter) |
| **PB0** | `futureSensor1Pin` | Input (GPIO) | 5V-Tolerant, Pull-Up | Coil / Thread Sensor (Auxiliary Opto Input) |
| **PB3** | `futureSensor2Pin` | Input (GPIO) | 5V-Tolerant, Pull-Up | Safety Cover Limit Switch |
| **PB1** | `motionRelayPin` | Output (GPIO) | 3.3V Push-Pull | Stop Relay Base via 1.0kΩ Resistor & 2N2222 Transistor |
| **PB12** | `btnDown` | Input (GPIO) | Internal Pull-Up to 3.3V | `[DOWN]` Tactile Pushbutton (with optional 10kΩ Pull-Up) |
| **PB13** | `btnUp` | Input (GPIO) | Internal Pull-Up to 3.3V | `[UP]` Tactile Pushbutton (with optional 10kΩ Pull-Up) |
| **PB14** | `btnMode` | Input (GPIO) | Internal Pull-Up to 3.3V | `[MODE]` Tactile Pushbutton (with optional 10kΩ Pull-Up) |
| **PC13** | `STATUS_LED` | Output (GPIO) | Active-LOW (Onboard LED) | Onboard Visual Trigger Indicator |
| **5V** | `VCC_5V` | Power | 5.0V DC Regulated ($\ge 1\text{A}$) | Powers STM32, I2C LCD, Level Converter HV Rail |
| **GND** | `GND` | Power | 0V Common Ground | Star Ground Connection to all peripherals |

---

### 3.2 Stepper Motor Driver & Logic Level Converter Wiring (R0 Resistor)

**CRITICAL MCU PROTECTION RULE:** STM32 microcontroller operates strictly at 3.3V logic. **NEVER connect raw +5V directly to STM32 PA8! Doing so will burn the MCU core.** The $1.0\ \text{k}\Omega$ pull-up resistor (**R0**) connects strictly on the **HIGH-VOLTAGE (HV = 5V)** side of the Logic Level Converter. The STM32 PA8 pin connects strictly to the 3.3V Low-Voltage (`LV1`) side.

```
STM32 Board (3.3V Safe)        LOGIC LEVEL CONVERTER (LLC)        DM542 Driver (5V Side)
[ 3.3V Power ] ─────────────── LV  (Low-Voltage 3.3V)
[ GND Power  ] ─────────────── GND (Common Ground)

PA8 (TIM1 PWM) ─────────────── LV1 ───[ BSS138 FET ]─── HV1 ────┬─ PUL- (Terminal 2)
                                                                │
+5V Power Rail ─────────────── HV  (High-Voltage 5.0V) ──┬─[ R0: 1.0 kΩ Pull-Up ]
                                                         ├──────── PUL+ (Terminal 1)
PA2 (DIR Pin)  ─────────────── LV2 ───[ BSS138 FET ]─── HV2 ────── DIR- (Terminal 4)
+5V Power Rail ────────────────────────────────────────────────── DIR+ (Terminal 3)
(Unconnected)  ────────────────────────────────────────────────── ENA+ (Default Enabled)
(Unconnected)  ────────────────────────────────────────────────── ENA- (Default Enabled)

24V-36V DC Power Supply                                          Power Terminals
+24V / +36V DC ────────────────────────────────────────────────── VCC / +V
Power GND      ────────────────────────────────────────────────── GND / 0V

Stepper Motor (57HS22 NEMA 23)                                   Motor Terminals
Phase A Coil (Black) ──────────────────────────────────────────── A+
Phase A Coil (Green) ──────────────────────────────────────────── A-
Phase B Coil (Red)   ──────────────────────────────────────────── B+
Phase B Coil (Blue)  ──────────────────────────────────────────── B-
```

---

### 3.3 Proximity Sensor Isolated Optocoupler Circuit (R1 & R2 Resistors, C3 Cap)

The industrial inductive proximity sensor (LJ12A3-4-Z/BX NPN NO) operates on 24V. Optical isolation via PC817 optocoupler ensures high-voltage factory spikes never reach the STM32 microcontroller.

```
+24V DC Rail ────[ LJ12A3 Proximity Sensor ]
                        │
                  (Black Wire: Signal)
                        │
                [ R1: 2.2 kΩ, 0.5W ]  (Current Limiter for 24V to ~10mA)
                        │
                        ▼
                 ┌──────────────┐
                 │ PC817 Opto   │
                 │ Pin 1: Anode │
                 └──────┬───────┘
                        │
                 ┌──────┴───────┐
                 │ PC817 Opto   │
                 │Pin 2: Cathode│
                 └──────┬───────┘
                        │
Power GND ──────────────┴─────────────────────────── Machine 24V GND Rail

                 ───────────────────────────────── (5000V Galvanic Isolation)

STM32 +3.3V ─────┬─[ R2: 4.7 kΩ Pull-Up ]
                 │
                 ├──────────────┐
                 │ PC817 Opto   │
                 │Pin 4: Collect│
                 └──────┬───────┘
                        │
STM32 PA0 Pin ──────────┼─────────────────────────── [TIM2_CH1 Hardware Capture]
                        │
                 [ C3: 10 nF Ceramic ] (Hardware Low-Pass Anti-Chatter Filter)
                        │
STM32 GND ───────┴──────┴─────────────────────────── PC817 Pin 3 (Emitter) & MCU GND
```

---

### 3.4 Industrial Machine Emergency Stop Relay Circuit (R6 Resistor, D1 Diode, Q1 Transistor)

When a safety fault trips (tape break, thread break, or motion sync loss), STM32 pin **PB1** outputs HIGH (3.3V) to energize the machine E-Stop relay and instantly halt the sewing head.

```
STM32 Board                                   Relay Driver Circuit
                                              +12V / +24V DC Machine Relay Rail
                                                             │
                                                             ├─────────────┐
                                                             │             │
                                                     [ Relay Coil ]   [ D1: 1N4007 ]
                                                     (Omron / IDEC)  (Flyback Diode)
                                                             │        Cathode to +V
                                                             ├─────────────┘
                                                             │
                                                      Collector (C)
                                                             │
PB1 (Relay Pin) ───[ R6: 1.0 kΩ Base Resistor ]───► Base (B) [ Q1: 2N2222 NPN ]
                                                             │
                                                       Emitter (E)
                                                             │
STM32 GND ───────────────────────────────────────────────────┴───────────── Power GND
```

---

### 3.5 Optical Tape-Break Sensor Circuit (R3 Resistor, D2 Clamping Diode)

Monitors zipper tape presence at the feed entrance. If the tape breaks or finishes, phototransistor turns OFF, pulling PA3 HIGH to trigger E-Stop.

```
+5V Power Rail ────┬─[ R3: 1.0 kΩ Limiter ]───► Optical Sensor IR LED Anode
                   │                             IR LED Cathode ────────── GND
                   │
                   └─[ Internal Pull-Up ]
                             │
STM32 PA3 Pin ───────────────┼───► Phototransistor Collector (Emitter to GND)
                             │
                      [ D2: BAT54S Diode ] (3.3V Overvoltage Clamping)
                             │
STM32 GND ───────────────────┴──────────────────────────────────────────── MCU GND
```

---

### 3.6 I2C 16x2 LCD Display Bus Circuit (R4 & R5 Pull-Up Resistors)

The 16x2 LCD with PCF8574 I2C backpack communicates at 400 kHz Fast-Mode. External pull-up resistors maintain clean square edges over the display cable.

```
+5V Power Rail ──────────┬──────────────────┬───────────────── LCD VCC Pin
                         │                  │
                  [ R4: 4.7 kΩ ]     [ R5: 4.7 kΩ ]
                  (SCL Pull-Up)      (SDA Pull-Up)
                         │                  │
STM32 PB6 (SCL) ─────────┴──────────────────┼───────────────── LCD SCL Pin
                                            │
STM32 PB7 (SDA) ────────────────────────────┴───────────────── LCD SDA Pin
STM32 GND       ────────────────────────────────────────────── LCD GND Pin
```

---

### 3.7 Operator Keypad Pushbutton Circuit (R7, R8, R9 Resistors)

Tactile buttons `[UP]`, `[DOWN]`, and `[MODE]` utilize STM32 internal pull-ups. In high-EMI sewing factory environments, external 10kΩ pull-up resistors provide superior noise immunity against motor contactor sparking.

```
STM32 +3.3V ─────┬─[ R7: 10 kΩ ]─────┬─[ R8: 10 kΩ ]─────┬─[ R9: 10 kΩ ]
                 │                   │                   │
STM32 PB13 ──────┴───[ [UP] Button ] │                   │
                                     │                   │
STM32 PB12 ──────────────────────────┴──[ [DOWN] Button] │
                                                         │
STM32 PB14 ──────────────────────────────────────────────┴──[ [MODE] Button ]
                                                                   │
STM32 GND  ────────────────────────────────────────────────────────┴── All Buttons to GND
```

---

### 3.8 Power Decoupling & Bulk Capacitor Network (C1, C2, C4)

```
STM32 5V Pin  ─────┬───── [ C1: 100 nF Ceramic ] ─────┬───── STM32 GND
STM32 3.3V Pin ────┼───── [ C2: 100 nF Ceramic ] ─────┼───── STM32 GND
                   │                                  │
Driver +24V/36V ───┴─── [ C4: 1000 µF / 50V Elect ] ──┴───── Driver Power GND
```

---

## 4. ELECTRONIC RESISTOR & HARDWARE COMPONENT DETAILS

### 4.1 Complete Component Bill of Materials (BOM)

| Component Ref | Component Value | Rating / Package | Circuit Role | Purpose & Design Calculation |
| :--- | :--- | :--- | :--- | :--- |
| **R0 (PUL- Pull-Up)** | **1.0 kΩ** | 0.25 Watt, Metal Film | LLC HV Side 5V Pull-Up | Connects strictly between +5V and Level Converter `HV1` / `PUL-`; eliminates 1.7V leakage between 3.3V MCU & 5V opto; sharp rising edge at 3000 RPM |
| **R1 (Sensor Opto)** | **2.2 kΩ** | 0.5 Watt, Metal Film | Sensor Signal Limiting | Limits 24V proximity sensor output to ~10mA forward current for PC817 optocoupler diode ($R = (24-1.2)/0.010 = 2280\ \Omega$) |
| **R2 (PA0 Pull-Up)** | **4.7 kΩ** | 0.25 Watt, Through-Hole | PA0 Input Pull-Up | Pulls PA0 to +3.3V when PC817 transistor is OFF; sharp falling edge on sensor trigger ($I_C \approx 0.7\text{ mA}$) |
| **R3 (Tape Sensor)** | **1.0 kΩ** | 0.25 Watt, Through-Hole | Optical Sensor Limiting | Limits 5V to optical phototransistor IR emitter diode |
| **R4 (I2C SCL)** | **4.7 kΩ** | 0.25 Watt, Through-Hole | I2C Bus Pull-Up | Pulls PB6 (SCL) to +5V (standard on PCF8574 backpack) |
| **R5 (I2C SDA)** | **4.7 kΩ** | 0.25 Watt, Through-Hole | I2C Bus Pull-Up | Pulls PB7 (SDA) to +5V (standard on PCF8574 backpack) |
| **R6 (Relay Base)** | **1.0 kΩ** | 0.25 Watt, Through-Hole | NPN Transistor Base | Limits base current to ~2.6mA from PB1 (3.3V) to saturate 2N2222 transistor for relay coil switching |
| **R7, R8, R9 (Buttons)**| **10 kΩ** | 0.25 Watt, Through-Hole | Button Hardware Pull-Up | Supplementary external pull-up for PB12, PB13, PB14 in high-EMI industrial sewing environments |
| **D1 (Flyback Diode)** | **1N4007** | 1000V, 1A Diode | Relay Coil Snubber | Connected anti-parallel across PB1 relay coil; snubs inductive back-EMF spikes when relay turns off |
| **D2, D3 (Protection)**| **BAT54S / 1N4148** | Fast Switching Diode | Input Line Clamping | Clamps PA0 and PA3 input lines between GND and VCC to suppress inductive ringing spikes |
| **C1, C2 (Power)** | **100 nF (0.1 µF)** | 50V Ceramic | Power Decoupling | Placed directly between STM32 5V/3.3V and GND pins to filter high-frequency digital switching noise |
| **C3 (Sensor Filter)** | **10 nF (0.01 µF)** | 50V Ceramic | Hardware Debounce | Placed across PA0 and GND; forms 47 µs RC low-pass filter with R2 to reject motor contactor chatter |
| **C4 (Bulk Power)** | **1000 µF / 50V** | Electrolytic, High Temp | DC Supply Reservoir | Placed across +24V/+36V driver input terminals to absorb motor deceleration back-EMF energy |
| **Q1 (Relay Driver)** | **2N2222 / BC547** | NPN Transistor, TO-92 | Relay Coil Switch | Sinks 12V/24V relay coil current to ground when PB1 goes HIGH |
| **U1 (Optocoupler)** | **PC817 / EL817** | DIP-4 Optocoupler | Galvanic Isolation | 5000V RMS optical isolation between 24V machine chassis and 3.3V microcontroller |
| **U2 (Level Converter)**| **4-Ch LLC (BSS138)** | Bi-Directional Shifter | 3.3V to 5V Shifter | Isolates 3.3V STM32 (LV side) from 5V DM542 driver (HV side); prevents MCU burn |

---

### 4.2 Resistor Sizing Calculations

#### 1. Sensor Optocoupler Series Resistor ($R_1 = 2.2\text{ k}\Omega$):
- Sensor supply voltage $V_{IN} = 24\text{V}$
- PC817 optocoupler forward voltage $V_F = 1.2\text{V}$
- Desired optocoupler diode current $I_F = 10\text{ mA} = 0.010\text{ A}$
$$R_1 = \frac{V_{IN} - V_F}{I_F} = \frac{24\text{V} - 1.2\text{V}}{0.010\text{A}} = \frac{22.8\text{V}}{0.010\text{A}} = 2,280\ \Omega \approx 2.2\text{ k}\Omega$$
- Power dissipation:
$$P = I_F^2 \times R_1 = (0.010)^2 \times 2200 = 0.22\text{ W} \implies \text{Use 0.5 Watt rating}.$$

#### 2. Input Pull-Up Resistor ($R_2 = 4.7\text{ k}\Omega$):
- Logic high voltage $V_{CC} = 3.3\text{V}$
- Pull-up current when saturated: $I_C = \frac{3.3\text{V}}{4.7\text{ k}\Omega} \approx 0.7\text{ mA}$ (well within PC817 50mA rating).
- RC time constant with 10nF filter capacitor:
$$\tau = R \times C = 4,700\ \Omega \times 10 \times 10^{-9}\text{ F} = 47\ \mu\text{s}$$
- $47\ \mu\text{s}$ is fast enough to handle 3000 RPM (20 ms period) while completely squelching microsecond electrical sparks from industrial motor contactors.

#### 3. Relay Driver Base Resistor ($R_6 = 1.0\text{ k}\Omega$):
- STM32 GPIO output voltage $V_{OUT} = 3.3\text{V}$
- NPN transistor base-emitter saturation voltage $V_{BE} = 0.7\text{V}$
- Base current:
$$I_B = \frac{V_{OUT} - V_{BE}}{R_6} = \frac{3.3\text{V} - 0.7\text{V}}{1,000\ \Omega} = 2.6\text{ mA}$$
- At $h_{FE} = 50$, $2.6\text{ mA}$ base drive can saturate up to $130\text{ mA}$ relay coil current, securely switching standard 12V/24V industrial relays.

---

## 5. FACTORY PRE-FLIGHT VERIFICATION CHECKLIST (SURAT SHOP FLOOR)

Before commissioning the CNC feeder on active zipper production lines:
1. **Power & Polarity Check:** Verify 24V DC to DM542 driver and clean 5.0V DC to STM32 board.
2. **DIP Switch Confirmation:** Confirm DM542 switches are set to 6400 steps/rev (SW5=ON, SW6=OFF, SW7=ON, SW8=OFF).
3. **Sensor Air Gap:** Check inductive proximity sensor gap to cam tooth is between **1.0 mm and 1.5 mm**.
4. **Bench Stepper Jog Test:** Open Diagnostics Page 2 (`STEPPER JOG TST`), hold `[UP]` to confirm forward feeding, hold `[DOWN]` to confirm reverse feeding.
5. **Optocoupler Sinking Test:** Open Diagnostics Page 8 (`OPTO SINK TST`), hold `[UP]` and verify multimeter voltage drops to $\le 0.5\text{V}$.
6. **Handwheel Single Stitch Test:** Rotate machine handwheel 1 revolution by hand. Verify PC13 LED blinks once and roller steps exact tooth pitch.
7. **Timing Feasibility Confirmation:** Check Diagnostics Page 13 (`TIMING HEALTH`) displays `TIMING HEALTH: / SYSTEM OPTIMAL`.

---
*Manual compiled and verified for production compliance at Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC / Surat, Gujarat.*
