#include <iostream>
#include <cstdint>
#include <cassert>

int main() {
    std::cout << "Running test_fractional_accumulator..." << std::endl;
    uint32_t fracAcc = 0;
    uint64_t fractionalSteps = 0;
    uint32_t fracPart = 176848UL;
    const uint32_t CYCLES = 1000000;
    for (uint32_t i = 0; i < CYCLES; i++) {
        fracAcc += fracPart;
        if (fracAcc >= 1000000UL) {
            fractionalSteps++;
            fracAcc -= 1000000UL;
        }
    }
    assert(fractionalSteps == 176848ULL);
    assert(fracAcc == 0);
    std::cout << "[PASS] test_fractional_accumulator: 1,000,000 Triggers Long-Run Exact Convergence (Error = 0.000000)." << std::endl;
    return 0;
}
