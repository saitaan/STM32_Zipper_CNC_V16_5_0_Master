#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================================="
echo "COMPILING & RUNNING HOST-SIDE HARDENED TEST HARNESS"
echo "Working Directory: $SCRIPT_DIR"
echo "=========================================================="

TESTS=(
    "test_source_consistency"
    "test_exact_regression"
    "test_comprehensive_suite"
    "test_queue_formal"
    "test_fractional_ratios"
    "test_direction_safety"
    "test_overcapture"
    "test_trigger_capture"
    "test_pulse_conservation"
    "test_burst_boundary"
    "test_timer_overflow"
    "test_safety_sensors"
    "test_safety_priority"
    "test_pulsestep_persistence"
    "test_race_condition_matrix"
    "test_rpm_sweep"
    "test_watchdog"
    "test_fault_recovery"
    "test_randomized_stress_500k"
    "test_long_duration_10m"
    "test_mode_button_behavior"
)

TOTAL_TESTS=${#TESTS[@]}
TOTAL_PASS=0
TOTAL_FAIL=0
TOTAL_SKIP=0

for t in "${TESTS[@]}"; do
    if [ ! -f "${t}.cpp" ]; then
        echo "FATAL: Test source file missing: ${t}.cpp"
        TOTAL_FAIL=$((TOTAL_FAIL + 1))
        exit 1
    fi

    echo "--- Building & Running $t ---"
    if g++ -O3 -Wall -Wextra -Werror -std=c++11 -I../include -I../../source/include "${t}.cpp" -o "$t"; then
        if ./"$t"; then
            TOTAL_PASS=$((TOTAL_PASS + 1))
        else
            echo "FAILED: Test execution failed for $t"
            TOTAL_FAIL=$((TOTAL_FAIL + 1))
            exit 1
        fi
        rm -f "$t"
    else
        echo "FAILED: Compilation failed for $t"
        TOTAL_FAIL=$((TOTAL_FAIL + 1))
        exit 1
    fi
    echo ""
done

echo "=========================================================="
echo "TEST SUITE EXECUTION SUMMARY"
echo "=========================================================="
echo "TOTAL  : $TOTAL_TESTS"
echo "PASSED : $TOTAL_PASS"
echo "FAILED : $TOTAL_FAIL"
echo "SKIPPED: $TOTAL_SKIP"
echo "=========================================================="

if [ "$TOTAL_FAIL" -eq 0 ] && [ "$TOTAL_SKIP" -eq 0 ] && [ "$TOTAL_PASS" -eq "$TOTAL_TESTS" ]; then
    echo "STATUS: ALL $TOTAL_PASS TESTS PASSED 100% GREEN (ZERO FAILURES, ZERO SKIPPED)!"
    exit 0
else
    echo "STATUS: TEST SUITE FAILED"
    exit 1
fi
