# STM32 Zipper CNC V16.5.1 Physical Hardware Test Procedures

**Target Silicon:** STM32F103C8T6 (ARM Cortex-M3 @ 72MHz)  
**Required Equipment:**
- 2-Channel 100MHz Digital Storage Oscilloscope (DSO)
- Logic Analyzer (Saleae / 24MHz 8-Channel)
- Benchtop DC Power Supply (24V for Stepper Driver, 5V for Relay & Logic Shifter)
- Leadshine DM542 / DM556 Microstepping Driver + NEMA 23 Stepper Motor
- LJ12A3-4-Z/BX NPN Inductive Proximity Sensor (Cam Trigger)
- ST-Link V2 USB Programmer

---

## Test Procedure 1: Trigger Capture & Jitter Measurement (PA0 -> PA1)
1. Connect Channel 1 of DSO to **PA0** (Cam Proximity Input). Trigger mode: Negative Edge.
2. Connect Channel 2 of DSO to **PA1** (Step Pulse Output).
3. Spin machine handwheel to 1,500 RPM.
4. **Verification Criteria:**
   - Measure delay between falling edge of PA0 and first active-LOW step pulse on PA1.
   - Latency must be $\le 2.0\,\mu\text{s}$.
   - Step pulse width on PA1 must be strictly **.0\,\mu\text{s}$ active-LOW** (sitting at 3.3V HIGH during idle).

---

## Test Procedure 2: Pulse Conservation & Burst Boundary Verification
1. Attach Logic Analyzer Channel 0 to PA0, Channel 1 to PA1, Channel 2 to PA2 (DIR).
2. Set machine parameter to P5 (Size 1: 113.18 pulses / feed).
3. Record continuous stream of 100 consecutive proximity trigger events.
4. Export logic analyzer pulse count:
   - Total expected pulses $= 11,318$ pulses.
   - Count must match **exactly 11,318 pulses** (Zero missed pulses, zero extra pulses).

---

## Test Procedure 3: Standstill Relay E-Stop Interlock
1. While machine is running at 1,000 RPM, disconnect Tape Sensor (PA3).
2. Observe PB1 relay:
   - Relay trips HIGH within 15ms.
   - PA1 step pulses freeze instantly in silicon hardware.
3. Attempt to push Reset / Mode button while shaft is still turning ($\text{RPM} > 0$).
4. **Verification Criteria:**
   - Relay must remain tripped until machine comes to a complete **0 RPM Standstill**.
   - At 0 RPM, relay safely releases to LOW.
