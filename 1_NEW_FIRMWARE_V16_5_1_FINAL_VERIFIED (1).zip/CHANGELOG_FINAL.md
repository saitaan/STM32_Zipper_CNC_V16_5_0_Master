# Changelog — V16.5.1 Final Hardened Production Release

All changes in this release are strictly hardened for 100% deterministic motion, zero missed pulses, zero drift, full physical pinout compatibility, and race-free EEPROM deferred-trigger handoff.

---

### [V16.5.1-FINAL-HARDENED-PRODUCTION-LOCK] — 2026-10-04

#### 1. Hardware Trigger Capture & Overcapture Detection (TIM2_CH1 on PA0)
- **Added:** TIM2 Channel 1 configured in Hardware Input Capture mode (`CC1S = 01b`, `CC1P = 1`, `CC1E = 1`).
- **Added:** Hardware edge latching into `TIM2->CCR1` directly in silicon input capture register.
- **Added:** Hardware overcapture detection via `TIM_SR_CC1OF` status flag, explicitly logging overruns to `captureOverrunCount`.
- **Documented:** Transparent documentation of STM32F103 timer timebase sharing constraint between PA0 (CH1) and PA1 (CH2).

#### 2. Continuous 32-Bit Microsecond Hardware Timebase (TIM4)
- **Added:** Continuous 1.0 MHz 16-bit hardware timer (TIM4) running 24x7 (`TIM4->PSC = 71`, `TIM4->ARR = 0xFFFF`).
- **Added:** Dedicated 16-bit rollover interrupt handler (`TIM4_IRQHandler`) maintaining `tim4_overflow_count`.
- **Added:** Atomic, glitch-free `get_hardware_timestamp_us()` function providing an unbroken 32-bit microsecond timebase with pending overflow flag compensation.
- **Eliminated:** All dead or unreferenced timer fallback initialization.

#### 3. Formally Verified Lock-Free SPSC Burst Queue Integrated into Production Engine
- **Eliminated:** Unused/parallel scalar accumulator `queuedBurstSteps` completely removed from production firmware and tests.
- **Integrated:** Single authoritative production queue `BurstQueue` (16-entry ring buffer, power-of-2 wrap-safe masking) directly into `STM32_Zipper_CNC_V16_5_1_Firmware.ino`.
- **Formal Invariant:** `submitted == consumed + queued + aborted + dropped` strictly maintained across all operational states.
- **Explicit Overflow Protection:** Deterministic queue-full reject policy logs `overflowCount++` and `droppedPulses += steps`, preventing silent memory overwrites.
- **Emergency Stop Safety:** `abortAll()` safely flushes queued bursts on E-Stop and records aborted counts with zero drift.

#### 4. Direction Change Timing & Setup/Hold Protection
- **Added:** Explicit 20 µs hold delay after active burst completion before changing DIR pin state.
- **Added:** Explicit 20 µs setup delay after changing DIR pin state before firing next step pulse.
- **Verified:** 400% safety margin over Leadshine DM542 5.0 µs hardware specification.

#### 5. Fractional DDA Accumulator Long-Run Convergence
- **Verified:** 1,000,000 cycle formal convergence tests across test ratios: 1/2, 1/3, 2/3, 1/7, 3/7, 7/13, 13/29, and Sizes #5, #8, #10.
- **Verified:** Instantaneous phase error bounded strictly <= 1.0 pulse at all times, with total drift < 1.0 pulse over 1,000,000 teeth.

#### 6. Independent Safety Sensor Qualification (PA3 & PB0)
- **Eliminated:** Shared 15 ms qualification counter across PA3 (Tape Run-Out) and PB0 (Coil Jam).
- **Added:** Completely independent consecutive qualification counters: `pa3FaultCounterMs` and `pb0FaultCounterMs` in `src/safety_sensors.h` and `STM32_Zipper_CNC_V16_5_1_Firmware.ino`.
- **Enforced:** Strictly 15 consecutive samples @ 1 kHz (15.0 ms anti-vibration window) required per individual sensor.
- **Zero Cross-Accumulation:** PA3 active time cannot accumulate with PB0 active time (e.g. PA3 8ms + PB0 7ms will NEVER qualify or trip).
- **Saturating Counter:** Counters saturate safely at 15 without overflow.
- **Immediate Reset on Inactive:** If an active sensor returns to normal state, its counter immediately resets to 0.
- **Sensor Guard Bypass Handling:** When Sensor Guard is OFF, both counters are held at 0, no faults are generated, and no stale state survives bypass. When turned ON, qualification starts strictly from 0.
- **Standstill Recovery:** Relay is released ONLY when the machine is at complete standstill (0 RPM) AND both physical sensors are clear (`!tapeBroken && !coilBroken`).
- **Automated Test Suite:** `test_safety_sensors.cpp` verifying Test A through Test N (including 100,000 samples randomized burst stress test) with 100% green pass.

#### 7. Production-Safe PulseStep Persistence & Flash Wear Protection
- **Added:** Immediate RAM tuning with zero Flash wear during UP/DOWN adjustments.
- **Added:** Dynamic dirty tracking (`pulseModifiedByUser`). Adjusting and reverting to stored value immediately clears the dirty flag with 0 writes.
- **Added:** Strict Write Suppression: identical data write attempts skipped completely.
- **Added:** Authoritative safe-save gating (`isMachineSafelyIdle`): Flash programming strictly prohibited during motion, acceleration, decel, bursts, or queued stepping.
- **Added:** Dual-slot transactional storage with CRC-32 checksum and monotonic sequence counter for power-loss recovery.
- **Added:** Diagnostic `flashWriteCount` tracking real persistence operations.
- **Updated:** Menu Option 10 renamed to "10. Exit Menu" with safe manual save gating.
- **Automated Test Suite:** `test_pulsestep_persistence.cpp` verifying 9 test groups (basic, dirty tracking, wear protection, motion safety, user sequences, power loss, 10,000 randomized stress cycles, and continuous 60s qualification state machine).

#### 8. Section 6 Critical EEPROM Deferred-Trigger Race Fix (Two-Phase Atomic Handoff)
- **Eliminated Ordering Window:** Fixed window where a new physical trigger could arrive between unlock and deferred trigger dispatch.
- **Added:** `SAVE_LOCK_DISPATCHING` state to `FlashSaveTransactionEngine`. While in dispatching state, `isSaveLockActive()` remains strictly `true`.
- **Added:** `captureDeferredForDispatch(outDir, outTs)` atomically capturing deferred triggers and transitioning to `SAVE_LOCK_DISPATCHING`.
- **Added:** `completeHandoff()` called only after all deferred pulses have been safely handed off/dispatched to hardware timer or motion queue.
- **Added:** `dispatchDeferredSaveTriggers()` drain loop processing triggers arriving during handoff in exact FIFO order.
- **Guaranteed:** New triggers arriving during Flash save or deferred dispatch cannot overtake older deferred triggers.
- **Zero Loss / Zero Duplication:** 100% pulse conservation verified across save success, save abort, and Flash write failure (`saveOk == false`).

#### 9. Test Suite Integrity & Expansion (21 Targets, 100% Green)
- **Resolved Test Suite Inconsistency:** Reconciled documentation claims and runner configuration to 21 authoritative test suites.
- **Restored & Hardened Missing Test Files:**
  - `test_source_consistency.cpp`: Validates byte-for-byte synchronization of `.ino` and all headers across `src/`, `include/`, and `STM32_Zipper_CNC_V16_5_1_Firmware/`.
  - `test_safety_priority.cpp`: Validates 8 safety priority combinations (sensor fault, E-stop, active stepping, auto-save qualification, persistence request, simultaneous trigger + safety).
  - `test_race_condition_matrix.cpp`: Validates 5 groups of race condition matrices including trigger vs save, sensor vs save, capture vs save, deferred trigger failure paths, and two-phase atomic handoff anti-overtaking invariants.
  - `test_mode_button_behavior.cpp`: Validates full MODE button timing/state machine (Single press = Gear change, 1.5-3s hold = Size change, double click = Lock toggle, running lockout).
- **Cleaned Obsolete Files:** Removed unreferenced legacy files `test_fractional_accumulator.cpp` and `test_randomized_stress.cpp`.
- **Verified:** All 21 test targets compile with `-O3 -Wall -Wextra -Werror` and pass 100% green from `./tests/run_tests.sh`.

#### 10. Operator Controls & Ergonomics (V16.5.1 Verified Standard)
- **Swapped [MODE] Button Actions**:
  - **Single Press (< 350 ms)**: Cycles Pulse Tuning Gear (0.10 -> 1.00 -> 10.0 -> 100 Pulses) for fast access during machine calibration.
  - **1.5–3.0 Second Hold**: Cycles Zipper Size Sequence (#5 -> #8 -> #10) with automatic 0 RPM standstill EEPROM commit.
  - **Double-Click (< 350 ms)**: Toggles Keypad Lock / Unlock (`*[L]` / `*[U]`).
  - **8-Second Hold**: Enters Hidden Settings Menu (0 RPM Standstill only).
  - **Running Lockout**: Blocked when machine is running (`currentRPM > 0`).
- **Direction Hardening**:
  - Direction locked during normal RUN; runtime direction switching completely disabled in ISR/motion loops.
  - Direction change permitted strictly at 0 RPM standstill in Hidden Settings Menu Option 8 (`Motor Dir`) with >= 20 µs setup/hold delay.
