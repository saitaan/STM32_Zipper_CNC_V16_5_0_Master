#!/bin/bash
set -e

echo "=== STM32 Zipper CNC V16.5.1 Production Firmware Build ==="
SKETCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/STM32_Zipper_CNC_V16_5_1_Firmware"
BUILD_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/build"

echo "Sketch Directory: $SKETCH_DIR"
echo "Build Directory : $BUILD_DIR"

# 1. Clean previous build artifacts
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

# 2. Check for arduino-cli
if ! command -v arduino-cli &> /dev/null; then
    echo "ERROR: arduino-cli is required to compile for STM32F103C8T6."
    echo "Install instructions: https://arduino.github.io/arduino-cli/latest/installation/"
    exit 1
fi

# 3. Compile sketch
echo "Compiling firmware for STMicroelectronics:stm32:GenF1:pnum=BLUEPILL_F103C8..."
arduino-cli compile --fqbn STMicroelectronics:stm32:GenF1:pnum=BLUEPILL_F103C8 \
    --output-dir "$BUILD_DIR" \
    --export-binaries \
    --warnings all \
    "$SKETCH_DIR"

# 4. Deterministic binary extraction & rename
TARGET_BIN=$(find "$BUILD_DIR" -maxdepth 1 -name "*.ino.bin" | head -n 1)
if [ -z "$TARGET_BIN" ] || [ ! -f "$TARGET_BIN" ]; then
    echo "FATAL: Compilation did not produce an .ino.bin artifact!"
    exit 1
fi

mv -f "$TARGET_BIN" "$BUILD_DIR/STM32_Zipper_CNC_V16_5_1_Production.bin"
rm -f "$BUILD_DIR"/*.ino.elf "$BUILD_DIR"/*.ino.map "$BUILD_DIR"/*.ino.hex 2>/dev/null || true

# 5. Generate SHA-256 Checksum
cd "$BUILD_DIR"
sha256sum STM32_Zipper_CNC_V16_5_1_Production.bin > STM32_Zipper_CNC_V16_5_1_Production.bin.sha256

echo "=========================================================="
echo "BUILD SUCCESSFUL!"
ls -lh STM32_Zipper_CNC_V16_5_1_Production.bin
echo "SHA-256:"
cat STM32_Zipper_CNC_V16_5_1_Production.bin.sha256
echo "=========================================================="
