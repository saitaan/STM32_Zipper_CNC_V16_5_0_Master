@echo off
echo === STM32 Zipper CNC V16.5.1 Production Firmware Build ===
set SCRIPT_DIR=%~dp0
set SKETCH_DIR=%SCRIPT_DIR%..\STM32_Zipper_CNC_V16_5_1_Firmware
set BUILD_DIR=%SCRIPT_DIR%..\build

if exist "%BUILD_DIR%" rd /s /q "%BUILD_DIR%"
mkdir "%BUILD_DIR%"

where arduino-cli >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: arduino-cli not found in PATH!
    pause
    exit /b 1
)

echo Compiling firmware for BluePill F103C8...
arduino-cli compile --fqbn STMicroelectronics:stm32:GenF1:pnum=BLUEPILL_F103C8 --output-dir "%BUILD_DIR%" --export-binaries "%SKETCH_DIR%"

if exist "%BUILD_DIR%\STM32_Zipper_CNC_V16_5_1_Firmware.ino.bin" (
    move /y "%BUILD_DIR%\STM32_Zipper_CNC_V16_5_1_Firmware.ino.bin" "%BUILD_DIR%\STM32_Zipper_CNC_V16_5_1_Production.bin"
    echo Production binary generated successfully at build\STM32_Zipper_CNC_V16_5_1_Production.bin
) else (
    echo Compilation failed or target binary not found!
    pause
    exit /b 1
)
pause
