#ifndef SAFETY_SENSORS_H
#define SAFETY_SENSORS_H

#include <stdint.h>
#include <stdbool.h>

// =========================================================================
// HARDWARE SAFETY SENSOR SPECIFICATION & QUALIFICATION ENGINE
// Target Pins:
//   - PA3: Tape Run-Out Optical Sensor (PC817 Ch 1, Active-HIGH fault)
//   - PB0: Coil Jam / Breakage Fiber Sensor (PC817 Ch 2, Active-HIGH fault)
// Qualification Standard:
//   - Strictly 15 consecutive samples @ 1 kHz (15.0 ms anti-vibration window)
//   - Completely independent counters: pa3FaultCounterMs and pb0FaultCounterMs
//   - Zero cross-accumulation between sensors
//   - Saturating bounded counter behavior (max 15)
// =========================================================================

#define SENSOR_QUALIFICATION_MS 15U

// Core qualification update function executed at 1 kHz (every 1.0 ms)
// Used in production firmware safetyTimerCallback() and verified by test harness.
inline void updateSafetySensorCounters(bool guardActive,
                                       bool tapeBroken,
                                       bool coilBroken,
                                       volatile uint8_t &pa3Counter,
                                       volatile uint8_t &pb0Counter,
                                       bool &pa3Qualified,
                                       bool &pb0Qualified) {
    if (!guardActive) {
        pa3Counter = 0;
        pb0Counter = 0;
        pa3Qualified = false;
        pb0Qualified = false;
        return;
    }

    // 1. Independent PA3 Qualification (Tape Run-Out)
    // Increments only on continuous active fault state; resets immediately to 0 when inactive
    if (tapeBroken) {
        if (pa3Counter < SENSOR_QUALIFICATION_MS) {
            pa3Counter++;
        }
    } else {
        pa3Counter = 0;
    }

    // 2. Independent PB0 Qualification (Coil Jam)
    // Increments only on continuous active fault state; resets immediately to 0 when inactive
    if (coilBroken) {
        if (pb0Counter < SENSOR_QUALIFICATION_MS) {
            pb0Counter++;
        }
    } else {
        pb0Counter = 0;
    }

    // 3. Independent Qualification Flags
    pa3Qualified = (pa3Counter >= SENSOR_QUALIFICATION_MS);
    pb0Qualified = (pb0Counter >= SENSOR_QUALIFICATION_MS);
}

#endif // SAFETY_SENSORS_H
