#ifndef HARDWARE_CAPTURE_SPEC_H
#define HARDWARE_CAPTURE_SPEC_H

#include <stdint.h>
#include <stdbool.h>
#include <cstring>

// =========================================================================
// STM32F103C8T6 HARDWARE CAPTURE & TIMING SPECIFICATION
// =========================================================================
// 1. PIN & CHANNEL PHYSICAL MAPPING:
//    - PA0: Cam Proximity Sensor Input (PC817 Optocoupler).
//           Silicon Peripheral: TIM2_CH1_ETR / EXTI0.
//    - PA1: Stepper Driver PUL- Output (Level Shifter CH3).
//           Silicon Peripheral: TIM2_CH2 (Hardware PWM Mode 2).
//    - PA2: Stepper Driver DIR- Output (Level Shifter CH4).
//           Silicon Peripheral: GPIOA Pin 2 (Push-Pull Output).
//
// 2. HARDWARE CAPTURE MECHANISM (TIM2_CH1):
//    - TIM2 Channel 1 is configured in Input Capture mode (CC1S = 01b).
//    - Falling edge sensitivity (CC1P = 1, CC1E = 1).
//    - On physical falling edge, hardware timer peripheral automatically latches
//      TIM2->CNT into TIM2->CCR1 register without waiting for CPU interrupt execution.
//    - Latency Distinction:
//      1) Hardware timer capture: Autonomous silicon register latch.
//      2) ISR entry latency: Architectural theoretical ~12 to 18 cycles @ 72MHz.
//      3) Software processing latency: DWT/snapshot execution.
//      4) Physical measured latency: Physical trigger latency not independently measured.
//    - Overcapture Detection: TIM2->SR bit CC1OF automatically set by silicon
//      if a second trigger edge arrives before the previous capture was read.
//
// 3. SILICON ARCHITECTURE CONSTRAINT & TIM4 CONTINUOUS TIMEBASE:
//    - In STM32F103, Timer 2 channels share the same Prescaler (PSC) and
//      Auto-Reload Register (ARR).
//    - Because Channel 2 (PA1) is dedicated to autonomous stepper pulse
//      generation, TIM2's ARR defines the active step period (70us to 112us),
//      and TIM2 counter halts between feed bursts.
//    - Therefore, TIM2->CCR1 captures the intra-step arrival phase.
//    - For continuous macro-timing between machine revolutions (15ms to 600ms,
//      100 to 4,000 RPM), an independent 1.0 MHz 16-bit hardware timer (TIM4)
//      runs 24x7 with a 16-bit overflow counter to provide a continuous,
//      unbroken 32-bit microsecond timebase.
//
// 4. TIMING METRICS:
//    - Core Clock: 72 MHz Silicon Crystal.
//    - TIM4 Clock: 72 MHz / (71 + 1) = 1.0 MHz (1.0 us tick resolution).
//    - Maximum Input Trigger Frequency: 666 Hz (40,000 RPM theoretical, 4,000 RPM rated).
//    - Minimum Legitimate Trigger Spacing: 1,500 us (Speed-Adaptive Blanking Floor).
//    - Maximum Legitimate Trigger Spacing: 600,000 us (100 RPM minimum operating speed).
//    - Standstill Threshold: > 2,000,000 us (2.0s without trigger = 0 RPM).
// =========================================================================

// Truthful Overcapture Semantics (Prompt 8Writing Section 4):
// Hardware Overcapture (CC1OF) indicates that at least one falling edge occurred
// before the CPU read the capture register. Because the hardware status flag is a single bit
// that latches and does not count subsequent edges while set, overcaptureEventCount
// represents the number of detected overcapture events, providing a guaranteed
// lower-bound (>= 1) on lost physical edges rather than an exact unbounded count.
struct HardwareCaptureDiagnostics {
    uint32_t totalTriggersDetected;
    uint32_t hardwareCapturesRead;
    uint32_t captureOverruns;              // TIM_SR_CC1OF flag detections
    uint32_t noiseSpikesFiltered;          // Interval < 1500us
    uint32_t timeoutsDetected;             // Motion sync watchdog trips
    uint32_t lastLatchedCCR;               // Last TIM2->CCR1 latched value
    uint32_t lastTimestampUs;              // Last 32-bit continuous timestamp
    uint32_t lastIntervalUs;               // Last measured revolution period

    // Overcapture State & Invariant Tracking
    bool     isCaptureStreamDiscontinuous; // Flagged true when CC1OF detected
    uint32_t overcaptureTimestampUs;       // Timestamp of overcapture event
    uint32_t overcaptureEventCount;        // Exact count of CC1OF events detected
    uint32_t lowerBoundLostEdges;
    uint32_t knownLostPulses;          // Guaranteed lower-bound on lost physical edges (>= 1 per event)
    uint32_t acceptedPulses;               // Count of accepted pulses
    uint32_t resyncEvents;                 // Count of clean resynchronizations
};

class HardwareCaptureStreamEngine {
public:
    HardwareCaptureDiagnostics diag;

    HardwareCaptureStreamEngine() {
        memset(&diag, 0, sizeof(diag));
    }

    void handleHardwareEdge(bool cc1of, uint16_t ccr1, uint32_t timestampUs, uint32_t blankingFloorUs = 1500UL) {
        diag.totalTriggersDetected++;

        if (cc1of) {
            diag.captureOverruns++;
            diag.overcaptureEventCount++;
            diag.lowerBoundLostEdges++;
            diag.knownLostPulses++;
            diag.isCaptureStreamDiscontinuous = true;
            diag.overcaptureTimestampUs = timestampUs;
        }

        diag.hardwareCapturesRead++;
        diag.lastLatchedCCR = ccr1;

        if (diag.lastTimestampUs > 0) {
            uint32_t interval = timestampUs - diag.lastTimestampUs;
            if (interval < blankingFloorUs) {
                diag.noiseSpikesFiltered++;
                return;
            }
            diag.lastIntervalUs = interval;
        }

        // Clean edge accepted
        diag.acceptedPulses++;
        diag.lastTimestampUs = timestampUs;

        // If stream was discontinuous, resynchronize on the next clean accepted edge
        if (!cc1of && diag.isCaptureStreamDiscontinuous) {
            diag.isCaptureStreamDiscontinuous = false;
            diag.resyncEvents++;
        }
    }

    // Invariant: total physical edges must equal accepted + lowerBoundLostEdges + filtered
    bool verifyConservationInvariant(uint32_t physicalEdges) const {
        return (physicalEdges == (diag.acceptedPulses + diag.lowerBoundLostEdges + diag.noiseSpikesFiltered));
    }
};

#endif // HARDWARE_CAPTURE_SPEC_H
