# Technical Specification: Hardware Timing & Determinism

**Target MCU:** STM32F103C8T6 (ARM Cortex-M3 @ 72MHz)  
**Peripheral Mapping:**
- Timer 2 (TIM2): Step Pulse Burst Engine on PA1 (TIM2_CH2 PWM Mode 2, 1MHz timebase, 5.0µs pulse width).
- Timer 3 (TIM3): 1 kHz Hardware Safety Interlock (15ms anti-vibration qualification window).
- Timer 4 (TIM4): 1.0 MHz Continuous Free-Running Counter (PSC=71, ARR=0xFFFF).
- EXTI0: Preemptive Hardware Edge Latch on PA0 (LJ12A3 Cam Inductive Sensor via PC817).
- DWT CYCCNT: 72 MHz Core Cycle Counter (13.888 nanosecond tick resolution).

---

## 1. Trigger Edge Latch & Latency Analysis
The trigger capture architecture clearly distinguishes four timing domains:
1. **Hardware Timer Capture Timestamp:** TIM2 Channel 1 (`PA0`, `CC1S=01b`) autonomously latches `TIM2->CNT` directly into the `TIM2->CCR1` register on the active falling edge in silicon without software intervention.
2. **ISR Entry Timestamp:** ARM Cortex-M3 NVIC architectural interrupt response (theoretical ~12 to 18 cycles @ 72MHz for unmasked EXTI0).
3. **Software Processing Latency:** DWT cycle counter reads and atomic parameter snapshotting in ISR.
4. **Physical Electrical Latency:** Physical trigger latency not independently measured (requires external high-bandwidth oscilloscope probe on PC817 optocoupler emitter vs MCU PA0 pin).
Software jitter from `micros()` is completely bypassed by using the dedicated 1 MHz TIM4 hardware timebase and DWT cycle tracking.

---

## 2. Speed-Adaptive Blanking Window
The trigger blanking window protects against optocoupler ringing and inductive contactor chatter:
$$\text{Blanking Floor} = 1,500\,\mu\text{s} \quad (\text{rejects up to } 30,000\text{ RPM noise})$$
$$\text{Dynamic Blanking} = \min(4,500\,\mu\text{s}, \max(1,500\,\mu\text{s}, \Delta t_{\text{last}} / 3))$$
At machine limit of 4,000 RPM (15,000µs revolution period):
$$\text{Blanking} = 4,500\,\mu\text{s} \quad (30\% \text{ of period})$$
$$\text{Open Trigger Window} = 10,500\,\mu\text{s} \quad (70\% \text{ of period})$$
No valid trigger can ever be dropped due to blanking distortion.
