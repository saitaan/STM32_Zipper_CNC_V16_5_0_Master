#include <cmath>
/*
====================================================================================================
PROJECT  : STM32 ZIPPER CNC (ADAPTIVE SERVO-SYNC MASTER-FOLLOWER ENGINE)
VERSION  : 16.5.3 (HARDWARE TIMER ENGINE, REVERSIBLE MOTOR DIR & DUAL OPTICAL MASTER)
AUTHOR   : RAJESH SHAH / INDUSTRIAL AUTOMATION & EMBEDDED SYSTEMS
DATE     : SEPTEMBER 2026
TARGET   : STM32F103C8T6 (32-BIT ARM CORTEX-M3 @ 72MHz)
LOCATION : NIPON ZIPPER INDUSTRIES PVT LTD, SARIGAM GIDC, GUJARAT, INDIA

VERSION 16.5.0 ARCHITECTURAL ADVANCEMENTS & HARDWARE-LEVEL ENGINE:
1. ZERO-CPU HARDWARE TIMER 2 AUTONOMOUS BURST ENGINE:
   - Configures STM32 Hardware Timer 2 (TIM2) directly on PA1 (TIM2_CH2) for hardware-driven
     pulse generation. Pulse edges are clocked directly by 72MHz silicon crystal with hardware timer deterministic timing.
   - Stepper step generation runs 100% in silicon hardware, dropping CPU stepping overhead to 0%!
   - Supports seamless dual-mode execution:
     * Mode 0: Hardware Autonomous Timer Mode (72MHz Direct Peripheral Drive).
     * Mode 1: 1,000,000x Micro-Fractional DDA Phase-Locked Fallback Engine.
2. DUAL OPTICAL SAFETY GUARD SUBSYSTEM:
   - PA3: Tape Run-Out & Breakage Optical Sensor (PC817 Ch 1).
   - PB0: Coil Jam & Breakage Fiber-Optic Sensor (PC817 Ch 2).
   - PB1: Main Motor Stop Relay (5V Opto-Isolated Relay on NC Clutch-Brake Loop).
   - STRICT DEFAULT RULE: BYPASS [OFF] (Optional feature - remains inert until enabled in Menu).
   - Deterministic 15ms Qualified E-Stop: 1 kHz TIM3 hardware monitor validates fault over 15ms anti-vibration window, then immediately cuts TIM2 clock in silicon and trips PB1 relay.
3. BOOTUP HARDWARE RELAY GLITCH SUPPRESSION:
   - Atomic GPIOB->BRR clear on PB1 before setting pinMode to eliminate contact chatter on reset.
4. BACKWARDS-COMPATIBLE THREE-TIER EEPROM MIGRATION:
   - Automatically migrates existing V16.3.3 (0x5A431633) and V16.4.0 (0x5A431640) calibration parameters
     into V16.5.0 (0x5A431650) without resetting roller diameter or driver resolution.
5. 64-BIT DOUBLE PRECISION 1,000,000x DDA MATH:
   - Guaranteed < 0.025 mm error over 1.6 km of fed zipper tape.
====================================================================================================
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>
#include "burst_queue.h"
#include "motion_scheduler.h"
#include "hardware_capture_spec.h"
#include "safety_sensors.h"
#include "pulsestep_persistence.h"
#ifndef nvic_irq_enable
#define nvic_irq_enable(irq) NVIC_EnableIRQ(irq)
#endif

LiquidCrystal_I2C lcd(0x27, 16, 2);

// =========================================================================
// BUILD IDENTIFIERS & SOURCE-TO-BINARY METADATA
// =========================================================================
#define FW_VERSION_STR       "V16.5.4-ADAPTIVE-SERVO-SYNC"
#define FW_BUILD_DATE_STR    "OCT-2026"
#define FW_BUILD_METADATA    "NIPON_ZIPPER_CNC_FW_V16_5_4_ADAPTIVE_SERVO_SYNC:OCT-2026:TIM2_DMA_PHASE"

// Embedded ROM identifier string for binary provenance verification
const char g_firmware_build_tag[] __attribute__((used)) = FW_BUILD_METADATA;

// Hardware Pin Definitions (100% Backwards-Compatible Pinout)
const int statusLedPin      = PC13; // Built-in Onboard LED (Active-LOW: LOW=ON, HIGH=OFF)
#define STATUS_LED_ON()    (GPIOC->BRR = (1 << 13))   // Atomic Clear PC13 -> LED ON
#define STATUS_LED_OFF()   (GPIOC->BSRR = (1 << 13))  // Atomic Set PC13   -> LED OFF
const int proxSensorPin     = PA0;  // Cam Proximity (PC817 Opto, Clean MCU GND, Falling ISR)
const int stepPin           = PA1;  // Driver PUL- (Hardware TIM2_CH2 / Direct Register BSRR)
const int dirPin            = PA2;  // Driver DIR- via Level Shifter CH4 LV (GPIOA Pin 2)
// =========================================================================
// SENSOR POLARITY & FAIL-SAFE LOGIC DEFINITIONS
// Industrial optical sensors via PC817 optocoupler with STM32 INPUT_PULLUP:
// - NORMAL STATE (Tape/Coil Present): Sensor actively conducts, pulling pin LOW (0V).
// - FAULT STATE (Tape Run-Out / Break / Cable Cut): Optocoupler OFF, pin pulled HIGH (3.3V).
// Fail-safe: Wire break, disconnected sensor, or power loss safely trips E-Stop.
// =========================================================================
#define SENSOR_STATE_NORMAL     LOW   // Sunk to GND (0V) by conducting PC817 phototransistor
#define SENSOR_STATE_FAULT      HIGH  // Pulled to 3.3V by internal pull-up (Fail-Safe Open)

const int tapeSensorPin     = PA3;  // Tape Run-Out Optical Sensor (PC817 Ch 1: Normal=LOW, Fault/Broken=HIGH)
const int coilSensorPin     = PB0;  // Coil Breakage Fiber Sensor (PC817 Ch 2: Normal=LOW, Fault/Broken=HIGH)
const int mainMotorRelayPin = PB1;  // Main Motor Stop Relay (Active-HIGH Trip / NC Clutch Loop)
const int btnUp             = PB13; // UP Button (Swapped to match physical panel wiring)
const int btnDown           = PB12; // DOWN Button (Swapped to match physical panel wiring)
const int btnMode           = PB14; // MODE Multi-Function Button (Active-LOW to Clean MCU GND)

// Direct Register Bit Set/Reset (1-Cycle 13.8ns Sinking)
#define STEP_LOW_ACTIVE()  (GPIOA->BSRR = (1 << (1 + 16)))
#define STEP_HIGH_IDLE()   (GPIOA->BSRR = (1 << 1))
#define DIR_LOW()          (GPIOA->BSRR = (1 << (2 + 16)))
#define DIR_HIGH()         (GPIOA->BSRR = (1 << 2))

// 1,000,000x Micro-Fractional DDA Fixed-Point Scaling Factor (6 Decimal Places)
#define FIXED_SCALE 1000000ULL

// IWDG: Independent Watchdog Timer (40kHz LSI / 256 Prescaler -> 6.4ms/count, RLR=500 -> ~3.2s Timeout)
#define IWDG_INIT() do {     IWDG->KR = 0x5555;     IWDG->PR = 0x06;       IWDG->RLR = 500;       IWDG->KR = 0xAAAA;     IWDG->KR = 0xCCCC; } while (0)
#define IWDG_FEED() (IWDG->KR = 0xAAAA)

#define EEPROM_MAGIC_V16_3_3 0x5A431633UL
#define EEPROM_MAGIC_V16_4_0 0x5A431640UL
#define EEPROM_MAGIC         0x5A431650UL

// Persistent EEPROM Storage Configuration Structure
#define EEPROM_MAGIC_V16_5_1 0x5A431651UL

// Legacy V16.5.0 Struct (52 bytes) - preserved for automatic field migration
struct MachineConfigLegacy {
    uint32_t p5_fixed;
    uint32_t p8_fixed;
    uint32_t p10_fixed;
    int32_t  driverResolution;
    float    rollerDia;
    int32_t  maxRPMSetting;
    int32_t  feedAngleDeg;
    int32_t  safetyMarginPercent;
    int32_t  currentSize;
    uint32_t sensorGuardActive; // 0: BYPASS [OFF] (DEFAULT), 1: ACTIVE [ON]
    uint32_t hardwareTimerMode; // 0: AUTONOMOUS HW TIMER (DEFAULT), 1: CLASSIC DDA ENGINE
    uint32_t motorDirection;   // 0: NORMAL [FWD] (DEFAULT), 1: REVERSE [REV]
    uint32_t magic;
};

// =========================================================================
// PERSISTENT EEPROM CONFIGURATION STRUCTURE
// Authoritative structure size is dynamically enforced by sizeof(MachineConfig).
// Structure layout features 64-bit safe fixed-point pulse counts (p5, p8, p10)
// and 32-bit hardware parameters. magic header is placed at Offset 0 (0x5A431651UL)
// to uniquely differentiate from legacy V16.5.0/V16.4.0/V16.3.3 memory images.
// =========================================================================
struct MachineConfig {
    uint32_t magic;             // Offset 0: 0x5A431651UL (Magic header)
    uint32_t reserved;          // 64-bit alignment padding
    uint64_t p5_fixed;          // 64-bit safe fixed point (avoids uint32 overflow at 51200 res)
    uint64_t p8_fixed;          // 64-bit safe fixed point
    uint64_t p10_fixed;         // 64-bit safe fixed point
    int32_t  driverResolution;
    float    rollerDia;
    int32_t  maxRPMSetting;
    int32_t  feedAngleDeg;
    int32_t  safetyMarginPercent;
    int32_t  currentSize;
    uint32_t sensorGuardActive; // 0: BYPASS [OFF] (DEFAULT), 1: ACTIVE [ON]
    uint32_t hardwareTimerMode; // 0: AUTONOMOUS HW TIMER (DEFAULT), 1: CLASSIC DDA ENGINE
    uint32_t motorDirection;   // 0: NORMAL [FWD] (DEFAULT), 1: REVERSE [REV]
};

// 6-Decimal Exact Mathematical Pitch Pulses (6400 Resolution / 45.0mm Roller Diameter)
uint64_t p5_fixed  = 113176848ULL; // Size #5 (2.50mm): 113.176848 steps
uint64_t p8_fixed  = 135812218ULL; // Size #8 (3.00mm): 135.812218 steps
uint64_t p10_fixed = 181082957ULL; // Size #10 (4.00mm): 181.082957 steps

int32_t driverResolution    = 6400;
float   rollerDia           = 45.0f;
int32_t maxRPMSetting       = 3000;
int32_t feedAngleDeg        = 160;
int32_t safetyMarginPercent = 10;
bool    sensorGuardActive   = false; // DEFAULT IS STRICTLY BYPASS [OFF]
// Optional Tape Guard only. OFF = PA3 is ignored; it cannot alter proximity capture or STEP generation.
volatile bool hardwareTimerMode   = true;  // DEFAULT: TRUE (AUTONOMOUS HARDWARE TIMER ENGINE)

bool    motorDirection      = false; // DEFAULT: FALSE (NORMAL / FORWARD ROTATION)
bool    tempMotorDir        = false; // Staged Menu Direction

extern volatile bool hwBurstActive;
extern volatile int stepsRemaining;
void stopHardwareTimerImmediately();

// Hardware-level Motor Direction Controller (PA2 DIR-)
void applyMotorDirection() {
    // Safety: ensure any active movement is completely stopped before changing DIR pin
    if (hwBurstActive || stepsRemaining > 0) {
        stopHardwareTimerImmediately();
    }
    delayMicroseconds(20); // Safe hold time after last step pulse before DIR edge
    if (motorDirection) {
        DIR_LOW();  // Active-LOW sinking for Reverse rotation
    } else {
        DIR_HIGH(); // Idle-HIGH for Normal Forward rotation
    }
    delayMicroseconds(20); // Safe setup time (exceeds 5us DM542 specification by 400%)
}


int autoPulseWidth_P5   = 25;
int autoPulseWidth_P8   = 29;
int autoPulseWidth_P10  = 22;
volatile int activePulseWidth = 70; // Nominal 70us step period (~14.2 kHz) for 3000 RPM / 160 deg
unsigned long dynamicDebounceUs = 3000UL; // 3.0ms: Rejects EMI, supports 12 to 20,000 RPM

int32_t resStepGear    = 100;
float   diaStepGear    = 0.1f;
int32_t rpmStepGear    = 100;
int32_t angleStepGear  = 5;
int32_t marginStepGear = 1;

int32_t currentSize = 1; // 1: #5 (2.50mm), 2: #8 (3.00mm), 3: #10 (4.00mm)
// =========================================================================
// ATOMIC COHERENT PULSE PARAMETER SNAPSHOT & TELEMETRY
// =========================================================================
#ifndef DEBUG_TEST_MODE
#define DEBUG_TEST_MODE 0
#endif

struct PulseParameters {
    uint32_t integerPart;
    uint32_t fractionalPart;
    uint32_t generation;

    PulseParameters() : integerPart(113), fractionalPart(176848UL), generation(1) {}
    PulseParameters(uint32_t i, uint32_t f, uint32_t g) : integerPart(i), fractionalPart(f), generation(g) {}
    PulseParameters(const PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters(const volatile PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters& operator=(const PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    PulseParameters& operator=(const volatile PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    void operator=(const PulseParameters& o) volatile {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
    }
};

BurstQueue burstQueue;
volatile uint32_t captureOverrunCount = 0;
volatile uint32_t tim4_overflow_count = 0;

volatile PulseParameters activePulseParams   = {113, 176848UL, 1};
PulseParameters          pendingPulseParams  = {113, 176848UL, 1};
volatile uint32_t        paramGenerationUsed = 1;

#if DEBUG_TEST_MODE
volatile uint32_t acceptedTriggerCount   = 0;
volatile uint32_t rejectedTriggerCount   = 0;
volatile uint32_t triggerMissedCount     = 0;
volatile uint32_t requestedPulseCount    = 0;
volatile uint32_t startedPulseCount      = 0;
volatile uint32_t completedPulseCount    = 0;
volatile uint32_t abortedPulseCount      = 0;
volatile uint32_t queuedPulseCount       = 0;
volatile uint32_t burstStartedCount      = 0;
volatile uint32_t burstCompletedCount    = 0;
volatile uint32_t burstQueuedCount       = 0;
volatile uint32_t paramGenChangesCount   = 0;
volatile uint32_t maxISRLatencyCycles    = 0;
volatile uint32_t maxTriggerJitterUs     = 0;
volatile uint32_t assertionFailureCount  = 0;
#endif

void commitPulseParameters(uint32_t intPart, uint32_t fracPart) {
    pendingPulseParams.integerPart    = intPart;
    pendingPulseParams.fractionalPart = fracPart;
    pendingPulseParams.generation++;
#if DEBUG_TEST_MODE
    paramGenChangesCount++;
#endif
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    activePulseParams.integerPart = pendingPulseParams.integerPart;
    activePulseParams.fractionalPart = pendingPulseParams.fractionalPart;
    activePulseParams.generation = pendingPulseParams.generation;
    __set_PRIMASK(primask);
}

volatile uint64_t currentPulsesFixed = 113176848ULL;
volatile uint32_t currentPulsesInt   = 113;      // Whole step portion for fast 32-bit ISR math
volatile uint32_t currentPulsesFrac  = 176848UL; // Fractional micro-step portion (< 1,000,000)
volatile uint32_t pulseFracAccumulator = 0UL;     // 32-bit fractional accumulator (zero 64-bit division)
volatile uint64_t pulseAccumulatorFixed = 0ULL;
volatile uint32_t lastTriggerCycles    = 0;
volatile bool pendingMenuExit = false;
uint64_t stepGearFixed = 1000000ULL; // 1.00 pulse tuning step (1,000,000 units)

bool isUiLocked = true;
unsigned long lastUnlockActivity = 0UL;
unsigned long confirmDialogStartTime = 0UL;

// =========================================================================
// 1-MINUTE CONTINUOUS SMOOTH RUN AUTO-SAVE STATE MACHINE
// Gated strictly to 0 RPM Standstill (Zero Pulse & Trigger Interference)
// Anti-Repeat Latch: Saved exactly once per parameter modification
// =========================================================================
bool pulseModifiedByUser            = false;  // Armed when user tunes pulse with UP/DOWN
unsigned long smoothRunStartMillis   = 0UL;    // Legacy fallback timer
bool autoSavePendingStandstill       = false;  // Set when 60s qualified in RAM; deferred to 0 RPM
AutoSaveQualificationEngine autoSaveEngine(60000UL); // Formal 60-Second Auto-Save Engine
FlashSaveTransactionEngine  flashSaveTx;             // Atomic Flash Save Transaction Engine (Prompt 8Writing)

// Hardware Overcapture State Tracking (Prompt 6Writing Section 3)
volatile bool     isCaptureStreamDiscontinuous   = false;
volatile uint32_t knownOvercaptureLostPulses     = 0;
volatile uint32_t lastOvercaptureTimestampUs     = 0;
volatile uint32_t captureResyncCount             = 0;
volatile uint32_t acceptedTriggerPulses          = 0;

// Authoritative PulseStep Persistence State Tracking
uint32_t flashWriteCount            = 0;      // Diagnostic counter: strictly increments on actual Flash write
uint32_t activeEEPROMSlot           = 0;      // Active transaction slot (0 or 1)
uint32_t eepromSeqNumber            = 0;      // Monotonic transaction sequence counter
uint64_t pulseStepStored_p5         = 113176848ULL; // Stored ROM baseline for Size #5
uint64_t pulseStepStored_p8         = 135812218ULL; // Stored ROM baseline for Size #8
uint64_t pulseStepStored_p10        = 181082957ULL; // Stored ROM baseline for Size #10


unsigned long uiMessageTimer = 0UL;
const char* uiBannerLine1 = nullptr;
const char* uiBannerLine2 = nullptr;

// Staged RAM Parameters for Zero Flash Wear
int32_t tempDriverRes       = 6400;
float   tempRollerDia       = 45.0f;
int32_t tempMaxRPM          = 3000;
int32_t tempFeedAngle       = 160;
int32_t tempSafetyMargin    = 10;
bool    tempSensorGuard     = false;
bool    tempHwTimerMode     = true;
bool    hasStagedChanges    = false;
bool    isTimingWarningActive = false;
int diagMinW = 0;
const char* diagFixLine1 = nullptr;
const char* diagFixLine2 = nullptr;
int infoIndex = 1;

// Optical Safety Guard State Machine
unsigned long sensorTripStartTime = 0UL;
volatile bool isSensorFaultTripped = false;
volatile bool isMotionSyncLost     = false; // Software Trigger Watchdog
volatile int  faultType            = 0;     // 0: None, 1: Tape Run-Out, 2: Coil Breakage, 3: Trigger Sync Lost
// queuedBurstSteps removed: SPSC BurstQueue burstQueue is the single authoritative production scheduling queue

// Stepper Step State Machine
volatile bool triggerPull = false;
volatile unsigned long lastTriggerMicros = 0UL;
volatile unsigned long lastMeasuredIntervalUs = 0UL;
volatile unsigned long rawIntervalMicros = 0UL;
volatile int stepsRemaining = 0;
volatile int totalStepsInBurst = 0;
volatile int currentStepIndex = 0;
volatile bool stepPinState = HIGH;
volatile unsigned long lastStepMicros = 0UL;

// Hardware Timer 2 Burst Controller State
volatile bool hwBurstActive = false;
volatile int  hwBurstStepsTarget = 0;
volatile int  hwBurstStepsDone = 0;

volatile unsigned long currentRPM = 0UL;
unsigned long lastDisplayUpdate = 0UL;
unsigned long lastRpmDisplayUpdate = 0UL;
unsigned long lastButtonCheck = 0UL;
unsigned long modePressTime = 0UL;
unsigned long lastModeClickTime = 0UL;
unsigned long upPressTime = 0UL;
unsigned long downPressTime = 0UL;
unsigned long dualPressTime = 0UL;

bool modePressed = false;
bool upDownPressed = false;
bool pendingSingleClick = false;

int menuState = 0;
int oldMenuState = -1;
int hiddenOption = 1;
bool resetChoice = false;

// Hardware Timer 2 Instance for Stepping Pulses
// =========================================================================
// AUTHORITATIVE CNC MOVEMENT STATE MACHINE
// IDLE -> ARMED -> RUNNING -> STOPPING -> COMPLETE -> IDLE
// Fault/Abort: RUNNING/STOPPING -> FAULT/ABORTED -> IDLE (Standstill Gated)
// =========================================================================
enum MovementState {
    STATE_IDLE = 0,
    STATE_ARMED,
    STATE_RUNNING,
    STATE_STOPPING,
    STATE_COMPLETE,
    STATE_ABORTED,
    STATE_FAULT
};
volatile MovementState movementState = STATE_IDLE;

inline bool isMachineSafelyIdle() {
    return (currentRPM == 0UL) &&
           (stepsRemaining == 0) &&
           (!hwBurstActive) &&
           (burstQueue.isEmpty()) &&
           (movementState == STATE_IDLE || movementState == STATE_COMPLETE) &&
           (!isSensorFaultTripped) &&
           (!isMotionSyncLost);
}

const uint16_t STEP_PULSE_WIDTH_US   = 5; // 5.0us Active LOW pulse for Leadshine DM542

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U

// TIM2_CH1 is mapped to DMA1 Channel 5 on STM32F103. DMA mirrors the
// hardware-captured CCR1 values into RAM without adding CPU latency.
#define SERVO_CAPTURE_DMA_SAMPLES 32U
volatile uint16_t servoCaptureDma[ SERVO_CAPTURE_DMA_SAMPLES ];
volatile uint32_t servoCaptureDmaWriteCount = 0;
volatile uint32_t servoPhaseRelockCount = 0;
volatile bool servoPhaseLocked = false;
volatile uint32_t servoLastIntervalUs = 0;
volatile uint32_t servoPrevIntervalUs = 0;
volatile uint32_t servoMaxJitterUs = 0;
volatile uint32_t servoPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t servoPeriodFrac = 0;
volatile uint32_t hwBurstPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t hwBurstPeriodFrac = 0;

static inline uint16_t q16PeriodToTimerUs(volatile uint32_t &frac, uint32_t q16) {
    // True Q16.16 accumulation: retain both the configured fractional period
    // and the carry from prior timer cycles. This preserves the long-term
    // average period instead of truncating the Q16 fractional component.
    uint32_t sum = (q16 & 0xFFFFUL) + (frac & 0xFFFFUL);
    uint32_t whole = (q16 >> SERVO_PERIOD_Q_SHIFT) + (sum >> SERVO_PERIOD_Q_SHIFT);
    frac = sum & 0xFFFFUL;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline uint32_t calculateAdaptiveStepPeriodQ16(uint32_t revolutionUs, uint32_t stepCount) {
    if (stepCount == 0U || revolutionUs == 0U) return servoPeriodQ16;
    int angle = feedAngleDeg;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    int margin = safetyMarginPercent;
    if (margin < 0) margin = 0;
    if (margin > 25) margin = 25;
    uint64_t windowUs = ((uint64_t)revolutionUs * (uint64_t)angle) / 360ULL;
    windowUs = (windowUs * (uint64_t)(100 - margin)) / 100ULL;
    if (windowUs < 1ULL) windowUs = 1ULL;
    uint64_t q16 = (windowUs << SERVO_PERIOD_Q_SHIFT) / (uint64_t)stepCount;
    uint64_t minQ = ((uint64_t)SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT);
    uint64_t maxQ = ((uint64_t)SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT);
    if (q16 < minQ) q16 = minQ;
    if (q16 > maxQ) q16 = maxQ;
    return (uint32_t)q16;
}


HardwareTimer *stepTimer     = new HardwareTimer(TIM2);
HardwareTimer *safetyTimer   = new HardwareTimer(TIM3);
#if defined(TIM4)
HardwareTimer *timebaseTimer = new HardwareTimer(TIM4);
#endif
volatile uint8_t pa3FaultCounterMs   = 0; // Independent 15ms consecutive qualification counter for PA3 (Tape)
volatile uint8_t pb0FaultCounterMs   = 0; // Independent 15ms consecutive qualification counter for PB0 (Coil)

// =========================================================================
// TRUE HARDWARE TIMER 2 PWM (OC2) STEP GENERATION & BURST CONTROLLER
// 1. Pure Continuous PWM Mode 2: Inactive (HIGH) 0..CCR2-1, Active (LOW) CCR2..ARR.
// 2. Output is natively, physically HIGH at CNT=0 rollover.
// 3. Software halts CEN and CC2E at CNT=0 upon burst completion (0.2us latency vs 30us safety window).
// 4. Zero OPM hardware race conditions: Timer NEVER stalls or dies on rapid/boundary triggers!
// 5. Seamless mid-burst trigger accumulation: Target += stepCount without losing a single pulse.
// =========================================================================

// =========================================================================
// DETERMINISTIC MULTI-SEGMENT RAMP PARAMETER CALCULATOR
// Provides smooth, bounded acceleration/deceleration with zero staircase jerk
// Dedicated short-burst handling: N<=4 (pure cruise), 5<=N<=12 (gentle soft boundary)
// =========================================================================
static inline uint16_t calculateAdaptiveStepPeriodUs(uint32_t revolutionUs, uint32_t stepCount) {
    uint32_t q16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    uint32_t whole = q16 >> SERVO_PERIOD_Q_SHIFT;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline void updateStepPeriodFromServoInterval(uint32_t revolutionUs, uint32_t stepCount) {
    if (revolutionUs == 0U || stepCount == 0U) return;
    servoPrevIntervalUs = servoLastIntervalUs;
    servoLastIntervalUs = revolutionUs;
    if (servoPrevIntervalUs != 0U) {
        uint32_t jitter = (revolutionUs > servoPrevIntervalUs) ? (revolutionUs - servoPrevIntervalUs) : (servoPrevIntervalUs - revolutionUs);
        if (jitter > servoMaxJitterUs) servoMaxJitterUs = jitter;
    }
    servoPeriodQ16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    servoPhaseLocked = (servoPrevIntervalUs != 0U);
    if (servoPhaseLocked) servoPhaseRelockCount++;
}

void stepTimerCallback() {
    if (hwBurstActive && !isSensorFaultTripped && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        hwBurstStepsDone++;
#if DEBUG_TEST_MODE
        completedPulseCount++;
#endif

        if (hwBurstStepsDone >= hwBurstStepsTarget || isSensorFaultTripped) {
            BurstItem nextBurst{};
            if (!isSensorFaultTripped && movementState != STATE_FAULT && movementState != STATE_ABORTED && burstQueue.dequeue(nextBurst)) {
                // Seamlessly chain queued burst from authoritative SPSC BurstQueue without dropping timer
                hwBurstStepsTarget = (int)nextBurst.stepCount;
                hwBurstStepsDone   = 0;
#if DEBUG_TEST_MODE
                queuedPulseCount  -= nextBurst.stepCount;
                startedPulseCount += nextBurst.stepCount;
                burstStartedCount++;
#endif
                stepsRemaining     = hwBurstStepsTarget;
                totalStepsInBurst  = hwBurstStepsTarget;

                // Direction Fix (per Rajesh Shah directive):
                // Direction is strictly Settings-controlled and fixed during RUN.
                // Pulse, burst, queue, ISR, DDA, RPM, trigger, and sensor processing NEVER change DIR at runtime.

                // Each queued burst carries the period calculated from the physical
                // servo interval that created it. Never rewrite the active burst with a
                // newer measurement; this preserves deterministic phase timing.
                if (nextBurst.periodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && nextBurst.periodQ16 <= (SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT)) {
                    hwBurstPeriodQ16 = nextBurst.periodQ16;
                    hwBurstPeriodFrac = 0;
                    activePulseWidth = (int)(hwBurstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
                } else if (nextBurst.periodUs >= SERVO_PERIOD_MIN_US && nextBurst.periodUs <= SERVO_PERIOD_MAX_US) {
                    activePulseWidth = (int)nextBurst.periodUs;
                    hwBurstPeriodQ16 = ((uint32_t)activePulseWidth << SERVO_PERIOD_Q_SHIFT);
                    hwBurstPeriodFrac = 0;
                }
                uint16_t nextARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
                TIM2->ARR = nextARR;
                uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
                if (pWidth < 2) pWidth = 2;
                TIM2->CCR2 = nextARR - pWidth + 1;
                return;
            }

            // Burst complete with no queued steps: disable PWM output and stop timer in silicon
            TIM2->CCER &= ~TIM_CCER_CC2E; // Disconnect hardware PWM output on PA1 immediately
            TIM2->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
            
            // Restore PA1 pin to General Purpose Output HIGH (Idle)
            GPIOA->CRL &= ~(0xFU << 4);
            GPIOA->CRL |= (0x3U << 4); // 50MHz GP Output Push-Pull
            STEP_HIGH_IDLE();
            stepPinState = HIGH;

            // Clear any pending update flags in NVIC
            TIM2->SR &= ~TIM_SR_UIF;
            NVIC_ClearPendingIRQ(TIM2_IRQn);

            hwBurstActive  = false;
            stepsRemaining = 0;
            movementState  = isSensorFaultTripped ? STATE_FAULT : STATE_COMPLETE;
#if DEBUG_TEST_MODE
            burstCompletedCount++;
            if (queuedPulseCount == 0 && !hwBurstActive) {
                if (requestedPulseCount != (completedPulseCount + abortedPulseCount)) {
                    assertionFailureCount++;
                }
            }
#endif
            STATUS_LED_OFF(); // Stepper burst complete -> Turn OFF LED
        } else {
            stepsRemaining = (hwBurstStepsTarget - hwBurstStepsDone);
            movementState  = STATE_RUNNING;

            // Keep every pulse in the burst at the servo-synchronized period.
            // Artificial per-pulse ramps are deliberately removed because they change
            // the commanded pulse density away from the measured master motion.
            uint16_t scheduledPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
            activePulseWidth = (int)scheduledPeriodUs;
            uint16_t nextARR = (scheduledPeriodUs > 1) ? (uint16_t)(scheduledPeriodUs - 1) : 1;
            TIM2->ARR  = nextARR;
            uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
            if (pWidth < 2) pWidth = 2;
            TIM2->CCR2 = nextARR - pWidth + 1; // Pulse ends exactly at ARR rollover
        }
    } else {
        TIM2->CCER &= ~TIM_CCER_CC2E;
        TIM2->CR1  &= ~TIM_CR1_CEN;
        GPIOA->CRL &= ~(0xFU << 4);
        GPIOA->CRL |= (0x3U << 4);
        STEP_HIGH_IDLE();
        stepPinState   = HIGH;
        TIM2->SR &= ~TIM_SR_UIF;
        NVIC_ClearPendingIRQ(TIM2_IRQn);
        hwBurstActive  = false;
        stepsRemaining = 0;
        movementState  = isSensorFaultTripped ? STATE_FAULT : STATE_IDLE;
    }
}

// =========================================================================
// DETERMINISTIC 1 KHZ HARDWARE SAFETY MONITOR (TIM3)
// Unblockable by loop() or I2C LCD delays. 15ms Anti-Vibration Qualified E-Stop.
// =========================================================================
void safetyTimerCallback() {
    // Proximity synchronization watchdog is ALWAYS active and is independent
    // of the optional Tape Guard.  The Guard must never disable the primary
    // Proximity -> STEP synchronization path.
    bool tapeBroken = false;
    bool coilBroken = false; // Legacy input retained for pin/layout compatibility; not used by Tape Guard.
    if (sensorGuardActive) {
        tapeBroken = (((GPIOA->IDR & (1 << 3)) != 0) == (SENSOR_STATE_FAULT == HIGH)); // PA3 HIGH = Tape End/Fault
    } else {
        // No Guard sensor installed/selected: PA3 is electrically irrelevant.
        pa3FaultCounterMs = 0;
        pb0FaultCounterMs = 0;
    }

    // Software Trigger Watchdog (Motion Sync Lost Detection)
    if (currentRPM > 100UL && !isSensorFaultTripped && !isMotionSyncLost) {
        unsigned long elapsedSinceTrigger = micros() - lastTriggerMicros;
        // Watchdog formula: allows up to 4x deceleration slowdown plus 50ms margin, minimum 300ms
        unsigned long syncTimeoutUs = (lastMeasuredIntervalUs > 0) ? (lastMeasuredIntervalUs * 4UL + 50000UL) : 300000UL;
        if (syncTimeoutUs < 300000UL) syncTimeoutUs = 300000UL;

        if (elapsedSinceTrigger > syncTimeoutUs) {
            isMotionSyncLost = true;
            movementState    = STATE_FAULT;

            // Cut TIM2 stepping in silicon & clamp PA1 HIGH
            TIM2->CCER &= ~TIM_CCER_CC2E;
            TIM2->CR1  &= ~TIM_CR1_CEN;
            GPIOA->CRL &= ~(0xFU << 4);
            GPIOA->CRL |= (0x3U << 4);
            STEP_HIGH_IDLE();
            stepPinState = HIGH;

            // Disengage clutch via PB1 Relay HIGH
            GPIOB->BSRR = (1 << 1);

            uint32_t abortedFromQueue = burstQueue.abortAll();
#if DEBUG_TEST_MODE
            int uncompleted = (hwBurstStepsTarget - hwBurstStepsDone) + (int)abortedFromQueue;
            if (uncompleted > 0) {
                abortedPulseCount += uncompleted;
                queuedPulseCount = 0;
            }
#else
            (void)abortedFromQueue;
#endif
            hwBurstActive      = false;
            hwBurstStepsTarget = 0;
            hwBurstStepsDone   = 0;
            stepsRemaining     = 0;

            faultType = 3;
            uiBannerLine1 = "! SYNC TIMEOUT !";
            uiBannerLine2 = "TRIGGER LOST E-S";
            uiMessageTimer = millis() + 4000UL;
            oldMenuState = -1;
        }
    }

    // -------------------------------------------------------------------------
    // INDEPENDENT SENSOR QUALIFICATION (PA3: Tape Run-Out, PB0: Coil Jam)
    // -------------------------------------------------------------------------
    bool pa3Qualified = false;
    bool pb0Qualified = false;
    if (sensorGuardActive) {
        updateSafetySensorCounters(true, tapeBroken, coilBroken,
                                   pa3FaultCounterMs, pb0FaultCounterMs,
                                   pa3Qualified, pb0Qualified);
    }

    if (pa3Qualified) {
        if (!isSensorFaultTripped) {
            isSensorFaultTripped = true;
            movementState = STATE_FAULT;

            // Immediate Silicon Hardware E-Stop:
            TIM2->CCER &= ~TIM_CCER_CC2E; // Disconnect PWM output in 13.8ns
            TIM2->CR1  &= ~TIM_CR1_CEN;   // Stop TIM2 counter in silicon

            // Clamp PA1 to Safe Idle HIGH:
            GPIOA->CRL &= ~(0xFU << 4);
            GPIOA->CRL |= (0x3U << 4);
            STEP_HIGH_IDLE();
            stepPinState = HIGH;

            // Trip Main Motor Relay PB1 HIGH instantly (Opens clutch circuit):
            GPIOB->BSRR = (1 << 1); // 13.8ns atomic hardware relay drive

            // Clear flags & cancel pending steps:
            TIM2->SR &= ~TIM_SR_UIF;
            NVIC_ClearPendingIRQ(TIM2_IRQn);
            uint32_t abortedFromQueue = burstQueue.abortAll();
#if DEBUG_TEST_MODE
            int uncompleted = (hwBurstStepsTarget - hwBurstStepsDone) + (int)abortedFromQueue;
            if (uncompleted > 0) {
                abortedPulseCount += uncompleted;
                queuedPulseCount = 0;
            }
#else
            (void)abortedFromQueue;
#endif
            hwBurstActive      = false;
            hwBurstStepsTarget = 0;
            hwBurstStepsDone   = 0;
            stepsRemaining     = 0;

            if (pa3Qualified && pb0Qualified) {
                faultType = 1; // Prioritize Tape Run-Out
                uiBannerLine1 = "! TAPE RUN-OUT !";
            } else if (pa3Qualified) {
                faultType = 1;
                uiBannerLine1 = "! TAPE RUN-OUT !";
            } else {
                faultType = 2;
                uiBannerLine1 = "! COIL BROKEN ! ";
            }
            uiBannerLine2 = "MAIN MOTOR E-STOP";
            uiMessageTimer = millis() + 4000UL;
            oldMenuState = -1;
        }
    } else {
        // Deterministic Standstill Recovery: Relay is ONLY released when machine is at 0 RPM
        // and both sensors are clear (!tapeBroken && !coilBroken)
        if ((isSensorFaultTripped || isMotionSyncLost) && currentRPM == 0UL && !tapeBroken && !coilBroken) {
            isSensorFaultTripped = false;
            isMotionSyncLost     = false;
            movementState = STATE_IDLE;
            GPIOB->BRR = (1 << 1); // Release relay LOW
        }
    }
}


// =========================================================================
// CONTINUOUS 1 MHZ FREE-RUNNING TIMER 4 (STM32F103 HARDWARE TIMESTAMPING)
// 1.0 microsecond deterministic tick resolution, independent of TIM2/TIM3
// =========================================================================
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
void tim4UpdateCallback(void) {
    tim4_overflow_count++;
}

void initFreeRunningTimer4() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
    TIM4->PSC = 71;     // 72MHz / (71 + 1) = 1MHz (1.0 us tick)
    TIM4->ARR = 0xFFFF; // 16-bit free-running counter rollover at 65535us
    TIM4->CNT = 0;
    TIM4->SR &= ~TIM_SR_UIF;
    TIM4->DIER |= TIM_DIER_UIE; // Enable update interrupt for 32-bit rollover

    // Attach callback using official STM32duino HardwareTimer framework
    // (Prevents duplicate definition of TIM4_IRQHandler with SrcWrapper/HardwareTimer.cpp)
    timebaseTimer->pause();
    timebaseTimer->attachInterrupt(tim4UpdateCallback);
    timebaseTimer->resume();
}

// Provably race-safe atomic snapshot across 16-bit hardware timer overflow
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t high;
    uint16_t low;
    bool pending;

    do {
        high = tim4_overflow_count;
        low  = (uint16_t)(TIM4->CNT);
        pending = (TIM4->SR & TIM_SR_UIF) != 0;
    } while (high != tim4_overflow_count);

    // If an overflow interrupt is pending (UIF set) and CNT has already rolled over
    // to a small value (< 0x8000), account for the unserviced rollover in this reading
    if (pending && (low < 0x8000)) {
        high++;
    }

    return (high << 16) | low;
}
#else
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t nowCycles = 0;
#if defined(CoreDebug) && defined(DWT)
    nowCycles = DWT->CYCCNT;
#endif
    return (nowCycles != 0) ? (nowCycles / 72UL) : micros();
}
#endif
void initHardwareSafetyTimer3() {
    // 1. Enable TIM3 peripheral clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    // 2. Prescaler: 72MHz / (71 + 1) = 1MHz (1 tick = 1.0 microsecond)
    TIM3->PSC = 71;
    // Auto-reload: 1000 ticks = 1000 microseconds = 1.0ms (1 kHz sampling)
    TIM3->ARR = 999;
    TIM3->CNT = 0;

    // Clear update flag
    TIM3->SR &= ~TIM_SR_UIF;

    // Enable update interrupt
    TIM3->DIER |= TIM_DIER_UIE;

    // Attach callback with HardwareTimer wrapper
    safetyTimer->pause();
    safetyTimer->attachInterrupt(safetyTimerCallback);
    safetyTimer->resume();
}

void initHardwareTimer2() {
    // 1. Enable TIM2 peripheral clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    // 2. Ensure PA1 is initially General Purpose Output HIGH (Driver PUL- idle)
    pinMode(stepPin, OUTPUT);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;

    // 3. Configure Hardware Timer 2 Registers directly:
    // Prescaler: 72MHz / (71 + 1) = 1MHz (1 tick = 1.0 microsecond)
    TIM2->PSC = 71;
    uint16_t initARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
    TIM2->ARR = initARR;

    // Active LOW pulse width for DM542 optocoupler: exactly 5.0us ending at ARR
    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM2->CCR2 = initARR - pWidth + 1;

    // Configure Channel 2 for Hardware PWM Mode 2 (OC2M = 111b) with Preload Enable
    // PWM Mode 2 + Active LOW (CC2P = 1):
    // CNT < CCR2  -> Output is INACTIVE (HIGH / 3.3V)
    // CNT >= CCR2 -> Output is ACTIVE (LOW / Sinks PUL-)
    // At CNT=0 (and when stopped): Output is strictly HIGH!
    // Active pulse occurs from CCR2 to ARR, finishing cleanly at ARR rollover!
    // Zero runt pulses, zero CCR=0 suppression, zero pin freezing!
    TIM2->CCMR1 &= ~TIM_CCMR1_OC2M;
    TIM2->CCMR1 |= (0x7U << 12); // 111b = PWM Mode 2
    TIM2->CCMR1 |= TIM_CCMR1_OC2PE; // Output Compare Preload Enable

    // Polarity: Active-LOW (CC2P = 1 -> Sinks LOW during pulse, sits HIGH at idle)
    TIM2->CCER |= TIM_CCER_CC2P;

    // Auto-Reload Preload Enable (prevents glitch on ARR changes during ramp)
    TIM2->CR1 |= TIM_CR1_ARPE;

    // Continuous mode (OPM strictly disabled to prevent hardware counter death on boundary triggers)
    TIM2->CR1 &= ~TIM_CR1_OPM;

    // Channel 1 (PA0): Hardware Input Capture for Cam Proximity Sensor
    // CC1S = 01b (IC1 mapped on TI1), CC1P = 1 (Falling edge), CC1E = 1 (Capture Enabled)
    // Hardware automatically latches TIM2->CNT into TIM2->CCR1 at physical edge directly via silicon input capture register
    // Hardware sets TIM_SR_CC1OF flag if overcapture occurs
    TIM2->CCMR1 &= ~TIM_CCMR1_CC1S;
    TIM2->CCMR1 |= TIM_CCMR1_CC1S_0; // 01b: CC1 mapped on TI1
    TIM2->CCER  |= (TIM_CCER_CC1P | TIM_CCER_CC1E);

    // Hardware capture DMA: TIM2_CH1 -> DMA1 Channel 5 circular buffer.
    // This mirrors CCR1 in silicon and leaves the EXTI ISR free to perform only
    // phase/queue work. DMA is diagnostic/trace infrastructure and does not
    // change the electrical trigger input path.
#if defined(DMA1_Channel5)
    RCC->AHBENR |= RCC_AHBENR_DMA1EN;
    DMA1_Channel5->CCR = 0;
    DMA1_Channel5->CPAR = (uint32_t)&TIM2->CCR1;
    DMA1_Channel5->CMAR = (uint32_t)servoCaptureDma;
    DMA1_Channel5->CNDTR = SERVO_CAPTURE_DMA_SAMPLES;
    DMA1_Channel5->CCR = DMA_CCR_MINC | DMA_CCR_CIRC | DMA_CCR_PSIZE_0 | DMA_CCR_MSIZE_0;
    DMA1_Channel5->CCR |= DMA_CCR_PL_0;
    DMA1_Channel5->CCR |= DMA_CCR_EN;
#endif

    // Enable Update Interrupt (fires once per complete step period at CNT == ARR)
    TIM2->DIER |= TIM_DIER_UIE;

    // Attach stepTimerCallback with STM32duino HardwareTimer wrapper
    stepTimer->pause();
    stepTimer->attachInterrupt(stepTimerCallback);
}

void startHardwareTimerBurst(int stepCount, uint16_t burstPeriodUs = 0, uint32_t burstPeriodQ16 = 0) {
    if (stepCount <= 0 || isSensorFaultTripped || movementState == STATE_FAULT || movementState == STATE_ABORTED) return;

    // ATOMIC CRITICAL SECTION: Protect against TIM2 preemption race conditions
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    uint32_t nowUs = get_hardware_timestamp_us();
    hwBurstPeriodQ16 = burstPeriodQ16 ? burstPeriodQ16 : ((uint32_t)burstPeriodUs << SERVO_PERIOD_Q_SHIFT);
    if (burstPeriodQ16 == 0U && burstPeriodUs == 0U) hwBurstPeriodQ16 = servoPeriodQ16;
    hwBurstPeriodFrac = 0;
    static uint32_t s_burstSeq = 0;

    if (hwBurstActive) {
        // Enqueue into authoritative production SPSC BurstQueue
        bool enqueued = burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, (uint32_t)hwBurstPeriodQ16);
        if (enqueued) {
#if DEBUG_TEST_MODE
            burstQueuedCount++;
            queuedPulseCount += stepCount;
#endif
        }
        movementState = STATE_RUNNING;
        __set_PRIMASK(primask);
        return;
    }

    // Active burst is idle: enqueue into BurstQueue and immediately dequeue to start TIM2
    burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, (uint32_t)hwBurstPeriodQ16);
    BurstItem item{};
    burstQueue.dequeue(item);

    if (item.periodUs >= 8U && item.periodUs <= 500U) {
        activePulseWidth = (int)item.periodUs;
    }
    hwBurstStepsTarget = (int)item.stepCount;
    hwBurstStepsDone   = 0;
    hwBurstActive      = true;
#if DEBUG_TEST_MODE
    burstStartedCount++;
    startedPulseCount += stepCount;
#endif
    stepsRemaining     = stepCount;
    totalStepsInBurst  = stepCount;
    stepPinState       = HIGH;
    movementState      = STATE_RUNNING;

    // Connect PA1 directly to TIM2_CH2: Alternate Function Push-Pull 50MHz
    GPIOA->CRL &= ~(0xFU << 4);
    GPIOA->CRL |= (0xBU << 4); // 1011b = AF Output Push-Pull 50MHz

    // The servo is the mechanical master. Do not invent an acceleration ramp here.
    // activePulseWidth is derived from the most recent physical trigger interval;
    // maxRPMSetting is only the startup/fallback bound before the first valid interval.
    uint16_t initPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
    activePulseWidth = (int)initPeriodUs;
    uint16_t initARR = (initPeriodUs > 1) ? (uint16_t)(initPeriodUs - 1) : 1;
    TIM2->ARR  = initARR;

    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM2->CCR2 = initARR - pWidth + 1;

    // Ensure OPM is disabled
    TIM2->CR1 &= ~TIM_CR1_OPM;

    // Force load preload registers into shadow registers and reset CNT to 0
    // Temporarily mask UIE so EGR_UG does not latch a spurious update interrupt into NVIC
    TIM2->DIER &= ~TIM_DIER_UIE;
    TIM2->EGR   = TIM_EGR_UG;
    TIM2->SR   &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM2_IRQn);
    TIM2->DIER |= TIM_DIER_UIE;

    // Enable hardware PWM output on PA1 in silicon
    TIM2->CCER |= TIM_CCER_CC2E;

    // Start timer counter in silicon
    TIM2->CR1 |= TIM_CR1_CEN;

    __set_PRIMASK(primask);
}

void stopHardwareTimerImmediately() {
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    TIM2->CCER &= ~TIM_CCER_CC2E; // Disable hardware PWM output on PA1 in silicon
    TIM2->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
    TIM2->CR1  &= ~TIM_CR1_OPM;   // Ensure OPM cleared

    // Restore PA1 pin to General Purpose Output HIGH (Idle)
    GPIOA->CRL &= ~(0xFU << 4);
    GPIOA->CRL |= (0x3U << 4);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;

    // Clear all pending flags and interrupts
    TIM2->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM2_IRQn);

    uint32_t abortedFromQueue = burstQueue.abortAll();
#if DEBUG_TEST_MODE
    int uncompleted = (hwBurstStepsTarget - hwBurstStepsDone) + (int)abortedFromQueue;
    if (uncompleted > 0) {
        abortedPulseCount += uncompleted;
        queuedPulseCount = 0;
    }
#else
    (void)abortedFromQueue;
#endif

    hwBurstActive      = false;
    hwBurstStepsTarget = 0;
    hwBurstStepsDone   = 0;
    stepsRemaining     = 0;
    movementState      = isSensorFaultTripped ? STATE_FAULT : STATE_ABORTED;

    __set_PRIMASK(primask);
}

void recalculatePitchProfiles() {
    // Explicit numerical bounds checking
    if ((rollerDia != rollerDia) || rollerDia < 15.0f || rollerDia > 100.0f) rollerDia = 45.0f;
    if (driverResolution < 200 || driverResolution > 51200) driverResolution = 6400;
    double circumference = 3.14159265358979323846 * (double)rollerDia;
    double pulsesPerMM = (double)driverResolution / circumference;
    // 64-bit intermediate arithmetic: strictly prevents uint32_t overflow at max 51200 res / 15mm roller
    p5_fixed  = (uint64_t)(2.50 * pulsesPerMM * 1000000.0 + 0.5);
    p8_fixed  = (uint64_t)(3.00 * pulsesPerMM * 1000000.0 + 0.5);
    p10_fixed = (uint64_t)(4.00 * pulsesPerMM * 1000000.0 + 0.5);
    if (p5_fixed < 1000000ULL) p5_fixed = 1000000ULL;
    if (p8_fixed < 1000000ULL) p8_fixed = 1000000ULL;
    if (p10_fixed < 1000000ULL) p10_fixed = 1000000ULL;
}

void syncPulseIntegerFraction() {
    uint32_t intPart  = (uint32_t)(currentPulsesFixed / 1000000ULL);
    uint32_t fracPart = (uint32_t)(currentPulsesFixed % 1000000ULL);
    currentPulsesInt  = intPart;
    currentPulsesFrac = fracPart;
    commitPulseParameters(intPart, fracPart);
}

void updateActivePulseWidth() {
    syncPulseIntegerFraction();
    if (maxRPMSetting < 100 || maxRPMSetting > 4000) maxRPMSetting = 3000;
    if (feedAngleDeg < 30 || feedAngleDeg > 270) feedAngleDeg = 160;
    if (safetyMarginPercent < 0 || safetyMarginPercent > 25) safetyMarginPercent = 10;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));
    float activeSteps = (float)currentPulsesFixed / 1000000.0f;
    if (activeSteps < 1.0f) activeSteps = 1.0f;
    // Startup/fallback STEP period only; runtime period is replaced by measured servo timing.
    int calcPeriod = (int)(timeWindowUs / activeSteps);
    // Safe industrial limits: [8us, 500us] (125 kHz to 2 kHz stepping rates, guarantees >= 2.5us driver opto timing)
    if (calcPeriod < 8) calcPeriod = 8;
    if (calcPeriod > 500) calcPeriod = 500;
    activePulseWidth = calcPeriod;
}

void calculateAllPulseWidths() {
    if (maxRPMSetting <= 0) maxRPMSetting = 3000;
    if (feedAngleDeg <= 0) feedAngleDeg = 160;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));

    float s5 = (float)p5_fixed / 1000000.0f;
    if (s5 < 1.0f) s5 = 1.0f;
    // Safe industrial limit: Full step period [8us, 500us] (guarantees >= 2.5us driver opto timing)
    autoPulseWidth_P5 = constrain((int)(timeWindowUs / s5), 8, 500);

    float s8 = (float)p8_fixed / 1000000.0f;
    if (s8 < 1.0f) s8 = 1.0f;
    autoPulseWidth_P8 = constrain((int)(timeWindowUs / s8), 8, 500);

    float s10 = (float)p10_fixed / 1000000.0f;
    if (s10 < 1.0f) s10 = 1.0f;
    autoPulseWidth_P10 = constrain((int)(timeWindowUs / s10), 8, 500);

    updateActivePulseWidth();

    // 50% nominal period debounce: completely rejects trailing edge & contactor EMI noise
    dynamicDebounceUs = 3000UL; // Legacy UI/diagnostic value; trigger qualification uses measured adaptive blanking.
}

void evaluateDiagnostics() {
    float tempDia  = (tempRollerDia > 0.1f) ? tempRollerDia : 45.0f;
    int32_t tempRes   = (tempDriverRes > 200) ? tempDriverRes : 6400;
    int32_t tempRPM   = (tempMaxRPM > 100) ? tempMaxRPM : 3000;
    int32_t tempAngle  = (tempFeedAngle > 10) ? tempFeedAngle : 160;
    int32_t tempMargin = constrain(tempSafetyMargin, 0, 25);

    float tempCirc = 3.14159265f * tempDia;
    float tempPPM  = (float)tempRes / tempCirc;
    float s10_test = 4.00f * tempPPM;
    if (s10_test < 1.0f) s10_test = 1.0f;

    float timeWinTest = (60000000.0f / (float)tempRPM) * ((float)tempAngle / 360.0f) * (1.0f - ((float)tempMargin / 100.0f));
    diagMinW = (int)(timeWinTest / s10_test);

    if (diagMinW < 6) {
        isTimingWarningActive = true;
        if (tempRes > 12800) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET RES <= 12800";
        } else if (tempAngle < 120) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "INC ANGLE >= 150";
        } else if (tempRPM > 2500) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RPM <= 2500 ";
        } else if (tempMargin > 15) {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "SET MARGIN 10%  ";
        } else {
            diagFixLine1 = "SUGGESTED FIX:  ";
            diagFixLine2 = "DEC RES/INC ANG ";
        }
    } else {
        isTimingWarningActive = false;
        diagFixLine1 = "TIMING HEALTH:  ";
        diagFixLine2 = "SYSTEM OPTIMAL  ";
    }
}

// =========================================================================
// TWO-PHASE ATOMIC DEFERRED TRIGGER DISPATCH ENGINE (SECTION 6 RACE FIX)
// Dispatches any triggers deferred during Flash save/abort window.
// Prevents newer incoming physical triggers from overtaking older deferred work.
// Only after deferred pulses are safely handed off does the lock return to IDLE.
// =========================================================================
static void dispatchDeferredSaveTriggers() {
    uint8_t defDir = 0;
    uint32_t defTs = 0;
    uint32_t defSteps = flashSaveTx.captureDeferredForDispatch(defDir, defTs);
    while (defSteps > 0) {
        if (!isSensorFaultTripped && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
            if (hardwareTimerMode) {
                startHardwareTimerBurst(defSteps);
            } else {
                uint32_t primask = __get_PRIMASK();
                __disable_irq();
                stepsRemaining += defSteps;
                totalStepsInBurst = stepsRemaining;
                __set_PRIMASK(primask);
            }
        } else {
#if DEBUG_TEST_MODE
            abortedPulseCount += defSteps;
#endif
        }
        defSteps = flashSaveTx.captureDeferredForDispatch(defDir, defTs);
    }
    flashSaveTx.completeHandoff();
}

bool saveToEEPROM() {
    // 1. Request Atomic Save Lock (SAVE_LOCK_IDLE -> SAVE_LOCK_ACQUIRING)
    if (!flashSaveTx.requestSaveLock()) {
        return false;
    }

    // 2. Authoritative Safe-Save Precondition Check & Lock Confirmation
    if (!flashSaveTx.confirmLockAndTransition(isMachineSafelyIdle())) {
        dispatchDeferredSaveTriggers();
        return false; // Prohibited while machine moving or safety fault active
    }

    // 3. Prepare Candidate Dual-Slot Record
    uint32_t targetSlot = 1 - activeEEPROMSlot;
    int targetOffset = (targetSlot == 0) ? 0 : 128;
    uint32_t nextSeq = eepromSeqNumber + 1;

    MachineConfigRecord rec;
    rec.magic    = EEPROM_MAGIC_V16_5_1;
    rec.seq      = nextSeq;
    rec.reserved = 0;

    rec.payload.p5_fixed            = p5_fixed;
    rec.payload.p8_fixed            = p8_fixed;
    rec.payload.p10_fixed           = p10_fixed;
    rec.payload.driverResolution    = driverResolution;
    rec.payload.rollerDia           = rollerDia;
    rec.payload.maxRPMSetting       = maxRPMSetting;
    rec.payload.feedAngleDeg        = feedAngleDeg;
    rec.payload.safetyMarginPercent = safetyMarginPercent;
    rec.payload.currentSize         = currentSize;
    rec.payload.sensorGuardActive   = sensorGuardActive ? 1 : 0;
    rec.payload.hardwareTimerMode   = hardwareTimerMode ? 0 : 1;
    rec.payload.motorDirection      = motorDirection ? 1 : 0;

    // 4. Complete-Payload Equality Check against active persisted payload (Section 6)
    MachineConfigRecord activeRec;
    int activeOffset = (activeEEPROMSlot == 0) ? 0 : 128;
    EEPROM.get(activeOffset, activeRec);
    if (PulseStepPersistenceManager::validateRecord(activeRec) &&
        memcmp(&rec.payload, &activeRec.payload, sizeof(MachineConfigPayload)) == 0) {
        // Complete serialized payload identical: skip Flash write (0 writes)
        dispatchDeferredSaveTriggers();
        return true;
    }

    rec.crc32 = calculateCRC32((const uint8_t*)&rec.payload, sizeof(MachineConfigPayload));

    // 5. Atomic Flash Programming in Smallest Safe Critical Section
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    EEPROM.put(targetOffset, rec);
    __set_PRIMASK(primask);

    // 6. Verification Read-back
    MachineConfigRecord readBack;
    EEPROM.get(targetOffset, readBack);

    bool saveOk = false;
    if (PulseStepPersistenceManager::validateRecord(readBack) &&
        memcmp(&rec, &readBack, sizeof(MachineConfigRecord)) == 0) {
        // Successfully verified in ROM
        flashWriteCount++;
        activeEEPROMSlot = targetSlot;
        eepromSeqNumber  = nextSeq;

        // Synchronize stored baseline
        pulseStepStored_p5  = p5_fixed;
        pulseStepStored_p8  = p8_fixed;
        pulseStepStored_p10 = p10_fixed;
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
        calculateAllPulseWidths();
        saveOk = true;
    }

    // 7. Atomic Handoff and Dispatch of Any Triggers Deferred During Save Window (Section 6)
    dispatchDeferredSaveTriggers();
    return saveOk;
}

void loadFactoryDefaults() {
    driverResolution    = 6400;
    rollerDia           = 45.0f;
    maxRPMSetting       = 3000;
    feedAngleDeg        = 160;
    safetyMarginPercent = 10;
    currentSize         = 1;
    sensorGuardActive   = false; // BYPASS DEFAULT
    hardwareTimerMode   = true;  // AUTONOMOUS HARDWARE ENGINE DEFAULT
    motorDirection      = false; // NORMAL FORWARD DEFAULT
    applyMotorDirection();
    recalculatePitchProfiles();
    currentPulsesFixed  = p5_fixed;
    calculateAllPulseWidths();
    // Do NOT write Flash merely because defaults loaded in RAM
    pulseStepStored_p5  = p5_fixed;
    pulseStepStored_p8  = p8_fixed;
    pulseStepStored_p10 = p10_fixed;
    pulseModifiedByUser = false;
    hasStagedChanges    = false;
}

void loadFromEEPROM() {
    MachineConfigRecord rec0, rec1;
    EEPROM.get(0, rec0);
    EEPROM.get(128, rec1);

    bool v0 = PulseStepPersistenceManager::validateRecord(rec0);
    bool v1 = PulseStepPersistenceManager::validateRecord(rec1);

    MachineConfigRecord *chosen = nullptr;
    uint32_t chosenSlot = 0;

    if (v0 && v1) {
        if (rec0.seq >= rec1.seq) {
            chosen = &rec0;
            chosenSlot = 0;
        } else {
            chosen = &rec1;
            chosenSlot = 1;
        }
    } else if (v0) {
        chosen = &rec0;
        chosenSlot = 0;
    } else if (v1) {
        chosen = &rec1;
        chosenSlot = 1;
    }

    if (chosen != nullptr) {
        // Valid transactional record found
        activeEEPROMSlot = chosenSlot;
        eepromSeqNumber  = chosen->seq;

        p5_fixed            = chosen->payload.p5_fixed;
        p8_fixed            = chosen->payload.p8_fixed;
        p10_fixed           = chosen->payload.p10_fixed;
        driverResolution    = chosen->payload.driverResolution;
        rollerDia           = chosen->payload.rollerDia;
        maxRPMSetting       = chosen->payload.maxRPMSetting;
        feedAngleDeg        = chosen->payload.feedAngleDeg;
        safetyMarginPercent = chosen->payload.safetyMarginPercent;
        currentSize         = chosen->payload.currentSize;
        sensorGuardActive   = (chosen->payload.sensorGuardActive == 1);
        hardwareTimerMode   = (chosen->payload.hardwareTimerMode == 0);
        motorDirection      = (chosen->payload.motorDirection == 1);

        applyMotorDirection();
        calculateAllPulseWidths();
        recalculatePitchProfiles();

        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        if (currentSize == 1) currentPulsesFixed = p5_fixed;
        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
        else currentPulsesFixed = p10_fixed;
        __set_PRIMASK(primask);
        updateActivePulseWidth();

        pulseStepStored_p5  = p5_fixed;
        pulseStepStored_p8  = p8_fixed;
        pulseStepStored_p10 = p10_fixed;
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
    } else {
        // Check legacy single-slot format (V16.5.0 / V16.4.0 / V16.3.3)
        MachineConfigLegacy leg;
        EEPROM.get(0, leg);
        if (leg.magic == EEPROM_MAGIC || (leg.driverResolution >= 200 && (leg.rollerDia == leg.rollerDia) && leg.rollerDia > 0.1f)) {
            p5_fixed            = (uint64_t)leg.p5_fixed;
            p8_fixed            = (uint64_t)leg.p8_fixed;
            p10_fixed           = (uint64_t)leg.p10_fixed;
            driverResolution    = leg.driverResolution;
            rollerDia           = leg.rollerDia;
            maxRPMSetting       = (leg.maxRPMSetting >= 100 && leg.maxRPMSetting <= 4000) ? leg.maxRPMSetting : 3000;
            feedAngleDeg        = (leg.feedAngleDeg >= 30 && leg.feedAngleDeg <= 270) ? leg.feedAngleDeg : 160;
            safetyMarginPercent = (leg.safetyMarginPercent <= 25) ? leg.safetyMarginPercent : 10;
            currentSize         = (leg.currentSize >= 1 && leg.currentSize <= 3) ? leg.currentSize : 1;
            sensorGuardActive   = false;
            hardwareTimerMode   = true;
            motorDirection      = false;
            applyMotorDirection();
            recalculatePitchProfiles();
            uint32_t primask = __get_PRIMASK();
            __disable_irq();
            if (currentSize == 1) currentPulsesFixed = p5_fixed;
            else if (currentSize == 2) currentPulsesFixed = p8_fixed;
            else currentPulsesFixed = p10_fixed;
            __set_PRIMASK(primask);
            calculateAllPulseWidths();

            // Migrated baseline:
            pulseStepStored_p5  = p5_fixed;
            pulseStepStored_p8  = p8_fixed;
            pulseStepStored_p10 = p10_fixed;
            pulseModifiedByUser = false;
            autoSavePendingStandstill = false;
            hasStagedChanges    = false;
        } else {
            loadFactoryDefaults();
        }
    }
}

// Proximity Sensor Hardware ISR (Active-LOW Falling Edge)
// Preemption Priority Level 1: Hardware-Authoritative Edge Capture & Speed-Adaptive Blanking Engine
void sensorISR() {
    // 1. Hardware Input Capture & Overcapture Detection (TIM2_CH1 on PA0)
#if defined(TIM2)
    if (TIM2->SR & TIM_SR_CC1OF) {
        TIM2->SR &= ~TIM_SR_CC1OF; // Clear overcapture flag
        captureOverrunCount++;
        isCaptureStreamDiscontinuous = true;
        knownOvercaptureLostPulses++;
        lastOvercaptureTimestampUs = get_hardware_timestamp_us();
    }
    if (TIM2->SR & TIM_SR_CC1IF) {
        TIM2->SR &= ~TIM_SR_CC1IF; // Clear capture interrupt flag
    }
    volatile uint16_t latchedCCR1 = TIM2->CCR1; // Read hardware-latched capture register (hardware timer latched)
    (void)latchedCCR1;
#endif

    // 2. Authoritative Continuous 32-Bit Microsecond Hardware Timestamp
    uint32_t nowCycles = 0;
#if defined(CoreDebug) && defined(DWT)
    nowCycles = DWT->CYCCNT;
#endif
    unsigned long nowUs = get_hardware_timestamp_us();
    unsigned long diff = 0;

    if (lastTriggerMicros == 0UL) {
        lastMeasuredIntervalUs = 0UL;
        currentRPM = 0UL;
    } else {
        if (nowCycles != 0 && lastTriggerCycles != 0) {
            uint32_t diffCycles = nowCycles - lastTriggerCycles; // Unsigned wrap-safe arithmetic
            diff = diffCycles / 72UL;
        } else {
            diff = nowUs - lastTriggerMicros;
        }

        if (diff > 2000000UL) {
            // Standstill detection (> 2.0s means machine was stationary)
            lastMeasuredIntervalUs = 0UL;
            currentRPM = 0UL;
        } else {
            // Speed-Adaptive Dynamic Blanking Engine:
            // 2.0ms floor rejects optocoupler ringing & contactor EMI up to 30,000 RPM.
            // 5.0ms ceiling guarantees valid trigger window open even if machine accelerates to 3,600+ RPM.
            // Speed-Adaptive Dynamic Blanking Engine:
            // 1.5ms floor rejects optocoupler ringing & contactor EMI up to 30,000 RPM.
            // 4.5ms ceiling guarantees >=70% valid trigger window open at 4,000 RPM (15.0ms period).
            unsigned long activeBlankingUs = 1500UL;
            if (lastMeasuredIntervalUs > 0UL) {
                activeBlankingUs = lastMeasuredIntervalUs / 3UL; // 33% of previous revolution
                if (activeBlankingUs < 1500UL) activeBlankingUs = 1500UL;
                if (activeBlankingUs > 4500UL) activeBlankingUs = 4500UL;
            }

            if (diff < activeBlankingUs) {
#if DEBUG_TEST_MODE
                rejectedTriggerCount++;
#endif
                return; // Electrical noise spike / contact bounce inside blanking window rejected!
            }

            lastMeasuredIntervalUs = diff;
            acceptedTriggerPulses++;


            // Resynchronize discontinuous stream cleanly on next valid edge
            if (isCaptureStreamDiscontinuous) {
                isCaptureStreamDiscontinuous = false;
                captureResyncCount++;
            }
        }
    }

    // 2. Hardware-synchronous RPM measurement
    if (lastTriggerMicros != 0UL && diff > 0UL && diff < 5000000UL) {
        unsigned long instantRPM = 60000000UL / diff;
        if (currentRPM == 0UL) {
            currentRPM = instantRPM;
        } else {
            currentRPM = (unsigned long)((3UL * instantRPM + 5UL * currentRPM) / 8UL);
        }
    }
    lastTriggerMicros = nowUs;
    lastTriggerCycles = nowCycles;
    STATUS_LED_ON(); // Flash Onboard PC13 LED on Cam Proximity Trigger

    // 3. Atomic Coherent Parameter Snapshot & Zero-Latency Stepper Burst Triggering
    if (!isSensorFaultTripped && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        // Capture integer and fractional microsteps from the exact same generation
        PulseParameters snap;
        snap.integerPart = activePulseParams.integerPart;
        snap.fractionalPart = activePulseParams.fractionalPart;
        snap.generation = activePulseParams.generation;
#if DEBUG_TEST_MODE
        paramGenerationUsed = snap.generation;
        acceptedTriggerCount++;
        requestedPulseCount += snap.integerPart;
#endif
        int newSteps = (int)snap.integerPart;
        pulseFracAccumulator += snap.fractionalPart;
        if (pulseFracAccumulator >= 1000000UL) {
            newSteps++;
            pulseFracAccumulator -= 1000000UL;
#if DEBUG_TEST_MODE
            requestedPulseCount++;
#endif
        }

        // Servo is the master: derive this trigger's burst period from the exact
        // physical revolution interval and exact integer pulse count for this burst.
        // First trigger has no interval yet, so the configured max-RPM value remains
        // only the startup/fallback estimate.
        uint32_t burstPeriodQ16 = (diff > 0UL)
            ? calculateAdaptiveStepPeriodQ16((uint32_t)diff, (uint32_t)newSteps)
            : servoPeriodQ16;
        uint16_t burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        if (burstPeriodUs < SERVO_PERIOD_MIN_US) burstPeriodUs = SERVO_PERIOD_MIN_US;
        if (burstPeriodUs > SERVO_PERIOD_MAX_US) burstPeriodUs = SERVO_PERIOD_MAX_US;
        if (diff > 0UL) {
            updateStepPeriodFromServoInterval((uint32_t)diff, (uint32_t)newSteps);
            burstPeriodQ16 = servoPeriodQ16;
            burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        }

        if (newSteps > 0) {
            if (flashSaveTx.isSaveLockActive()) {
                // Defer incoming trigger during save window without losing it!
                flashSaveTx.deferTrigger(newSteps, motorDirection ? 1 : 0, nowUs);
            } else if (hardwareTimerMode) {
                startHardwareTimerBurst(newSteps, burstPeriodUs, burstPeriodQ16);
            } else {
                uint32_t primask = __get_PRIMASK();
                __disable_irq();
                if (stepsRemaining == 0) {
                    stepsRemaining = newSteps;
                    totalStepsInBurst = stepsRemaining;
                    currentStepIndex = 0;
                    lastStepMicros = micros();
                } else {
                    stepsRemaining += newSteps;
                    totalStepsInBurst = stepsRemaining;
                }
                __set_PRIMASK(primask);
            }
        }
    }

    // 4. Signal background loop to exit menu if machine starts running while in settings
    if (menuState != 0) {
        pendingMenuExit = true;
    }
}

void setup() {
    // Hardware Safety: Ensure Main Motor Relay Pin (PB1) is driven LOW in hardware before setting OUTPUT
    GPIOB->BRR = (1 << 1); // Atomic Clear PB1 LOW
    pinMode(mainMotorRelayPin, OUTPUT);
    digitalWrite(mainMotorRelayPin, LOW);

    pinMode(stepPin, OUTPUT);
    pinMode(dirPin, OUTPUT);
    applyMotorDirection();
    STEP_HIGH_IDLE();

    pinMode(proxSensorPin, INPUT_PULLUP);
    pinMode(tapeSensorPin, INPUT_PULLUP);
    pinMode(coilSensorPin, INPUT_PULLUP);

    pinMode(btnUp, INPUT_PULLUP);
    pinMode(btnDown, INPUT_PULLUP);
    pinMode(btnMode, INPUT_PULLUP);

    pinMode(statusLedPin, OUTPUT);
    STATUS_LED_OFF(); // Built-in LED initial state: OFF

    // Initialize ARM Cortex-M3 DWT Cycle Counter for Sub-Microsecond Hardware Timestamping
#if defined(CoreDebug) && defined(DWT)
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
#endif

    Wire.begin();
    Wire.setClock(400000);
#if defined(WIRE_HAS_TIMEOUT) || defined(ARDUINO_ARCH_STM32)
    Wire.setTimeout(25000);
#endif

    lcd.init();
    lcd.backlight();
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("  NIPON ZIPPER  ");
    lcd.setCursor(0, 1);
    lcd.print(" BY RAJESH SHAH ");
    delay(2000); // 2 Seconds Splash Screen

    loadFromEEPROM();

    // Initialize Hardware Timer 2 for Autonomous Stepper Generation
    initHardwareTimer2();
    // Initialize Hardware Safety Timer 3 for Deterministic 1 kHz Safety Sampling
    initHardwareSafetyTimer3();
#if defined(TIM4) && defined(RCC_APB1ENR_TIM4EN)
    initFreeRunningTimer4();
#endif

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("SYSTEM READY...");
    lcd.setCursor(0, 1);
    lcd.print(hardwareTimerMode ? "ENGINE: HW-TIMER" : "ENGINE: DDA-LOOP");
    delay(800);

    attachInterrupt(digitalPinToInterrupt(proxSensorPin), sensorISR, FALLING);
    // Top Priority (0): Stepper StepPulse Timing (TIM2) - 1us timer resolution
    NVIC_SetPriority(TIM2_IRQn, 0);
    // High Priority (1): Cam Proximity Sensor Edge Capture (EXTI0) - Instantaneous hardware edge latch
    NVIC_SetPriority(EXTI0_IRQn, 1);
    // Medium Priority (2): Deterministic 1 kHz Hardware Safety Monitor (TIM3) - 15ms anti-vibration trip
    NVIC_SetPriority(TIM3_IRQn, 2);
    // Background Priority (3): SysTick Arduino timekeeping
    NVIC_SetPriority(SysTick_IRQn, 3);
    IWDG_INIT();
}

void loop() {
    IWDG_FEED();

    // =========================================================================
    // INTERACTIVE OPTOCOUPLER SINKING BENCH TEST (Menu 9, Option 8)
    // Allows technician to verify PUL- <= 0.5V with standard Digital Multimeter
    // =========================================================================
    if (menuState == 9 && infoIndex == 8 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        if (digitalRead(btnUp) == LOW) {
            STEP_LOW_ACTIVE(); // Force PA1 LOW (Sinks DM542 PUL- to GND)
            stepPinState = LOW;
        } else {
            STEP_HIGH_IDLE();  // Release to Idle HIGH (+5V through optocoupler)
            stepPinState = HIGH;
        }
    }

    // Onboard PC13 LED: Live Cam Proximity Diagnostic (Handwheel alignment & monitoring)
    if (!hwBurstActive && stepsRemaining == 0) {
        if (movementState == STATE_COMPLETE || movementState == STATE_ABORTED) {
            movementState = STATE_IDLE; // Safely return to IDLE when machine is at rest
        }
        if (digitalRead(proxSensorPin) == LOW) {
            STATUS_LED_ON();  // Cam detected in front of sensor
        } else {
            STATUS_LED_OFF(); // Cam clear
        }
    }

    // =========================================================================
    // SAFETY GUARD STATUS & BYPASS CONTROLLER
    // Real-time sensor sampling & E-stop executed by 1 kHz TIM3 hardware interrupt.
    // =========================================================================
    if (!sensorGuardActive && isSensorFaultTripped) {
        // BYPASS MODE: Clear any residual fault
        isSensorFaultTripped = false;
        movementState = STATE_IDLE;
        digitalWrite(mainMotorRelayPin, LOW);
        pa3FaultCounterMs = 0;
        pb0FaultCounterMs = 0;
    }

    // RPM Zeroing timeout if machine stops > 2.0s
    if (currentRPM > 0UL && (micros() - lastTriggerMicros > 2000000UL)) {
        currentRPM = 0UL;
        lastMeasuredIntervalUs = 0UL; // Reset measured interval on standstill
        // Keep oldMenuState intact to prevent lcd.clear() full redraw glitch on startup!
    }

    // =========================================================================
    // 1-MINUTE CONTINUOUS SMOOTH RUN AUTO-SAVE ENGINE (PROMPT 6Writing SECTION 1)
    // Gated strictly to 0 RPM Standstill (Zero Pulse & Trigger Interference)
    // Anti-Repeat Latch: Saved exactly once per parameter modification
    // =========================================================================
    bool isRpmFresh = (lastTriggerMicros != 0UL) && ((micros() - lastTriggerMicros) < 2000000UL);
    autoSaveEngine.update(currentRPM, 300UL, isRpmFresh, isSensorFaultTripped, isMotionSyncLost, (currentRPM == 0UL), pulseModifiedByUser, millis());
    autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

    if (currentRPM == 0UL) {
        if (autoSaveEngine.autoSavePendingStandstill && isMachineSafelyIdle()) {
            bool isAnyDirty = (p5_fixed != pulseStepStored_p5) ||
                              (p8_fixed != pulseStepStored_p8) ||
                              (p10_fixed != pulseStepStored_p10) ||
                              pulseModifiedByUser ||
                              hasStagedChanges;
            if (isAnyDirty) {
                saveToEEPROM();
                uiBannerLine1 = "AUTO-SAVED OK!  ";
                uiBannerLine2 = "SETTINGS SAVED  ";
                uiMessageTimer = millis() + 1500UL;
                oldMenuState = -1;
            }
            autoSaveEngine.clearPendingSave();
            autoSavePendingStandstill = false;
        }
    }

    // Safety Auto-Abort: Return to Main Screen if machine starts running while in any menu
    if (pendingMenuExit) {
        pendingMenuExit = false;
        menuState = 0;
        oldMenuState = -1;
        loadFromEEPROM();
    }

    // Classic DDA Software Fallback Stepper Execution (Active only when hardwareTimerMode == false)
    if (!hardwareTimerMode && stepsRemaining > 0 && !isSensorFaultTripped) {
        unsigned long currentMicros = micros();
        // DDA is a service fallback only.  It follows the most recently measured
        // physical Proximity interval and does NOT invent an acceleration/deceleration ramp.
        unsigned long activeStepPeriod = (unsigned long)activePulseWidth;
        // In DDA mode, each toggle is half of the step period (50% duty cycle)
        unsigned long halfPeriod = activeStepPeriod / 2UL;
        if (halfPeriod < 3UL) halfPeriod = 3UL; // Minimum 3us half-period (6us step period)

        if (currentMicros - lastStepMicros >= halfPeriod) {
            if (stepPinState == HIGH) {
                STEP_LOW_ACTIVE();
                stepPinState = LOW;
            } else {
                STEP_HIGH_IDLE();
                stepPinState = HIGH;
                stepsRemaining--;
                currentStepIndex++;
                if (stepsRemaining % 100 == 0) {
                    IWDG_FEED();
                }
            }

            if (currentMicros - lastStepMicros > (halfPeriod * 3UL) / 2UL) {
                lastStepMicros = currentMicros;
            } else {
                lastStepMicros += halfPeriod;
            }
        }
        return;
    }

// Manual Save Confirmation Dialog (menuState 12) eliminated per Rajesh Shah directive
    // Auto-Relock Timeout after 30s of inactivity
    if (!isUiLocked && menuState == 0) {
        if (millis() - lastUnlockActivity > 30000UL) {
            isUiLocked = true;
            oldMenuState = -1;
        }
    }

    // Industrial Edge-Triggered Button States with Hold Auto-Repeat
static bool upPressedState = false;
static unsigned long upFirstPressTime = 0UL;
static unsigned long lastUpRepeatTime = 0UL;

static bool downPressedState = false;
static unsigned long downFirstPressTime = 0UL;
static unsigned long lastDownRepeatTime = 0UL;

    // Button Debouncing and Event Processing
    if (millis() - lastButtonCheck > 20UL) {
        lastButtonCheck = millis();
        if (digitalRead(btnUp) == LOW || digitalRead(btnDown) == LOW || digitalRead(btnMode) == LOW) {
            lastUnlockActivity = millis();
        }

        // Single Click MODE handling: Pulse Tuning Gear Change (0.10 -> 1.00 -> 10.0 -> 100 Pulses)
        if (pendingSingleClick && (millis() - lastModeClickTime > 350UL)) {
            pendingSingleClick = false;
            if (isUiLocked && menuState == 0) {
                uiBannerLine1 = "KEYPAD LOCKED!  ";
                uiBannerLine2 = "DBL-CLICK [MODE]";
                uiMessageTimer = millis() + 1000UL;
                oldMenuState = -1;
            } else if (!isUiLocked && menuState == 0) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (stepGearFixed == 100000ULL) {
                        stepGearFixed = 1000000ULL;
                        uiBannerLine1 = "GEAR: 1.00 PULSE";
                    } else if (stepGearFixed == 1000000ULL) {
                        stepGearFixed = 10000000ULL;
                        uiBannerLine1 = "GEAR: 10.0 PULSE";
                    } else if (stepGearFixed == 10000000ULL) {
                        stepGearFixed = 100000000ULL;
                        uiBannerLine1 = "GEAR: 100 PULSE ";
                    } else {
                        stepGearFixed = 100000ULL;
                        uiBannerLine1 = "GEAR: 0.10 PULSE";
                    }
                    uiBannerLine2 = "FINE TUNING OK  ";
                    uiMessageTimer = millis() + 800UL;
                    lastUnlockActivity = millis();
                    oldMenuState = -1;
                } else {
                    uiBannerLine1 = "MACHINE RUNNING!";
                    uiBannerLine2 = "GEAR CHG BLOCKED";
                    uiMessageTimer = millis() + 800UL;
                    oldMenuState = -1;
                }
            }
        }

        // Dual Button Press: Emergency Factory Reset (>10s)
        if (digitalRead(btnUp) == LOW && digitalRead(btnDown) == LOW) {
            if (!upDownPressed) dualPressTime = millis();
            upDownPressed = true;
            if (millis() - dualPressTime > 10000UL && menuState != 3) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    menuState = 3;
                    resetChoice = false;
                    oldMenuState = -1;
                } else {
                    uiBannerLine1 = "MACHINE RUNNING!";
                    uiBannerLine2 = "RESET BLOCKED!  ";
                    uiMessageTimer = millis() + 1000UL;
                    oldMenuState = -1;
                }
            }
        } else {
            upDownPressed = false;
        }

        // MODE Button State Machine
        if (digitalRead(btnMode) == LOW) {
            if (!modePressed) modePressTime = millis();
            modePressed = true;
        } else if (modePressed) {
            unsigned long holdTime = millis() - modePressTime;
            modePressed = false;

            if (menuState == 0) {
                if (holdTime < 350UL) {
                    if (pendingSingleClick && (millis() - lastModeClickTime < 350UL)) {
                        pendingSingleClick = false;
                        isUiLocked = !isUiLocked;
                        lastUnlockActivity = millis();
                        uiBannerLine1 = isUiLocked ? "KEYPAD LOCKED!  " : "KEYPAD UNLOCKED ";
                        uiBannerLine2 = isUiLocked ? "*[L] ACTIVE     " : "*[U] ACTIVE     ";
                        uiMessageTimer = millis() + 800UL;
                        oldMenuState = -1;
                        lastModeClickTime = 0UL;
                    } else {
                        lastModeClickTime = millis();
                        if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                            pendingSingleClick = true;
                        } else {
                            pendingSingleClick = false;
                            if (!isUiLocked) {
                                uiBannerLine1 = "MACHINE RUNNING!";
                                uiBannerLine2 = "GEAR CHG BLOCKED";
                                uiMessageTimer = millis() + 800UL;
                                oldMenuState = -1;
                            }
                        }
                    }
                } else if (holdTime >= 1500UL && holdTime < 3000UL && !isUiLocked) {
                    // 1.5-3 Second Hold: Zipper Size Sequence Switch (#5 -> #8 -> #10 -> #5)
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        currentSize++;
                        if (currentSize > 3) currentSize = 1;
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentSize == 1) currentPulsesFixed = p5_fixed;
                        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                        else currentPulsesFixed = p10_fixed;
                        __set_PRIMASK(primask);
                        updateActivePulseWidth();
                        saveToEEPROM(); // Standstill size commit
                        lastUnlockActivity = millis();
                        if (currentSize == 1) {
                            uiBannerLine1 = "ACTIVE: SIZE #5 ";
                            uiBannerLine2 = "PITCH: 2.50 mm  ";
                        } else if (currentSize == 2) {
                            uiBannerLine1 = "ACTIVE: SIZE #8 ";
                            uiBannerLine2 = "PITCH: 3.00 mm  ";
                        } else {
                            uiBannerLine1 = "ACTIVE: SIZE #10";
                            uiBannerLine2 = "PITCH: 4.00 mm  ";
                        }
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "SIZE CHG BLOCKED";
                        uiMessageTimer = millis() + 800UL;
                        oldMenuState = -1;
                    }
                } else if (holdTime >= 4000UL && holdTime < 8000UL && !isUiLocked) {
                    // Manual Save removed per Rajesh Shah directive!
                    // Display Auto-Save status banner to inform operator.
                    uiBannerLine1 = "AUTO-SAVE ACTIVE";
                    uiBannerLine2 = "[1-MIN RUN-QUAL]";
                    uiMessageTimer = millis() + 1500UL;
                    oldMenuState = -1;
                } else if (holdTime >= 8000UL && !isUiLocked) {
                    if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        tempDriverRes       = driverResolution;
                        tempRollerDia       = rollerDia;
                        tempMaxRPM          = maxRPMSetting;
                        tempFeedAngle       = feedAngleDeg;
                        tempSafetyMargin    = safetyMarginPercent;
                        tempSensorGuard     = sensorGuardActive;
                        tempHwTimerMode     = hardwareTimerMode;
                        tempMotorDir        = motorDirection;
                        hasStagedChanges    = false;
                        menuState = 1;
                        hiddenOption = 1;
                        oldMenuState = -1;
                    } else {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "MENU LOCKED [L] ";
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    }
                }
            } else if (menuState == 1) {
                // Hidden Menu Navigation
                if (hiddenOption == 1)      menuState = 2;  // Driver Res
                else if (hiddenOption == 2) menuState = 4;  // Roller Dia
                else if (hiddenOption == 3) menuState = 5;  // Max RPM
                else if (hiddenOption == 4) menuState = 6;  // Feed Angle
                else if (hiddenOption == 5) menuState = 8;  // Safety Margin
                else if (hiddenOption == 6) menuState = 10; // Tape Guard (ON/OFF)
                else if (hiddenOption == 7) menuState = 11; // Hardware Engine Mode (HW-TIMER vs DDA-LOOP)
                else if (hiddenOption == 8) menuState = 13; // Motor Direction (NORMAL vs REVERSE)
                else if (hiddenOption == 9) {
                    evaluateDiagnostics();
                    infoIndex = 1;
                    menuState = 9;  // Info / Diag Screen
                    oldMenuState = -1;
                } else if (hiddenOption == 10) {
                    // 10. Exit Menu: Apply staged settings to RAM and auto-persist if safely idle at 0 RPM
                    driverResolution    = tempDriverRes;
                    rollerDia           = tempRollerDia;
                    maxRPMSetting       = tempMaxRPM;
                    feedAngleDeg        = tempFeedAngle;
                    safetyMarginPercent = tempSafetyMargin;
                    sensorGuardActive   = tempSensorGuard;
                    hardwareTimerMode   = tempHwTimerMode;
                    motorDirection      = tempMotorDir;
                    applyMotorDirection();
                    recalculatePitchProfiles();
                    hasStagedChanges    = false;
                    menuState = 0;
                    oldMenuState = -1;
                    isUiLocked = true;
                    if (isMachineSafelyIdle() && currentRPM == 0UL) {
                        saveToEEPROM();
                        uiBannerLine1 = "SETTINGS SAVED  ";
                        uiBannerLine2 = "AUTO-SAVE OK    ";
                    } else {
                        autoSavePendingStandstill = true;
                        uiBannerLine1 = "SETTINGS STAGED ";
                        uiBannerLine2 = "AUTO-SAVE PEND  ";
                    }
                    uiMessageTimer = millis() + 1000UL;
                }
            } else if (menuState == 2 || menuState == 4 || menuState == 5 || menuState == 6 ||
                       menuState == 8 || menuState == 9 || menuState == 10 || menuState == 11 || menuState == 13) {
                menuState = 1;
                oldMenuState = -1;
            } else if (menuState == 3) {
                if (resetChoice) {
                    loadFactoryDefaults();
                    uiBannerLine1 = "FACTORY RESET OK";
                    uiBannerLine2 = "DEFAULTS LOADED ";
                    uiMessageTimer = millis() + 1000UL;
                }
                menuState = 0;
                oldMenuState = -1;
            }
        }

                // UP Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool upRaw = (digitalRead(btnUp) == LOW);
        bool triggerUpStep = false;
        if (upRaw && !upDownPressed) {
            if (!upPressedState) {
                upPressedState = true;
                upFirstPressTime = millis();
                lastUpRepeatTime = millis();
                triggerUpStep = true; // Immediate 1-step on press!
            } else if (millis() - upFirstPressTime >= 600UL) {
                if (millis() - lastUpRepeatTime >= 200UL) {
                    lastUpRepeatTime = millis();
                    triggerUpStep = true; // Auto-repeat!
                }
            }
        } else {
            upPressedState = false;
        }

        if (triggerUpStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        uiBannerLine1 = "KEYPAD LOCKED!  ";
                        uiBannerLine2 = "DBL-CLICK [MODE]";
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        currentPulsesFixed += stepGearFixed;
                        if (currentPulsesFixed > PULSE_STEP_MAX_FIXED) currentPulsesFixed = PULSE_STEP_MAX_FIXED;
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        uint64_t currentStored = (currentSize == 1) ? pulseStepStored_p5 : ((currentSize == 2) ? pulseStepStored_p8 : pulseStepStored_p10);
                        pulseModifiedByUser = (currentPulsesFixed != currentStored);
                        smoothRunStartMillis = 0UL;
                        autoSavePendingStandstill = false;

                        static char tuningL1[17];
                        static char tuningL2[17];
                        unsigned long pInt = (unsigned long)(currentPulsesFixed / 1000000ULL);
                        unsigned long pFrac = (unsigned long)((currentPulsesFixed % 1000000ULL) / 10000ULL);
                        snprintf(tuningL1, sizeof(tuningL1), "PULSE: %lu.%02lu    ", pInt, pFrac);
                        const char* gearStr = "+1.00";
                        if (stepGearFixed == 100000ULL) gearStr = "+0.10";
                        else if (stepGearFixed == 1000000ULL) gearStr = "+1.00";
                        else if (stepGearFixed == 10000000ULL) gearStr = "+10.0";
                        else if (stepGearFixed == 100000000ULL) gearStr = "+100 ";
                        snprintf(tuningL2, sizeof(tuningL2), "GEAR: %s [UP] ", gearStr);
                        uiBannerLine1 = tuningL1;
                        uiBannerLine2 = tuningL2;
                        uiMessageTimer = millis() + 1200UL;
                        oldMenuState = -1;
                    } else if (currentRPM > 0UL || stepsRemaining > 0 || hwBurstActive) {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "PULSE TUNE LOCK ";
                        uiMessageTimer = millis() + 800UL;
                        oldMenuState = -1;
                    }
                    break;
                case 1:
                    hiddenOption--;
                    if (hiddenOption < 1) hiddenOption = 10;
                    break;
                case 2:
                    tempDriverRes += resStepGear;
                    if (tempDriverRes > 51200) tempDriverRes = 51200;
                    hasStagedChanges = true;
                    break;
                case 3: resetChoice = true; break;
                case 4:
                    tempRollerDia += diaStepGear;
                    if (tempRollerDia > 100.0f) tempRollerDia = 100.0f;
                    hasStagedChanges = true;
                    break;
                case 5:
                    tempMaxRPM += rpmStepGear;
                    if (tempMaxRPM > 4000) tempMaxRPM = 4000;
                    hasStagedChanges = true;
                    break;
                case 6:
                    tempFeedAngle += angleStepGear;
                    if (tempFeedAngle > 270) tempFeedAngle = 270;
                    hasStagedChanges = true;
                    break;
                case 8:
                    tempSafetyMargin += marginStepGear;
                    if (tempSafetyMargin > 25) tempSafetyMargin = 25;
                    hasStagedChanges = true;
                    break;
                case 10:
                    tempSensorGuard = true; // Turn Tape Guard ACTIVE [ON]
                    hasStagedChanges = true;
                    break;
                case 11:
                    tempHwTimerMode = true; // Select AUTONOMOUS HW TIMER
                    hasStagedChanges = true;
                    break;
                case 13:
                    tempMotorDir = false; // Select NORMAL [FWD]
                    hasStagedChanges = true;
                    break;
                case 9:
                    infoIndex--;
                    if (infoIndex < 1) infoIndex = 12;
                    break;
// Obsolete manual Save Settings Confirmation Dialog (case 7) removed
            }
            upPressTime = millis();
        }

        // DOWN Button Event (Edge-Triggered 1-Step + 600ms Hold Auto-Repeat)
        bool downRaw = (digitalRead(btnDown) == LOW);
        bool triggerDownStep = false;
        if (downRaw && !upDownPressed) {
            if (!downPressedState) {
                downPressedState = true;
                downFirstPressTime = millis();
                lastDownRepeatTime = millis();
                triggerDownStep = true; // Immediate 1-step on press!
            } else if (millis() - downFirstPressTime >= 600UL) {
                if (millis() - lastDownRepeatTime >= 200UL) {
                    lastDownRepeatTime = millis();
                    triggerDownStep = true; // Auto-repeat!
                }
            }
        } else {
            downPressedState = false;
        }

        if (triggerDownStep) {
            lastUnlockActivity = millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        uiBannerLine1 = "KEYPAD LOCKED!  ";
                        uiBannerLine2 = "DBL-CLICK [MODE]";
                        uiMessageTimer = millis() + 1000UL;
                        oldMenuState = -1;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentPulsesFixed > stepGearFixed + PULSE_STEP_MIN_FIXED) {
                            currentPulsesFixed -= stepGearFixed;
                        } else {
                            currentPulsesFixed = PULSE_STEP_MIN_FIXED; // Minimum 1.00 pulse clamp
                        }
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        uint64_t currentStored = (currentSize == 1) ? pulseStepStored_p5 : ((currentSize == 2) ? pulseStepStored_p8 : pulseStepStored_p10);
                        pulseModifiedByUser = (currentPulsesFixed != currentStored);
                        smoothRunStartMillis = 0UL;
                        autoSavePendingStandstill = false;

                        static char tuningL1[17];
                        static char tuningL2[17];
                        unsigned long pInt = (unsigned long)(currentPulsesFixed / 1000000ULL);
                        unsigned long pFrac = (unsigned long)((currentPulsesFixed % 1000000ULL) / 10000ULL);
                        snprintf(tuningL1, sizeof(tuningL1), "PULSE: %lu.%02lu    ", pInt, pFrac);
                        const char* gearStr = "-1.00";
                        if (stepGearFixed == 100000ULL) gearStr = "-0.10";
                        else if (stepGearFixed == 1000000ULL) gearStr = "-1.00";
                        else if (stepGearFixed == 10000000ULL) gearStr = "-10.0";
                        else if (stepGearFixed == 100000000ULL) gearStr = "-100 ";
                        snprintf(tuningL2, sizeof(tuningL2), "GEAR: %s [DN] ", gearStr);
                        uiBannerLine1 = tuningL1;
                        uiBannerLine2 = tuningL2;
                        uiMessageTimer = millis() + 1200UL;
                        oldMenuState = -1;
                    } else if (currentRPM > 0UL || stepsRemaining > 0 || hwBurstActive) {
                        uiBannerLine1 = "MACHINE RUNNING!";
                        uiBannerLine2 = "PULSE TUNE LOCK ";
                        uiMessageTimer = millis() + 800UL;
                        oldMenuState = -1;
                    }
                    break;
// case 12 manual confirmation removed
                case 1:
                    hiddenOption++;
                    if (hiddenOption > 10) hiddenOption = 1;
                    break;
                case 2:
                    if (tempDriverRes > resStepGear + 200) tempDriverRes -= resStepGear;
                    else tempDriverRes = 200;
                    hasStagedChanges = true;
                    break;
                case 3: resetChoice = false; break;
                case 4:
                    if (tempRollerDia > diaStepGear + 15.0f) tempRollerDia -= diaStepGear;
                    else tempRollerDia = 15.0f;
                    hasStagedChanges = true;
                    break;
                case 5:
                    if (tempMaxRPM > rpmStepGear + 100) tempMaxRPM -= rpmStepGear;
                    else tempMaxRPM = 100;
                    hasStagedChanges = true;
                    break;
                case 6:
                    if (tempFeedAngle > angleStepGear + 30) tempFeedAngle -= angleStepGear;
                    else tempFeedAngle = 30;
                    hasStagedChanges = true;
                    break;
                case 8:
                    if (tempSafetyMargin >= marginStepGear) tempSafetyMargin -= marginStepGear;
                    hasStagedChanges = true;
                    break;
                case 10:
                    tempSensorGuard = false; // Turn Tape Guard BYPASS [OFF]
                    hasStagedChanges = true;
                    break;
                case 11:
                    tempHwTimerMode = false; // Select CLASSIC DDA ENGINE
                    hasStagedChanges = true;
                    break;
                case 13:
                    tempMotorDir = true; // Select REVERSE [REV]
                    hasStagedChanges = true;
                    break;
                case 9:
                    infoIndex++;
                    if (infoIndex > 12) infoIndex = 1;
                    break;
// Obsolete case 7 removed
            }
            downPressTime = millis();
        }

        if (digitalRead(btnUp) == HIGH && digitalRead(btnDown) == HIGH) {
            upDownPressed = false;
        }
    }

    // 16x2 Character LCD Screen Renderer (Anti-Blanking & Anti-Flicker Direct Overwrite)
    if (uiBannerLine1 != nullptr) {
        if (millis() < uiMessageTimer) {
            char b1[17], b2[17];
            snprintf(b1, sizeof(b1), "%-16s", uiBannerLine1);
            snprintf(b2, sizeof(b2), "%-16s", uiBannerLine2 ? uiBannerLine2 : "");
            lcd.setCursor(0, 0); lcd.print(b1);
            lcd.setCursor(0, 1); lcd.print(b2);
            oldMenuState = -2;
            return;
        } else {
            uiBannerLine1 = nullptr;
            uiBannerLine2 = nullptr;
            oldMenuState = -1;
            lcd.clear();
        }
    }

    // Running-State RPM Refresh (0.4ms I2C duration)
    if (menuState == 0 && currentRPM > 0UL && oldMenuState == menuState) {
        if (millis() - lastRpmDisplayUpdate > 250UL) {
            lastRpmDisplayUpdate = millis();
            char rpmBuf[16];
            unsigned int dispRpm = (currentRPM > 9999UL) ? 9999U : (unsigned int)currentRPM;
            snprintf(rpmBuf, sizeof(rpmBuf), "%04u", dispRpm);
            lcd.setCursor(5, 0);
            lcd.print(rpmBuf);
        }
        return;
    }

    // Stationary Screen Refresh (100ms cycle)
    if (millis() - lastDisplayUpdate > 100UL) {
        if (menuState != oldMenuState) {
            lcd.clear();
            oldMenuState = menuState;
        }

        char l1[17], l2[17];
        switch (menuState) {
            case 0: // Normal Operational Screen
            {
                int szNum = (currentSize == 1) ? 5 : ((currentSize == 2) ? 8 : 10);
                double actualPitch = ((double)currentPulsesFixed / 1000000.0) * (3.14159265358979323846 * (double)rollerDia) / (double)driverResolution;
                int actInt = constrain((int)actualPitch, 0, 99);
                int actFrac = constrain((int)((actualPitch - (float)actInt) * 100.0f + 0.5f), 0, 99);
                if (actFrac >= 100) { actInt++; actFrac -= 100; }
                char lenStr[6];
                snprintf(lenStr, sizeof(lenStr), "%d.%02d", actInt, actFrac);
                unsigned int dispRpm = constrain((unsigned int)currentRPM, 0U, 9999U);
                snprintf(l1, sizeof(l1), "S:%-2d %04u I:%s", szNum, dispRpm, lenStr);
                char cue = (activePulseWidth <= 2) ? '*' : ((activePulseWidth < 6) ? '#' : (hardwareTimerMode ? 'H' : 'u'));
                int pInt = (int)(currentPulsesFixed / 1000000ULL);
                int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                snprintf(l2, sizeof(l2), "P:%3d.%01d W:%d%c%s",
                         pInt, pFrac, activePulseWidth, cue, isUiLocked ? "[L]" : "[U]");
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
            }
            break;

            case 1: // Hidden Settings Staged Menu List
            {
                if (hiddenOption == 1)      snprintf(l1, sizeof(l1), "1. Driver Res   ");
                else if (hiddenOption == 2) snprintf(l1, sizeof(l1), "2. Roller Dia   ");
                else if (hiddenOption == 3) snprintf(l1, sizeof(l1), "3. Max RPM      ");
                else if (hiddenOption == 4) snprintf(l1, sizeof(l1), "4. Feed Angle   ");
                else if (hiddenOption == 5) snprintf(l1, sizeof(l1), "5. Safety Margin");
                else if (hiddenOption == 6) snprintf(l1, sizeof(l1), "6. Tape Guard   ");
                else if (hiddenOption == 7) snprintf(l1, sizeof(l1), "7. Engine Mode  ");
                else if (hiddenOption == 8) snprintf(l1, sizeof(l1), "8. Motor Dir    ");
                else if (hiddenOption == 9) snprintf(l1, sizeof(l1), "9. Info Diag    ");
                else if (hiddenOption == 10)snprintf(l1, sizeof(l1), "10. Exit Menu   ");

                if (hiddenOption == 1)      snprintf(l2, sizeof(l2), "Val: %-5d steps", (int)tempDriverRes);
                else if (hiddenOption == 2) {
                    int dInt = (int)tempRollerDia;
                    int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
                    snprintf(l2, sizeof(l2), "Val: %2d.%1d mm  ", dInt, dFrac);
                }
                else if (hiddenOption == 3) snprintf(l2, sizeof(l2), "Val: %-4d RPM  ", (int)tempMaxRPM);
                else if (hiddenOption == 4) snprintf(l2, sizeof(l2), "Val: %-3d deg   ", (int)tempFeedAngle);
                else if (hiddenOption == 5) snprintf(l2, sizeof(l2), "Val: %-2d%%     ", (int)tempSafetyMargin);
                else if (hiddenOption == 6) snprintf(l2, sizeof(l2), tempSensorGuard ? "State: ACTIVE[ON]" : "State: BYPASS[OF]");
                else if (hiddenOption == 7) snprintf(l2, sizeof(l2), tempHwTimerMode ? "Mode: HW-TIMER  " : "Mode: DDA-LOOP  ");
                else if (hiddenOption == 8) snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: REVERSE[RV]" : "Dir: NORMAL [FW]");
                else if (hiddenOption == 9) snprintf(l2, sizeof(l2), "View System Diag");
                else if (hiddenOption == 10)snprintf(l2, sizeof(l2), "Apply & Standby ");

                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
            }
            break;

            case 2: // Edit Driver Resolution
                snprintf(l1, sizeof(l1), "Res: %-5d stp", (int)tempDriverRes);
                snprintf(l2, sizeof(l2), "Step: %-3d [MD]", (int)resStepGear);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 3: // Emergency Factory Reset
                lcd.setCursor(0, 0); lcd.print("Factory Reset?  ");
                lcd.setCursor(0, 1); lcd.print(resetChoice ? ">YES  NO         " : " YES >NO         ");
                break;

            case 4: // Edit Roller Diameter
            {
                int dInt = (int)tempRollerDia;
                int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
                snprintf(l1, sizeof(l1), "Dia: %2d.%1d mm  ", dInt, dFrac);
                int gInt = (int)diaStepGear;
                int gFrac = (int)((diaStepGear - (float)gInt) * 10.0f + 0.5f);
                snprintf(l2, sizeof(l2), "Step: %d.%1d [MD]", gInt, gFrac);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
            }
            break;

            case 5: // Edit Max RPM
                snprintf(l1, sizeof(l1), "Max RPM: %-4d   ", (int)tempMaxRPM);
                snprintf(l2, sizeof(l2), "Step: %-3d [MD]", (int)rpmStepGear);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 6: // Edit Feed Angle
                snprintf(l1, sizeof(l1), "Angle: %-3d deg ", (int)tempFeedAngle);
                snprintf(l2, sizeof(l2), "Step: %-2d  [MD]", (int)angleStepGear);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 8: // Edit Safety Margin
                snprintf(l1, sizeof(l1), "Safety Margin:  ");
                snprintf(l2, sizeof(l2), "Margin: %-2d%% [MD]", (int)tempSafetyMargin);
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 10: // Edit Tape Guard (ACTIVE vs BYPASS)
                snprintf(l1, sizeof(l1), "Tape Guard:     ");
                snprintf(l2, sizeof(l2), tempSensorGuard ? "State: >ON  [UP]" : "State: >OFF [DN]");
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 11: // Edit Hardware Engine Mode (HW-TIMER vs DDA-LOOP)
                snprintf(l1, sizeof(l1), "Engine Mode:    ");
                snprintf(l2, sizeof(l2), tempHwTimerMode ? "Mode: >HW-TIMER " : "Mode: >DDA-LOOP ");
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 13: // Edit Motor Direction (NORMAL vs REVERSE)
                snprintf(l1, sizeof(l1), "Motor Direction:");
                snprintf(l2, sizeof(l2), tempMotorDir ? "Dir: >REV  [DN]" : "Dir: >FWD  [UP]");
                lcd.setCursor(0, 0); lcd.print(l1);
                lcd.setCursor(0, 1); lcd.print(l2);
                break;

            case 9: // Info / Diag: System Info & Field Troubleshooter
            {
                int cycle = (millis() / 1500UL) % 2;
                lcd.setCursor(0, 0);
                switch (infoIndex) {
                    case 1:
                        lcd.print("VER: " FW_VERSION_STR);
                        lcd.setCursor(0, 1);
                        lcd.print("BUILD: " FW_BUILD_DATE_STR);
                        break;
                    case 2:
                        lcd.print("DEV: RAJESH SHAH");
                        lcd.setCursor(0, 1);
                        lcd.print("NIPON ZIPPER IND");
                        break;
                    case 3:
                        lcd.print("1. MOTOR STALL? ");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: INC ANGLE  " : "OR DEC RES/RPM  ");
                        break;
                    case 4:
                        lcd.print("2. PITCH ERROR? ");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: TUNE DIA MM" : "OR GEAR +/- PUL ");
                        break;
                    case 5:
                        lcd.print("3. SENSOR NOISE?");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: CLEAN CAM  " : "CHECK PC817 GND ");
                        break;
                    case 6:
                        lcd.print("4. MOTOR HOT?   ");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: SW4=HALF   " : "CURR 2.8A-3.0A  ");
                        break;
                    case 7:
                        lcd.print("5. TEETH DRIFT? ");
                        lcd.setCursor(0, 1);
                        lcd.print(cycle == 0 ? "FIX: TIGHT TAPE " : "CHK ROLLER GRIP ");
                        break;
                    case 8:
                        lcd.print("6. OPTO SINK TST");
                        lcd.setCursor(0, 1);
                        lcd.print(digitalRead(btnUp) == LOW ? "V<=0.5V SINK ON " : "HOLD [UP] TEST  ");
                        break;
                    case 9:
                        lcd.print("PROX HEALTH     ");
                        lcd.setCursor(0, 1);
                        if (lastMeasuredIntervalUs > 0UL) {
                            char b[17];
                            snprintf(b, sizeof(b), "P:%4lu RPM:%4lu", lastMeasuredIntervalUs, currentRPM);
                            lcd.print(b);
                        } else {
                            lcd.print("P:WAIT  RPM: 0  ");
                        }
                        break;
                    case 10:
                        lcd.print("SYNC HEALTH     ");
                        lcd.setCursor(0, 1);
                        if (isMotionSyncLost) lcd.print("FAULT:SYNC LOST ");
                        else if (servoPhaseLocked) {
                            char b[17];
                            snprintf(b, sizeof(b), "LOCK J:%4luus", servoMaxJitterUs);
                            lcd.print(b);
                        } else lcd.print("ACQUIRING...    ");
                        break;
                    case 11:
                        lcd.print("CAPTURE HEALTH  ");
                        lcd.setCursor(0, 1);
                        {
                            char b[17];
                            snprintf(b, sizeof(b), "OF:%lu RS:%lu", captureOverrunCount, captureResyncCount);
                            lcd.print(b);
                        }
                        break;
                    case 12:
                        lcd.print("STEP / GUARD    ");
                        lcd.setCursor(0, 1);
                        {
                            char b[17];
                            if (!tempSensorGuard) snprintf(b, sizeof(b), "STEP:%s G:OFF", hwBurstActive ? "RUN" : "IDLE");
                            else if (digitalRead(tapeSensorPin) == HIGH) snprintf(b, sizeof(b), "STEP:%s TAPE-END", hwBurstActive ? "RUN" : "IDLE");
                            else snprintf(b, sizeof(b), "STEP:%s TAPE:OK", hwBurstActive ? "RUN" : "IDLE");
                            lcd.print(b);
                        }
                        break;
                    default:
                        infoIndex = 1;
                        break;
                }
            }
            break;

// case 12 manual confirmation screen removed

// Obsolete case 7 display dialog removed
        }
        lastDisplayUpdate = millis();
    }
}
