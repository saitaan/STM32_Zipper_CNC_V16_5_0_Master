# STM32 Zipper CNC V16.5.0 Master Production Edition

**Organization:** Nipon Zipper Industries Pvt Ltd, Sarigam GIDC, Gujarat, India  
**Target MCU:** STM32F103C8T6 (32-bit ARM Cortex-M3 @ 72MHz)  
**Lead Engineer:** Rajesh Shah (Industrial Automation & Embedded Systems)  

## Key Architectural Breakthroughs:
1. **Autonomous Hardware Timer 2 Engine (PA1 / TIM2_CH2):** Stepping pulses generated in silicon timer interrupts. 0% CPU loop load, 0ns jitter up to 3000 RPM.
2. **Dual Optical Safety Guard Subsystem (PA3 / PB0 / PB1):** Sub-millisecond E-Stop on tape run-out or spiral coil jam. Strict factory default: `BYPASS [OFF]` for 100% backwards compatibility with V16.3 wiring.
3. **Multi-Tier EEPROM Migration Engine:** Automatically migrates calibration data from legacy V16.3.3 and V16.4.0 without resetting roller diameter or driver resolution.
4. **Fast 400kHz I2C LCD Engine:** Decoupled UI rendering with running-state RPM-only quick updates to prevent pulse delays.

## Automated Compilation via GitHub Actions:
This repository includes `.github/workflows/compile.yml`. Pushing to this repository automatically compiles `STM32_Zipper_CNC_V16_5_0_Production.bin` via Arduino CLI and uploads the ready-to-flash binary as an artifact.
