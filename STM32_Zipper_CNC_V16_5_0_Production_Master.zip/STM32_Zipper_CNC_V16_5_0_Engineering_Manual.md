# STM32 ZIPPER CNC V16.5.0 ULTRA-HARDWARE MASTER EDITION
## Autonomous Hardware Timer 2 Engine • 0% CPU Stepping Load • Dual Optical Safety Guard
**Organization:** Nipon Zipper Industries Pvt Ltd, Sarigam GIDC, Gujarat, India  
**Lead Engineer / Author:** Rajesh Shah (Industrial Automation & Embedded Systems)  
**Target Microcontroller:** STM32F103C8T6 (32-bit ARM Cortex-M3 @ 72MHz)  
**Date:** September 2026  

---

### 1. Executive Summary & V16.5.0 Breakthroughs
Version 16.5.0 represents a revolutionary generational upgrade from software loop-based stepping to **Autonomous Hardware Silicon Execution**:
1. **Hardware Timer 2 Autonomous Burst Engine (`TIM2` on `PA1`):**
   - Configures STM32 Hardware Timer 2 on Pin `PA1` (`TIM2_CH2`).
   - Sinks pulses directly via silicon hardware clock without `loop()` polling or software delay counters.
   - Stepping CPU load drops from 50% to **0%**, completely eliminating CPU starvation during high-speed feed bursts.
2. **Dual-Mode Engine Selector (Option 7 in Hidden Menu):**
   - **Mode 0: HW-TIMER [AUTO]:** Hardware autonomous peripheral execution (0ns jitter).
   - **Mode 1: DDA-LOOP [DDA]:** Classic 1,000,000x micro-fractional DDA fallback engine.
3. **Dual Optical Safety Guard Subsystem:**
   - `PA3`: Tape Run-Out & Breakage Optical Sensor (PC817 Ch 1).
   - `PB0`: Coil Jam & Breakage Fiber-Optic Sensor (PC817 Ch 2).
   - `PB1`: Main Motor E-Stop Relay (NC Clutch-Brake Loop).
   - **STRICT DEFAULT: BYPASS [OFF]** (Must be enabled explicitly via Option 6).
   - Optical trip immediately disables `TIM2` in hardware and trips `PB1` relay in sub-millisecond time.
4. **Three-Tier EEPROM Migration Engine:**
   - Seamlessly imports calibration data from V16.3.3 (`0x5A431633`) and V16.4.0 (`0x5A431640`) into V16.5.0 (`0x5A431650`) without resetting roller diameter or driver resolution.

---

### 2. Hardware Pinout & Industrial Netlist (100% Backwards-Compatible)

| Peripheral | STM32 Pin | Signal Type | Hardware Peripheral Mapping |
| :--- | :--- | :--- | :--- |
| **Cam Proximity Sensor** | `PA0` | Input (Active-LOW) | PC817 Optocoupler -> Clean MCU GND (EXTI0 / FALLING ISR) |
| **Stepper Step Pulse (PUL-)**| `PA1` | Output (Active-LOW) | **Hardware TIM2_CH2** / BSS138 CH3 Level Shifter |
| **Stepper Direction (DIR-)** | `PA2` | Output (Active-LOW) | GPIOA Direct BSRR / BSS138 CH4 Level Shifter |
| **Tape Run-Out Optical Sensor**| `PA3` | Input (Active-LOW) | PC817 Ch 1 Optocoupler (Pull-up to 3.3V) |
| **Coil Breakage Fiber Sensor** | `PB0` | Input (Active-LOW) | PC817 Ch 2 Optocoupler (Pull-up to 3.3V) |
| **Main Motor Stop Relay** | `PB1` | Output (Active-HIGH Trip)| 5V Opto-Isolated Relay Module (NC Clutch Loop) |
| **UP Push Button** | `PB12` | Input (Active-LOW) | Internal Pull-Up to Clean MCU GND |
| **DOWN Push Button** | `PB13` | Input (Active-LOW) | Internal Pull-Up to Clean MCU GND |
| **MODE Push Button** | `PB14` | Input (Active-LOW) | Internal Pull-Up to Clean MCU GND |
| **16x2 Character LCD** | `PB6` / `PB7` | I2C (400kHz) | Level-Shifted 5V Fast I2C Bus |

---

### 3. Hidden Menu Navigation & Options (V16.5.0)
1. `1. Driver Res`: Microstepping resolution (Default: 6400 steps).
2. `2. Roller Dia`: Roller diameter in mm (Default: 45.0 mm).
3. `3. Max RPM`: Maximum machine speed (Default: 3000 RPM).
4. `4. Feed Angle`: Mechanical feed window sector (Default: 160°).
5. `5. Safety Margin`: Timing calculation buffer (Default: 10%).
6. `6. Sensor Guard`: **`State: BYPASS [OFF]`** (Default) / **`ACTIVE [ON]`**.
7. `7. Engine Mode`: **`Mode: HW-TIMER`** (Default) / **`Mode: DDA-LOOP`**.
8. `8. Info Diag`: 5-Point Interactive Field Troubleshooter.
9. `9. Save & Sync`: Commits all staged RAM tweaks atomically to EEPROM (`0x5A431650`).
10. `10. Cancel/Exit`: Discards uncommitted staged changes.
