#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cassert>
#include <vector>

std::string findAndRead(const std::string &subPath) {
    std::vector<std::string> prefixes = {
        "../",
        "../../source/",
        "../../",
        "../include/",
        "../../source/include/",
        "../src/",
        "../../source/src/",
        "../STM32_Zipper_CNC_V16_5_1_Firmware/",
        "../../source/STM32_Zipper_CNC_V16_5_1_Firmware/",
        "../STM32_Zipper_CNC_V16_5_0_Firmware/",
        "../../source/STM32_Zipper_CNC_V16_5_0_Firmware/"
    };

    for (const auto &pre : prefixes) {
        std::string fullPath = pre + subPath;
        std::ifstream file(fullPath, std::ios::binary);
        if (file.is_open()) {
            std::stringstream ss;
            ss << file.rdbuf();
            return ss.str();
        }
    }

    std::cerr << "FATAL: Could not locate required source file for: " << subPath << std::endl;
    assert(false);
    return "";
}

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << "TEST: Authoritative Firmware Source Consistency Check" << std::endl;
    std::cout << "==========================================================" << std::endl;

    std::string ino1 = findAndRead("STM32_Zipper_CNC_V16_5_1_Firmware/STM32_Zipper_CNC_V16_5_1_Firmware.ino");
    std::string ino2 = findAndRead("STM32_Zipper_CNC_V16_5_0_Firmware/STM32_Zipper_CNC_V16_5_0_Firmware.ino");

    assert(ino1.size() > 10000);
    assert(ino1 == ino2);
    std::cout << "[PASS] 1. Authoritative Firmware Source (.ino) is 100% byte-for-byte synchronized across V16_5_1 and V16_5_0 (" 
              << ino1.size() << " bytes)." << std::endl;

    std::vector<std::string> headers = {
        "burst_queue.h",
        "hardware_capture_spec.h",
        "motion_scheduler.h",
        "pulsestep_persistence.h",
        "safety_sensors.h"
    };

    for (const auto &h : headers) {
        std::string p_inc = findAndRead("include/" + h);
        std::string p_src = findAndRead("src/" + h);
        std::string p_fmw1 = findAndRead("STM32_Zipper_CNC_V16_5_1_Firmware/" + h);
        std::string p_fmw0 = findAndRead("STM32_Zipper_CNC_V16_5_0_Firmware/" + h);

        assert(p_inc.size() > 0);
        assert(p_inc == p_src);
        assert(p_inc == p_fmw1);
        assert(p_inc == p_fmw0);
        std::cout << "[PASS] 2. Header synchronized across all directories: " << h << " (" << p_inc.size() << " bytes)." << std::endl;
    }

    std::cout << "==========================================================" << std::endl;
    std::cout << "ALL SOURCE CONSISTENCY CHECKS PASSED (100% IDENTICAL)!" << std::endl;
    std::cout << "==========================================================" << std::endl;

    return 0;
}
