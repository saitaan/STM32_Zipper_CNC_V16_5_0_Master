# STM32 Zipper CNC V16.5.1 Master Production Edition

**Organization:** Nipon Zipper Industries Pvt Ltd, Sarigam GIDC, Gujarat, India  
**Target MCU:** STM32F103C8T6 (32-bit ARM Cortex-M3 @ 72MHz)  
**Lead Engineer:** Rajesh Shah (Industrial Automation & Embedded Systems)  
**Release Version:** V16.5.1 Production Master (October 2026)  

---

## What's New in V16.5.1

1. **Button Pin Assignment Reversal (Zero Hardware Rewiring):**
   - Swapped `btnUp` to **PB13** and `btnDown` to **PB12** directly in firmware to match physical control panel wiring.
   - Dual-press features (Factory Reset `[UP] + [DOWN]` on boot, Keypad Lock toggle `[UP] + [DOWN]` during run) remain 100% operational.

2. **Reversible Motor Direction via Settings Menu:**
   - Added menu item: **`8. Motor Dir`**
   - Toggle between `NORMAL [FWD]` (PA2 DIR- driven HIGH) and `REVERSE [REV]` (PA2 DIR- driven LOW).
   - Saved persistently in EEPROM across power cycles. Zero phase wire swapping needed!

3. **Dedicated Live Tuning Display Template (Anti-Blanking & Anti-Flicker):**
   - Eliminates display blanking during pulse pitch tuning on stationary machine (`currentRPM == 0`).
   - Uses persistent global static buffers and direct cursor character overwrite without `lcd.clear()`.
   - Line 1: `PULSE: %lu.%02lu    ` (e.g. `PULSE: 113.18   `)
   - Line 2: `GEAR: %s [%s]  ` (e.g. `GEAR: +1.00 [UP] ` / `GEAR: -1.00 [DN] `)

4. **Strict Real-Time Isolation & Zero Pulse Loss Guarantee:**
   - **PA0 Cam Proximity Sensor (`EXTI0`):** Locked at NVIC Preemption Priority 1 (highest).
   - **PA1 Stepper Pulse Engine (`TIM2`):** Locked at NVIC Priority 3.
   - Display rendering is strictly throttled while machine is running (`currentRPM > 0`).

---

## Hardware Pinout Map

| Pin | Function | Target Hardware | Notes |
|:---:|:---:|:---|:---|
| **PB13** | **UP Button** | Tactile Switch to Star GND | **Swapped in V16.5.1** |
| **PB12** | **DOWN Button** | Tactile Switch to Star GND | **Swapped in V16.5.1** |
| **PB14** | **MODE Button** | Tactile Switch to Star GND | Short: Size toggle; Long: Menu |
| **PA0** | **Cam Proximity** | LJ12A3 via PC817 Opto | **NVIC Priority 1 (Preemptive)** |
| **PA1** | **Driver PUL-** | DM542/DM556 Stepper Driver | **Hardware Timer 2 (TIM2)** |
| **PA2** | **Driver DIR-** | DM542/DM556 Stepper Driver | **Reversible in Menu (NORMAL/REVERSE)** |
| **PA3** | **Tape Run-Out**| Optical Sensor (PC817 Ch 1) | Instant E-Stop (Default: BYPASS [OFF]) |
| **PB0** | **Coil Jam** | Fiber Sensor (PC817 Ch 2) | Instant E-Stop (Default: BYPASS [OFF]) |
| **PB1** | **Main Motor Relay**| 5V Opto Relay on Clutch | Glitch-free startup via atomic GPIOB->BRR |
| **PC13**| **Status LED** | Onboard Green LED (Active-LOW)| Live feed blinking; handwheel alignment |
| **PB6/PB7**| **I2C1 LCD** | 16x2 LCD PCF8574 Backpack | 400kHz with 25ms timeout noise immunity |

---

## Automated Compilation via GitHub Actions

This repository includes `.github/workflows/compile.yml`. Pushing to this repository automatically compiles `STM32_Zipper_CNC_V16_5_1_Production.bin` via Arduino CLI and uploads the ready-to-flash binary artifact.
