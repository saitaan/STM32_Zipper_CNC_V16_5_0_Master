# STM32 Zipper CNC V16.5.1 Production Engineering Manual

Document Release: V16.5.1 Production Master (October 2026)
Manufacturer: Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC, Gujarat, India
Lead Engineer: Rajesh Shah (Automation & Embedded Systems)
System Core: JARVIS High-Precision CNC OS

---

## 1. Hardware Pinout Map & Inverted Wire Alignment

| Pin | Function | Target Hardware | Notes |
|:---:|:---:|:---|:---|
| **PB13** | **UP Button** | Tactile Switch to Star GND | **Swapped in V16.5.1** to match physical panel wiring |
| **PB12** | **DOWN Button** | Tactile Switch to Star GND | **Swapped in V16.5.1** to match physical panel wiring |
| **PB14** | **MODE Button** | Tactile Switch to Star GND | Single-click: Size toggle; Long-press: Settings |
| **PA0** | **Cam Proximity** | LJ12A3 via PC817 Opto | **NVIC Priority 1 (Preemptive)**: 0% pulse loss |
| **PA1** | **Driver PUL-** | DM542/DM556 Stepper Driver | **Hardware Timer 2 (TIM2)**: 0ns software jitter |
| **PA2** | **Driver DIR-** | DM542/DM556 Stepper Driver | **Reversible in Menu**: NORMAL [FWD] / REVERSE [REV] |
| **PA3** | **Tape Run-Out**| Optical Sensor (PC817 Ch 1) | Instant E-Stop trip (Default: BYPASS [OFF]) |
| **PB0** | **Coil Jam** | Fiber Sensor (PC817 Ch 2) | Instant E-Stop trip (Default: BYPASS [OFF]) |
| **PB1** | **Main Motor Relay**| 5V Opto Relay on Clutch | Glitch-free startup via atomic GPIOB->BRR |
| **PC13**| **Status LED** | Onboard Green LED (Active-LOW)| Live feed blinking; handwheel alignment |
| **PB6/PB7**| **I2C1 LCD** | 16x2 LCD PCF8574 Backpack | 400kHz with 25ms timeout noise immunity |

---

## 2. New Features in V16.5.1

### A. Reversible Motor Direction in Settings Menu
- **Option 8 in Settings:** `8. Motor Dir`
  - Toggle between `NORMAL [FWD]` and `REVERSE [REV]`.
  - In `NORMAL`: PA2 (DIR-) is driven HIGH (DM542 opto OFF).
  - In `REVERSE`: PA2 (DIR-) is driven LOW (DM542 opto ON).
  - Persisted in EEPROM across power cycles. Zero physical rewiring needed!

### B. Dedicated Live Tuning Display Template (Anti-Blanking)
- When adjusting pulses on a stationary machine (`currentRPM == 0`):
  - Line 1: `PULSE: %lu.%02lu    ` (e.g. `PULSE: 113.18   `)
  - Line 2: `GEAR: %s [%s]  ` (e.g. `GEAR: +1.00 [UP] ` / `GEAR: -1.00 [DN] `)
  - Uses direct cursor overwrite without `lcd.clear()`, totally eliminating screen blanking and flicker.

### C. Zero-Interference Real-Time Supremacy
- The Cam sensor interrupt (`EXTI0` Priority 1) and Timer 2 (`TIM2` Priority 3) strictly preempt the background LCD display task.
- Display writes are strictly throttled during machine operation, guaranteeing 0% jitter and zero dropped pulses.
