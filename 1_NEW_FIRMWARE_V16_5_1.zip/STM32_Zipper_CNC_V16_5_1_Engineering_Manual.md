# STM32 Zipper CNC V16.5.1 Master Engineering Manual
## Production Release Baseline: V16.5.1 Audited Zero-Miss & Zero-Truncation Master
**Author / Authority:** Rajesh Shah (Lead Automation & Embedded Systems Engineer)  
**Organization:** Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC, Gujarat, India  
**Target Silicon:** STM32F103C8T6 (32-bit ARM Cortex-M3 @ 72 MHz)

---

### 1. Hardware Pin Assignment & Electrical Specifications
* **PA0:** Cam Proximity Sensor Input (Falling Edge EXTI0, PC817 Galvanic Optocoupler). Active-LOW, internal pull-up + external 3.3kΩ pull-up to clean 3.3V MCU GND.
* **PA1:** Stepper Step Pulse Output (TIM2_CH2). Silicon Hardware PWM Mode 1 with Output Compare Preload (OC2PE). Active-LOW sinking for Leadshine DM542 PUL-.
* **PA2:** Stepper Direction Output (DIR- via BSS138 Level Shifter CH4). Normal: HIGH (Forward), Reverse: LOW (Reverse).
* **PA3:** Tape Runout Optical Sensor (PC817 Ch 1). Active-LOW.
* **PB0:** Coil Jam / Fiber Breakage Sensor (PC817 Ch 2). Active-LOW.
* **PB1:** Main Motor Stop Relay Trigger (Active-HIGH Trip -> opens NC Clutch-Brake loop in <5ms).
* **PB6 / PB7:** I2C1 (SCL / SDA @ 400 kHz) for 16x2 Character LCD.
* **PB12:** DOWN Push Button (Swapped to match physical panel wiring).
* **PB13:** UP Push Button (Swapped to match physical panel wiring).
* **PB14:** MODE Multi-Function Button (Active-LOW to Clean MCU GND).
* **PC13:** Onboard Telemetry LED (Active-LOW: blinks on trigger/step, steady on idle).

---

### 2. Zero-Miss Speed-Adaptive Cam Trigger Blanking Engine
* **Authoritative Edge Event:** EXTI0 Falling Edge is treated as the sole, authoritative physical event in silicon hardware. GPIO IDR re-check is strictly eliminated to prevent race conditions caused by interrupt latency or narrow optocoupler pulses.
* **Standstill Detection:** If time since last trigger exceeds 2.0s (`diff > 2000000UL`) or on startup (`lastTriggerMicros == 0`), the machine is identified as stationary. Standstill resets `lastMeasuredIntervalUs = 0` and allows the first trigger to pass immediately with 0µs blanking penalty.
* **Adaptive Revolution Tracking:** For running operations, dynamic blanking tracks the raw measured period of the preceding revolution (`lastMeasuredIntervalUs / 3UL`):
  * **Noise Floor (2,000 µs = 2.0 ms):** Completely filters out PC817 optocoupler storage/fall times, mechanical contact bounce, and inductive relay spikes. Equivalent to 30,000 RPM (10x higher than 3,000 RPM maximum machine speed).
  * **Acceleration Safety Ceiling (5,000 µs = 5.0 ms):** Equivalent to 12,000 RPM. Guarantees that valid triggers are never rejected even during extreme clutch engagement where the machine jumps from low idle to 3,600+ RPM in a single revolution (16.6 ms period).

---

### 3. Silicon Hardware PWM & Zero-Truncation Step Generator
* **Hardware Timer Architecture:** PA1 is driven directly by STM32 Timer 2 Channel 2 hardware compare logic with 0.00ns software jitter and 0% CPU stepping overhead.
* **Step Pulse Waveform:**
  * Active LOW phase: exactly 5.0 µs (exceeds Leadshine DM542 2.5 µs minimum optocoupler saturation requirement).
  * Inactive HIGH recovery phase: `ARR - 5.0 µs` (minimum 15 µs at 50 kHz, ensuring complete optocoupler recovery).
* **Audited Final-Step Zero-Truncation State Machine:**
  * When `hwBurstStepsDone + 1 >= hwBurstStepsTarget` (final step starting):
    1. Preload register `TIM2->CCR2` is set to 0. (Because OC2PE is active, active shadow register remains 5 during the current final pulse).
    2. One-Pulse Mode (`TIM_CR1_OPM`) is armed in CR1.
  * At final step Update Event (overflow from ARR to 0):
    1. Preload value 0 is transferred to shadow CCR2.
    2. OPM hardware clears CEN bit, halting counter at `CNT = 0`.
    3. Comparator evaluates `CNT (0) < CCR2 (0)` -> FALSE.
    4. PA1 remains 100% continuously HIGH! Zero runt pulses, zero truncated spikes, zero pin freezing!
* **Seamless Burst Extension:** If a new cam trigger arrives while a burst is running, `hwBurstStepsTarget` accumulates atomically under interrupt-disabled critical section (`__disable_irq`), OPM is disarmed, and CCR2 preload is restored to valid pulse width.

---

### 4. Mathematical Pitch DDA Verification
* **64-bit Fixed Scale Factor:** `FIXED_SCALE = 1,000,000L` (6 decimal places).
* **Calibration Parameters (6400 steps/rev, 45.0 mm roller):**
  * Size #5 (2.50 mm pitch): `113176848L` (113.176848 pulses).
  * Size #8 (3.00 mm pitch): `135812218L` (135.812218 pulses).
  * Size #10 (4.00 mm pitch): `181082957L` (181.082957 pulses).
* **Cumulative Drift:** Guaranteed $< 0.022\text{ mm}$ position drift across continuous production.
